"""Fixed fresh-process confirmation of PARI conversion memory use."""
import argparse
import hashlib
import json
from pathlib import Path
import resource
import statistics
import subprocess
import sys
from sage.all import pari
import benchmark as bench
import bindings as b

HERE=b.HERE
intent=json.loads((HERE/'memory-intent-v1.json').read_text())


def stack():
    values={}
    for name in ['stacksize','getstack']:
        try:values[name]=int(getattr(pari,name)())
        except AttributeError:values[name]=None
    return values


def worker(index,arm,path):
    mode='cold' if index%2==0 else 'warm'
    case={'degree':163,'seed':intent['seed_base']+index,
          'operation':'pari_cold' if mode=='cold' else 'pari_small'}
    operation,expected,plans,E=bench.fixture(case)
    before=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    before_stack=stack()
    b.activate('pari',arm)
    for _ in range(intent['calls_per_worker']):
        actual=operation(arm);assert actual==expected;del actual
    row={'index':index,'mode':mode,'case':case,'arm':arm,'rss_before':before,
         'rss_after':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
         'stack_before':before_stack,'stack_after':stack(),'exact':True}
    path.write_text(json.dumps(row,indent=2)+'\n')


def parent():
    out=HERE/'memory-001';out.mkdir(exist_ok=False)
    paths=[HERE/'memory-intent-v1.json',Path(__file__),HERE/'benchmark.py',HERE/'bindings.py']
    paths+=list((HERE/'candidate').glob('*.py*'))+list((HERE/'candidate').glob('*.so'))
    hashes={str(p):bench.digest(p) for p in paths}
    (out/'execution.json').write_text(json.dumps({'hashes':hashes},indent=2)+'\n')
    rows=[]
    for i in range(intent['pairs']):
        order=['incumbent','candidate'] if i%2==0 else ['candidate','incumbent']
        for arm in order:
            path=out/f'pair-{i:02d}-{arm}.json'
            with path.with_suffix('.log').open('w') as log:
                subprocess.run([sys.executable,__file__,'--index',str(i),'--arm',arm,
                                '--output',str(path)],stdout=log,stderr=subprocess.STDOUT,
                               timeout=180,check=True)
            row=json.loads(path.read_text());rows.append(row)
            print(i,arm,row['rss_before'],row['rss_after'],row['stack_after'],flush=True)
    modes={}
    for mode in ['cold','warm']:
        medians={arm:statistics.median(r['rss_after'] for r in rows
                  if r['arm']==arm and r['mode']==mode) for arm in ['incumbent','candidate']}
        limit=max(1.05*medians['incumbent'],medians['incumbent']+2*1024**2)
        modes[mode]={'medians':medians,'limit':limit,'passed':medians['candidate']<=limit}
    assert all(bench.digest(p)==v for p,v in hashes.items())
    passed=all(v['passed'] for v in modes.values())
    (out/'summary.json').write_text(json.dumps({'passed':passed,'modes':modes,'rows':rows},indent=2)+'\n')
    print(json.dumps(modes),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--index',type=int)
    parser.add_argument('--arm');parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.arm:worker(args.index,args.arm,args.output)
    else:parent()
