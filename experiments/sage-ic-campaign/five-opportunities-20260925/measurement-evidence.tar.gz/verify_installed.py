"""Verify actual installed APIs, including the existing arithmetic regressions."""
import hashlib
import importlib
import json
from pathlib import Path
import sys
import unittest
from sage.all import EllipticCurve, GF
from sage.schemes.elliptic_curves import binary_batch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
receipt=json.loads((HERE/'install-001/install.json').read_text())
for row in receipt['files']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']

suite=unittest.TestSuite()
for folder,name in [
    ('experiments/sage-binary-point-construction','test_construction'),
    ('experiments/sage-binary-native-frobenius','test_native_frobenius'),
    ('experiments/sage-binary-hardware','test_hardware'),
    ('experiments/sage-ic-campaign/scalar-add-20260924','test_add'),
]:
    sys.path.insert(0,str(ROOT/folder))
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name)))


class InstalledFeatureTests(unittest.TestCase):
    def test_fused_public_api(self):
        if 'fused' not in receipt['accepted']:return
        E=EllipticCurve(GF(2**5,'z',impl='ntl'),[1,1,0,0,1])
        points=list(E)
        pairs=[(P,Q) for P in points for Q in points]
        for power in (-1,0,1,7):
            mapped=binary_batch.frobenius_points(E,(P for P,Q in pairs),power)
            self.assertEqual(binary_batch.frobenius_add_pairs(E,iter(pairs),power),
                             [P+Q for P,(_,Q) in zip(mapped,pairs)])


suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(InstalledFeatureTests))
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
