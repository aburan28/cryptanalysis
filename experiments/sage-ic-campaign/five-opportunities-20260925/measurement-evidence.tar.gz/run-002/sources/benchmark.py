"""Paired complete-operation gates, with exact verification inside timing."""
import argparse
import hashlib
import json
import math
import platform
import random
import resource
import statistics
import subprocess
import sys
import time
from pathlib import Path
import numpy as np
from sage.all import EllipticCurve, GF, ZZ, set_random_seed
from sage.structure.coerce_actions import IntegerMulAction
import bindings as b

sys.path.insert(0, str(b.ROOT/'experiments/sage-binary-hardware'))
from public_points import generate
HERE = b.HERE
INTENT = json.loads((HERE/'intent-v2.json').read_text())
OPERATIONS = ['singleton','pari_small','pari_wide','pari_cold','pairs','cartesian','table_cold','table_warm','fused']
GROUPS = {'singleton':'singleton','pari_small':'pari','pari_wide':'pari','pari_cold':'pari','pairs':'batch',
          'cartesian':'batch','table_cold':'table','table_warm':'table','fused':'fused'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fixture(case):
    set_random_seed(case['seed'])
    F = GF(2**case['degree'], 'z', impl='ntl')
    E = EllipticCurve(F, [1,1,0,0,1])
    if case.get('control') == 'prime':
        E = EllipticCurve(GF(101), [1,1])
        points = [E.random_point() for _ in range(48)]
    elif case.get('control') == 'unsupported':
        E = EllipticCurve(F, [1,1,F.gen(),0,1])
        points = [E.random_point() for _ in range(48)]
    else:
        points, _ = generate(E, 48, case['seed'])
    op = case['operation']
    pairs = [(points[i % 48],points[(5*i+7) % 48]) for i in range(256)]
    if op == 'singleton':
        pairs = pairs[:16]
        expected = [b.GENERIC_ADD(P,Q) for P,Q in pairs]
    elif op.startswith('pari'):
        points = points[:1 if op == 'pari_cold' else 16]
        k = ZZ(17) if op != 'pari_wide' else ZZ(2)**(case['degree']-1)+12345
        b.CLASS._add_ = b.GENERIC_ADD
        expected = [IntegerMulAction(ZZ,P.parent())._act_(k,P) for P in points]
        b.reset()
        E.pari_curve()  # Existing common cache, not candidate-only preparation.
    elif op == 'pairs':
        expected = [b.GENERIC_ADD(P,Q) for P,Q in pairs]
    elif op == 'cartesian':
        left, right = points[:24], points[24:48]
        expected = [b.GENERIC_ADD(P,Q) for P in left for Q in right]
    elif op.startswith('table'):
        points = [points[i%48] for i in range(256)]
        expected = b.BASELINE.frobenius_points(E, points, 7)
    else:
        mapped = b.BASELINE.frobenius_points(E, [P for P,Q in pairs], 7)
        expected = [b.GENERIC_ADD(P,Q) for P,(_,Q) in zip(mapped,pairs)]
    plans = {}
    if op == 'table_warm':
        for arm in ['incumbent','candidate']:
            b.activate('table',arm)
            plans[arm] = b.binary_hardware.FrobeniusPlan(E, 7, backend='cpu', cpu_threads=1)
        b.reset()
    def operation(arm):
        api = b.CANDIDATE if arm == 'candidate' else b.BASELINE
        if op == 'singleton': return [P+Q for P,Q in pairs]
        if op.startswith('pari'):
            if op == 'pari_cold':
                # Both arms pay the same cache reset, and candidate creation is timed.
                E.base_ring().__dict__.pop('_binary_batch_pari_generator', None)
            return [k*P for P in points]
        if op == 'pairs': return api.add_pairs(E,pairs)
        if op == 'cartesian': return api.add_cartesian(E,left,right)
        if op == 'table_warm': return plans[arm].apply(points)
        if op == 'table_cold':
            with b.binary_hardware.FrobeniusPlan(E,7,backend='cpu',cpu_threads=1) as plan:
                return plan.apply(points)
        if arm == 'candidate': return api.frobenius_add_pairs(E,pairs,7)
        mapped = api.frobenius_points(E, (P for P,Q in pairs), 7)
        return api.add_pairs(E,zip(mapped,(Q for P,Q in pairs)))
    return operation, expected, plans, E


def worker(case, output, rss_arm=None):
    operation, expected, plans, E = fixture(case)
    kind = GROUPS[case['operation']]
    repeats = 2 if case['operation']=='table_cold' else 8
    if rss_arm:
        b.activate(kind,rss_arm)
        for _ in range(12):
            actual=operation(rss_arm); assert actual==expected; del actual
        result={'case':case,'arm':rss_arm,'rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    else:
        # Validate before freezing this worker's timing boundary, including cold conversion setup.
        for arm in ['incumbent','candidate']:
            b.activate(kind,arm)
            assert operation(arm)==expected
        orders = [('incumbent','candidate'),('candidate','incumbent')]*6
        random.Random(case['seed']).shuffle(orders)
        trials=[]
        for order in orders:
            row={'order':order,'wall':{},'cpu':{}}
            for arm in order:
                b.activate(kind,arm)
                cpu0=time.process_time_ns(); start=time.perf_counter_ns()
                for _ in range(repeats):
                    actual=operation(arm)
                    assert actual==expected
                    del actual
                row['wall'][arm]=(time.perf_counter_ns()-start)/1e9
                row['cpu'][arm]=(time.process_time_ns()-cpu0)/1e9
            trials.append(row)
        logs=[math.log(t['wall']['incumbent']/t['wall']['candidate']) for t in trials]
        cpu=[t['cpu']['candidate']/t['cpu']['incumbent'] for t in trials]
        result={'case':case,'trials':trials,'speedup':math.exp(statistics.median(logs)),
                'cpu_ratio':statistics.median(cpu),'exact':True,
                'verified_outputs':len(expected)*(2+24*repeats),
                'rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    for plan in plans.values(): plan.close()
    b.reset()
    output.write_text(json.dumps(result,indent=2)+'\n')


def aggregate(rows):
    rng=np.random.default_rng(202609254001)
    matrix=np.array([[math.log(t['wall']['incumbent']/t['wall']['candidate'])
                      for t in r['trials']] for r in rows])
    samples=rng.integers(0,12,size=(5000,12))
    boot=np.exp(np.median(matrix[:,samples],axis=2).mean(axis=0))
    return {'geomean':float(np.exp(np.median(matrix,axis=1).mean())),
            'ci95':[float(x) for x in np.quantile(boot,[.025,.975])],
            'min_cell':min(r['speedup'] for r in rows),
            'max_cpu_ratio':max(r['cpu_ratio'] for r in rows)}


def parent(out):
    out.mkdir(exist_ok=False)
    paths=list((HERE/'candidate').glob('*.py*'))+list((HERE/'candidate').glob('*.so'))
    paths += list((HERE/'baseline').glob('*.py*'))+[Path(b.OLD_NATIVE.__file__),HERE/'bindings.py',
               HERE/'benchmark.py',HERE/'test_candidates.py',HERE/'intent-v2.json']
    hashes={str(p):digest(p) for p in paths}
    (out/'execution.json').write_text(json.dumps({'hashes':hashes,'platform':platform.platform(),
        'python':sys.version,'executable':sys.executable},indent=2)+'\n')
    rows=[]
    for phase in ['primary','confirmation']:
        for spec in INTENT[phase+'_cases']:
            for op in OPERATIONS:
                case=dict(spec,phase=phase,operation=op)
                run_case(case,out,rows)
    # Guard public APIs that are not eligible for the native arithmetic path.
    for control in ['prime','unsupported']:
        for op in ['singleton','pari_small']:
            run_case({'degree':19,'seed':202609254101,'phase':'control',
                      'control':control,'operation':op},out,rows)
    decisions={}
    for kind in ['singleton','pari','batch','table','fused']:
        group=[r for r in rows if GROUPS[r['case']['operation']]==kind]
        stats={phase:aggregate([r for r in group if r['case']['phase']==phase])
               for phase in ['primary','confirmation']}
        sample=next(r['case'] for r in reversed(group) if r['case']['phase']=='confirmation')
        rss={}
        for arm in ['incumbent','candidate']:
            path=out/f'rss-{kind}-{arm}.json'
            cmd=[sys.executable,__file__,'--case',json.dumps(sample),'--worker-out',str(path),'--rss-arm',arm]
            with path.with_suffix('.log').open('w') as log:
                subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180,check=True)
            rss[arm]=json.loads(path.read_text())['rss_bytes']
        gates={'primary':stats['primary']['geomean']>1.02 and stats['primary']['ci95'][0]>1,
               'confirmation':stats['confirmation']['geomean']>1.01 and stats['confirmation']['ci95'][0]>1,
               'cells':all(r['speedup']>=.98 for r in group),
               'cpu':all(r['cpu_ratio']<=1.05 for r in group),
               'rss':rss['candidate']<=max(rss['incumbent']*1.05,rss['incumbent']+2*1024**2)}
        decisions[kind]={'status':'PASS_LOCAL' if all(gates.values()) else 'HOLD',
                         'gates':gates,'aggregates':stats,'rss':rss}
    assert all(digest(p)==h for p,h in hashes.items())
    (out/'summary.json').write_text(json.dumps({'decisions':decisions,
        'cells':[{k:v for k,v in r.items() if k!='trials'} for r in rows],
        'all_exact':all(r['exact'] for r in rows),
        'verified_outputs':sum(r['verified_outputs'] for r in rows)},indent=2)+'\n')
    print(json.dumps(decisions,indent=2),flush=True)


def run_case(case,out,rows):
    path=out/f'cell-{len(rows):02d}.json'
    previous=HERE/'run-001'/path.name
    if previous.exists() and previous.parent != out.resolve():
        prior=json.loads(previous.read_text())
        if prior['case']==case:
            path.write_text(previous.read_text())
            path.with_name(path.stem+'-parent.json').write_text(json.dumps({
                'reused_from':str(previous),'sha256':digest(previous),
                'reason':'resume after correcting the cold-plan CPU thread keyword'})+'\n')
            rows.append(prior)
            return
    cmd=[sys.executable,__file__,'--case',json.dumps(case),'--worker-out',str(path)]
    with path.with_suffix('.log').open('w') as log:
        try:
            proc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
            status=proc.returncode
        except subprocess.TimeoutExpired:
            status='timeout'
    path.with_name(path.stem+'-parent.json').write_text(json.dumps({'case':case,'status':status})+'\n')
    if status!=0: raise RuntimeError(f'failed cell {path}: {status}')
    row=json.loads(path.read_text());rows.append(row)
    print(case,round(row['speedup'],3),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path)
    parser.add_argument('--case')
    parser.add_argument('--worker-out',type=Path)
    parser.add_argument('--rss-arm')
    args=parser.parse_args()
    if args.case: worker(json.loads(args.case),args.worker_out,args.rss_arm)
    else: parent(args.out)
