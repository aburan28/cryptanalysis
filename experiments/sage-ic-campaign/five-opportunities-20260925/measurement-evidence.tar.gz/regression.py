"""Run the existing public API regressions against the selected candidate."""
import importlib
import sys
import unittest
import bindings as b

from sage.schemes import elliptic_curves
b.binary_batch._native = b.NATIVE
elliptic_curves.binary_batch_ntl = b.NATIVE
sys.modules['sage.schemes.elliptic_curves.binary_batch_ntl'] = b.NATIVE
for name in ['add_pairs','add_cartesian','frobenius_add_pairs']:
    setattr(b.binary_batch,name,getattr(b.CANDIDATE,name))
b.CLASS._add_ = b.ADD
b.CLASS.__pari__ = b.PARI
b.binary_hardware.FrobeniusPlan._make_table = b.TABLE

locations = [
    ('experiments/sage-binary-point-construction','test_construction'),
    ('experiments/sage-binary-native-frobenius','test_native_frobenius'),
    ('experiments/sage-binary-hardware','test_hardware'),
    ('experiments/sage-ic-campaign/scalar-add-20260924','test_add'),
]
suite=unittest.TestSuite()
for folder,name in locations:
    sys.path.insert(0,str(b.ROOT/folder))
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name)))
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
