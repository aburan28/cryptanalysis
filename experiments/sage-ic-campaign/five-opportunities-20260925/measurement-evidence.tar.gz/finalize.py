"""Resolve immutable receipts and generate the selected source patch/report."""
import copy
import difflib
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def decisions():
    summary=json.loads((HERE/'run-003/summary.json').read_text())
    final=copy.deepcopy(summary['decisions'])
    memory=json.loads((HERE/'memory-001/summary.json').read_text())
    final['pari']['original_rss_gate']=final['pari']['gates']['rss']
    final['pari']['memory_confirmation']='memory-001/summary.json'
    final['pari']['gates']['rss']=memory['passed']
    final['pari']['status']='PASS_LOCAL' if all(final['pari']['gates'].values()) else 'HOLD'
    (HERE/'FINAL_DECISION.json').write_text(json.dumps({
        'decisions':final,'timing_receipt_sha256':digest(HERE/'run-003/summary.json'),
        'memory_receipt_sha256':digest(HERE/'memory-001/summary.json'),
        'original_runs_preserved':True},indent=2)+'\n')
    return final


def archive():
    resolved={}
    for name in ['run-001','run-002','run-003','memory-001']:
        out=HERE/name
        receipt=json.loads((out/'execution.json').read_text())
        hashes=receipt['hashes']
        sources=out/'sources';sources.mkdir(exist_ok=True)
        locations={}
        for path,expected in hashes.items():
            original=Path(path)
            candidates=[original,sources/original.name,HERE/'candidate-v1'/original.name,
                        HERE/'baseline'/original.name,HERE/'install-001/previous-installed'/original.name]
            match=next((p for p in candidates if p.is_file() and digest(p)==expected),None)
            if match is None:raise RuntimeError(f'Unresolved receipt: {name}: {path}')
            if original.parent==HERE:
                if match!=sources/original.name:shutil.copy2(match,sources/original.name)
                match=sources/original.name
            locations[path]=str(match.relative_to(HERE)) if match.is_relative_to(HERE) else str(match)
        resolved[name]=locations
    (HERE/'receipt-locations.json').write_text(json.dumps(resolved,indent=2)+'\n')


def patch():
    selected=HERE/'install-001/selected'
    pieces=[]
    for name in ['binary_batch.py','binary_batch_ntl.pyx','binary_hardware.py','ell_point.py','meson.build']:
        before=(HERE/'install-001/previous-meson.build' if name=='meson.build'
                else HERE/'baseline'/name)
        after=(ROOT/'third_party/sage-binary/src/sage/schemes/elliptic_curves'/name
               if name=='meson.build' else selected/name)
        relative='src/sage/schemes/elliptic_curves/'+name
        pieces.extend(difflib.unified_diff(before.read_text().splitlines(keepends=True),
            after.read_text().splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative))
    (HERE/'selected.patch').write_text(''.join(pieces))


if __name__=='__main__':
    decisions();archive()
    if (HERE/'install-001/install.json').exists():patch()
