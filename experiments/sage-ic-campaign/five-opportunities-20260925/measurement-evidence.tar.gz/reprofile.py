"""Post-install hotspot diagnostics; not a speedup or IC measurement."""
import cProfile
import hashlib
import json
from pathlib import Path
import pstats
import sys
from sage.all import EllipticCurve, GF, set_random_seed
from sage.schemes.elliptic_curves import binary_batch, ell_point

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'experiments/sage-binary-hardware'))
from public_points import generate
out=HERE/'profile-installed';out.mkdir(exist_ok=False)
set_random_seed(202609256001)
F=GF(2**131,'z',impl='ntl');E=EllipticCurve(F,[1,1,0,0,1])
points,_=generate(E,64,202609256001)
pairs=list(zip(points,points[1:]+points[:1]))
operations={'scalar_add':lambda:[P+Q for P,Q in pairs],
            'scalar_mul_17':lambda:[17*P for P in points],
            'pairs':lambda:binary_batch.add_pairs(E,pairs),
            'cartesian':lambda:binary_batch.add_cartesian(E,points,points)}
if hasattr(binary_batch,'frobenius_add_pairs'):
    operations['fused']=lambda:binary_batch.frobenius_add_pairs(E,pairs,7)
for name,fn in operations.items():
    expected=fn()
    def checked():
        for _ in range(64):assert fn()==expected
    profile=cProfile.Profile();profile.runcall(checked)
    with (out/(name+'.txt')).open('w') as stream:
        pstats.Stats(profile,stream=stream).strip_dirs().sort_stats('tottime').print_stats(25)
(out/'execution.json').write_text(json.dumps({'diagnostic_only':True,'seed':202609256001,
    'hashes':{m.__file__:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()
              for m in [binary_batch,binary_batch._native,ell_point]}},indent=2)+'\n')
