"""Install only mechanisms that pass the frozen follow-up gates.

The compiled file is the exact measured candidate. Sources are checked against
the initial snapshot before mutation; installed files are archived first.
"""
import hashlib
import json
from pathlib import Path
import shutil
from sage.schemes.elliptic_curves import binary_batch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
source=ROOT/'third_party/sage-binary/src/sage/schemes/elliptic_curves'
installed=Path(binary_batch.__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


summary=json.loads((HERE/'FINAL_DECISION.json').read_text())
accepted={k for k,v in summary['decisions'].items() if v['status']=='PASS_LOCAL'}
if not accepted:
    raise RuntimeError('No candidate passed; leave the runtime unchanged.')
plan=json.loads((HERE/'intent-v3.json').read_text())
for name,expected in plan['baseline_source_hashes'].items():
    if digest(source/name)!=expected:
        raise RuntimeError(f'Concurrent source change in {name}; refusing to overwrite it.')
receipt=HERE/'install-001'
receipt.mkdir(exist_ok=False)
previous=receipt/'previous-installed'; previous.mkdir()
selected=receipt/'selected'; selected.mkdir()
for name in ['binary_batch.py','binary_batch_ntl.pyx','binary_hardware.py','ell_point.py']:
    text=(HERE/'candidate'/name).read_text()
    baseline=(HERE/'baseline'/name).read_text()
    if name=='binary_batch.py':
        text=text.replace('This module is opt-in and does not change the scalar point API. It is\nintended for independent public mathematical computations, such as pair\nconstruction and checking sums. Its branches and field operations are\nvariable-time.',
            'These batch APIs support independent public mathematical computations,\nsuch as pair construction and checking sums. The optional native helpers also\nsupport scalar point arithmetic. Branches and field operations are variable-time.')
        if 'batch' not in accepted:
            # Keep the public pair/Cartesian functions exactly as before;
            # the fused operation can still use the new private kernel.
            suffix=text[text.index('\n\ndef frobenius_add_pairs'):]
            text=baseline+suffix
        if 'fused' not in accepted:
            text=text[:text.index('\n\ndef frobenius_add_pairs')]
    if name=='ell_point.py':
        if 'singleton' not in accepted:
            text=text.replace('return binary_batch._native._add_one(E, self, other, a2)',
                              'return binary_batch.add_pairs(E, ((self, other),))[0]')
        if 'pari' not in accepted:
            start=text.index('    def __pari__(self):',text.index('class EllipticCurvePoint_finite_field'))
            end=text.index('    def _acted_upon_',start)
            text=text[:start]+text[end:]
            text=text.replace("try:\n    from sage.rings.finite_rings.element_ntl_gf2e import FiniteField_ntl_gf2eElement\nexcept ImportError:\n    FiniteField_ntl_gf2eElement = ()\n",'')
    if name=='binary_hardware.py' and 'table' not in accepted:
        text=baseline
    (selected/name).write_text(text)
binary=next((HERE/'candidate').glob('binary_batch_ntl*.so'))
shutil.copy2(binary,selected/binary.name)
files=[]
for p in selected.iterdir():
    target=installed/p.name
    if target.exists():shutil.copy2(target,previous/p.name)
    # A new inode keeps already running Sage processes on their original library.
    temporary=target.with_name(target.name+'.five-opportunities-new')
    shutil.copy2(p,temporary);temporary.replace(target)
    if p.suffix in ['.py','.pyx']:
        shutil.copy2(p,source/p.name)
    files.append({'path':str(target),'sha256':digest(target)})
meson=source/'meson.build'
shutil.copy2(meson,receipt/'previous-meson.build')
text=meson.read_text()
needle='dependencies: [py_dep, ntl, gmp, cysignals],'
if needle not in text:raise RuntimeError('Unexpected native Meson dependencies')
text=text.replace(needle,'dependencies: [py_dep, ntl, gmp, cysignals, cypari2],',1)
meson.write_text(text)
(receipt/'install.json').write_text(json.dumps({'accepted':sorted(accepted),'files':files,
    'summary_sha256':digest(HERE/'FINAL_DECISION.json'),
    'meson_sha256':digest(meson)},indent=2)+'\n')
print('Installed:',', '.join(sorted(accepted)))
