"""Independent arithmetic, representation and fallback checks for five candidates."""
import copy
import pickle
import sys
import unittest
import numpy as np
from sage.all import EllipticCurve, GF, ZZ, pari, set_random_seed
from sage.structure.coerce_actions import IntegerMulAction
import bindings as b

sys.path.insert(0, str(b.ROOT/'experiments/sage-binary-hardware'))
from public_points import generate


class CandidateTests(unittest.TestCase):
    def tearDown(self):
        b.reset()

    def fixture(self, degree=19, ordinary=False, alternate=False):
        set_random_seed(202609253000+degree)
        F = GF(2**degree, 'z', impl='ntl')
        if alternate:
            F = GF(2**degree, 'w', modulus=F.modulus().reverse(), impl='ntl')
        E = EllipticCurve(F, [1, F.gen() if ordinary else 1, 0, 0,
                             F.gen() if ordinary else 1])
        points, _ = generate(E, 8, 202609253000+degree)
        return F, E, points

    def test_exhaustive_small_field(self):
        for a in (0, 1):
            E = EllipticCurve(GF(2**3, 'z', impl='ntl'), [1, a, 0, 0, 1])
            points = list(E)
            expected = [b.GENERIC_ADD(P, Q) for P in points for Q in points]
            self.assertEqual(b.CANDIDATE.add_pairs(E, ((P,Q) for P in points for Q in points)), expected)
            for size in (1, 3, 17, 1024):
                self.assertEqual(b.CANDIDATE.add_cartesian(E, iter(points), iter(points), size), expected)
            b.activate('singleton', 'candidate')
            self.assertEqual([P+Q for P in points for Q in points], expected)

    def test_contexts_and_point_state(self):
        for degree, ordinary, alternate in [(19,True,False),(67,False,False),
                                           (131,False,True),(163,False,False)]:
            F, E, points = self.fixture(degree, ordinary, alternate)
            O = E(0); T = E(0, E.a6().sqrt())
            P = points[0]
            scaled = copy.copy(P)
            scaled._coords = tuple(c*F.gen() for c in P)
            scaled._normalized = False
            points += [O, T, -P, scaled]
            pairs = [(P,Q) for P in points for Q in points]
            expected = [b.GENERIC_ADD(P,Q) for P,Q in pairs]
            other = GF(2**23, 'u', impl='ntl')
            def stream():
                for pair in pairs:
                    other.gen()**11
                    yield pair
            actual = b.CANDIDATE.add_pairs(E, stream())
            self.assertEqual(actual, expected)
            b.activate('singleton', 'candidate')
            self.assertEqual([P+Q for P,Q in pairs], expected)
            self.assertIs(b.NATIVE._add_one(E, O, P, E.a2()), P)
            for result in actual[:8]:
                self.assertIs(result.parent(), E.point_homset())
                self.assertEqual(pickle.loads(pickle.dumps(result)), result)
                self.assertEqual(copy.copy(result), result)

    def test_pari_representation_and_scalars(self):
        for degree, alternate in [(3,False),(19,False),(67,False),(131,True),(163,False)]:
            F, E, points = self.fixture(degree, alternate=alternate)
            points += [E(0), E(0, 1)]
            originals = [b.OLD_PARI(P) for P in points]
            for P, expected in zip(points, originals):
                self.assertEqual(b.NATIVE._pari_point(E, P), expected)
            b.CLASS._add_ = b.GENERIC_ADD
            scalars = [ZZ(-17), ZZ(0), ZZ(17), ZZ(2)**(degree-1)+12345]
            expected = [[IntegerMulAction(ZZ, P.parent())._act_(k, P) for P in points]
                        for k in scalars]
            b.activate('pari', 'candidate')
            for k, result in zip(scalars, expected):
                self.assertEqual([k*P for P in points], result)
            scaled = copy.copy(points[0]); scaled._coords = tuple(c*F.gen() for c in scaled)
            scaled._normalized = False
            self.assertEqual(pari(scaled), originals[0])
            # Keep returned Gen values alive across repeated conversion/stack activity.
            saved = [pari(P) for P in points]
            for _ in range(40):
                pari(points[0]); pari(2)**2048
            self.assertEqual(saved, originals)
            b.reset()

    def test_table_exact(self):
        for degree, alternate in [(19,False),(67,False),(131,True),(163,False)]:
            F, E, points = self.fixture(degree, alternate=alternate)
            for power in (0, 1, 7, degree-1):
                with b.binary_hardware.FrobeniusPlan(E, power, backend='cpu') as plan:
                    self.assertTrue(np.array_equal(b.NATIVE._frobenius_table(F, power), plan._table))
                    expected = plan.apply(points)
                b.activate('table','candidate')
                with b.binary_hardware.FrobeniusPlan(E, power, backend='cpu') as plan:
                    self.assertEqual(plan.apply(points), expected)
                    self.assertFalse(plan._table.flags.writeable)
                b.reset()

    def test_fused_exact(self):
        for degree in (3, 19, 67, 131):
            F, E, points = self.fixture(degree)
            points += [E(0), E(0,1), -points[0]]
            pairs = [(P,Q) for P in points for Q in points]
            for power in (-1, 0, 1, 7, degree):
                mapped = b.BASELINE.frobenius_points(E, [P for P,Q in pairs], power)
                expected = [b.GENERIC_ADD(P,Q) for P,(_,Q) in zip(mapped,pairs)]
                self.assertEqual(b.CANDIDATE.frobenius_add_pairs(E, iter(pairs), power), expected)

    def test_custom_points(self):
        F, E, points = self.fixture()
        class Custom(b.CLASS):
            def __init__(self, *args, **kw):
                super().__init__(*args, **kw)
                self.marker = 'custom'
        old = E._point
        try:
            E._point = Custom
            custom = [Custom(E, list(P), check=False) for P in points]
            expected = b.BASELINE.add_pairs(E, list(zip(custom,custom)))
            actual = b.CANDIDATE.add_pairs(E, list(zip(custom,custom)))
            self.assertEqual(actual, expected)
            self.assertTrue(all(type(P) is Custom and P.marker == 'custom' for P in actual))
            expected = b.BASELINE.add_pairs(E, zip(b.BASELINE.frobenius_points(E,custom,7),custom))
            self.assertEqual(b.CANDIDATE.frobenius_add_pairs(E, zip(custom,custom), 7), expected)
        finally:
            E._point = old

    def test_fallbacks_and_errors(self):
        for F in [GF(101), GF(5**2, 'z'), GF(2**8, 'z', impl='givaro')]:
            E = EllipticCurve(F, [1,1]) if F.characteristic()!=2 else EllipticCurve(F,[1,1,0,0,1])
            P = E.random_point()
            expected = b.OLD_PARI(P)
            b.activate('pari','candidate')
            self.assertEqual(pari(P), expected)
            b.reset()
            if F.characteristic()==2:
                self.assertEqual(b.CANDIDATE.add_pairs(E, [(P,P)]), [b.GENERIC_ADD(P,P)])
        F, E, points = self.fixture()
        self.assertEqual(b.CANDIDATE.add_cartesian(E, [], points), [])
        for bad in [0, -1]:
            with self.assertRaises(ValueError): b.CANDIDATE.add_cartesian(E, points, points, bad)
        for bad in [None, 123, EllipticCurve(F,[1,0,0,0,1])(0)]:
            with self.assertRaises(ValueError): b.CANDIDATE.add_pairs(E, [(points[0],bad)])
        with self.assertRaises(ValueError): b.NATIVE._frobenius_table(F,-1)
        with self.assertRaises(ValueError): b.CANDIDATE.frobenius_add_pairs(EllipticCurve(F,[1,1,0,0,F.gen()]), [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
