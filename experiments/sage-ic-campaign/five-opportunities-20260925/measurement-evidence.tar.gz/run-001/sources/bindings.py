"""Load isolated candidates using the real Sage class identities in both arms."""
import ast
import importlib.util
from pathlib import Path
import sys
from sage.schemes.elliptic_curves import binary_batch, binary_hardware, ell_point

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CLASS = ell_point.EllipticCurvePoint_finite_field
OLD_NATIVE = binary_batch._native
OLD_ADD = CLASS._add_
OLD_PARI = CLASS.__pari__
OLD_TABLE = binary_hardware.FrobeniusPlan._make_table


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def method(path, classname, name, namespace):
    """Avoid loading a duplicate point class, which changes exact-type guards."""
    tree = ast.parse(path.read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == classname)
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == name)
    code = ast.Module(body=[fn], type_ignores=[])
    scope = dict(namespace)
    exec(compile(code, str(path), 'exec'), scope)
    return scope[name]


NATIVE = load('binary_batch_ntl', next((HERE/'candidate').glob('binary_batch_ntl*.so')))
CANDIDATE = load('sage_five_candidate_batch', HERE/'candidate/binary_batch.py')
CANDIDATE._native = NATIVE
BASELINE = load('sage_five_baseline_batch', HERE/'baseline/binary_batch.py')
BASELINE._native = OLD_NATIVE
ADD = method(HERE/'candidate/ell_point.py', 'EllipticCurvePoint_field', '_add_', ell_point.__dict__)
PARI = method(HERE/'candidate/ell_point.py', 'EllipticCurvePoint_finite_field', '__pari__', ell_point.__dict__)
TABLE = method(HERE/'candidate/binary_hardware.py', 'FrobeniusPlan', '_make_table', binary_hardware.__dict__)
GENERIC_ADD = method(HERE.parent/'scalar-add-20260924/baseline/ell_point.py',
                     'EllipticCurvePoint_field', '_add_', ell_point.__dict__)


def activate(kind, arm):
    candidate = arm == 'candidate'
    binary_batch._native = NATIVE if candidate else OLD_NATIVE
    CLASS._add_ = ADD if candidate and kind == 'singleton' else OLD_ADD
    CLASS.__pari__ = PARI if candidate and kind == 'pari' else OLD_PARI
    binary_hardware.FrobeniusPlan._make_table = TABLE if candidate and kind == 'table' else OLD_TABLE


def reset():
    activate('none', 'incumbent')
