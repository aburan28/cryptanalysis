"""PARI polynomial-word boundaries and binary-field variable-name checks."""
import copy
import unittest
from sage.all import GF, EllipticCurve, pari
import bindings as b


class WordBoundaryTests(unittest.TestCase):
    def tearDown(self):
        b.reset()

    def test_exact_representation(self):
        for degree in (2, 63, 64, 65, 127, 128, 129, 255, 256):
            for name in ('x', 'beta'):
                F = GF(2**degree, name, impl='ntl')
                E = EllipticCurve(F, [1,1,0,0,1])
                for bits in (0, 1, 2, (1 << (degree-1)), (1 << degree)-1):
                    # These are representation fixtures, not curve arithmetic inputs.
                    P = E._point(E, [F.from_integer(bits), F.from_integer(bits^1), F.one()], check=False)
                    expected = b.OLD_PARI(P)
                    actual = b.NATIVE._pari_point(E, P)
                    self.assertEqual(actual, expected)
                    self.assertEqual(str(actual), str(expected))

    def test_order_cache_survives_multiplication(self):
        E=EllipticCurve(GF(2**5,'z',impl='ntl'),[1,1,0,0,1])
        P=next(P for P in E if P)
        n=P.order()
        b.activate('pari','candidate')
        for k in (0,1,-1,2,17):
            Q=k*P
            self.assertEqual(Q._order,n//n.gcd(k))


if __name__=='__main__':
    unittest.main(verbosity=2)
