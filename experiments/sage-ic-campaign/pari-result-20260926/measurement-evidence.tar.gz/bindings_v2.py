"""Use real Sage class identities while swapping archived methods/binaries."""
import ast
import importlib.util
from pathlib import Path
import sys
from sage.schemes.elliptic_curves import binary_batch, ell_point

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CLASS = ell_point.EllipticCurvePoint_finite_field

def method(path, classname, name):
    tree = ast.parse(path.read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == classname)
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == name)
    scope = dict(ell_point.__dict__)
    exec(compile(ast.Module(body=[fn], type_ignores=[]), str(path), 'exec'), scope)
    return scope[name]

def native(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

DIRECTORIES = {'baseline': 'baseline', 'candidate': 'candidate-v2'}
METHODS = {arm: method(HERE/DIRECTORIES[arm]/'ell_point.py', CLASS.__name__, '_acted_upon_')
           for arm in ['baseline', 'candidate']}
NATIVES = {arm: native('_sage_result_'+arm+'.binary_batch_ntl',
                      next((HERE/DIRECTORIES[arm]).glob('binary_batch_ntl*.so')))
           for arm in ['baseline', 'candidate']}
GENERIC_ADD = method(HERE.parent/'scalar-add-20260924/baseline/ell_point.py',
                     'EllipticCurvePoint_field', '_add_')
INSTALLED_ADD = CLASS._add_

def activate(arm):
    CLASS._acted_upon_ = METHODS[arm]
    binary_batch._native = NATIVES[arm]
    CLASS._add_ = INSTALLED_ADD
