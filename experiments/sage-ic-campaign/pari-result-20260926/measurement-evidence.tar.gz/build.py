"""Build the candidate separately from the installed incumbent."""
from pathlib import Path
from setuptools import Extension, setup
from Cython.Build import cythonize
from sage.env import sage_include_directories

HERE = Path(__file__).resolve().parent
extension = Extension('binary_batch_ntl',
    [str(HERE/'candidate/binary_batch_ntl.pyx')], language='c++',
    include_dirs=sage_include_directories(), libraries=['ntl', 'gmp', 'pari'],
    extra_compile_args=['-O3', '-std=c++17'])
setup(name='sage-pari-result', ext_modules=cythonize([extension],
    build_dir=str(HERE/'build'), compiler_directives={'language_level': 3}),
    script_args=['build_ext', '--build-lib', str(HERE/'candidate'),
                 '--build-temp', str(HERE/'build/objects')])
