"""Independent scalar replay and representation/lifecycle regression checks."""
import json
import pickle
from pathlib import Path
import unittest
from sage.all import EllipticCurve, GF, ZZ, set_random_seed
from sage.libs.pari import pari
from sage.structure.coerce_actions import IntegerMulAction
import bindings_v2 as b


def reference(P, k):
    previous = b.CLASS._add_
    b.CLASS._add_ = b.GENERIC_ADD
    try:
        return IntegerMulAction(ZZ, P.parent())._act_(ZZ(k), P)
    finally:
        b.CLASS._add_ = previous


class ResultTests(unittest.TestCase):
    def setUp(self):
        set_random_seed(202609260401)
        b.activate('candidate')

    def assert_point(self, actual, expected):
        self.assertEqual(actual, expected)
        self.assertIs(type(actual), type(expected))
        self.assertIs(actual.parent(), expected.parent())
        self.assertIs(actual.curve(), expected.curve())
        self.assertEqual(hash(actual), hash(expected))
        self.assertEqual(pickle.loads(pickle.dumps(actual)), expected)
        self.assertTrue(actual.curve().is_on_curve(*actual.xy()) if actual else True)

    def test_exhaustive_small_fields(self):
        for degree in [2, 3, 4]:
            F = GF(2**degree, 'z', impl='ntl')
            for a in [0, 1, F.gen()]:
                E = EllipticCurve(F, [1, a, 0, 0, 1])
                for P in E:
                    for k in [-17, -2, -1, 0, 1, 2, 17]:
                        self.assert_point(ZZ(k)*P, reference(P, k))

    def test_machine_word_boundaries_and_context(self):
        for degree in [19, 31, 63, 64, 65, 127, 128, 129, 131, 163, 255, 256]:
            for name in ['x', 'beta']:
                F = GF(2**degree, name, impl='ntl')
                for coeffs in [[1, 1, 0, 0, 1], [1, F.gen(), 1, 0, 1]]:
                    E = EllipticCurve(F, coeffs)
                    P = E.random_point()
                    for k in [-17, 0, 17, ZZ(2)**(degree-1)+12345]:
                        expected = reference(P, k)
                        # Change the process's active NTL modulus between calls.
                        other = GF(2**7, 'other', impl='ntl')
                        unused = other.gen()**19
                        self.assert_point(ZZ(k)*P, expected)

    def test_generic_fallbacks(self):
        for F in [GF(101), GF(65537), GF(2**19, 'p', impl='pari_ffelt'),
                  GF(2**8, 'g', impl='givaro'), GF(5**3, 'a'),
                  GF(101**3, 'b', impl='pari_ffelt')]:
            E = EllipticCurve(F, [1, 1, 0, 0, 1])
            P = E.random_point()
            for k in [-17, 0, 2, 17, 1234567]:
                self.assert_point(ZZ(k)*P, reference(P, k))

    def test_order_and_custom_class(self):
        F = GF(2**7, 'z', impl='ntl')
        E = EllipticCurve(F, [1, 1, 0, 0, 1])
        P = E.random_point()
        order = P.order()
        for k in [-17, 0, 1, 2, 17, order]:
            Q = ZZ(k)*P
            self.assertEqual(Q._order, order // order.gcd(k))
            self.assert_point(Q, reference(P, k))
        class CustomPoint(b.CLASS):
            pass
        Q = CustomPoint(E, list(P))
        self.assertEqual(17*Q, reference(P, 17))
        old_constructor = E._point
        E._point = CustomPoint
        try:
            self.assertEqual(17*P, reference(P, 17))
        finally:
            E._point = old_constructor

    def test_generic_pari_coordinates_and_infinity(self):
        E = EllipticCurve(GF(2**7, 'z', impl='ntl'), [1, 1, 0, 0, 1])
        native = b.NATIVES['candidate']
        self.assert_point(native._from_pari_point(E, pari([0])), E(0))
        self.assert_point(native._from_pari_point(E, pari([0, 1])), E(0, 1))
        with self.assertRaises(ValueError):
            native._from_pari_point(E, pari([1, 2, 3]))
        # A different polynomial variable takes the generic conversion fallback.
        P = E.random_point()
        coords = pari([P[0].polynomial(), P[1].polynomial()])
        self.assert_point(native._from_pari_point(E, coords), P)

    def test_non_normalized_and_missing_native(self):
        F = GF(2**19, 'z', impl='ntl')
        E = EllipticCurve(F, [1, 1, 0, 0, 1])
        P = E.random_point()
        Q = E(P)
        Q._coords = tuple(c*F.gen() for c in P)
        Q._normalized = False
        expected = reference(P, 17)
        self.assert_point(17*Q, expected)
        native = b.binary_batch._native
        b.binary_batch._native = None
        try:
            self.assert_point(17*P, expected)
        finally:
            b.binary_batch._native = native


if __name__ == '__main__':
    unittest.main(verbosity=2)
