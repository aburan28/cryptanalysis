"""Install only the exact candidate accepted by the frozen second experiment."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = ROOT/'third_party/sage-binary/src/sage/schemes/elliptic_curves'
INSTALLED = Path(sys.prefix)/'lib/python3.14/site-packages/sage/schemes/elliptic_curves'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


decision_path = HERE/'run-002/summary.json'
decision = json.loads(decision_path.read_text())
assert decision['status'] == 'PASS_LOCAL' and decision['all_exact']
assert all(decision['gates'].values())
execution = json.loads((HERE/'run-002/execution.json').read_text())
assert all(digest(Path(path)) == expected for path, expected in execution['hashes'].items())
assert (HERE/'tests-v2-001.log').read_text().rstrip().endswith('OK')
out = HERE/'install-001'
out.mkdir(exist_ok=False)
(out/'previous-installed').mkdir()
(out/'selected').mkdir()
changed = ['ell_point.py', 'binary_batch_ntl.pyx']
native = next((HERE/'candidate-v2').glob('binary_batch_ntl*.so')).name
for name in changed+[native]:
    assert digest(INSTALLED/name) == digest(HERE/'baseline'/name), name
for name in changed:
    assert digest(SOURCE/name) == digest(HERE/'baseline'/name), name
files = changed+[native, 'binary_batch.py', 'binary_hardware.py']
for name in files:
    shutil.copy2(INSTALLED/name, out/'previous-installed'/name)
    selected = HERE/'candidate-v2'/name if name in changed+[native] else INSTALLED/name
    shutil.copy2(selected, out/'selected'/name)
manifest_path = ROOT/'experiments/sage-binary-arithmetic/runtime-current.json'
previous_manifest = manifest_path.read_bytes()
(out/'previous-runtime.json').write_bytes(previous_manifest)
try:
    for name in changed+[native]:
        destinations = [INSTALLED/name]
        if name in changed:
            destinations.append(SOURCE/name)
        for path in destinations:
            temporary = path.with_name(path.name+'.install-tmp')
            shutil.copy2(out/'selected'/name, temporary)
            temporary.replace(path)
    receipt = {'accepted': ['batch', 'fused', 'pari', 'pari_result'],
               'files': [{'path': str(INSTALLED/name), 'sha256': digest(INSTALLED/name)} for name in files],
               'summary_sha256': digest(decision_path),
               'execution_sha256': digest(HERE/'run-002/execution.json'),
               'intent_sha256': digest(HERE/'intent-v2.json')}
    (out/'install.json').write_text(json.dumps(receipt, indent=2)+'\n')
    # A fresh interpreter loads and probes the new binary before publishing its pin.
    subprocess.run([sys.executable, str(ROOT/'experiments/sage-binary-arithmetic/pin_runtime.py'),
                    '--receipt', str(out/'install.json'), '--decision', str(decision_path)], check=True)

except BaseException:
    for name in changed+[native]:
        shutil.copy2(out/'previous-installed'/name, INSTALLED/name)
    for name in changed:
        shutil.copy2(HERE/'baseline'/name, SOURCE/name)
    temporary = manifest_path.with_suffix('.restore-tmp')
    temporary.write_bytes(previous_manifest)
    temporary.replace(manifest_path)
    raise
