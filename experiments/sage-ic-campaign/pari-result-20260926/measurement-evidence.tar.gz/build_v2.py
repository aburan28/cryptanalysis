"""Build candidate v2 without changing the installed incumbent."""
from pathlib import Path
from setuptools import Extension, setup
from Cython.Build import cythonize
from sage.env import sage_include_directories

HERE = Path(__file__).resolve().parent
extension = Extension('binary_batch_ntl',
    [str(HERE/'candidate-v2/binary_batch_ntl.pyx')], language='c++',
    include_dirs=sage_include_directories(), libraries=['ntl', 'gmp', 'pari'],
    extra_compile_args=['-O3', '-std=c++17'])
setup(name='sage-pari-result-v2', ext_modules=cythonize([extension],
    build_dir=str(HERE/'build-v2'), compiler_directives={'language_level': 3}),
    script_args=['build_ext', '--build-lib', str(HERE/'candidate-v2'),
                 '--build-temp', str(HERE/'build-v2/objects')])
