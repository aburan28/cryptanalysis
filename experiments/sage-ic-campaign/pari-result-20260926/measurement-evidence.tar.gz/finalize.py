"""Write the decision report, reviewable patches and artifact hashes."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


decision = json.loads((HERE/'run-002/summary.json').read_text())
assert decision['status'] == 'PASS_LOCAL'
receipt = json.loads((HERE/'install-001/install.json').read_text())
assert receipt['summary_sha256'] == digest(HERE/'run-002/summary.json')
assert all(digest(Path(entry['path'])) == entry['sha256'] for entry in receipt['files'])
assert (HERE/'installed-tests-001.log').read_text().rstrip().endswith('OK')
assert (HERE/'hardware-installed-tests-001.log').read_text().rstrip().endswith('OK')
assert 'All tests passed!' in (HERE/'doctests-001.log').read_text()
runtime = json.loads((HERE/'runtime-checks-003.json').read_text())
assert all('pari_result' in r['features'] for r in runtime['launchers'])

patch = []
for filename in ['ell_point.py', 'binary_batch_ntl.pyx']:
    relative = 'src/sage/schemes/elliptic_curves/'+filename
    patch.extend(difflib.unified_diff((HERE/'baseline'/filename).read_text().splitlines(True),
                                    (HERE/'candidate-v2'/filename).read_text().splitlines(True),
                                    fromfile='a/'+relative, tofile='b/'+relative))
(HERE/'selected.patch').write_text(''.join(patch))
runtime_patch = ''.join(difflib.unified_diff((HERE/'runtime-source-sage-before.sh').read_text().splitlines(True),
    (ROOT/'third_party/sage-binary/src/bin/sage').read_text().splitlines(True),
    fromfile='a/src/bin/sage', tofile='b/src/bin/sage'))
(HERE/'runtime-source.patch').write_text(runtime_patch)

stats = decision['aggregates']
lines = ['# Direct scalar result conversion: PASS_LOCAL', '',
    'Installed the exact measured candidate v2 on this host. The incumbent was the',
    'already optimized September 25 build, including direct PARI input conversion.',
    'These are arithmetic-component measurements, not an IC pipeline speedup.', '',
    '| Suite | Geometric speedup | 95% paired-bootstrap interval |',
    '| --- | ---: | --- |']
for phase in ['primary', 'confirmation']:
    stat = stats[phase]
    lines.append(f'| {phase} | {stat["geomean"]:.3f}x | {stat["ci95"][0]:.3f}–{stat["ci95"][1]:.3f} |')
lines += ['', '| Field degree / backend | Workload | Speedup | Candidate/baseline CPU |',
          '| --- | --- | ---: | ---: |']
for row in decision['cells']:
    case = row['case']
    label = case.get('kind', f'GF(2^{case["degree"]}), {case["phase"]}')
    lines.append(f'| {label} | {case["operation"]} | {row["speedup"]:.3f}x | {row["cpu_ratio"]:.3f} |')
lines += ['', f'All {decision["verified_outputs"]:,} timed-suite outputs matched independent scalar replay.',
          'Each interval includes the public multiplication, exact equality, and result destruction.',
          'Fixture generation and the common PARI curve cache are outside both arms.',
          'Module imports are outside timing; cold means the field-generator cache, not process startup.',
          'Cold cases include removal and recreation of the field generator cache.', '',
          'All frozen gain, confidence, per-cell, CPU, and memory gates passed.',
          'RSS uses seven fresh pairs for each of two cells; median bytes are:', '']
for record in decision['rss']:
    case, median = record['case'], record['medians']
    lines.append(f'- n={case["degree"]} {case["operation"]}: baseline {median["baseline"]:,}; candidate {median["candidate"]:,}.')
lines += ['', 'Candidate v1 remains HOLD in `run-001/summary.json`; its control regressions',
          'and raw timing records are preserved. V2 broadens the direct point construction',
          'to the other standard finite-field backends, uses fresh inputs and shorter',
          'interleaved timing blocks, and retains all original acceptance thresholds.', '',
          'Validation receipts: `tests-v2-001.log`, `installed-tests-001.log`,',
          '`hardware-installed-tests-001.log` (explicit installed-backend rerun),',
          '`doctests-001.log`, `meson-build-001.log`, and `runtime-checks-003.json`.',
          'The regular Meson target was compiled separately; the installed binary is',
          'the exact independently built binary used in the accepted benchmark.', '',
          'The local user shim, repository launcher and existing experiment launcher',
          'all select the checked build. Nested `sage` commands preserve that route.',
          'The checks reject stale hashes, wrong interpreters and inherited Python',
          'package overrides. The installed receipt and runtime manifest bind the code',
          'to this decision. Previously running Python processes must be restarted.', '',
          '`profile-installed/` contains post-install diagnostics. `selected.patch` is',
          'incremental against the archived `baseline/`; `runtime-source.patch` preserves',
          'the workspace launcher on child PATH. New launcher utilities live in',
          '`experiments/sage-binary-arithmetic/`, with the repository entry point at `sage`.', '']
(HERE/'RESULT.md').write_text('\n'.join(lines))
files = [p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts
         and not any(part in ['build', 'build-v2', 'patch-check'] for part in p.relative_to(HERE).parts)
         and p.name != 'MANIFEST.json']
manifest = {str(path.relative_to(HERE)): digest(path) for path in sorted(files)}
(HERE/'MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(HERE/'RESULT.md')
