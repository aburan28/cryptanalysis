"""Post-install profiles and call counts; separate from acceptance timings."""
import cProfile
import hashlib
import json
from pathlib import Path
import pstats
import sys
from sage.all import EllipticCurve, GF, ZZ, set_random_seed
from sage.schemes.elliptic_curves import binary_batch, ell_point

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
installed_action = ell_point.EllipticCurvePoint_finite_field._acted_upon_
installed_native = binary_batch._native
import bindings_v2 as b
b.METHODS['candidate'] = installed_action
b.NATIVES['candidate'] = installed_native
sys.path.insert(0, str(ROOT/'experiments/sage-binary-hardware'))
from public_points import generate
out = HERE/'profile-installed'
out.mkdir(exist_ok=False)
set_random_seed(202609262001)
F = GF(2**131, 'z', impl='ntl')
E = EllipticCurve(F, [1, 1, 0, 0, 1])
points, unused = generate(E, 16, 202609262001)
records = []
for name, scalar, repeats in [('small_17', ZZ(17), 64),
                               ('fullwidth', ZZ(2)**130+12345, 4)]:
    b.activate('baseline')
    expected = [scalar*P for P in points]
    def checked():
        for unused in range(repeats):
            actual = [scalar*P for P in points]
            assert actual == expected
            del actual
    for arm in ['baseline', 'candidate']:
        b.activate(arm)
        checked()
        profile = cProfile.Profile()
        profile.runcall(checked)
        with (out/f'{name}-{arm}.txt').open('w') as stream:
            stats = pstats.Stats(profile, stream=stream).strip_dirs().sort_stats('tottime')
            stats.print_stats(30)
        calls = {str(key): {'calls': value[1], 'exclusive_s': value[2], 'inclusive_s': value[3]}
                 for key, value in stats.stats.items()
                 if key[2] in ['Sequence', 'normalize_coordinates', '_element_constructor_', '_acted_upon_']}
        records.append({'operation': name, 'arm': arm, 'total_s': stats.total_tt, 'calls': calls})
(out/'execution.json').write_text(json.dumps({'diagnostic_only': True, 'seed': 202609262001,
    'profiles': records, 'installed': {module.__file__: hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
                                    for module in [binary_batch, installed_native, ell_point]}}, indent=2)+'\n')
