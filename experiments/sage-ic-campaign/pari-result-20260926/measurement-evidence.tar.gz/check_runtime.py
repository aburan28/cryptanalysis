"""Exercise actual launch paths and prove stale installations are rejected."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CHECKER = ROOT/'experiments/sage-binary-arithmetic/runtime_check.py'
MANIFEST = CHECKER.with_name('runtime-current.json')
records = []
for launcher in [ROOT/'sage', ROOT/'experiments/sage-binary-arithmetic/run-sage.sh',
                 Path.home()/'.local/bin/sage']:
    # Contamination by an old app's Python settings must not select its modules.
    env = dict(os.environ, PYTHONPATH='/nonexistent/old-sage',
               PYTHONHOME='/nonexistent/old-sage', PYTHONUSERBASE='/nonexistent/old-sage')
    proc = subprocess.run([str(launcher), '--runtime-info'], env=env, check=True,
                          text=True, capture_output=True, timeout=90)
    record = json.loads(proc.stdout)
    assert record['status'] == 'verified'
    record['launcher'] = str(launcher)
    records.append(record)
child = subprocess.run(['sage', '-python', '-c',
    'import json,shutil,subprocess; print(json.dumps({"sage":shutil.which("sage"),"child":json.loads(subprocess.check_output(["sage","--runtime-info"],text=True))}))'],
    check=True, text=True, capture_output=True, timeout=90)
child = json.loads(child.stdout)
assert Path(child['sage']).resolve() == ROOT/'sage'
assert child['child']['status'] == 'verified'
with tempfile.TemporaryDirectory(prefix='sage-runtime-check-') as temp:
    tampered = json.loads(MANIFEST.read_text())
    tampered['files'][0]['sha256'] = '0'*64
    path = Path(temp)/'manifest.json'
    path.write_text(json.dumps(tampered))
    rejected = subprocess.run([sys.executable, str(CHECKER), '--manifest', str(path)],
                               capture_output=True, text=True, timeout=30)
    assert rejected.returncode == 1
    assert 'differs from the verified build' in rejected.stderr
wrong = subprocess.run(['/usr/bin/python3', str(CHECKER)],
                       capture_output=True, text=True, timeout=30)
assert wrong.returncode == 1 and 'wrong Python prefix' in wrong.stderr
output = {'launchers': records, 'nested_sage': child,
          'stale_manifest_rejected': rejected.stderr.strip(),
          'wrong_python_rejected': wrong.stderr.strip(),
          'manifest_sha256': hashlib.sha256(MANIFEST.read_bytes()).hexdigest()}
print(json.dumps(output, indent=2))
