"""Run arithmetic regressions against the actual installed methods and binary."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import unittest
from sage.all import EllipticCurve, GF
from sage.schemes.elliptic_curves import binary_batch, ell_point

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
os.environ['SAGE_BINARY_USE_INSTALLED'] = '1'
receipt = json.loads((HERE/'install-001/install.json').read_text())
for entry in receipt['files']:
    assert hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest() == entry['sha256']
installed_action = ell_point.EllipticCurvePoint_finite_field._acted_upon_
installed_native = binary_batch._native
import test_result_v2
test_result_v2.b.METHODS['candidate'] = installed_action
test_result_v2.b.NATIVES['candidate'] = installed_native
suite = unittest.defaultTestLoader.loadTestsFromModule(test_result_v2)
for directory, name in [
    ('experiments/sage-binary-point-construction', 'test_construction'),
    ('experiments/sage-binary-native-frobenius', 'test_native_frobenius'),
    ('experiments/sage-binary-hardware', 'test_hardware'),
    ('experiments/sage-ic-campaign/scalar-add-20260924', 'test_add'),
]:
    sys.path.insert(0, str(ROOT/directory))
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(name)))

class FusedRegression(unittest.TestCase):
    def test_fused_public_api(self):
        E = EllipticCurve(GF(2**5, 'z', impl='ntl'), [1, 1, 0, 0, 1])
        points = list(E)
        pairs = [(P, Q) for P in points for Q in points]
        for power in [-1, 0, 1, 7]:
            mapped = binary_batch.frobenius_points(E, (P for P, Q in pairs), power)
            self.assertEqual(binary_batch.frobenius_add_pairs(E, iter(pairs), power),
                             [P+Q for P, (_, Q) in zip(mapped, pairs)])

suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(FusedRegression))
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
