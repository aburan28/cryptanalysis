"""Complete scalar multiplication with independent verification in timing."""
import argparse
import hashlib
import json
import math
import os
import platform
import random
import resource
import statistics
import subprocess
import sys
import time
from pathlib import Path
import numpy as np
from sage.all import EllipticCurve, GF, ZZ, set_random_seed
import bindings_v2 as b
from test_result_v2 import reference

HERE = b.HERE
INTENT = json.loads((HERE/'intent-v2.json').read_text())
sys.path.insert(0, str(b.ROOT/'experiments/sage-binary-hardware'))
from public_points import generate


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fixture(case):
    degree = case['degree']
    set_random_seed(case['seed'])
    kind = case.get('kind')
    F = (GF(101) if kind == 'prime' else
         GF(2**degree, 'z', impl='pari_ffelt' if kind == 'pari_backend' else 'ntl'))
    E = EllipticCurve(F, [1, F.gen(), 1, 0, 1] if kind == 'nonkoblitz_ntl'
                      else [1, 1, 0, 0, 1])
    if kind:
        points = [E.random_point() for _ in range(16)]
    else:
        points, unused = generate(E, 16, case['seed'])
    if case['operation'] == 'cold_17':
        points = points[:1]
    k = ZZ(2)**(degree-1)+12345 if case['operation'] == 'fullwidth' else ZZ(17)
    expected = [reference(P, k) for P in points]
    E.pari_curve()
    def operation():
        if case['operation'] == 'cold_17':
            F.__dict__.pop('_binary_batch_pari_generator', None)
        return [k*P for P in points]
    return operation, expected


def worker(case, output, rss_arm):
    operation, expected = fixture(case)
    if rss_arm:
        b.activate(rss_arm)
        for unused in range(32):
            actual = operation()
            assert actual == expected
            del actual
        result = {'case': case, 'arm': rss_arm, 'exact': True,
                  'rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    else:
        for arm in ['baseline', 'candidate']:
            b.activate(arm)
            assert operation() == expected
        orders = [('baseline', 'candidate'), ('candidate', 'baseline')]*6
        random.Random(case['seed']).shuffle(orders)
        trials = []
        repeats = {'small_17': 512, 'cold_17': 4096, 'fullwidth': 32}[case['operation']]
        for order in orders:
            row = {'order': order, 'wall': {'baseline': 0, 'candidate': 0},
                   'cpu': {'baseline': 0, 'candidate': 0}, 'blocks': []}
            for block in range(16):
                block_order = order if block % 2 == 0 else order[::-1]
                sample = {'order': block_order, 'wall': {}, 'cpu': {}}
                for arm in block_order:
                    b.activate(arm)
                    cpu0 = time.process_time_ns()
                    wall0 = time.perf_counter_ns()
                    for unused in range(repeats//16):
                        actual = operation()
                        assert actual == expected
                        del actual
                    sample['wall'][arm] = (time.perf_counter_ns()-wall0)/1e9
                    sample['cpu'][arm] = (time.process_time_ns()-cpu0)/1e9
                    row['wall'][arm] += sample['wall'][arm]
                    row['cpu'][arm] += sample['cpu'][arm]
                row['blocks'].append(sample)
            trials.append(row)
        result = {'case': case, 'exact': True, 'trials': trials,
                  'speedup': math.exp(statistics.median(math.log(t['wall']['baseline']/t['wall']['candidate']) for t in trials)),
                  'cpu_ratio': statistics.median(t['cpu']['candidate']/t['cpu']['baseline'] for t in trials),
                  'verified_outputs': len(expected)*(2+24*repeats)}
    output.write_text(json.dumps(result, indent=2)+'\n')


def aggregate(rows):
    matrix = np.array([[math.log(t['wall']['baseline']/t['wall']['candidate'])
                        for t in r['trials']] for r in rows])
    rng = np.random.default_rng(202609260501)
    indices = rng.integers(0, 12, (5000, 12))
    boot = np.exp(np.median(matrix[:, indices], axis=2).mean(axis=0))
    return {'geomean': float(np.exp(np.median(matrix, axis=1).mean())),
            'ci95': [float(v) for v in np.quantile(boot, [.025, .975])]}


def launch(case, path, arm=None):
    command = [sys.executable, __file__, '--case', json.dumps(case), '--output', str(path)]
    if arm:
        command += ['--rss-arm', arm]
    with path.with_suffix('.log').open('w') as stream:
        try:
            proc = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
            status = proc.returncode
        except subprocess.TimeoutExpired:
            status = 'timeout'
    if status != 0:
        path.with_suffix('.failure.json').write_text(json.dumps({'case': case, 'status': status, 'arm': arm})+'\n')
        raise RuntimeError(f'worker failed: {path}')
    return json.loads(path.read_text())


def parent(out):
    out.mkdir(exist_ok=False)
    files = [HERE/n for n in ['intent-v2.json', 'bindings_v2.py', 'benchmark_v2.py', 'test_result_v2.py']]
    for arm in ['baseline', 'candidate-v2']:
        files.extend(p for p in (HERE/arm).iterdir() if p.suffix in ['.py', '.pyx', '.so'])
    hashes = {str(p): digest(p) for p in files}
    (out/'execution.json').write_text(json.dumps({'hashes': hashes, 'platform': platform.platform(),
        'python': sys.version, 'executable': sys.executable}, indent=2)+'\n')
    rows = []
    for phase in ['primary', 'confirmation']:
        for spec in INTENT[phase+'_cases']:
            for op in INTENT['operations']:
                case = dict(spec, phase=phase, operation=op)
                row = launch(case, out/f'cell-{len(rows):02d}.json')
                rows.append(row)
                print(case, row['speedup'], flush=True)
    for spec in INTENT['controls']:
        case = dict(spec, phase='control', operation='small_17')
        row = launch(case, out/f'cell-{len(rows):02d}.json')
        rows.append(row)
        print(case, row['speedup'], flush=True)
    rss = []
    for index in [3, 10]:
        case = rows[index]['case']
        measurements = {'baseline': [], 'candidate': []}
        for repetition in range(7):
            arms = ['baseline', 'candidate'] if repetition % 2 == 0 else ['candidate', 'baseline']
            for arm in arms:
                record = launch(case, out/f'rss-{index}-{repetition}-{arm}.json', arm)
                measurements[arm].append(record['rss_bytes'])
        medians = {arm: statistics.median(values) for arm, values in measurements.items()}
        rss.append({'case': case, 'measurements': measurements, 'medians': medians,
                    'passed': medians['candidate'] <= max(1.05*medians['baseline'], medians['baseline']+2*1024**2)})
    aggregates = {phase: aggregate([r for r in rows if r['case']['phase'] == phase])
                  for phase in ['primary', 'confirmation']}
    gates = {'primary': aggregates['primary']['geomean'] > 1.02 and aggregates['primary']['ci95'][0] > 1,
             'confirmation': aggregates['confirmation']['geomean'] > 1.01 and aggregates['confirmation']['ci95'][0] > 1,
             'cells': all(r['speedup'] >= .98 for r in rows),
             'cpu': all(r['cpu_ratio'] <= 1.05 for r in rows),
             'rss': all(r['passed'] for r in rss)}
    assert all(digest(p) == h for p, h in hashes.items())
    summary = {'status': 'PASS_LOCAL' if all(gates.values()) else 'HOLD', 'gates': gates,
               'aggregates': aggregates, 'rss': rss, 'all_exact': True,
               'verified_outputs': sum(r['verified_outputs'] for r in rows),
               'cells': [{k:v for k,v in r.items() if k != 'trials'} for r in rows]}
    (out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--case')
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--rss-arm', choices=['baseline', 'candidate'])
    args = parser.parse_args()
    if args.case:
        worker(json.loads(args.case), args.output, args.rss_arm)
    else:
        parent(args.output)
