"""Freeze intent and archive the installed incumbent before implementation."""
import hashlib
import json
import shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
source = ROOT / 'third_party/sage-binary/src/sage/schemes/elliptic_curves'
installed = ROOT / 'third_party/sage-binary/local/var/lib/sage/venv-python3.14/lib/python3.14/site-packages/sage/schemes/elliptic_curves'
for name in ['baseline', 'candidate']:
    dest = HERE / name
    dest.mkdir()
    for filename in ['ell_point.py', 'binary_batch_ntl.pyx']:
        assert (source / filename).read_bytes() == (installed / filename).read_bytes()
        shutil.copy2(source / filename, dest / filename)
    if name == 'baseline':
        for path in installed.glob('binary_batch_ntl*.so'):
            shutil.copy2(path, dest / path.name)
profile = HERE.parent / 'five-opportunities-20260925/profile-installed/scalar_mul_17.txt'
intent = {
    'step_id': HERE.name, 'status': 'intent frozen before implementation and timing',
    'scope': 'complete public scalar multiplication; arithmetic component only',
    'incumbent': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in (HERE / 'baseline').iterdir()},
    'mechanism': 'Convert PARI binary FFELT result words directly to NTL coordinates and initialize the standard affine point. Remove polynomial evaluation, Sequence and redundant normalization. Retain fallback for other fields and custom constructors.',
    'profile': {'path': str(profile.relative_to(ROOT)),
                'sha256': hashlib.sha256(profile.read_bytes()).hexdigest(),
                'total_s': 1.182, 'Sequence_inclusive_s': .239,
                'point_constructor_inclusive_s': .147,
                'disjoint_hotspot_share': .327,
                'prediction_if_half_eliminated': 1 / (1 - .327 / 2)},
    'invariants': ['Exact coordinates, type, parent, hashing, serialization',
                   'Zero, infinity, negative scalars, torsion, custom point classes',
                   'Cached order n/gcd(n,k) retained',
                   'Restore NTL context after Python callbacks',
                   'Check PARI field metadata before raw conversion; fallback otherwise',
                   'Independent generic-addition scalar replay; same completed work'],
    'primary_cases': [{'degree': 19, 'seed': 202609260101},
                      {'degree': 131, 'seed': 202609260102}],
    'confirmation_cases': [{'degree': 31, 'seed': 202609260201},
                           {'degree': 163, 'seed': 202609260202}],
    'operations': ['small_17', 'fullwidth', 'cold_17'],
    'controls': [{'kind': 'prime', 'degree': 19, 'seed': 202609260301},
                 {'kind': 'pari_backend', 'degree': 19, 'seed': 202609260302},
                 {'kind': 'nonkoblitz_ntl', 'degree': 19, 'seed': 202609260303}],
    'timing': 'Fresh worker per cell. Fixtures and independent references outside timing. Complete k*P, exact comparison and destruction inside. Cold resets generator cache each call and charges recreation. Warm both arms equally. 12 balanced AB/BA rounds; 128 repetitions of 16 points warm or one point cold.',
    'resources': {'cpu_threads': 1, 'cell_timeout_s': 240, 'rss_fresh_pairs': 7,
                  'rss_cases': ['primary n131 small_17', 'confirmation n163 fullwidth'],
                  'disk_limit_MiB': 150, 'benchmark_budget_minutes': 15},
    'criteria': {'primary_geomean_gt': 1.02, 'confirmation_geomean_gt': 1.01,
                 'both_ci95_lower_gt': 1, 'every_cell_ge': .98,
                 'every_cell_cpu_ratio_le': 1.05,
                 'rss_median_candidate_le': 'max(1.05 * baseline, baseline + 2 MiB)',
                 'bootstrap': 5000, 'rounds': 12},
    'decision': 'PASS_LOCAL requires correctness and all gates; otherwise HOLD/REJECT. Preserve all attempts; install only after PASS_LOCAL.'}
path = HERE / 'intent-v1.json'
path.write_text(json.dumps(intent, indent=2) + '\n')
(HERE / 'intent-v1.sha256').write_text(hashlib.sha256(path.read_bytes()).hexdigest() + '\n')
print(path)
