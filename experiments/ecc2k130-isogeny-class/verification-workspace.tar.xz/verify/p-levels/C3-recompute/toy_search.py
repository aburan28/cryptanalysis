# search Koblitz toys y^2+xy=x^3+a x^2+1 over F_{2^m} with small l | f (t^2-4q = -7 f^2)
import math
def trace(m, a):
    n1 = 1 + sum(1 for x in (0,1) for y in (0,1) if (y*y+x*y+x**3+a*x*x+1)%2==0)
    t1 = 3 - n1; s=[2,t1]
    for k in range(2,m+1): s.append(t1*s[-1]-2*s[-2])
    return s[m]
def kron(a,n):
    a%=n; res=1
    while a:
        while a%2==0:
            a//=2
            if n%8 in (3,5): res=-res
        a,n=n,a
        if a%4==3 and n%4==3: res=-res
        a%=n
    return res if n==1 else 0
def order(g,n):
    k=1; x=g%n
    while x!=1: x=x*g%n; k+=1
    return k
primes=[x for x in range(3,120) if all(x%d for d in range(2,int(x**.5)+1))]
for m in range(3,64):
    if not all(m%d for d in range(2,int(m**.5)+1)): pass
    for a in (0,1):
        t=trace(m,a); q=2**m; D=t*t-4*q
        if D % -7: continue
        f2=D//-7; f=math.isqrt(f2)
        if f*f!=f2: continue
        for l in primes:
            if l==7 or f%l: continue
            if (f//l)%l==0: continue
            c=t*pow(2,-1,l)%l
            r=order(c,l); d = r//2 if (r%2==0) else r
            others=[x for x in primes if x!=l and x!=7 and f%x==0 and x<60]
            print(f"m={m} a={a} l={l} kron={kron(-7,l)} r={r} d={d} (l-1)/r={(l-1)//r} m*r={m*r} m*d*l={m*d*l} other_small_l={others}")
