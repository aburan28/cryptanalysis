# Lean variant of toy_c3.py for larger l (no full factorisation of psi_l): distinct-degree split via gcds.
# Usage: sage -python toy_large_l.py <m> <a2> <l>
import sys, json, time
from sage.all import GF, EllipticCurve, PolynomialRing, ZZ, Integer, matrix, Zmod, set_random_seed, factor, prod
set_random_seed(20260923)
T0 = time.time()
m = int(sys.argv[1]); a2i = int(sys.argv[2]); l = int(sys.argv[3]); q = 2**m
out = {'m': m, 'a2': a2i, 'l': l}
n1 = 1 + sum(1 for x in (0, 1) for y in (0, 1) if (y*y + x*y + x**3 + a2i*x*x + 1) % 2 == 0)
t1 = 3 - n1
def s_seq(k):
    a, b = 2, t1
    for _ in range(k): a, b = b, t1*b - 2*a
    return a
t = s_seq(m)
def card(k): return q**k + 1 - s_seq(m*k)
D = t*t - 4*q; f = Integer(D // -7).isqrt(); assert f*f == D // -7 and f % l == 0 and (f//l) % l
c = t * pow(2, -1, l) % l; assert (c*c - q) % l == 0
r = int(Zmod(l)(c).multiplicative_order()); d = r//2 if r % 2 == 0 else r
if r % 2 == 0: assert pow(c, r//2, l) == l-1
def vl(n):
    n = Integer(n); v = 0
    while n % l == 0: n //= l; v += 1
    return v
out.update({'t': t, 'factor_f': str(factor(f)), 'kron(-7,l)': int(ZZ(-7).kronecker(l)), 'c': c, 'r': r, 'd': d,
            'v_l #E(F_q^k), k | r': {int(k): vl(card(k)) for k in ZZ(r).divisors()}})
K = GF(2**m, 'z'); E0 = EllipticCurve(K, [1, a2i, 0, 0, 1]); assert E0.order() == card(1)
def embed(Lf):
    phi = K.hom([K.gen().minpoly().any_root(Lf)])
    Mt = matrix(GF(2), [list(phi(K.gen()**i)._vector_()) for i in range(m)])
    def back(y):
        sol = Mt.solve_left(y._vector_()); return sum(K(int(sol[i]))*K.gen()**i for i in range(m))
    return phi, back
L = GF(2**(m*r), 'Z'); phi, back = embed(L)
NL = card(r); v = vl(NL); cof = NL // l**v
out['v_l #E(F_{q^r})'] = v
EL0 = EllipticCurve(L, [phi(a) for a in E0.a_invariants()])
while True:
    P = cof*EL0.random_point()
    if P.is_zero(): continue
    while not (l*P).is_zero(): P = l*P
    break
xs = [(k*P)[0] for k in range(1, (l-1)//2 + 1)]
vsum = back(sum(xs))
E1 = EllipticCurve(K, [1, a2i, 0, vsum, 1 + vsum])
RL = PolynomialRing(L, 'X'); h = prod(RL.gen() - x for x in xs)
for co in h.list(): assert co**q == co
hK = PolynomialRing(K, 'X')([back(co) for co in h.list()])
assert E0.isogeny(hK).codomain().j_invariant() == E1.j_invariant()
out['j(E1) != j(E0)'] = bool(E1.j_invariant() != E0.j_invariant())
R = PolynomialRing(K, 'X'); X = R.gen()
def frob_powers(psi, exps):
    # returns {e: X^(q^e) mod psi} by iterated squaring (m squarings per q-power)
    want = sorted(set(exps)); res = {}; y = X % psi; done = 0
    for e in want:
        for _ in range(m*(e - done)): y = (y*y) % psi
        done = e; res[e] = y
    return res
for name, E in [('E0', E0), ('E1', E1)]:
    t_ = time.time(); res = {}
    psi = R(E.division_polynomial(l)); res['deg psi_l'] = int(psi.degree())
    ks = [d, r] + ([l*d] + [k*d for k in (2,3,5,7,11) if k < l] if name == 'E1' else [])
    FP = frob_powers(psi, ks)
    Xqd = FP[d]
    g = psi.gcd(Xqd - X); res['deg gcd(psi, X^{q^d}-X)'] = int(g.degree())
    Xqr = FP[r]
    g2 = psi.gcd(Xqr - X); res['deg gcd(psi, X^{q^r}-X) (x-roots in F_{q^r})'] = int(g2.degree())
    if name == 'E1':
        fa = g.factor(); res['factor degrees of degree-d part'] = sorted(int(u.degree()) for u, e in fa)
        vs = g.list()[-2]
        Eup = EllipticCurve(K, [1, a2i, 0, E.a4() + vs, E.a6() + vs])
        res['j(up) == j(E0)'] = bool(Eup.j_invariant() == E0.j_invariant())
        # remaining roots: all have degree l*d?  check gcd with X^{q^{l d}} - X covers psi entirely
        Xqld = FP[l*d]
        res['deg gcd(psi, X^{q^{l d}}-X)'] = int(psi.gcd(Xqld - X).degree())
        # and no root of degree k*d for 1 < k < l (would show as extra gcd degree)
        extra = {}
        for k in (2, 3, 5, 7, 11):
            if k < l:
                extra[k] = int(psi.gcd(FP[k*d] - X).degree())
        res['deg gcd(psi, X^{q^{k d}}-X) for small k'] = extra
        EL1 = EllipticCurve(L, [phi(a) for a in E.a_invariants()]); maxo = 0
        for _ in range(12):
            Q = cof*EL1.random_point(); k = 0
            while not Q.is_zero(): Q = l*Q; k += 1
            maxo = max(maxo, k)
        res['max l-power exponent of points in E1(F_{q^r})'] = maxo
    res['seconds'] = round(time.time() - t_, 1)
    out[name] = res
out['seconds_total'] = round(time.time() - T0, 1)
json.dump(out, open(f'/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C3-recompute/toylarge_m{m}_a{a2i}_l{l}.json', 'w'), indent=1, default=str)
print('WROTE', json.dumps(out, default=str))
