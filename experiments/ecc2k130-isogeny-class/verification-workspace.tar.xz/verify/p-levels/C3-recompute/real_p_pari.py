# Cross-check of real_p.py numbers with PARI (different code path).
from sage.all import pari
import json
gp = pari
res = {}
gp('q = 2^131')
gp('E2 = ellinit([1,0,0,0,1], 2); n1 = ellcard(E2); a1 = 2+1-n1')
gp('Kpol = x^2 - a1*x + 2; pi131 = Mod(x,Kpol)^131; t = trace(pi131)')
gp('f2 = (t^2-4*q)/(-7); f = sqrtint(f2); p = f/263')
res['t'] = str(gp('t')); res['f^2==f2'] = str(gp('f^2==f2')); res['p'] = str(gp('p'))
res['isprime(p)'] = str(gp('isprime(p)')); res['kronecker(-7,p)'] = str(gp('kronecker(-7,p)'))
gp('c = lift(Mod(t,p)/2)')
res['c'] = str(gp('c')); res['znorder'] = str(gp('znorder(Mod(c,p))'))
res['factor(p-1)'] = str(gp('factor(p-1)'))
gp('r = znorder(Mod(c,p))')
res['(p-1)/r'] = str(gp('(p-1)/r')); res['Mod(c,p)^(r/2)'] = str(gp('Mod(c,p)^(r/2)'))
gp('P3 = p^3; pir = Mod(Mod(1,P3)*x, Mod(1,P3)*(x^2 - t*x + q))^r; nr = norm(1 - pir)')
res['norm(1-pi^r) mod p^3'] = str(gp('lift(nr)'))
res['v_p'] = str(gp('valuation(lift(nr), p)'))
gp('nrm(z) = my(L = lift(lift(z)), a = polcoef(L,0), b = polcoef(L,1)); a^2 + a*b*t + b^2*q')
gp('vk(k, e) = my(z = 1 - Mod(Mod(1,p^e)*x, Mod(1,p^e)*(x^2 - t*x + q))^k); valuation(lift(Mod(nrm(z), p^e)), p)')
res['norm formula == PARI norm at k=r'] = str(gp('lift(Mod(nrm(1-pir),P3)) == lift(nr)'))
for lab, k in [('r', 'r'), ('r/2', 'r/2'), ('r/5', 'r/5'), ('r/17', 'r/17'), ('r/289510489', 'r/289510489'), ('r*p', 'r*p'), ('r*p^2', 'r*p^2')]:
    res['v_p #E(F_q^k), k=' + lab + ' (mod p^8)'] = str(gp('vk(%s, 8)' % k))
json.dump(res, open('/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C3-recompute/real_p_pari.json','w'), indent=1)
for k,v in res.items(): print(k, ':', v)
