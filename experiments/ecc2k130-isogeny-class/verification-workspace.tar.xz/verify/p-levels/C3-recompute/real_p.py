# Independent recomputation of the real-p numbers behind claim C3.
# Plain python3 only (no Sage / PARI), own primality test, own factoring,
# own quadratic-order arithmetic.  Run: python3 real_p.py
import json, math, random, sys, time

random.seed(20260923)
t0 = time.time()
q = 2**131
m = 131

# ---- trace of Frobenius from #E0(F_2) by brute force + Lucas recurrence ----
def count_F2(a2, b):
    # y^2 + x y = x^3 + a2 x^2 + b over F_2, projective count
    n = 1
    for x in (0, 1):
        for y in (0, 1):
            if (y*y + x*y + x**3 + a2*x*x + b) % 2 == 0:
                n += 1
    return n
n1 = count_F2(0, 1)
t1 = 2 + 1 - n1
s = [2, t1]
for k in range(2, m + 1):
    s.append(t1*s[-1] - 2*s[-2])
t = s[m]
D = t*t - 4*q
assert D % (-7) == 0
f2 = D // (-7)
f = math.isqrt(f2)
assert f*f == f2

# ---- Miller-Rabin (deterministic bases for n < 3.3e24) + Pollard rho ----
def is_probable_prime(n):
    if n < 2: return False
    small = [2,3,5,7,11,13,17,19,23,29,31,37,41]
    for pr in small:
        if n % pr == 0: return n == pr
    d, r_ = n-1, 0
    while d % 2 == 0: d//=2; r_+=1
    bases = small if n < 3317044064679887385961981 else small + [random.randrange(2, n-1) for _ in range(30)]
    for a in bases:
        x = pow(a, d, n)
        if x in (1, n-1): continue
        for _ in range(r_-1):
            x = x*x % n
            if x == n-1: break
        else:
            return False
    return True

def rho(n):
    if n % 2 == 0: return 2
    while True:
        x = random.randrange(2, n); y = x; c = random.randrange(1, n); d = 1
        while d == 1:
            x = (x*x + c) % n; y = (y*y + c) % n; y = (y*y + c) % n
            d = math.gcd(abs(x-y), n)
        if d != n: return d

def factor(n):
    fs = {}
    for pr in range(2, 10000):
        while n % pr == 0:
            fs[pr] = fs.get(pr, 0) + 1; n //= pr
    stack = [n] if n > 1 else []
    while stack:
        x = stack.pop()
        if x == 1: continue
        if is_probable_prime(x):
            fs[x] = fs.get(x, 0) + 1; continue
        d = rho(x); stack += [d, x//d]
    return dict(sorted(fs.items()))

ff = factor(f)
assert 263 in ff
p = f // 263
assert is_probable_prime(p) and p < 3317044064679887385961981  # deterministic MR range

def kron(a, n):  # Jacobi symbol, n odd positive
    a %= n; res = 1
    while a:
        while a % 2 == 0:
            a //= 2
            if n % 8 in (3, 5): res = -res
        a, n = n, a
        if a % 4 == 3 and n % 4 == 3: res = -res
        a %= n
    return res if n == 1 else 0

# ---- eigenvalue c: char poly x^2 - t x + q = (x - t/2)^2 mod p ----
c = t * pow(2, -1, p) % p
assert (c*c - q) % p == 0
c_alt = ((t - f)//2) % p          # pi = (t-f)/2 + f*omega in Z[omega]
assert c == c_alt

pm1 = factor(p - 1)
def order_mod(g, n, nfac):  # order of g in (Z/n)^*, n prime, nfac = factorization of n-1
    o = n - 1
    for pr, e in nfac.items():
        for _ in range(e):
            if pow(g, o // pr, n) == 1: o //= pr
            else: break
    return o
r = order_mod(c, p, pm1)
# brute cross-check of the order by its definition on divisors
assert pow(c, r, p) == 1
for pr in pm1:
    if r % pr == 0: assert pow(c, r//pr, p) != 1
r_even = (r % 2 == 0)
minus1_in = pow(c, r//2, p) == p-1 if r_even else False
ord_pm = r//2 if (r_even and minus1_in) else r   # order of c in F_p^*/{+-1}
n_factors = ((p-1)//2) // ord_pm

# ---- v_p(#E(F_{q^r})) method 1: Lucas sequence s_k = pi^k + pibar^k mod p^3 ----
M = p**3
def matmul(A, B, mod):
    return [[(A[0][0]*B[0][0] + A[0][1]*B[1][0]) % mod, (A[0][0]*B[0][1] + A[0][1]*B[1][1]) % mod],
            [(A[1][0]*B[0][0] + A[1][1]*B[1][0]) % mod, (A[1][0]*B[0][1] + A[1][1]*B[1][1]) % mod]]
def matpow(A, e, mod):
    R = [[1,0],[0,1]]
    while e:
        if e & 1: R = matmul(R, A, mod)
        A = matmul(A, A, mod); e >>= 1
    return R
def s_k(k, mod):
    # [s_{k+1}, s_k]^T = T^k [s_1, s_0]^T with T = [[t,-q],[1,0]]
    T = [[t % mod, (-q) % mod], [1, 0]]
    Tk = matpow(T, k, mod)
    return (Tk[1][0]*t + Tk[1][1]*2) % mod
def vp_mod(x, pr, mod):
    x %= mod
    if x == 0: return '>=' + str(round(math.log(mod, pr)))
    v = 0
    while x % pr == 0: x //= pr; v += 1
    return v
cardE_r_mod = (pow(q, r, M) + 1 - s_k(r, M)) % M
v1 = vp_mod(cardE_r_mod, p, M)

# ---- method 2: arithmetic in Z[omega], omega^2 = omega - 2; Norm(x+y w) = x^2 + x y + 2 y^2 ----
def zmul(A, B, mod):
    a, b = A; c_, d = B
    # (a + b w)(c + d w) = ac + (ad+bc) w + bd w^2 = (ac - 2bd) + (ad + bc + bd) w
    return ((a*c_ - 2*b*d) % mod, (a*d + b*c_ + b*d) % mod)
def zpow(A, e, mod):
    R = (1, 0)
    while e:
        if e & 1: R = zmul(R, A, mod)
        A = zmul(A, A, mod); e >>= 1
    return R
pi_elt = ((t - f)//2, f)
# sanity: pi has norm q and trace t
a_, b_ = pi_elt
assert a_*a_ + a_*b_ + 2*b_*b_ == q
assert 2*a_ + b_ == t
A_r, B_r = zpow(pi_elt, r, M)
x_, y_ = (1 - A_r) % M, (-B_r) % M
norm2 = (x_*x_ + x_*y_ + 2*y_*y_) % M
v2 = vp_mod(norm2, p, M)
assert norm2 == cardE_r_mod
# also pi^r mod p O_K should be 1 (c^r = 1) and pi^r mod p^2 O_K should not be in Z + p^2 O_K-type trivial
Ar1, Br1 = zpow(pi_elt, r, p)
# valuation at primes above p separately (p split or inert?)
kr = kron(-7, p)

# ---- Jordan-block matrices of pi on E[p] = O/pO (Lenstra: E[n] ~ O/nO for ordinary E, End = O) ----
# O = Z + g*O_K, basis {1, g*omega}; pi = A + B*omega with g | B
def pi_matrix(g):
    A, B = pi_elt
    assert B % g == 0
    # pi*1 = A*1 + (B/g)*(g w);  pi*(g w) = g(A w + B w^2) = g(A w + B(w - 2)) = (A+B)(g w) - 2 g B
    # mod pO = pZ + p g O_K: the term -2gB (integer) and B*(g w) where p g | g B?  write generally:
    # columns = images of basis vectors in coordinates (1, g w), reduced mod p
    col1 = (A % p, (B//g) % p)
    # (A+B)(g w) - 2gB  -> coords: const -2gB, gw-coord A+B
    col2 = ((-2*g*B) % p, (A + B) % p)
    return [[col1[0], col2[0]], [col1[1], col2[1]]]
mats = {}
for name, g in [('conductor_1', 1), ('conductor_263', 263), ('conductor_p', p), ('conductor_263p', 263*p)]:
    Mx = pi_matrix(g)
    tr = (Mx[0][0] + Mx[1][1]) % p
    det = (Mx[0][0]*Mx[1][1] - Mx[0][1]*Mx[1][0]) % p
    Nm = [[(Mx[0][0]-c) % p, Mx[0][1]], [Mx[1][0], (Mx[1][1]-c) % p]]
    nonzero = any(v % p for row in Nm for v in row)
    N2 = matmul(Nm, Nm, p)
    mats[name] = {'matrix_mod_p': Mx, 'trace_mod_p': tr, 'det_mod_p': det,
                  'pi_minus_c_is_zero_on_E[p]': not nonzero,
                  '(pi_minus_c)^2_zero': all(v % p == 0 for row in N2 for v in row)}

out = {
    'script': 'real_p.py (plain python3, own MR/rho, own Z[omega] arithmetic)',
    'n1_E0_F2': n1, 't1': t1, 't': t, 'f': f, 'factor_f': {str(k): v for k, v in ff.items()},
    'p': p, 'p_prime_MR_deterministic': True, 'log2_p': math.log2(p),
    'kronecker(-7,p)': kr,
    'c = t/2 mod p': c, 'c^2 == q mod p': True,
    'factor_p_minus_1': {str(k): v for k, v in pm1.items()},
    'r = ord_p(c)': r, '(p-1)/r': (p-1)//r, 'r_even': r_even, 'c^(r/2) == -1': minus1_in,
    'order_of_c_in_Fp*/{+-1} (= deg of x(P) over F_q)': ord_pm,
    'kernel_poly_degree (p-1)/2': (p-1)//2,
    'num_irreducible_factors_of_kernel_poly': n_factors,
    'full_E[p]_field_degree_over_F_q = lcm(r,p)': r*p // math.gcd(r, p),
    'x-coord degree of non-kernel p-torsion = lcm(ord_pm, p)': ord_pm*p // math.gcd(ord_pm, p),
    '#E(F_q^r) mod p^3 (Lucas)': cardE_r_mod, 'v_p #E(F_q^r) (Lucas)': v1,
    'v_p #E(F_q^r) (Z[omega] norm)': v2,
    'pi^r mod p O_K': [Ar1, Br1],
    'pi_action_on_E[p]': mats,
    'seconds': time.time() - t0,
}
json.dump(out, open('/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C3-recompute/real_p.json', 'w'), indent=1, default=str)
for k, v in out.items(): print(k, ':', v)
