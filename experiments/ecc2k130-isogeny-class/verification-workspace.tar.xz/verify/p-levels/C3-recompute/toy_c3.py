# Independent toy test of claim C3 (own code; does NOT reuse p-levels/toy_volcano.sage).
# Koblitz curves E0: y^2 + xy = x^3 + a2 x^2 + 1 over F_{2^m}; l | f with v_l(f) = 1, l inert in Q(sqrt(-7)).
# Descent by hand-written char-2 Velu from a random line of E0[l] (all l+1 lines descend when l is inert).
# On the descended curve E1 (conductor l) and on E12 (conductor l*l2) we check:
#   (a) factor-degree pattern of the l-division polynomial over F_q (Galois action of pi on E[l]):
#       Jordan block predicts (l-1)/(2d) factors of degree d and (l-1)/(2d) of degree l*d;
#       scalar action (crater) predicts (l^2-1)/(2d) factors of degree d.  d = order of c in F_l^*/{+-1}.
#   (b) the product of the degree-d factors is a kernel polynomial whose Velu codomain is back up the volcano;
#       no other F_q-rational l-subgroup can exist (all other orbits have size l*d > (l-1)/2).
#   (c) E1(F_{q^r})[l^oo] cyclic of order l^{v_l #E(F_{q^r})} (count of l-torsion x-roots in F_{q^r}, point of order l^2,
#       and Sage abelian_group as a second route).
#   (d) no l-torsion over F_{q^k} for proper divisors k of r.
#   (e) (small toys only) full E1[l] over F_{q^{r l}}: explicit matrix of Frobenius on a basis = Jordan block, eigenvalue c.
# Usage: sage -python toy_c3.py <m> <a2> <l> [<l2>|0] [full]
import sys, json, time, math
from sage.all import (GF, EllipticCurve, PolynomialRing, ZZ, Integer, matrix, Zmod, set_random_seed, factor, prod)

set_random_seed(20260923)
T0 = time.time()
m = int(sys.argv[1]); a2i = int(sys.argv[2]); l = int(sys.argv[3])
l2 = int(sys.argv[4]) if len(sys.argv) > 4 and sys.argv[4] not in ('full', '0') else None
do_full = 'full' in sys.argv
q = 2**m
out = {'m': m, 'a2': a2i, 'l': l, 'l2': l2}

n1 = 1 + sum(1 for x in (0, 1) for y in (0, 1) if (y*y + x*y + x**3 + a2i*x*x + 1) % 2 == 0)
t1 = 3 - n1
def s_seq(k):
    a, b = 2, t1
    for _ in range(k): a, b = b, t1*b - 2*a
    return a  # s_k = tau^k + taubar^k
t = s_seq(m)
def card(k):  # #E(F_{q^k}) for every curve isogenous to E0 over F_q
    return q**k + 1 - s_seq(m*k)
D = t*t - 4*q
assert D % (-7) == 0
f = Integer(D // -7).isqrt(); assert f*f == D // -7
assert f % l == 0 and (f // l) % l != 0
out['t'] = t; out['f'] = int(f); out['factor_f'] = str(factor(f))
def kron(a, n): return int(ZZ(a).kronecker(n))
out['kron(-7,l)'] = kron(-7, l)
c = t * pow(2, -1, l) % l
assert (c*c - q) % l == 0
r = int(Zmod(l)(c).multiplicative_order())
d = r // 2 if (r % 2 == 0) else r
if r % 2 == 0: assert pow(c, r//2, l) == l - 1
out.update({'c': c, 'r': r, 'd_ord_pm': d})
def vl(n, p_=l):
    n = Integer(n); v = 0
    while n % p_ == 0: n //= p_; v += 1
    return v
out['v_l #E(F_q^k) for k|r'] = {int(k): vl(card(k)) for k in ZZ(r).divisors()}

K = GF(2**m, 'z')
E0 = EllipticCurve(K, [1, a2i, 0, 0, 1])
assert E0.order() == card(1)  # Sage point count agrees with Lucas

def embed(Lfield):
    phi = K.hom([K.gen().minpoly().any_root(Lfield)])
    rows = [list(phi(K.gen()**i)._vector_()) for i in range(m)]
    Mt = matrix(GF(2), rows)  # m x n
    def back(y):
        sol = Mt.solve_left(y._vector_())
        return sum(K(int(sol[i])) * K.gen()**i for i in range(m))
    return phi, back

def velu_down(E, ell, kname):
    """Pick a random line of E[ell] (E on the crater at ell so pi acts as scalar), return codomain over K."""
    cc = t * pow(2, -1, ell) % ell
    rr = int(Zmod(ell)(cc).multiplicative_order())
    L = GF(2**(m*rr), 'Z')
    phi, back = embed(L)
    EL = EllipticCurve(L, [phi(a) for a in E.a_invariants()])
    NL = card(rr); v = vl(NL, ell)
    cof = NL // ell**v
    while True:
        P = cof * EL.random_point()
        if P.is_zero(): continue
        while not (ell * P).is_zero(): P = ell * P
        break
    xs = [(k*P)[0] for k in range(1, (ell-1)//2 + 1)]
    R = PolynomialRing(L, 'X'); X = R.gen()
    h = prod(X - x for x in xs)
    for co in h.list(): assert co**q == co   # kernel polynomial is F_q-rational
    hK = PolynomialRing(K, 'X')([back(co) for co in h.list()])
    vsum = back(sum(xs))
    a1_, a2_, a3_, a4_, a6_ = E.a_invariants(); assert a1_ == 1 and a3_ == 0
    Ec = EllipticCurve(K, [1, a2_, 0, a4_ + vsum, a6_ + vsum])   # char-2 Velu, a1=1, a3=0
    js = E.isogeny(hK).codomain().j_invariant()                  # cross-check with Sage
    assert js == Ec.j_invariant(), kname
    return Ec, hK

E1, h01 = velu_down(E0, l, 'E0->E1')
out['j(E1) != j(E0)'] = bool(E1.j_invariant() != E0.j_invariant())
curves = {'E0': E0, 'E1': E1}
if l2:
    assert f % l2 == 0 and (f // l2) % l2 != 0
    out['kron(-7,l2)'] = kron(-7, l2)
    E12, _ = velu_down(E1, l2, 'E1->E12')
    curves['E12'] = E12

def analyse(name, E):
    res = {}
    t_ = time.time()
    psi = E.division_polynomial(l)
    fac = psi.factor()
    degs = {}
    for g, e in fac:
        assert e == 1
        dg = int(g.degree()); degs[dg] = degs.get(dg, 0) + 1
    res['psi_l degree'] = psi.degree()
    res['factor degree pattern {deg: count}'] = dict(sorted(degs.items()))
    res['pattern == Jordan prediction'] = (degs == {d: (l-1)//(2*d), l*d: (l-1)//(2*d)})
    res['pattern == scalar prediction'] = (degs == {d: (l*l-1)//(2*d)})
    if res['pattern == Jordan prediction']:
        hup = prod(g for g, e in fac if g.degree() == d)
        res['ascending kernel poly degree'] = hup.degree()
        vsum = hup.list()[-2]  # sum of roots (char 2)
        a1_, a2_, a3_, a4_, a6_ = E.a_invariants()
        Eup = EllipticCurve(K, [1, a2_, 0, a4_ + vsum, a6_ + vsum])
        assert E.isogeny(hup).codomain().j_invariant() == Eup.j_invariant()
        res['j(up) == j(E0)'] = bool(Eup.j_invariant() == E0.j_invariant())
        res['j(up) == j(E1)'] = bool(Eup.j_invariant() == E1.j_invariant())
        psi_up = Eup.division_polynomial(l).factor()
        res['up-curve l-pattern is scalar (crater at l)'] = sorted({g.degree() for g, e in psi_up}) == [d]
        if l2:
            psi_up2 = Eup.division_polynomial(l2).factor()
            res['up-curve l2-factor degrees'] = sorted({g.degree() for g, e in psi_up2})
        L = GF(2**(m*r), 'Z'); phi, back = embed(L)
        EL = EllipticCurve(L, [phi(a) for a in E.a_invariants()])
        roots_in_L = sum(g.degree() for g, e in fac if r % g.degree() == 0)
        res['#x-roots of psi_l in F_{q^r}'] = roots_in_L
        res['=> #E(F_{q^r})[l] <= 1 + 2*roots'] = 1 + 2*roots_in_L
        NL = card(r); v = vl(NL)
        res['v_l #E(F_{q^r})'] = v
        cof = NL // l**v; maxord = 0
        for _ in range(20):
            P = cof * EL.random_point(); k = 0
            while not P.is_zero(): P = l * P; k += 1
            maxord = max(maxord, k)
        res['max l-power order exponent found in E(F_{q^r})'] = maxord
        EL.set_order(NL)
        inv = EL.abelian_group().invariants()
        res['abelian_group invariants over F_{q^r}'] = [int(x) for x in inv]
        res['l-part invariants'] = [int(l**vl(x)) for x in inv if x % l == 0]
    res['seconds'] = round(time.time() - t_, 2)
    return res

for name, E in curves.items():
    out[name] = analyse(name, E)

if do_full:
    full = {}
    deg = r * l
    M = GF(2**(m*deg), 'W'); phi, back = embed(M)
    NM = card(deg); v = vl(NM); cof = NM // l**v
    full['v_l #E(F_{q^{rl}})'] = v
    for name, E in curves.items():
        t_ = time.time()
        EM = EllipticCurve(M, [phi(a) for a in E.a_invariants()])
        def rand_l():
            while True:
                P = cof * EM.random_point()
                if P.is_zero(): continue
                while not (l*P).is_zero(): P = l*P
                return P
        P1 = rand_l()
        span1 = [k*P1 for k in range(l)]
        tries = 0
        while True:
            P2 = rand_l(); tries += 1
            if P2 not in span1: break
            if tries > 200: raise RuntimeError('E[l] not in E(F_{q^{rl}})')
        wp = P1.weil_pairing(P2, l)
        def frob(P): return EM([P[0]**q, P[1]**q]) if not P.is_zero() else P
        table = {}
        for a in range(l):
            for b in range(l):
                table[a*P1 + b*P2] = (a, b)
        F1 = table[frob(P1)]; F2 = table[frob(P2)]
        A = matrix(Zmod(l), [[F1[0], F2[0]], [F1[1], F2[1]]])
        Nm = A - c
        rec = {'weil_pairing != 1': bool(wp != 1), 'frob_matrix': [[int(x) for x in row] for row in A.rows()],
               'trace': int(A.trace()), 'det': int(A.det()),
               'A - c != 0': bool(Nm != 0), '(A - c)^2 == 0': bool(Nm*Nm == 0)}
        Ak = A; k = 1
        while Ak != 1: Ak = Ak*A; k += 1
        rec['ord(A)'] = k; rec['seconds'] = round(time.time() - t_, 2)
        full[name] = rec
    out['full_torsion_F_q^(r l)'] = full

out['seconds_total'] = round(time.time() - T0, 1)
tag = f"m{m}_a{a2i}_l{l}" + (f"_l2{l2}" if l2 else '') + ('_full' if do_full else '')
json.dump(out, open(f"/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C3-recompute/toy_{tag}.json", 'w'), indent=1, default=str)
print('WROTE', tag, out['seconds_total'])
