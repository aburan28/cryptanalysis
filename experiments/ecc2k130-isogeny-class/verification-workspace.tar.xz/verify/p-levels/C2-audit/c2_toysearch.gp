\\ Toy search: Koblitz curve y^2+xy=x^3+1 over F_{2^m}, m prime; primes l | f_m (t_m^2-2^{m+2} = -7 f_m^2)
\\ For every INERT l (kronecker(-7,l)=-1) check the consequence m | l+1 (tau has order m in (O_K/l)^*/F_l^*).
tr(m) = my(a0=2,a1=-1); for(k=1,m-1,[a0,a1]=[a1,-a1-2*a0]); a1;
{
my(ninert=0, bad=0, small=List());
forprime(m=3, 400,
  my(t=tr(m), D=t^2-4*2^m, f=sqrtint(D/(-7)));
  if(-7*f^2 != D, error("not -7f^2"));
  my(F=factor(f, 10^7)[,1]);   \\ partial factorization, only trial-divided primes < 10^7 are certified
  for(i=1,#F, my(l=F[i]); if(l < 10^7 && l>7 && kronecker(-7,l)==-1,
      ninert++; if((l+1) % m, bad++; print("VIOLATION m=",m," l=",l));
      if(l < 2000, listput(small, [m,l,valuation(f,l)]))) ));
print("inert primes l<10^7 dividing f_m, m prime <= 400: ", ninert, "; violations of m | l+1: ", bad);
print("small inert toys (m, l, v_l(f)): ", small);
}
