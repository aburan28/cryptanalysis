\\ C2 audit: class-group structure checks with binary quadratic forms (GP only)
default(parisize, 2^30);
p = 146505763881528721; P1 = p+1;
Dp = -7*p^2; D263 = -7*263^2; D263p = -7*263^2*p^2;
id(D) = qfbred(qfbpow(qfbprimeform(D,2),0));
isid(g,D) = qfbred(g) == id(D);
\\ exact order of g given a multiple M and its prime factors
exord(g, M, D) = my(o=M, F=factor(M)[,1]); if(!isid(qfbpow(g,M),D), return(-1)); for(i=1,#F, while(o % F[i]==0 && isid(qfbpow(g,o/F[i]),D), o/=F[i])); o;
\\ --- prime above 2 ---
{
foreach([[D263,"263"],[Dp,"p"],[D263p,"263p"]], v,
  my(D=v[1], g=qfbprimeform(D,2), gb = qfbprimeform(D,2)^(-1));
  print("D(", v[2], ") = ", D, ": kronecker(D,2)=", kronecker(D,2),
        "; prime form above 2 = ", qfbred(g), "; is identity: ", isid(g,D),
        "; g^131 identity: ", isid(qfbpow(g,131),D),
        "; exact order (multiple 131): ", exord(g,131,D));
  \\ is 2 represented by the principal form x^2+xy+((1-D)/4)y^2 ?  (y=0 => x^2=2 impossible; y!=0 => value >= (|D|)/4 > 2)
  print("   principal form = ", id(D), "; (1-D)/4 = ", (1-D)/4, " > 2 so 2 not properly represented by principal form"));
}
\\ --- Cl(O_p): find an element of exact order p+1 ---
{
my(found=0);
forprime(l=3, 200, if(kronecker(Dp,l)==1 && Dp % l,
   my(o = exord(qfbprimeform(Dp,l), P1, Dp));
   if(o==P1 && !found, found=l; print("Cl(-7p^2): prime form above ", l, " has exact order p+1 = ", o, " (checked g^(p+1)=1 and g^((p+1)/r)!=1 for r | p+1)"))));
if(!found, print("no generator found"));
}
\\ --- Cl(O_263p): subgroup of order 262(p+1) ---
{
my(g1=0, l1=0);
forprime(l=3, 200, if(kronecker(D263p,l)==1 && D263p % l && !g1,
   my(g=qfbprimeform(D263p,l)); if(exord(g,P1,D263p)==P1, g1=g; l1=l)));
print("Cl(-7*263^2p^2): g1 = prime form above ", l1, " has exact order p+1 (exponent of group divides? g^(p+1)=1 checked)");
\\ exponent check: every prime form <400 killed by p+1
my(allk=1, cnt=0); forprime(l=3,400, if(kronecker(D263p,l)==1 && D263p % l, cnt++; if(!isid(qfbpow(qfbprimeform(D263p,l),P1),D263p), allk=0)));
print("  all ", cnt, " split prime forms l<400 satisfy g^(p+1)=1: ", allk);
my(sub1_2 = qfbred(qfbpow(g1, P1/2)), sub1_131 = vector(130, k, qfbred(qfbpow(g1, k*P1/131))));
my(done=0);
forprime(l=3, 400, if(kronecker(D263p,l)==1 && D263p % l && l!=l1 && !done,
   my(g2 = qfbpow(qfbprimeform(D263p,l), P1/262), o2 = exord(g2, 262, D263p));
   if(o2==262,
      my(e2 = qfbred(qfbpow(g2,131)), e131 = qfbred(qfbpow(g2,2)));
      my(int2 = (e2 == sub1_2), int131 = 0);
      for(k=1,130, if(e131 == sub1_131[k], int131=1));
      print("  candidate g2 from prime ", l, ": ord(g2)=", o2, "; order-2 elt of <g2> in <g1>: ", int2, "; order-131 subgroup of <g2> in <g1>: ", int131);
      if(!int2 && !int131, done=1; print("  => <g1> cap <g2> trivial, |<g1,g2>| = (p+1)*262 = ", P1*262, "; so 262(p+1) divides h(O_263p)")))));
}
\\ --- Cl(O_263) ---
print("Cl(-7*263^2): prime form above 3 order: ", if(kronecker(D263,3)==1, exord(qfbprimeform(D263,3),262,D263), "3 not split"));
\\ --- qfbclassno (PARI) ---
print("qfbclassno(Dp) = ", qfbclassno(Dp), "; qfbclassno(D263p) = ", qfbclassno(D263p), "; qfbclassno(D263) = ", qfbclassno(D263));
