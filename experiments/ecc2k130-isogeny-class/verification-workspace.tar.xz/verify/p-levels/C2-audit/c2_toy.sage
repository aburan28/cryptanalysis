# C2 audit toy: Phi_l(1,Y) mod 2 for inert and split l | f_m (Koblitz y^2+xy=x^3+1 over F_{2^m}).
# Predictions for inert l with v_l(f_m)=1: Y+1 does not divide (0 horizontal), squarefree of degree l+1 (l+1 distinct
# descending codomains = h(O_l) = l+1), every irreducible factor has degree m (all roots in F_{2^m}\F_2, i.e.
# all l+1 isogenies F_q-rational, sigma-orbits of size m), (l+1)/m orbits; each root is the j of a curve with trace t_m.
import json, time
def tr(m):
    a0, a1 = 2, -1
    for k in range(1, m): a0, a1 = a1, -a1 - 2*a0
    return a1
R.<Y> = GF(2)[]
out = {}
for (m, l) in [(37, 73), (17, 271), (43, 257), (157, 313), (41, 409), (11, 23), (19, 457)]:
    T = time.time()
    t = tr(m); q = 2^m; D = t^2 - 4*q; f = isqrt(D // -7); assert -7*f^2 == D and f % l == 0
    Phi = R(str(pari(f"lift(polmodular({l}, 0, Mod(1,2), 'Y))")))
    fac = Phi.factor()
    degs = sorted([g.degree() for g, e in fac for _ in range(e)])
    mults = sorted(set(e for g, e in fac))
    lin = [(str(g), e) for g, e in fac if g.degree() == 1]
    rec = {"m": m, "l": l, "kronecker(-7,l)": int(kronecker(-7, l)), "v_l(f)": int(valuation(f, l)),
           "deg Phi_l(1,Y)": int(Phi.degree()), "linear factors (j in F_2) with mult": lin,
           "multiset of factor degrees (compressed)": {str(d): degs.count(d) for d in sorted(set(degs))},
           "multiplicities": [int(e) for e in mults], "h_formula(O_l)": int(l - kronecker(-7, l))}
    # pick one root per orbit (degree-m factors) and point-count
    K.<z> = GF(2^m)
    RK.<W> = K[]
    ok_counts = []
    for g, e in fac:
        if g.degree() != m: continue
        j = RK(g.change_ring(K)).roots(multiplicities=False)[0]
        orders = sorted(int(EllipticCurve(K, [1, a2, 0, 0, 1/j]).cardinality()) for a2 in (0, 1))
        ok_counts.append(q + 1 - t in orders)
    rec["every orbit has a curve of order q+1-t"] = all(ok_counts); rec["orbits point-counted"] = len(ok_counts)
    rec["time_s"] = round(time.time() - T, 1)
    print(rec, flush=True)
    out[f"m{m}_l{l}"] = rec
json.dump(out, open("c2_toy_out.json", "w"), indent=1, default=str)
