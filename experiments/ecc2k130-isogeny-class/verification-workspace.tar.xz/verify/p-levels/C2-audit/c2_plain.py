# C2 audit in plain Python (no Sage/PARI): exact arithmetic in O_K = Z[w], w = (1+sqrt(-7))/2, w^2 = w - 2.
import json, math
def mul(x, y):            # (a+bw)(c+dw) = ac + (ad+bc)w + bd w^2, w^2 = w - 2
    a, b = x; c, d = y
    return (a*c - 2*b*d, a*d + b*c + b*d)
def norm(x): a, b = x; return a*a + a*b + 2*b*b
def pw(x, n):
    r = (1, 0)
    while n:
        if n & 1: r = mul(r, x)
        x = mul(x, x); n >>= 1
    return r
tau = (-1, 1)             # -1 + w = (-1+sqrt(-7))/2, root of x^2+x+2
assert norm(tau) == 2 and mul(tau, tau) == (-2 - tau[0], -tau[1])   # tau^2 = -tau - 2
pi = pw(tau, 131)
a, b = pi
q = 2**131
t = 2*a + b               # trace of a+bw is 2a+b
out = {"pi = tau^131 = a + b*w": [a, b], "norm(pi) == 2^131": norm(pi) == q, "trace t": t}
p = 146505763881528721
out["|b| == 263*p"] = abs(b) == 263*p
out["b mod p"] = b % p; out["b mod 263"] = b % 263
out["pi = a (mod p O_K), a mod p"] = a % p
out["2a mod p == t mod p"] = (2*a - t) % p == 0
# tau in Z + c O_K ?  (b-coordinate of tau is 1)
out["tau in Z + c*O_K for c in {263,p,263p}"] = [tau[1] % c == 0 for c in (263, p, 263*p)]
# Miller-Rabin with the first 13 prime bases: deterministic below 3.3e24 > p
def mr(n):
    d, s = n - 1, 0
    while d % 2 == 0: d //= 2; s += 1
    for aa in [2,3,5,7,11,13,17,19,23,29,31,37,41]:
        x = pow(aa, d, n)
        if x in (1, n-1): continue
        for _ in range(s-1):
            x = x*x % n
            if x == n-1: break
        else: return False
    return True
out["p < 3.3e24"] = p < 3317044064679887385961981; out["MR(p) deterministic"] = mr(p); out["MR(263)"] = mr(263)
out["Euler (-7)^((p-1)/2) mod p"] = pow(-7 % p, (p-1)//2, p); out["p-1"] = p - 1
# roots of x^2+x+2 mod p <=> -7 square mod p; brute check impossible, use Euler; also Jacobi by reciprocity
def jacobi(a_, n):
    a_ %= n; r = 1
    while a_:
        while a_ % 2 == 0:
            a_ //= 2
            if n % 8 in (3, 5): r = -r
        a_, n = n, a_
        if a_ % 4 == 3 and n % 4 == 3: r = -r
        a_ %= n
    return r if n == 1 else 0
out["jacobi(-7,p)"] = jacobi(-7, p)
out["h(O_p) = p+1"] = p + 1; out["h(O_263p) = 262(p+1)"] = 262*(p+1)
out["log2 h(O_p)"] = math.log2(p+1); out["log2 h(O_263p)"] = math.log2(262*(p+1))
out["(p+1) % 131"] = (p+1) % 131; out["(p+1)//131"] = (p+1)//131
# order of tau in (O_K/p)^*/F_p^*: tau^k scalar mod p <=> b-coordinate of tau^k = 0 mod p
def pwmod(x, n, m):
    r = (1, 0)
    while n:
        if n & 1: r = tuple(v % m for v in mul(r, x))
        x = tuple(v % m for v in mul(x, x)); n >>= 1
    return r
out["tau^131 mod p has b = 0 (scalar)"] = pwmod(tau, 131, p)[1] == 0
out["tau^1 mod p scalar"] = tau[1] % p == 0
out["tau^(p+1) mod p is scalar (in F_p)"] = pwmod(tau, p+1, p)[1] == 0
json.dump(out, open("c2_plain_out.json", "w"), indent=1, default=str)
for k, v in out.items(): print(k, "=", v)
