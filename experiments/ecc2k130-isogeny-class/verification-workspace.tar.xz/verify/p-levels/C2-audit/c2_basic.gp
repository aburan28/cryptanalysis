\\ C2 audit: independent GP recomputation (no Sage, no files from the sweep)
default(parisize, 2^30);
q = 2^131;
\\ trace of Frobenius of y^2+xy=x^3+1 over F_{2^131}: tau^2+tau+2=0, t_1=-1
a0 = 2; a1 = -1; for(k=1,130, [a0,a1] = [a1, -a1 - 2*a0]); t = a1;
print("t = ", t);
Dpi = t^2 - 4*q;
print("Dpi = ", Dpi, "  Dpi % 7 = ", Dpi % 7);
f2 = Dpi / (-7); f = sqrtint(f2); print("f = ", f, "  f^2 == -Dpi/7: ", f^2 == f2);
print("factor(f) = ", factor(f));
p = f/263; print("p = ", p, " isprime(p) = ", isprime(p), " log2 p = ", log(p)/log(2));
print("kronecker(-7,p) = ", kronecker(-7,p));
print("(-7)^((p-1)/2) mod p = ", lift(Mod(-7,p)^((p-1)/2)), "  (p-1 = ", p-1, ")");
print("p mod 7 = ", p % 7, ", kronecker(p,7) = ", kronecker(p,7));
print("polisirreducible(x^2+x+2 mod p) = ", polisirreducible(Mod(1,p)*(x^2+x+2)));
print("factormod(x^2-x+2, p) = ", factormod(x^2-x+2, p));
print("kronecker(-7,263) = ", kronecker(-7,263));
\\ class numbers by the conductor formula (Cox Thm 7.24): h(O_K)=1, O_K^*={+-1}
hform(c) = my(F=factor(c)[,1], h=c); for(i=1,#F, h *= (1 - kronecker(-7,F[i])/F[i])); h;
hp = hform(p); h263p = hform(263*p); h263 = hform(263);
print("h(O_263) formula = ", h263);
print("h(O_p) formula = ", hp, "  == p+1: ", hp == p+1, "  log2 = ", log(hp)/log(2));
print("h(O_263p) formula = ", h263p, "  == 262(p+1): ", h263p == 262*(p+1), "  log2 = ", log(h263p)/log(2));
print("factor(p+1) = ", factor(p+1));
print("(p+1) % 131 = ", (p+1) % 131, "  (p+1)/131 = ", (p+1)/131, "  262(p+1)/131 = ", 262*(p+1)/131);
print("gcd(262, p+1) = ", gcd(262, p+1));
