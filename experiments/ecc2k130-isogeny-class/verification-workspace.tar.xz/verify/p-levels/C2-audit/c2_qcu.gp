\\ C2 audit: Buchmann-McCurley subexponential class group (quadclassunit), GRH-conditional; independent of the conductor formula
default(parisize, 2^31);
p = 146505763881528721;
foreach([-7*263^2, -7*p^2, -7*263^2*p^2], D, my(T=getabstime(), Q=quadclassunit(D)); print("quadclassunit(", D, "): no = ", Q.no, ", cyc = ", Q.cyc, ", time ", (getabstime()-T)/1000., " s"));
