\\ C1 recompute in standalone PARI/GP (different tool from the plain-python path)
default(parisize, 10^8);
q = 2^131;
\\ trace by PARI point counting over F_q with the ECC2K-130 modulus
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
E = ellinit([1,0,0,0,1], z);
card = ellcard(E);
t = q + 1 - card;
print("t = ", t);
print("card == 4N: ", card == 4*680564733841876926932320129493409985129);
D = t^2 - 4*q; print("D/-7 = ", D/-7, "  issquare: ", issquare(D/-7, &f), " f=", f);
print("factor f: ", factor(f));
p = 146505763881528721;
print("isprime(p) = ", isprime(p), "  (APRCL/BPSW deterministic < 2^64)");
c = Mod(t,p)/2;
print("c = ", lift(c));
r = znorder(c);
print("znorder(c) = ", r, "   factor: ", factor(r), "  (p-1)/r = ", (p-1)/r);
print("log2 r = ", log(r)/log(2), "  r/2 = ", r/2, " log2(r/2) = ", log(r/2)/log(2));
print("c^(r/2) == -1: ", c^(r/2) == -1);
print("znorder(-c) = ", znorder(-c));
print("c^2 == q mod p: ", c^2 == Mod(q,p));
print("kronecker(-7,p) = ", kronecker(-7,p));
\\ tau as element of F_{p^2} = F_p[x]/(x^2+x+2) (field since -7 is a non-residue)
T = ffgen(Mod(1,p)*(x^2+x+2), 'T);
ot = fforder(T);
print("fforder(tau mod p) = ", ot, "  == 131 r: ", ot == 131*r, "  factor: ", factor(ot));
print("tau^131 == c: ", T^131 == lift(c));
print("(p+1) % 131 = ", (p+1) % 131, "  (p-1) % 131 = ", (p-1) % 131);
\\ #E0(F_{q^k}) mod p^3 via matrix power (PARI Mod matrices)
M = Mod([t, -q; 1, 0], p^3);
vk(k) = my(P = M^k, n = lift(Mod(q,p^3)^k + 1 - trace(P))); if(n==0, "big", valuation(n,p));
print("v_p #E0(F_{q^r}) = ", vk(r));
fa = factor(r)[,1];
for(i=1,#fa, print("  v_p #E0(F_{q^(r/", fa[i], ")}) = ", vk(r/fa[i])));
\\ brute-force scan: first k with p | #E0(F_{q^k}) using Lucas mod p, k up to 3e6
tk = [Mod(2,p), c*2]; \\ t_0, t_1 mod p
a = Mod(2,p); b = Mod(t,p); Q = Mod(q,p); qk = Q; firstk = 0;
for(k=1, 3*10^6, if(qk + 1 - b == 0, firstk = k; break); [a, b] = [b, Mod(t,p)*b - Q*a]; qk *= Q);
print("first k<=3e6 with p | #E0(F_{q^k}): ", firstk);
