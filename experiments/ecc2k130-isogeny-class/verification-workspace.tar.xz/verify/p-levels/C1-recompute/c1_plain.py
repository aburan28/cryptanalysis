#!/usr/bin/env python3
"""C1 recompute, plain python3 only (no Sage/PARI).

Independent code path:
  * pi = tau^131 computed exactly in Z[tau]/(tau^2+tau+2) by square-and-multiply
    (not via the Lucas recurrence for t).
  * p-1 factored with my own trial division + Pollard-Brent + Miller-Rabin.
  * ord_p(c) computed from scratch by stripping prime factors of p-1
    (NOT by checking the claimed r).
  * #E0(F_{q^k}) mod p^3 via 2x2 companion-matrix power of x^2 - t x + q.
  * tau mod p: order in F_p[x]/(x^2+x+2) by own polynomial arithmetic, and
    the eigenvalues lambda1, lambda2 (if p splits) with their own orders.
"""
import json, math, random, sys

random.seed(20260923)

q = 2**131
p_claim = 146505763881528721
c_claim = 65861677189822723
r_claim = 12208813656794060
r_fact_claim = {2: 2, 5: 1, 17: 1, 31: 1, 4001: 1, 289510489: 1}
t_task = -22283658519494248867
f_task = 38531015900842053623

out = {}

# ---------- Z[tau], tau^2 = -tau - 2 ----------
def zt_mul(u, v):
    a, b = u; c, d = v
    # (a + b tau)(c + d tau) = ac + (ad+bc) tau + bd tau^2 ; tau^2 = -tau - 2
    return (a*c - 2*b*d, a*d + b*c - b*d)

def zt_pow(u, e):
    r = (1, 0)
    while e:
        if e & 1: r = zt_mul(r, u)
        u = zt_mul(u, u); e >>= 1
    return r

A, B = zt_pow((0, 1), 131)       # pi = A + B tau
# trace(a + b tau) = 2a + b*tr(tau) = 2a - b ; norm = a^2 - ab + 2 b^2
trace = 2*A - B
norm = A*A - A*B + 2*B*B
assert norm == q, "N(tau^131) != 2^131"
out['pi_in_Ztau'] = {'A': A, 'B': B}
out['trace_from_Ztau'] = trace
out['trace_matches_task'] = (trace == t_task)
out['card_E0'] = q + 1 - trace
# disc: pi - pibar = B (tau - taubar) = B sqrt(-7)  => t^2-4q = -7 B^2
out['t2_minus_4q_eq_-7B2'] = (trace*trace - 4*q == -7*B*B)
out['absB_eq_f'] = (abs(B) == f_task)

# ---------- primality / factoring ----------
def is_probable_prime(n):
    if n < 2: return False
    small = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71]
    for s in small:
        if n % s == 0: return n == s
    d, s = n-1, 0
    while d % 2 == 0: d//=2; s+=1
    # deterministic for n < 3.3e24 with these bases
    for a in [2,3,5,7,11,13,17,19,23,29,31,37,41]:
        x = pow(a, d, n)
        if x in (1, n-1): continue
        for _ in range(s-1):
            x = x*x % n
            if x == n-1: break
        else:
            return False
    return True

def brent(n):
    if n % 2 == 0: return 2
    while True:
        y, cc, m = random.randrange(1, n), random.randrange(1, n), 128
        g = r = qq = 1
        while g == 1:
            x = y
            for _ in range(r): y = (y*y + cc) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(m, r-k)):
                    y = (y*y + cc) % n
                    qq = qq*abs(x-y) % n
                g = math.gcd(qq, n); k += m
            r *= 2
        if g == n:
            g = 1
            while g == 1:
                ys = (ys*ys + cc) % n
                g = math.gcd(abs(x-ys), n)
        if g != n: return g

def factor(n, acc=None):
    if acc is None: acc = {}
    if n == 1: return acc
    for s in range(2, 10000):
        while n % s == 0:
            acc[s] = acc.get(s, 0) + 1; n //= s
        if n == 1: return acc
    if is_probable_prime(n):
        acc[n] = acc.get(n, 0) + 1; return acc
    d = brent(n)
    factor(d, acc); factor(n//d, acc)
    return acc

def trial_prime(n):
    if n < 2: return False
    i = 2
    while i*i <= n:
        if n % i == 0: return False
        i += 1
    return True

p = p_claim
out['p_divides_f'] = (f_task % p == 0) and (f_task // p == 263)
out['p_is_prime_MR13'] = is_probable_prime(p)   # deterministic below 3.3e24
fac_pm1 = factor(p-1)
out['p_minus_1_factorization'] = {str(k): v for k, v in sorted(fac_pm1.items())}
assert math.prod(k**v for k, v in fac_pm1.items()) == p-1
for k in fac_pm1:
    assert is_probable_prime(k)
    if k < 10**12: assert trial_prime(k)

# ---------- c and its order ----------
c = (trace * pow(2, -1, p)) % p
out['c_computed'] = c
out['c_matches_claim'] = (c == c_claim)
out['A_mod_p_eq_c'] = (A % p == c)             # pi - c in p*Z[tau] ?
out['B_mod_p'] = B % p                            # must be 0
out['pi_minus_c_in_pOK'] = ((A - c) % p == 0 and B % p == 0)
out['c2_eq_q_mod_p'] = (c*c % p == q % p)
# (x-c)^2 = x^2 - 2c x + c^2  vs  x^2 - t x + q
out['charpoly_is_(x-c)^2_mod_p'] = ((2*c - trace) % p == 0 and (c*c - q) % p == 0)

def mult_order(g, n, fac_nm1):
    """order of g in (Z/n)^*, n prime, fac_nm1 = factorization of n-1."""
    o = n - 1
    for l, e in fac_nm1.items():
        for _ in range(e):
            if pow(g, o // l, n) == 1: o //= l
            else: break
    return o

r = mult_order(c, p, fac_pm1)
out['ord_c'] = r
out['ord_c_matches_claim'] = (r == r_claim)
out['(p-1)/ord_c'] = (p-1)//r
fr = factor(r)
out['ord_c_factorization'] = {str(k): v for k, v in sorted(fr.items())}
out['ord_c_factorization_matches_claim'] = (fr == r_fact_claim)
out['log2_r'] = math.log2(r)
out['r_half'] = r // 2
out['log2_r_half'] = math.log2(r // 2)
out['c^(r/2)'] = pow(c, r//2, p)
out['c^(r/2)_is_-1'] = (pow(c, r//2, p) == p-1)
# order certificate for r (own)
out['c^r==1'] = pow(c, r, p) == 1
out['c^(r/l)!=1 all l'] = all(pow(c, r//l, p) != 1 for l in fr)
# twist: Frobenius -pi acts as -c
mc = (-c) % p
out['ord_minus_c'] = mult_order(mc, p, fac_pm1)
out['ord_minus_c_eq_r'] = out['ord_minus_c'] == r
# x-coordinate field: smallest k with c^k = +-1 = order of c in F_p^*/{+-1}
k_pm = r // 2 if pow(c, r//2, p) == p-1 else r
# verify minimality: for each prime l | k_pm, c^(k_pm/l) not in {+1,-1}
out['x_field_degree'] = k_pm
out['x_field_degree_minimal'] = all(pow(c, k_pm//l, p) not in (1, p-1) for l in factor(k_pm))
out['131*r'] = 131 * r
out['131_divides_p-1'] = ((p-1) % 131 == 0)

# ---------- #E0(F_{q^k}) mod p^3 via companion matrix ----------
M3 = p**3
def mat_mul(X, Y, m):
    return [[(X[0][0]*Y[0][0] + X[0][1]*Y[1][0]) % m, (X[0][0]*Y[0][1] + X[0][1]*Y[1][1]) % m],
            [(X[1][0]*Y[0][0] + X[1][1]*Y[1][0]) % m, (X[1][0]*Y[0][1] + X[1][1]*Y[1][1]) % m]]
def mat_pow(X, e, m):
    R = [[1, 0], [0, 1]]
    while e:
        if e & 1: R = mat_mul(R, X, m)
        X = mat_mul(X, X, m); e >>= 1
    return R
Cmp = [[trace % M3, (-q) % M3], [1, 0]]   # companion of x^2 - t x + q
def card_mod(k, m=M3):
    # trace of C^k = pi^k + pibar^k
    P = mat_pow([[x % m for x in row] for row in Cmp], k, m)
    tk = (P[0][0] + P[1][1]) % m
    return (pow(q, k, m) + 1 - tk) % m
def vp(x, m=M3):
    if x % m == 0: return '>=3'
    v = 0
    while x % p == 0: x //= p; v += 1
    return v
# sanity: k=1 -> #E0 mod p^3
assert card_mod(1) == out['card_E0'] % M3
v_r = vp(card_mod(r))
out['v_p(#E0(F_{q^r}))'] = v_r
out['v_p(#E0(F_{q^(r/l)}))'] = {str(l): vp(card_mod(r//l)) for l in fr}
out['v_p(#E0(F_{q^(r/2)}))'] = vp(card_mod(r//2))
# twist over F_{q^k}: trace -> (-1)^k t_k ; twist of E0 over F_q has frob -pi
Ct = [[(-trace) % M3, (-q) % M3], [1, 0]]
def card_twist_mod(k, m=M3):
    P = mat_pow(Ct, k, m); tk = (P[0][0] + P[1][1]) % m
    return (pow(q, k, m) + 1 - tk) % m
out['v_p(#E0tw(F_{q^r}))'] = vp(card_twist_mod(r))
out['v_p(#E0tw(F_{q^(r/l)}))'] = {str(l): vp(card_twist_mod(r//l)) for l in fr}

# ---------- tau in F_p[x]/(x^2+x+2) ----------
def pm(u, v):
    a, b = u; c2, d = v
    return ((a*c2 - 2*b*d) % p, (a*d + b*c2 - b*d) % p)
def ppow(u, e):
    R = (1, 0)
    while e:
        if e & 1: R = pm(R, u)
        u = pm(u, u); e >>= 1
    return R
tau = (0, 1)
out['tau^131_mod_p'] = ppow(tau, 131)
out['tau^131_eq_c'] = (ppow(tau, 131) == (c, 0))
leg = pow((-7) % p, (p-1)//2, p)
out['legendre(-7,p)'] = 1 if leg == 1 else (-1 if leg == p-1 else 0)
# order of tau in the unit group of F_p[x]/(x^2+x+2)
if out['legendre(-7,p)'] == 1:
    grp = p - 1          # exponent of F_p^* x F_p^*
    fg = dict(fac_pm1)
else:
    grp = p*p - 1
    fg = factor(p + 1, dict(fac_pm1))
o = grp
for l, e in fg.items():
    for _ in range(e):
        if ppow(tau, o // l) == (1, 0): o //= l
        else: break
out['ord_tau_mod_p'] = o
out['ord_tau_eq_131r'] = (o == 131 * r)

# eigenvalues if split
def sqrt_mod(a, p):
    # Tonelli-Shanks
    a %= p
    if a == 0: return 0
    Q, S = p-1, 0
    while Q % 2 == 0: Q //= 2; S += 1
    z = 2
    while pow(z, (p-1)//2, p) != p-1: z += 1
    M, cc, tt, R = S, pow(z, Q, p), pow(a, Q, p), pow(a, (Q+1)//2, p)
    while tt != 1:
        i, t2 = 0, tt
        while t2 != 1: t2 = t2*t2 % p; i += 1
        b = pow(cc, 1 << (M-i-1), p)
        M, cc, tt, R = i, b*b % p, tt*b*b % p, R*b % p
    return R
if out['legendre(-7,p)'] == 1:
    s = sqrt_mod(-7, p)
    assert s*s % p == (-7) % p
    inv2 = pow(2, -1, p)
    lam = [((-1 + s)*inv2) % p, ((-1 - s)*inv2) % p]
    for L in lam: assert (L*L + L + 2) % p == 0
    out['lambda'] = lam
    out['lambda^131'] = [pow(L, 131, p) for L in lam]
    out['ord_lambda'] = [mult_order(L, p, fac_pm1) for L in lam]
    out['ord_lambda_factored'] = [{str(k): v for k, v in sorted(factor(x).items())} for x in out['ord_lambda']]
    # smallest m with a point of order p in E0(F_{2^m}): tau^m acts as lambda_i^m on the
    # lambda_i eigenline; need lambda_i^m = 1 for some i.
    out['min_abs_degree_point_order_p'] = min(out['ord_lambda'])
    out['min_abs_degree_full_Ep'] = math.lcm(*out['ord_lambda'])

json.dump(out, open('/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C1-recompute/c1_plain_out.json', 'w'),
          indent=1, default=str)
for k, v in out.items(): print(k, '=', v)
