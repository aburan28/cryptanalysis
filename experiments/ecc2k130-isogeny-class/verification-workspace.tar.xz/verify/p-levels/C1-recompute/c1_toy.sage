# Toy-scale check of the C1 mechanism on the same Koblitz curve E0: y^2+xy=x^3+1 over F_{2^n}.
# For small n, pi_n = tau^n = A + B tau.  For an odd prime l | B (l != 7), pi_n acts on E0[l]
# as the scalar c = A mod l, so E0[l] <= E0(F_{2^{n k}}) iff ord_l(c) | k.  We verify this by
# computing actual group structures in Sage, including that no point of order l exists for
# proper divisors of r, and where the x-coordinates live.
import json, itertools
def ztau_pow(n):
    A, B = 1, 0
    for _ in range(n):  # multiply by tau: (A + B tau) tau = A tau + B(-tau-2) = -2B + (A-B) tau
        A, B = -2*B, A - B
    return A, B
results = []
for n in range(3, 40):
    A, B = ztau_pow(n)
    for l, _ in factor(abs(B)):
        if l in (2, 7): continue
        c = Mod(A, l)
        r = c.multiplicative_order()
        m = n*r
        if m > 72: continue
        K = GF(2**m, 'w')
        E = EllipticCurve(K, [1,0,0,0,1])
        inv = E.abelian_group().invariants()
        # full l-torsion present iff at least two invariants divisible by l
        full = sum(1 for d in inv if d % l == 0) >= 2
        proper_ok = True
        for (pl, _) in factor(r):
            Kk = GF(2**(n*(r//pl)), 'u'); Ek = EllipticCurve(Kk, [1,0,0,0,1])
            if Ek.cardinality() % l == 0: proper_ok = False
        leg = kronecker(-7, l)
        rec = dict(n=n, l=int(l), c=int(c), r=int(r), m=int(m), inv=[int(d) for d in inv],
                   full_l_torsion_at_r=bool(full), no_l_point_at_r_over_prime=bool(proper_ok),
                   kron=int(leg), c_half_is_minus1=bool(r % 2 == 0 and c**(r//2) == -1))
        # x-coordinates field check when c^(r/2) = -1 and r>1: division polynomial roots degree
        if rec['c_half_is_minus1'] and l < 40:
            F2 = GF(2)
            psi = E.division_polynomial(l)   # over F_{2^m}; take a quick check via minimal field
            # x-coords of l-torsion: roots of psi_l; they should all lie in F_{2^{n r/2}}
            Kh = GF(2**(n*(r//2)), 'v'); Eh = EllipticCurve(Kh, [1,0,0,0,1])
            ph = Eh.division_polynomial(l)
            nroots = len(ph.roots())
            rec['psi_roots_in_F_2^(n r/2)'] = int(nroots); rec['expected'] = int((l*l-1)//2)
        results.append(rec); print(rec)
json.dump(results, open('c1_toy_out.json','w'), indent=1)
allok = all(x['full_l_torsion_at_r'] and x['no_l_point_at_r_over_prime'] for x in results)
print("cases:", len(results), "all consistent:", allok)
