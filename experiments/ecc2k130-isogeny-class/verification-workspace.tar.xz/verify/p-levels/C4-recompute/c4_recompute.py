# C4 independent recomputation (pure python3 integers; no Sage, no PARI).
# Own Miller-Rabin, own Pollard-Brent rho, own multiplicative orders,
# own 2x2 companion-matrix powers, own F_{p^2} arithmetic, own 2D lattice CVP.
# Run:  python3 c4_recompute.py  > c4_recompute.log ; writes c4_recompute.json
import json, math, random, time
from fractions import Fraction

T0 = time.time()
OUT = {}
def rec(k, v):
    OUT[k] = v
    print(k, "=", v, flush=True)

# ---------------------------------------------------------------- primitives
def is_probable_prime(n, rounds=40):
    if n < 2: return False
    small = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71]
    for s in small:
        if n % s == 0: return n == s
    d, s = n - 1, 0
    while d % 2 == 0: d //= 2; s += 1
    # deterministic set for n < 3.3e24, plus random bases beyond
    bases = [2,3,5,7,11,13,17,19,23,29,31,37,41]
    rng = random.Random(n & 0xffffffff)
    bases += [rng.randrange(2, n - 1) for _ in range(rounds)]
    for a in bases:
        a %= n
        if a == 0: continue
        x = pow(a, d, n)
        if x in (1, n - 1): continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1: break
        else:
            return False
    return True

def pollard_brent(n, seed=1):
    if n % 2 == 0: return 2
    rng = random.Random(seed)
    while True:
        y, c, m = rng.randrange(1, n), rng.randrange(1, n), 128
        g, r, qq = 1, 1, 1
        while g == 1:
            x = y
            for _ in range(r): y = (y * y + c) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(m, r - k)):
                    y = (y * y + c) % n
                    qq = qq * abs(x - y) % n
                g = math.gcd(qq, n); k += m
            r *= 2
        if g == n:
            g = 1
            while g == 1:
                ys = (ys * ys + c) % n
                g = math.gcd(abs(x - ys), n)
        if g != n: return g

def factor(n, time_budget=600):
    fs = {}
    # trial division
    for pr in range(2, 20000):
        while n % pr == 0:
            fs[pr] = fs.get(pr, 0) + 1; n //= pr
    stack = [n] if n > 1 else []
    t_start = time.time()
    while stack:
        m = stack.pop()
        if m == 1: continue
        if is_probable_prime(m):
            fs[m] = fs.get(m, 0) + 1; continue
        if time.time() - t_start > time_budget:
            raise RuntimeError("factor budget exceeded on %d" % m)
        d = pollard_brent(m, seed=len(stack) + m % 1000)
        stack += [d, m // d]
    return dict(sorted(fs.items()))

def mult_order(a, mod, fac_group_order, group_order):
    o = group_order
    for pr, e in fac_group_order.items():
        for _ in range(e):
            if pow(a, o // pr, mod) == 1: o //= pr
            else: break
    return o

def jacobi(a, n):
    a %= n; res = 1
    while a:
        while a % 2 == 0:
            a //= 2
            if n % 8 in (3, 5): res = -res
        a, n = n, a
        if a % 4 == 3 and n % 4 == 3: res = -res
        a %= n
    return res if n == 1 else 0

def log2(x): # exact-ish log2 of big ints / Fractions
    if isinstance(x, Fraction):
        return log2(x.numerator) - log2(x.denominator)
    x = int(x)
    b = x.bit_length()
    if b <= 60: return math.log2(x)
    return (b - 60) + math.log2(x >> (b - 60))

# ---------------------------------------------------------------- constants
q = 2 ** 131
# F_2-Frobenius: #E0(F_2) = 4 -> t_1 = 2 + 1 - 4 = -1 ; s_k = t_1 s_{k-1} - 2 s_{k-2}
s0, s1 = 2, -1
for _ in range(130):
    s0, s1 = s1, -s1 - 2 * s0
t = s1
rec("t (Lucas, own)", str(t))
assert t == -22283658519494248867
N4 = q + 1 - t
assert N4 % 4 == 0
N = N4 // 4
rec("N", str(N)); rec("log2 N", log2(N))
Dpi = t * t - 4 * q
assert Dpi % -7 == 0
f2 = Dpi // -7
f = math.isqrt(f2); assert f * f == f2
rec("f", str(f))
assert f % 263 == 0
p = f // 263
rec("p", str(p)); rec("log2 p", log2(p))
rec("N probable prime (MR, 53 bases)", is_probable_prime(N))
rec("p prime (MR, deterministic below 3.3e24)", is_probable_prime(p))
rec("263 prime", is_probable_prime(263))
rec("jacobi(-7,p)", jacobi(-7, p)); rec("jacobi(-7,263)", jacobi(-7, 263))
rec("euler(-7,p) == p-1", pow(-7 % p, (p - 1) // 2, p) == p - 1)

# ---------------------------------------------------------------- Frobenius mod p
c = t * pow(2, -1, p) % p
rec("c = t/2 mod p", c)
assert (c * c - q) % p == 0 and (2 * c - t) % p == 0      # x^2 - t x + q = (x - c)^2 mod p
fac_pm1 = factor(p - 1)
rec("factor(p-1) (own rho)", {str(k): v for k, v in fac_pm1.items()})
r = mult_order(c, p, fac_pm1, p - 1)
fac_r = factor(r)
rec("r = ord_p(c)", r); rec("factor(r)", {str(k): v for k, v in fac_r.items()})
rec("log2 r", log2(r)); rec("(p-1)/r", (p - 1) // r)
assert pow(c, r, p) == 1 and all(pow(c, r // l, p) != 1 for l in fac_r)
half = pow(c, r // 2, p) == p - 1
rec("c^(r/2) == -1 mod p", half)
# r_x = min k with c^k = +-1 : order of c in F_p^*/{+-1}
rx = r // 2 if (r % 2 == 0 and half) else r
# brute certificate: c^k = +-1 iff c^(2k) = 1 iff r | 2k
rec("r_x (min k, c^k = +-1)", rx); rec("log2 r_x", log2(rx))

# companion matrix of x^2 - t x + q mod m
def matmul(A, B, m):
    return [[(A[0][0]*B[0][0] + A[0][1]*B[1][0]) % m, (A[0][0]*B[0][1] + A[0][1]*B[1][1]) % m],
            [(A[1][0]*B[0][0] + A[1][1]*B[1][0]) % m, (A[1][0]*B[0][1] + A[1][1]*B[1][1]) % m]]
def matpow(A, e, m):
    R = [[1, 0], [0, 1]]
    while e:
        if e & 1: R = matmul(R, A, m)
        A = matmul(A, A, m); e >>= 1
    return R
def det_minus(Mk, eps, m):  # det(M^k - eps*I) mod m
    return ((Mk[0][0] - eps) * (Mk[1][1] - eps) - Mk[0][1] * Mk[1][0]) % m
M = [[0, (-q) % p], [1, t % p]]
Nil = [[(M[0][0] - c) % p, M[0][1]], [M[1][0], (M[1][1] - c) % p]]
rec("companion M - c*I nonzero mod p (Z[pi] has p | conductor, Jordan block)", any(x % p for row in Nil for x in row))
rec("(M - c*I)^2 == 0 mod p", all(x == 0 for row in matmul(Nil, Nil, p) for x in row))
# identity det(M^k - I) = (c^k - 1)^2 and det(M^k + I) = (c^k + 1)^2 mod p, random k
rng = random.Random(20260923)
ok = True
for _ in range(2000):
    k = rng.randrange(1, 10 ** 18)
    Mk = matpow(M, k, p); ck = pow(c, k, p)
    ok &= det_minus(Mk, 1, p) == (ck - 1) ** 2 % p and det_minus(Mk, -1, p) == (ck + 1) ** 2 % p
rec("det(M^k -+ I) == (c^k -+ 1)^2 mod p for 2000 random k", ok)
# Lucas-sequence cross-check of #E(F_{q^k}) mod p = q^k + 1 - t_k with t_k = trace(M^k)
def trace_k(k, m):
    Mk = matpow([[0, (-q) % m], [1, t % m]], k, m)
    return (Mk[0][0] + Mk[1][1]) % m
ks = {"r": r, "r_x": rx, "2r_x": 2 * rx, "r+1": r + 1, "r_x+1": rx + 1}
for l in fac_r: ks["r/%d" % l] = r // l
for l in factor(rx): ks["r_x/%d" % l] = rx // l
tab = {}
for name, k in ks.items():
    Nk = (pow(q, k, p) + 1 - trace_k(k, p)) % p
    Ntw = (pow(q, k, p) + 1 + trace_k(k, p)) % p
    tab[name] = {"k": k, "#E(F_q^k) mod p": Nk, "#E'(F_q^k) (quadratic twist) mod p": Ntw}
rec("p | #E(F_{q^k}) / twist table", tab)
# 2-adic... p-adic valuations over F_{q^r} and twist over F_{q^{r_x}}
p3 = p ** 3
Nr_p3 = (pow(q, r, p3) + 1 - trace_k(r, p3)) % p3
Ntw_p3 = (pow(q, rx, p3) + 1 + trace_k(rx, p3)) % p3
def vp(x, pr, cap):
    if x == 0: return ">=%d" % cap
    v = 0
    while x % pr == 0: x //= pr; v += 1
    return v
rec("v_p(#E(F_{q^r})) (computed mod p^3)", vp(Nr_p3, p, 3))
rec("v_p(#E'(F_{q^{r_x}})) twist (computed mod p^3)", vp(Ntw_p3, p, 3))

# ---------------------------------------------------------------- tau in F_{p^2}
# O_K / p = F_p[w]/(w^2 + w + 2), tau = w  (tau^2 + tau + 2 = 0); irreducible since (-7|p) = -1
def f2mul(a, b):  # (a0 + a1 w)(b0 + b1 w), w^2 = -w - 2
    a0, a1 = a; b0, b1 = b
    c0 = a0 * b0; c1 = a0 * b1 + a1 * b0; c2 = a1 * b1
    return ((c0 - 2 * c2) % p, (c1 - c2) % p)
def f2pow(a, e):
    R = (1, 0)
    while e:
        if e & 1: R = f2mul(R, a)
        a = f2mul(a, a); e >>= 1
    return R
tau = (0, 1)
t131 = f2pow(tau, 131)
rec("tau^131 in F_p (w-coefficient 0)", t131[1] == 0)
rec("tau^131 == c mod p", t131 == (c, 0))
rec("tau^1 in F_p", False)
# order of tau in F_{p^2}^* / F_p^* : smallest d with tau^d in F_p ; divides 131 -> 1 or 131
rec("order of tau in F_{p^2}^*/F_p^* (131 prime, tau not in F_p)", 131 if t131[1] == 0 else "not 131")
# and more generally: smallest d with tau^d in Z + p O_K is 131 => sigma-power endomorphisms are pi^k only

# ---------------------------------------------------------------- sizes & bounds
bits_elem = 131 * rx
rec("bits per F_{q^{r_x}} element = 131*r_x", bits_elem)
rec("bytes per F_{q^{r_x}} element", bits_elem / 8)
rec("log2 sqrt(p)", log2(p) / 2)
rec("log2(sqrt(p) * r_x)  [sqrtVelu LB, linear-cost ext arithmetic]", log2(p) / 2 + log2(rx))
rec("log2(131 r * r)  [cofactor mult over F_{q^r}, as in sweep]", log2(131 * r) + log2(r))
rec("log2(131 r_x * r_x)  [x-only cofactor mult on quadratic twist over F_{q^{r_x}}]", log2(131 * rx) + log2(rx))
kdeg = (p - 1) // 2
rec("kernel polynomial degree (p-1)/2", kdeg)
rec("(p-1)/2 / r_x = # F_q-irreducible factors", Fraction(kdeg, rx))
rec("bytes to store kernel polynomial (131 bits/coeff)", kdeg * 131 / 8)
rec("log2 p^3 (Galbraith Phi_p cost)", 3 * log2(p))
rec("log2 p^2 (quadratic-in-l methods: Robert22 Thm6.3/6.7, De Feo 2011 Couveignes)", 2 * log2(p))

# ---------------------------------------------------------------- endomorphism degrees
# O_c = Z + c*O_K, O_K = Z[w], w = (1+sqrt(-7))/2, N(x + y w) = x^2 + x y + 2 y^2
def min_nonscalar_norm(cond):
    best = None
    for b in range(1, 6):
        y = b * cond
        for x in (-(y // 2) - 1, -(y // 2), -(y // 2) + 1, -((y + 1) // 2)):
            n = x * x + x * y + 2 * y * y
            if best is None or n < best: best = n
    return best
for name, cond in [("1", 1), ("263", 263), ("p", p), ("263p", 263 * p)]:
    mn = min_nonscalar_norm(cond)
    rec("min nonscalar endo degree, conductor %s" % name, str(mn))
    rec("log2 of it", log2(mn))
    if cond > 1:
        assert 4 * mn == 7 * cond * cond + 1
rec("log2 (7 p^2 / 4)", log2(Fraction(7 * p * p, 4)))

# ---------------------------------------------------------------- rho baselines
rec("log2 sqrt(pi N/4)", 0.5 * (log2(N) + math.log2(math.pi / 4)))
rec("log2 sqrt(pi N/(4*131))", 0.5 * (log2(N) + math.log2(math.pi / (4 * 131))))
rec("log2 sqrt(131)", 0.5 * math.log2(131))

# ---------------------------------------------------------------- small-order eigenvalues
# Eigen-map O_K -> Z/N for the prime nn = (N, pi - 1): pi = (t - f)/2 + f w  ->  w_N
wN = (1 - (t - f) // 2) * pow(f, -1, N) % N
assert (t - f) % 2 == 0
rec("w_N^2 - w_N + 2 == 0 mod N", (wN * wN - wN + 2) % N == 0)
tauN = (wN - 1) % N    # tau = w - 1 satisfies tau^2 + tau + 2 = 0 ; check which root has order 131
rec("tau_N = w_N - 1 satisfies x^2+x+2", (tauN * tauN + tauN + 2) % N == 0)
fac_Nm1 = factor(N - 1, time_budget=1500)
rec("factor(N-1) (own rho)", {str(k): v for k, v in fac_Nm1.items()})
ord_tau = mult_order(tauN, N, fac_Nm1, N - 1)
rec("ord_N(tau_N)", ord_tau)
rec("tau_N == repo/ground-truth TAU_EIGEN 196511074115861092422032515080945363956", tauN == 196511074115861092422032515080945363956)

# CVP: min N(a + b*cond*w) over a + b*cond*w_N == z (mod N)
def Q(a, y):   # norm of a + y w
    return a * a + a * y + 2 * y * y
def min_norm_with_eigen(cond, z):
    # lattice vectors (a, b): a + b*cond*w_N == 0 mod N ; basis (N,0), (-cond*w_N mod N, 1)
    B = [[N, 0], [(-cond * wN) % N, 1]]
    def qf(v):
        return Q(v[0], v[1] * cond)
    def bil(u, v):   # symmetric bilinear form with bil(v,v) = qf(v)
        return Fraction(qf([u[0] + v[0], u[1] + v[1]]) - qf(u) - qf(v), 2)
    # Lagrange-Gauss reduction under qf
    b1, b2 = B
    if qf(b1) > qf(b2): b1, b2 = b2, b1
    while True:
        mu = bil(b1, b2) / qf(b1)
        m = math.floor(mu + Fraction(1, 2))
        b2 = [b2[0] - m * b1[0], b2[1] - m * b1[1]]
        if qf(b2) >= qf(b1): break
        b1, b2 = b2, b1
    # target: minimise qf(t0 + x b1 + y b2), t0 = (z, 0); exact enumeration
    t0 = [z % N, 0]
    # Gram-Schmidt
    g11 = Fraction(qf(b1)); g12 = bil(b1, b2)
    mu21 = g12 / g11
    b2s_norm = Fraction(qf(b2)) - mu21 * mu21 * g11
    # coordinates of -t0 in basis (b1, b2) (solve linear system exactly)
    det = b1[0] * b2[1] - b1[1] * b2[0]
    X = Fraction(-t0[0] * b2[1] + t0[1] * b2[0], det)
    Y = Fraction(-b1[0] * t0[1] + b1[1] * t0[0], det)
    # Babai upper bound
    yb = round(Y); xb = round(X + (Y - yb) * mu21)
    best = qf([t0[0] + xb * b1[0] + yb * b2[0], t0[1] + xb * b1[1] + yb * b2[1]])
    bestv = (xb, yb)
    # enumerate y with (y - Y)^2 * |b2*|^2 <= best
    rad = math.isqrt(int(Fraction(best) / b2s_norm) + 1) + 1
    for y in range(math.floor(Y) - rad, math.ceil(Y) + rad + 1):
        rem = Fraction(best) - (y - Y) ** 2 * b2s_norm
        if rem < 0: continue
        center = X + (Y - y) * mu21
        rx_ = math.isqrt(int(rem / g11) + 1) + 1
        for x in range(math.floor(center) - rx_, math.ceil(center) + rx_ + 1):
            v = [t0[0] + x * b1[0] + y * b2[0], t0[1] + x * b1[1] + y * b2[1]]
            n = qf(v)
            if n < best and n > 0:
                best, bestv = n, (x, y)
    return best

divs = [1]
for pr, e in fac_Nm1.items():
    divs = [d * pr ** k for d in divs for k in range(e + 1)]
small_m = sorted(d for d in divs if 3 <= d <= 5000)
rec("divisors m of N-1 with 3 <= m <= 5000", small_m)
gN = None
# generator-free: element of exact order m = x^((N-1)/m) for random x, check exact order
def elem_of_order(m):
    rr = random.Random(m)
    fm = factor(m)
    while True:
        x = pow(rr.randrange(2, N - 1), (N - 1) // m, N)
        if all(pow(x, m // l, N) != 1 for l in fm): return x
res = {}
for cond_name, cond in [("1 (E0)", 1), ("263", 263), ("p", p), ("263p", 263 * p)]:
    per = {}
    for m in small_m:
        z = elem_of_order(m)
        # all elements of exact order m: z^j, gcd(j, m) = 1
        best = None
        for j in range(1, m):
            if math.gcd(j, m) != 1: continue
            nm = min_norm_with_eigen(cond, pow(z, j, N))
            if best is None or nm < best: best = nm
        per[m] = round(log2(best), 3)
    res[cond_name] = per
    rec("min log2 N(alpha) over alpha in O_%s with eigenvalue of exact order m" % cond_name, per)
# sanity: on O_K the eigenvalue tau_N (order 131) is realised by tau itself (norm 2)
rec("O_K: min norm with eigenvalue tau_N", min_norm_with_eigen(1, tauN))
rec("O_p: min log2 norm with eigenvalue tau_N", log2(min_norm_with_eigen(p, tauN)))
rec("reference log2(N*p)", log2(N) + log2(p))
rec("reference log2(N*263)", log2(N) + log2(263))
rec("elapsed_s", round(time.time() - T0, 1))
json.dump(OUT, open(__file__.replace(".py", ".json"), "w"), indent=1, default=str)
