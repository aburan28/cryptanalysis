import math
from fractions import Fraction
N=680564733841876926932320129493409985129; p=146505763881528721
t=-22283658519494248867; f=263*p
wN=(1-(t-f)//2)*pow(f,-1,N)%N
def Q(a,y): return a*a+a*y+2*y*y
cond=p
B=[[N,0],[(-cond*wN)%N,1]]
qf=lambda v: Q(v[0],v[1]*cond)
bil=lambda u,v: Fraction(qf([u[0]+v[0],u[1]+v[1]])-qf(u)-qf(v),2)
b1,b2=B
if qf(b1)>qf(b2): b1,b2=b2,b1
it=0
while True:
    it+=1
    mu=bil(b1,b2)/qf(b1); m=math.floor(mu+Fraction(1,2))
    b2=[b2[0]-m*b1[0],b2[1]-m*b1[1]]
    if qf(b2)>=qf(b1): break
    b1,b2=b2,b1
print(it, math.log2(qf(b1)), math.log2(qf(b2)), b1, b2)
print("check lattice cond", (b1[0]+b1[1]*cond*wN)%N, (b2[0]+b2[1]*cond*wN)%N)
