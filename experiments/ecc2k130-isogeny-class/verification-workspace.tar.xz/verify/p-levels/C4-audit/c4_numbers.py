#!/usr/bin/env python3
"""C4 audit: independent recomputation (plain python3, no Sage/PARI) of every number in claim C4,
plus the parameters of the Kani/meet-in-the-middle route of Galbraith (ePrint 2024/924, RNT 11:7 2025)
instantiated for N = p.

Run:  TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp python3 c4_numbers.py
Writes c4_numbers.json next to this file.
"""
import json, math, os, random, time
from math import gcd, log2, isqrt

T0 = time.time()
out = {}
def rec(k, v):
    out[k] = v
    print(f"{k} = {v}")

# ---------- own primality / factoring ----------
def is_prime(n):
    if n < 2: return False
    small = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71]
    for p_ in small:
        if n % p_ == 0: return n == p_
    d, s = n - 1, 0
    while d % 2 == 0: d //= 2; s += 1
    # deterministic for n < 3.3e24 with these bases; for larger n it is a strong probable-prime test
    for a in small[:13]:
        x = pow(a, d, n)
        if x in (1, n - 1): continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1: break
        else:
            return False
    return True

def pollard_rho(n):
    if n % 2 == 0: return 2
    while True:
        c = random.randrange(1, n); f = lambda x: (x * x + c) % n
        x = y = random.randrange(2, n); d = 1
        while d == 1:
            x = f(x); y = f(f(y)); d = gcd(abs(x - y), n)
        if d != n: return d

def factor(n):
    fs = {}
    def rec_(m):
        if m == 1: return
        if is_prime(m): fs[m] = fs.get(m, 0) + 1; return
        for q_ in range(2, 10000):
            if m % q_ == 0:
                fs[q_] = fs.get(q_, 0) + 1; rec_(m // q_); return
        d = pollard_rho(m); rec_(d); rec_(m // d)
    rec_(n)
    return dict(sorted(fs.items()))

def mult_order(a, m, fac_phi):
    """order of a mod prime m given factorisation of m-1"""
    o = m - 1
    for l, e in fac_phi.items():
        for _ in range(e):
            if pow(a, o // l, m) == 1: o //= l
            else: break
    return o

# ---------- (1) trace via Z[omega] arithmetic (independent of the Lucas recurrence) ----------
# O_K = Z[w], w = (1+sqrt(-7))/2, w^2 = w - 2.  tau = F_2-Frobenius of E0 satisfies tau^2 + tau + 2 = 0,
# tau = w - 1 (check: (w-1)^2 + (w-1) + 2 = w^2 - w + 2 = 0).  pi = tau^131.
def zmul(a, b):   # (a0 + a1 w)(b0 + b1 w), w^2 = w - 2
    a0, a1 = a; b0, b1 = b
    return (a0*b0 - 2*a1*b1, a0*b1 + a1*b0 + a1*b1)
def zpow(a, e):
    r = (1, 0)
    while e:
        if e & 1: r = zmul(r, a)
        a = zmul(a, a); e >>= 1
    return r
tau = (-1, 1)
assert zmul(tau, tau)[0] + tau[0] + 2 == 0 and zmul(tau, tau)[1] + tau[1] == 0
pi_ = zpow(tau, 131)
# trace of a0 + a1 w is 2 a0 + a1 ; norm is a0^2 + a0 a1 + 2 a1^2
t = 2*pi_[0] + pi_[1]
normpi = pi_[0]**2 + pi_[0]*pi_[1] + 2*pi_[1]**2
q = 2**131
assert normpi == q
rec("t (from tau^131 in Z[w])", t)
assert t == -22283658519494248867
N4 = q + 1 - t
assert N4 % 4 == 0
N = N4 // 4
rec("N", N); rec("N is (strong) probable prime, 13 bases", is_prime(N))
# pi = a + f*w  with f = conductor of Z[pi]
f = abs(pi_[1])
rec("f = |coefficient of w in pi|", f)
assert t*t - 4*q == -7*f*f
facf = factor(f)
rec("factor(f)", {str(k): v for k, v in facf.items()})
p = max(facf)
assert facf == {263: 1, p: 1}
rec("p", p); rec("log2 p", log2(p)); rec("p prime (deterministic MR, p < 3.3e24)", is_prime(p))

# ---------- (2) Frobenius eigenvalue c on E[p], r, r_x ----------
c = (t * pow(2, -1, p)) % p
assert (c*c - q) % p == 0
fac_pm1 = factor(p - 1)
rec("factor(p-1)", {str(k): v for k, v in fac_pm1.items()})
r = mult_order(c, p, fac_pm1)
rec("r = ord_p(c)", r); rec("log2 r", log2(r))
rec("(p-1)/r (number of pi-orbits on kernel\\{0})", (p - 1)//r)
assert r % 2 == 0 and pow(c, r//2, p) == p - 1
rx = r // 2
rec("r_x = r/2 (c^(r/2) = -1)", rx); rec("log2 r_x", log2(rx))
rec("(p-1)/(2 r_x) (F_q-irreducible factors of kernel poly)", (p - 1)//(2*rx))
# ord of -c, to double-check r_x is the least k with c^k = +-1
ominus = mult_order(p - c, p, fac_pm1)
rec("ord_p(-c)", ominus)
rx_check = min(k for k in (r, rx, ominus) if pow(c, k, p) in (1, p - 1))
assert rx_check == rx

# ---------- (3) point counts over F_{q^k} via 2x2 companion matrix mod m ----------
def matpow_trace(k, m, tt):
    # trace of M^k with M = [[tt, -q],[1, 0]] mod m
    def mm(A, B):
        return [[(A[0][0]*B[0][0] + A[0][1]*B[1][0]) % m, (A[0][0]*B[0][1] + A[0][1]*B[1][1]) % m],
                [(A[1][0]*B[0][0] + A[1][1]*B[1][0]) % m, (A[1][0]*B[0][1] + A[1][1]*B[1][1]) % m]]
    R = [[1, 0], [0, 1]]; A = [[tt % m, (-q) % m], [1, 0]]
    while k:
        if k & 1: R = mm(R, A)
        A = mm(A, A); k >>= 1
    return (R[0][0] + R[1][1]) % m
def Nk(k, m, twist=False):
    tt = -t if twist else t
    return (pow(q, k, m) + 1 - matpow_trace(k, m, tt)) % m
chk = {}
chk["N_r mod p^2"] = Nk(r, p*p)
chk["N_r mod p^3 != 0"] = Nk(r, p**3) != 0
chk["N_(r/l) mod p != 0 for all primes l | r"] = all(Nk(r//l, p) != 0 for l in factor(r))
# theory: det(1 - pi^k | E[p]) = (1 - c^k)^2 mod p, so p | N_k  <=>  c^k = 1  <=>  r | k
chk["N_k == (1-c^k)^2 mod p for 2000 random k"] = all(
    Nk(k, p) == (1 - pow(c, k, p))**2 % p for k in [random.randrange(1, 10**18) for _ in range(2000)])
chk["twist: p | Ntw_k  <=>  (-c)^k = 1, checked at k = ord(-c) and its maximal divisors"] = (
    Nk(ominus, p, True) == 0 and all(Nk(ominus//l, p, True) != 0 for l in factor(ominus)))
rec("pointcount_checks", chk)
assert chk["N_r mod p^2"] == 0 and chk["N_r mod p^3 != 0"] and chk["N_(r/l) mod p != 0 for all primes l | r"]

# ---------- (4) tau mod p: smallest k with tau^k in Z + p O_K ----------
# tau^k = a + b w lies in Z + p O_K  iff  p | b.  Since 131 is prime and tau^131 = pi (b = f, p | f),
# the least such k is 1 or 131; check k = 1..131 directly (cheap).
bs = []
cur = (1, 0)
kmin = None
for k in range(1, 132):
    cur = zmul(cur, tau)
    if cur[1] % p == 0 and kmin is None: kmin = k
rec("least k>=1 with tau^k in Z + p*O_K", kmin)
cur = (1, 0); kmin263 = None
for k in range(1, 132):
    cur = zmul(cur, tau)
    if cur[1] % 263 == 0 and kmin263 is None: kmin263 = k
rec("least k>=1 with tau^k in Z + 263*O_K", kmin263)

# ---------- (5) minimal nonscalar endomorphism degree in Z + g O_K ----------
# N(x + g y w) = (x + g y/2)^2 + 7 g^2 y^2 / 4 ; min over y != 0 is (7 g^2 + 1)/4 for odd g
for g in (263, p, 263*p):
    exact = (7*g*g + 1)//4
    # brute-check the minimum with y = +-1, x near -g/2
    brute = min((x + g*y*0)**2 + g*x*y + 2*g*g*y*y for y in (1, -1) for x in range(-g//2 - 3, -g//2 + 4)) if g < 10**6 else None
    if brute is not None: assert brute == exact
    rec(f"min nonscalar endo degree, conductor {g}: log2", log2(exact))

# ---------- (6) rho baselines ----------
rho_E0 = math.sqrt(math.pi * N / (4*131)); rho_neg = math.sqrt(math.pi * N / 4)
rec("log2 rho E0 (neg + tau)", log2(rho_E0)); rec("log2 rho negation only", log2(rho_neg))
rec("saving in bits", log2(rho_neg) - log2(rho_E0))

# ---------- (7) the claim's cost figures ----------
bits = 131 * rx
rec("bits per F_{q^{r/2}} element", bits); rec("bytes per F_{q^{r/2}} element", bits / 8)
rec("log2(sqrt(p) * r/2)  [claimed sqrt-Velu LB]", 0.5*log2(p) + log2(rx))
rec("log2(131 * r^2)      [claimed cofactor LB, y-coords over F_{q^r}]", log2(131) + 2*log2(r))
rec("log2(131 * (r/2)^2)  [x-only ladder over F_{q^{r/2}} instead]", log2(131) + 2*log2(rx))
rec("log2(p^3)            [Phi_p route]", 3*log2(p))
rec("log2(p^2)            [Couveignes/De Feo O~(l^2) route, not listed in C4]", 2*log2(p))
kbytes = (p - 1)//2 * 131 / 8
rec("bytes of kernel polynomial ((p-1)/2 coeffs x 131 bits)", kbytes)
# Galois-orbit (trace) form of Velu given ONE kernel point Q0 in E(F_{q^r}):
#   x(phi(P)) = x_P + sum_{j=1}^{(p-1)/r} Tr_{F_{q^r}/F_q}( x(P + g_j Q0) - x(g_j Q0) )
# cost ~ (p-1)/r scalar mults by <= log2 p bit scalars in E(F_{q^r}) + traces
n_orb = (p - 1)//r
ops_ext = n_orb * (math.ceil(log2(p)) * 1.5 * 10 + 20)   # ~10 F_{q^r}-mults per group op, generous
rec("trace-Velu: #orbits", n_orb)
rec("trace-Velu: log2 #F_{q^r}-mults", log2(ops_ext))
rec("trace-Velu: log2 F_q-ops, linear model (r per F_{q^r} op)", log2(ops_ext) + log2(r))
rec("trace-Velu: log2 F_q-ops, M(r)=r*log2(r) model", log2(ops_ext) + log2(r) + log2(log2(r)))

# ---------- (8) Galbraith 2024 Theorem 1 instantiated with N = p ----------
# Elkies primes: odd l > 3, (t^2-4q | l) = 1, l not dividing f.  (t^2-4q | l) = (-7 | l) for l not | f.
def legendre(a, l):
    v = pow(a % l, (l - 1)//2, l)
    return -1 if v == l - 1 else v
D = t*t - 4*q
elk = [l for l in range(5, 2000) if is_prime(l) and D % l != 0 and legendre(D, l) == 1]
rec("first Elkies primes (l>3)", elk[:20])
# eigenvalues of pi mod l and the extension degree over F_q where the eigenpoints live
def sqrt_mod(a, l):
    a %= l
    for x in range(l):
        if x*x % l == a: return x
    return None
eig = {}
for l in elk[:40]:
    s = sqrt_mod(D, l)
    al = (t + s) * pow(2, -1, l) % l; be = (t - s) * pow(2, -1, l) % l
    assert (al*al - t*al + q) % l == 0 and (be*be - t*be + q) % l == 0 and al != be
    fl = factor(l - 1)
    eig[l] = (al, be, mult_order(al, l, fl), mult_order(be, l, fl))
rec("Elkies l -> (alpha, beta, deg F_q-ext of alpha-eigenpoint, of beta-eigenpoint)", {str(k): v for k, v in list(eig.items())[:20]})
# search S (subset of the first s Elkies primes) with A_S^2 < N/2 as large as possible, then the
# smallest n with 3^n A_S^2 > N; m = 3^n A_S^2 - N; prefer m a sum of two squares (dimension-4 Kani).
Np = p
def sum_two_squares(m):
    fm = factor(m)
    return all(e % 2 == 0 for l, e in fm.items() if l % 4 == 3)
s = int(4/3 * math.log(Np))
pool = elk[:s]
rec("s = floor(4/3 ln N)", s); rec("largest prime in pool", pool[-1])
random.seed(20260923)
best = None; tried = 0; found2 = []
target = Np / 2
for trial in range(200000):
    k = random.randrange(3, 9)
    S = sorted(random.sample(pool, k))
    A = math.prod(S)
    if A*A >= target or A*A < target / (3 * 700**2): continue
    n = 0
    while 3**n * A*A <= Np: n += 1
    M = 3**n * A * A; m = M - Np
    tried += 1
    if m % 2 == 0 and m % 3 != 0 and sum_two_squares(m):
        M1 = 3**((n + 1)//2) * A
        phiA = math.prod(l - 1 for l in S)
        found2.append((max(S), S, n, M, m, M1, phiA))
        if len(found2) >= 200: break
found2.sort(key=lambda z: (z[0], z[6]))
rec("Kani parameter candidates tried", tried); rec("candidates with m a sum of two squares", len(found2))
if found2:
    mx, S, n, M, m, M1, phiA = found2[0]
    rec("example S (Elkies primes)", S); rec("example n (power of 3)", n)
    rec("example M = 3^n A_S^2", M); rec("example m = M - p", m)
    rec("example log2 M", log2(M)); rec("example M1 = 3^ceil(n/2) A_S, log2", log2(M1))
    rec("example #guesses phi(A_S), log2", log2(phiA))
    rec("example max eigenpoint extension degree over F_q", max(max(eig[l][2], eig[l][3]) for l in S if l in eig))
rec("log2 sqrt(p) (Galbraith Thm 1: O~(N^(1/2)) F_q-ops)", 0.5*log2(p))
rec("elapsed_s", round(time.time() - T0, 1))
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "c4_numbers.json"), "w"), indent=1, default=str)
print("ALL ASSERTIONS PASSED")
