# C4 audit toy: the Koblitz curve E0: y^2+xy=x^3+1 over F_{2^37}.  Here t^2-4q = -7 f^2, f = 73*2663,
# and l = 73 is INERT in Q(sqrt-7) -- the same situation as p for ECC2K-130.  c = t/2 mod 73 has
# order r = 18 and c^9 = -1, so E0[73] lives over F_{q^18} = F_{2^666}, kernel x-coords over F_{q^9}.
# Checks (all by direct computation):
#  (a) every 73-isogeny out of E0 descends; the floor curve E1 has E1(F_{q^18})[73^oo] cyclic;
#  (b) the unique F_q-rational 73-subgroup of E1 is the c-eigenline, its x-coords lie in F_{q^9} and
#      in no smaller F_{q^k}; the corresponding isogeny ascends back to j = 1;
#  (c) small-degree (3,5,7,11) isogenies from E1 stay on the 73-floor (level preserved) and never reach j=1;
#  (d) Galois-orbit ("trace") form of Velu:  x(psi(P)) = x_P + sum_j Tr_{F_{q^18}/F_q}(x(P+g_j Q)-x(g_j Q)),
#      j over the (73-1)/18 = 4 cosets of <c> -- i.e. evaluation needs O(#orbits * log l) ext-field ops,
#      not sqrt(l) (sqrt-Velu) ;
#  (e) transport of a toy DLP of order 230603167 from E1 to E0 via psi.
import json, time, random
T0 = time.time(); set_random_seed(int(20260923)); random.seed(int(20260923))
out = {}
def rec(k, v):
    out[k] = v; print(k, "=", v, flush=True)
m = 37; q = 2^m
t0, t1 = 2, -1
for k in range(1, m): t0, t1 = t1, -t1 - 2*t0
t = t1
f = isqrt((4*q - t^2)//7); assert -7*f^2 == t^2 - 4*q
l = 73; assert f % l == 0 and kronecker(-7, l) == -1
c = GF(l)(t)/2; r = c.multiplicative_order(); rx = r//2 if c^(r//2) == -1 else r
rec("t", t); rec("f", str(factor(f))); rec("c", int(c)); rec("r", r); rec("r_x", rx)
def tk(k):   # trace of pi^k
    a, b = 2, t
    for _ in range(k - 1): a, b = b, t*b - q*a
    return b if k >= 1 else 2
NK = q^r + 1 - tk(r)
v = valuation(NK, l); rec("v_73 #E(F_{q^r})", v)
K37.<a> = GF(2^m); K.<z> = GF(2^(m*r))
rts = K37.modulus().change_ring(K).roots(multiplicities=False)
emb = K37.hom([rts[0]], K); sec = emb.section()
E0 = EllipticCurve(K37, [1, 0, 0, 0, 1]); assert E0.order() == q + 1 - t
def ext(E):
    return EllipticCurve(K, [emb(ai) for ai in E.a_invariants()])
def frob_q(P):   # q-power Frobenius on a point over K
    return P.curve()(P[0]^q, P[1]^q)
def ptorsion_point(EK, NK, l, v):
    while True:
        R = (NK // l^v) * EK.random_point()
        if R.is_zero(): continue
        while not (l*R).is_zero(): R = l*R
        return R
E0K = ext(E0)
Q0 = ptorsion_point(E0K, NK, l, v)
# (a1) pi acts on E0[73] as the scalar c
rec("E0: pi(Q) == c*Q for a random 73-torsion point", frob_q(Q0) == int(c)*Q0)
Q0b = ptorsion_point(E0K, NK, l, v)
rec("E0: Weil pairing of two random 73-torsion pts != 1 (E0[73] fully over F_{q^r})", Q0.weil_pairing(Q0b, l) != 1)
def kerpoly(Q):
    R.<X> = K[]
    h = prod(X - (k*Q)[0] for k in range(1, (l - 1)//2 + 1))
    return PolynomialRing(K37, 'X')([sec(co) for co in h.list()])
h0 = kerpoly(Q0)
phi0 = E0.isogeny(h0); E1 = phi0.codomain()
rec("j(E1) != 1", E1.j_invariant() != 1); rec("#E1 == #E0", E1.order() == E0.order())
E1K = ext(E1)
# (a2) E1(F_{q^r})[73^oo] cyclic:  pairings of random 73-power-torsion points' 73-multiples are trivial
pts = []
for _ in range(4):
    R = (NK // l^v) * E1K.random_point()
    pts.append(R)
orders_ok = True; lines = []
for R in pts:
    S = R
    while not (l*S).is_zero(): S = l*S
    lines.append(S)
rec("E1: all random 73-torsion points pairwise dependent (Weil pairing 1)",
    all(lines[i].weil_pairing(lines[j], l) == 1 for i in range(4) for j in range(i+1, 4)))
def l_order(R):
    e = 0
    while not R.is_zero(): R = l*R; e += 1
    return l^e
rec("E1: max order of 73-part of random points", str(max(l_order(R) for R in pts)))
Q1 = lines[0]
rec("E1: pi(Q1) == c*Q1", frob_q(Q1) == int(c)*Q1)
xq = Q1[0]
def in_sub(xx, k): return xx^(q^k) == xx
rec("E1: x(Q1) in F_{q^k} for k in (1,3,9,18)", {k: bool(in_sub(xq, k)) for k in (1, 3, 9, 18)})
rec("E1: Q1 in E1(F_{q^k}) for k in (1,2,3,6,9,18)", {k: bool(Q1[0]^(q^k) == Q1[0] and Q1[1]^(q^k) == Q1[1]) for k in (1, 2, 3, 6, 9, 18)})
h1 = kerpoly(Q1)
rec("kernel poly of ascending isogeny: degrees of F_q-irreducible factors", sorted([g.degree() for g, e in h1.factor()]))
psi = E1.isogeny(h1); E0p = psi.codomain()
rec("ascending isogeny lands on j = 1", E0p.j_invariant() == 1)
rec("codomain F_q-isomorphic to E0", E0p.is_isomorphic(E0))
# (c) small-degree isogenies from E1 keep the level (73-part of E(F_{q^r}) stays cyclic) and never hit j=1
def on_floor(E):
    EK = ext(E); ls = []
    for _ in range(3):
        R = (NK // l^v) * EK.random_point()
        while not (l*R).is_zero(): R = l*R
        ls.append(R)
    return all(ls[i].weil_pairing(ls[j], l) == 1 for i in range(3) for j in range(i+1, 3))
small = {}
for ell in (3, 5, 7, 11):
    try:
        isos = E1.isogenies_prime_degree(ell)
    except Exception as ex:
        small[str(ell)] = {"error": str(ex)[:200]}; continue
    small[str(ell)] = {"count": len(isos), "any_j_eq_1": any(I.codomain().j_invariant() == 1 for I in isos),
                       "all_on_73_floor": all(on_floor(I.codomain()) for I in isos)}
rec("small-degree isogenies from E1", small)
# (d) trace form of Velu
gens = []; seen = set(); H = set(int(c^i) for i in range(r))
for g in range(1, l):
    if g in seen: continue
    gens.append(g); seen |= set(int(g*h) % l for h in H)
rec("coset reps of <c> in F_73^*", gens)
def trace(zz):
    s = zz; acc = zz
    for _ in range(r - 1):
        s = s^q; acc += s
    return acc
agree = 0; ntest = 5
for _ in range(ntest):
    P = E1.random_point()
    PK = E1K(emb(P[0]), emb(P[1]))
    X = PK[0]
    for g in gens:
        G = g*Q1; X += trace((PK + G)[0] - G[0])
    agree += int(sec(X) == psi(P)[0])
rec("trace-Velu x(psi(P)) == Sage psi(P).x() on random points", f"{agree}/{ntest}")
# (e) DLP transport
ell = 230603167; assert (E1.order() % ell) == 0
while True:
    P = (E1.order() // ell) * E1.random_point()
    if not P.is_zero(): break
kk = random.randrange(1, int(ell)); Qd = kk*P
iso = E0p.isomorphism_to(E0)
PP, QQ = iso(psi(P)), iso(psi(Qd))
rec("transported point: nonzero and killed by ell", (not PP.is_zero()) and (ell*PP).is_zero())
kr = discrete_log(QQ, PP, ord=ell, operation='+')
rec("DLP solved on E0 after transport equals planted k", int(kr) == kk)
rec("elapsed_s", round(time.time() - T0, 1))
json.dump(out, open("toy_vertical.json", "w"), indent=1, default=str)
print("DONE")
