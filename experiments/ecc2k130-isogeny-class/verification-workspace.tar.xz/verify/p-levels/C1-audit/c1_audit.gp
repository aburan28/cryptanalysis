\\ C1 audit in plain PARI/GP (gp binary, not via Sage). Run: gp -q c1_audit.gp
default(parisize, 10^8);
q = 2^131;
\\ trace of tau^131 directly from the characteristic polynomial x^2+x+2 of the F_2-Frobenius
tau = Mod(x, x^2+x+2);
pi = lift(tau^131);                      \\ A + B*x
A = polcoeff(pi,0); B = polcoeff(pi,1);
t = 2*A - B;                              \\ trace, since x + xbar = -1
print("t = ", t);
print("norm(pi)==q: ", A^2 - A*B + 2*B^2 == q);
f = abs(B); print("f = ", f, "  factor(f) = ", factor(f));
p = f/263;
print("p = ", p, "  isprime(p) (APRCL/ECPP proof): ", isprime(p, 2));
c = Mod(t,p)/2;
print("c = t/2 mod p = ", lift(c), "   A mod p = ", A % p);
r = znorder(c);
print("r = znorder(c) = ", r, "  factor(r) = ", factor(r));
print("log2 r = ", log(r)/log(2));
print("c^(r/2) = ", lift(c^(r/2)), " (p-1 = ", p-1, ")");
print("znorder(-c) = ", znorder(-c));
print("znorder(Mod(q,p)) = ", znorder(Mod(q,p)), "  znorder(Mod(2,p)) = ", znorder(Mod(2,p)));
\\ tau modulo p in F_{p^2}
g = ffgen((x^2+x+2)*Mod(1,p), 'a);
print("x^2+x+2 irreducible mod p: ", polisirreducible((x^2+x+2)*Mod(1,p)));
ot = fforder(g);
print("fforder(tau mod p) = ", ot, "  == 131*r: ", ot == 131*r);
print("tau^131 == c: ", g^131 == lift(c)*g^0);
print("fforder(tau^2) = ", fforder(g^2), "  == 131*r/2: ", fforder(g^2) == 131*r/2);
\\ point counts through ellcard over small analog is not possible here; use the Lucas trace via
\\ Mod-matrix power as a second route
M = Mod([t, -q; 1, 0], p^3);
Nk(k) = Mod(q,p^3)^k + 1 - trace(M^k);
print("N_r mod p^2 = ", lift(Nk(r)) % p^2, "   N_r mod p^3 = ", lift(Nk(r)));
fr = factor(r)[,1];
for(i=1,#fr, l=fr[i]; print("N_(r/", l, ") mod p = ", lift(Nk(r/l)) % p));
\\ exact field check: pi - A == B*tau, so p | B => pi == A on E0[p] (End(E0) = Z[tau] = O_K)
print("B mod p = ", B % p);
\\ O_K = Z[tau]?  disc(x^2+x+2) = -7 is fundamental
print("coredisc(-7) = ", coredisc(-7), "  nfdisc(x^2+x+2) = ", nfdisc(x^2+x+2));
quit;
