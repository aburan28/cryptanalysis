#!/usr/bin/env python3
"""C1 audit (pure python3, no Sage/PARI, no imports from the sweep or ground truth).

Claim C1: Frobenius pi acts on E0[p] as the scalar c = t/2 mod p = 65861677189822723,
r = ord_p(c) = 12208813656794060 = 2^2*5*17*31*4001*289510489, c^(r/2) = -1, ord(-c) = r.

Independent route used here:
  * t is NOT taken from anywhere: tau^131 is computed exactly in Z[tau], tau^2 = -tau - 2,
    giving pi = A + B*tau.  Then t = 2A - B, and pi - A = B*tau, so if p | B the action of pi on
    E0[p] (End(E0) = Z[tau] = O_K) is multiplication by A.  So c := A mod p (no division by 2).
  * orders computed with a hand-written order algorithm over a hand-factored group order.
  * point counts N_k = q^k + 1 - t_k mod p^2, p^3 via a hand-written 2x2 matrix power.
  * tau mod p in F_p[x]/(x^2+x+2) with hand-written arithmetic; its order and the least m with
    tau^m = +-1 (the field of definition over F_2 of points / x-coordinates).
"""
import json, math, random, sys, time

T0 = time.time()
out = {}

def rec(k, v):
    out[k] = v
    print(k, "=", v, flush=True)

# ---------- deterministic Miller-Rabin (valid for n < 3.3e24 with these bases) ----------
def is_prime(n):
    if n < 2:
        return False
    small = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]
    for s in small:
        if n % s == 0:
            return n == s
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    for a in small:
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True

def factor(n):
    """trial division up to 2^21, then require the cofactor to be 1 or prime (checked)."""
    fs = {}
    d = 2
    while d * d <= n and d < (1 << 21):
        while n % d == 0:
            fs[d] = fs.get(d, 0) + 1
            n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        assert is_prime(n), ("unfactored composite cofactor", n)
        fs[n] = fs.get(n, 0) + 1
    return fs

def fs_str(fs):
    return " * ".join(f"{l}^{e}" if e > 1 else f"{l}" for l, e in sorted(fs.items()))

def order_in_group(x, group_order, fs, mul, one, powf):
    """order of x in a group of order group_order with factorization fs."""
    o = group_order
    for l, e in fs.items():
        for _ in range(e):
            if powf(x, o // l) == one:
                o //= l
            else:
                break
    assert powf(x, o) == one
    for l in fs:
        if o % l == 0:
            assert powf(x, o // l) != one
    return o

# ---------- (0) exact tau^131 in Z[tau], tau^2 = -tau - 2 ----------
def zt_mul(u, v):
    # (a + b tau)(c + d tau) = ac + (ad + bc) tau + bd tau^2 ; tau^2 = -tau - 2
    a, b = u; c, d = v
    return (a * c - 2 * b * d, a * d + b * c - b * d)

def zt_pow(u, e):
    r = (1, 0)
    while e:
        if e & 1:
            r = zt_mul(r, u)
        u = zt_mul(u, u)
        e >>= 1
    return r

# sanity: #E0(F_2) by brute force over F_2 for y^2 + xy = x^3 + 1
cnt = 1 + sum(1 for x in (0, 1) for y in (0, 1) if (y * y + x * y - x ** 3 - 1) % 2 == 0)
rec("#E0(F_2) brute force", cnt)
assert cnt == 4   # => trace of tau is 2 + 1 - 4 = -1 => tau^2 + tau + 2 = 0

q = 2 ** 131
A, B = zt_pow((0, 1), 131)           # pi = tau^131 = A + B tau
t = 2 * A - B                        # tau + taubar = -1 => tr(A + B tau) = 2A - B
rec("pi = tau^131 = A + B*tau, A", A)
rec("B", B)
rec("t = 2A - B", t)
# norm(A + B tau) = A^2 - AB + 2B^2 must be q
assert A * A - A * B + 2 * B * B == q
disc = t * t - 4 * q
assert disc == -7 * B * B            # (pi - pibar)^2 = B^2 (tau - taubar)^2 = -7 B^2
f = abs(B)
rec("f = |B| (index of Z[pi] in O_K)", f)
assert f % 263 == 0
p = f // 263
rec("p = f/263", p)
assert is_prime(p) and is_prime(263)
rec("p prime (det. MR)", True)
rec("log2 p", math.log2(p))
N4 = q + 1 - t
assert N4 % 4 == 0
N = N4 // 4
rec("N prime (MR, probabilistic for this size)", is_prime(N))

# ---------- (1) c ----------
c_A = A % p                          # scalar by which pi acts on E0[p]
c_half = t * pow(2, -1, p) % p       # t/2 mod p (the claim's definition)
rec("c = A mod p", c_A)
rec("c = t/2 mod p", c_half)
assert c_A == c_half == 65861677189822723
assert c_A * c_A % p == q % p        # c^2 = N(pi) = q mod p (because pi = A mod p O_K)
rec("c^2 == q mod p", True)
# Legendre (-7|p): p inert or split in O_K
leg = pow(-7 % p, (p - 1) // 2, p)
rec("(-7|p) via Euler", 1 if leg == 1 else (-1 if leg == p - 1 else leg))

# ---------- (2) ord_p(c) ----------
fpm1 = factor(p - 1)
rec("factor(p-1)", fs_str(fpm1))
mulp = lambda a, b: a * b % p
powp = lambda a, e: pow(a, e, p)
r = order_in_group(c_A, p - 1, fpm1, mulp, 1, powp)
rec("r = ord_p(c)", r)
fr = factor(r)
rec("factor(r)", fs_str(fr))
rec("log2 r", math.log2(r))
assert r == 12208813656794060
assert fs_str(fr) == "2^2 * 5 * 17 * 31 * 4001 * 289510489"
rec("(p-1)/r", (p - 1) // r)
cert = {"c^r": pow(c_A, r, p)}
for l in fr:
    cert[f"c^(r/{l})"] = pow(c_A, r // l, p)
rec("order certificate", cert)
assert cert["c^r"] == 1 and all(v != 1 for k, v in cert.items() if k != "c^r")
rec("c^(r/2) == -1", pow(c_A, r // 2, p) == p - 1)
assert pow(c_A, r // 2, p) == p - 1
# least k with c^k in {+1,-1}
rx = order_in_group(c_A * c_A % p, p - 1, fpm1, mulp, 1, powp)   # ord(c^2)
# c^k = +-1  <=>  c^(2k) = 1  <=>  ord(c^2) | k   (since c^k is then a square root of 1)
rec("r_x = least k with c^k = +-1 = ord(c^2) = ord(q)", rx)
assert rx == r // 2 == 6104406828397030
rec("log2 r_x", math.log2(rx))
rec("ord_p(q mod p)", order_in_group(q % p, p - 1, fpm1, mulp, 1, powp))
rec("ord_p(2)", order_in_group(2, p - 1, fpm1, mulp, 1, powp))
rneg = order_in_group((-c_A) % p, p - 1, fpm1, mulp, 1, powp)
rec("ord_p(-c) (twist: Frobenius -pi)", rneg)
assert rneg == r
rec("r mod 4", r % 4)

# ---------- (3) point counts via 2x2 matrix powers ----------
def mat_mul(X, Y, m):
    return ((X[0][0] * Y[0][0] + X[0][1] * Y[1][0]) % m, (X[0][0] * Y[0][1] + X[0][1] * Y[1][1]) % m), \
           ((X[1][0] * Y[0][0] + X[1][1] * Y[1][0]) % m, (X[1][0] * Y[0][1] + X[1][1] * Y[1][1]) % m)

def mat_pow(M, e, m):
    R = ((1, 0), (0, 1))
    M = tuple(tuple(x % m for x in row) for row in M)
    while e:
        if e & 1:
            R = mat_mul(R, M, m)
        M = mat_mul(M, M, m)
        e >>= 1
    return R

def trace_k(tr, k, m):
    """trace of pi^k where pi has char poly x^2 - tr x + q."""
    M = ((tr, -q), (1, 0))
    P = mat_pow(M, k, m)
    return (P[0][0] + P[1][1]) % m

def Nk(k, m, tr=None):
    tr = t if tr is None else tr
    return (pow(q, k, m) + 1 - trace_k(tr, k, m)) % m

# sanity of trace_k against the exact Z[tau] computation for small k
for k in (1, 2, 3, 7, 10):
    a, b = zt_pow((A, B), k)
    assert (2 * a - b) % (p ** 3) == trace_k(t, k, p ** 3)
assert Nk(1, 10 ** 60) == N4 % 10 ** 60
rec("trace_k sanity vs exact Z[tau] (k=1,2,3,7,10)", True)

pc = {}
pc["N_r mod p^2"] = Nk(r, p * p)
pc["N_r mod p^3 == 0"] = Nk(r, p ** 3) == 0
pc["N_r / p^2 mod p"] = (Nk(r, p ** 3) // (p * p))
pc["N_(r/l) mod p"] = {str(l): Nk(r // l, p) for l in fr}
pc["N_(r/2) mod p"] = Nk(r // 2, p)
pc["N_(r/2) mod p == 4 (= (1-(-1))^2)"] = Nk(r // 2, p) == 4
# twist E0' over F_q: Frobenius -pi, trace -t
pc["twist N'_r mod p^2"] = Nk(r, p * p, -t)
pc["twist N'_(r/l) mod p"] = {str(l): Nk(r // l, p, -t) for l in fr}
rec("pointcount checks", pc)
assert pc["N_r mod p^2"] == 0 and not pc["N_r mod p^3 == 0"]
assert all(v != 0 for v in pc["N_(r/l) mod p"].values())
assert pc["twist N'_r mod p^2"] == 0 and all(v != 0 for v in pc["twist N'_(r/l) mod p"].values())

# identity check: N_k == (1 - c^k)^2 mod p for random k (this is what "pi = scalar c on E0[p]" predicts,
# since N_k = Norm(1 - pi^k) and pi = c mod p O_K)
random.seed(20260923)
ks = [random.randrange(1, 10 ** 18) for _ in range(200)] + list(range(1, 50))
bad = [k for k in ks if Nk(k, p) != (1 - pow(c_A, k, p)) ** 2 % p]
rec("N_k == (1-c^k)^2 mod p for 249 k values", len(bad) == 0)
assert not bad
# stronger: pi^k - 1 mod p O_K computed exactly in Z[tau]/p: pi^k = c^k + p*(...)
def zt_pow_mod(u, e, m):
    r_ = (1, 0)
    while e:
        if e & 1:
            r_ = tuple(x % m for x in zt_mul(r_, u))
        u = tuple(x % m for x in zt_mul(u, u))
        e >>= 1
    return r_

for k in ks[:40]:
    a, b = zt_pow_mod((A % p, B % p), k, p)
    assert b % p == 0 and a % p == pow(c_A, k, p)
rec("pi^k == c^k (mod p Z[tau]) for 40 random k", True)

# ---------- (4) tau mod p in F_p[x]/(x^2+x+2): field of definition over F_2 ----------
def f2_mul(u, v):
    a, b = u; c, d = v
    return ((a * c - 2 * b * d) % p, (a * d + b * c - b * d) % p)

def f2_pow(u, e):
    R = (1, 0)
    while e:
        if e & 1:
            R = f2_mul(R, u)
        u = f2_mul(u, u)
        e >>= 1
    return R

assert leg == p - 1  # x^2+x+2 (disc -7) irreducible mod p
fp2 = factor(p * p - 1) if False else None
# factor p^2-1 = (p-1)(p+1)
fpp1 = factor(p + 1)
rec("factor(p+1)", fs_str(fpp1))
fall = dict(fpm1)
for l, e in fpp1.items():
    fall[l] = fall.get(l, 0) + e
tau = (0, 1)
otau = order_in_group(tau, p * p - 1, fall, f2_mul, (1, 0), f2_pow)
rec("ord(tau mod p) in F_{p^2}^*", otau)
rec("ord(tau) == 131*r", otau == 131 * r)
assert otau == 131 * r
t131 = f2_pow(tau, 131)
rec("tau^131 mod p", t131)
assert t131 == (c_A, 0)
# least m >= 1 with tau^m = +-1: tau^m = -1 iff tau^(2m) = 1 and tau^m != 1; ord(tau^2):
otau2 = order_in_group(f2_mul(tau, tau), p * p - 1, fall, f2_mul, (1, 0), f2_pow)
rec("least m with tau^m = +-1 (x-coord field degree over F_2) = ord(tau^2)", otau2)
rec("== 131 * r/2", otau2 == 131 * (r // 2))
assert otau2 == 131 * (r // 2)
rec("tau^(131 r/2) == -1", f2_pow(tau, 131 * (r // 2)) == (p - 1, 0))

# ---------- (5) relation with the Weil pairing / embedding degree ----------
rec("ord_p(q) divides r (mu_p in F_{q^r})", r % order_in_group(q % p, p - 1, fpm1, mulp, 1, powp) == 0)

rec("elapsed_s", round(time.time() - T0, 2))
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C1-audit/c1_audit_plain_out.json", "w"),
          indent=1, default=str)
print("ALL ASSERTIONS PASSED")
