# C1 audit, theory check on toy analogues (Sage 10.9). Run: sage c1_toy_theory.sage
# E0: y^2 + xy = x^3 + 1 over F_{2^n}.  Frobenius pi_n = tau^n = A_n + B_n tau, f_n = |B_n|.
# For an odd prime l | f_n (l != 7) the claim's reasoning predicts:
#   (i)  pi_n acts on E0[l] as the scalar c = t_n/2 mod l,
#   (ii) every nonzero point of E0[l] has field of definition F_{2^(n r)}, r = ord_l(c),
#   (iii) every x-coordinate has degree r_x over F_{2^n}, r_x = r/2 if c^(r/2) = -1 else r,
#   (iv) l^2 | #E0(F_{2^(n r)}) and l does not divide #E0(F_{2^(n r/s)}) for primes s | r.
# (iii) is checked by factoring the l-division polynomial over F_{2^n} (all factor degrees must be r_x),
# (ii) by testing whether y is defined over F_{2^n}[x]/(h) for each factor h (Artin-Schreier trace),
# (iv) with PARI ellgroup over F_{2^(n r)} when n r is small, and with Lucas counts otherwise.
# Negative control: for primes l NOT dividing f_n the same prediction must fail somewhere.
import json, time
T0 = time.time()
Z.<X> = ZZ[]
Ot.<tt> = NumberField(X^2 + X + 2)
tau = tt

def frob(n):
    e = tau^n
    A, B = ZZ(e[0]), ZZ(e[1])
    return A, B, 2*A - B

def ord_mod(a, l):
    return Mod(a, l).multiplicative_order()

results = []
neg_control = []
cases_done = 0
for n in range(2, 72):
    A, B, t = frob(n)
    qn = 2^n
    assert A^2 - A*B + 2*B^2 == qn and t^2 - 4*qn == -7*B^2
    f = abs(B)
    K = GF(2^n, 'z')
    E = EllipticCurve(K, [1, 0, 0, 0, 1])
    assert E.trace_of_frobenius() == t
    ells_div = [l for l in prime_range(3, 60) if l != 7 and f % l == 0]
    ells_nodiv = [l for l in prime_range(3, 30) if l != 7 and f % l != 0][:3]
    for l, divides in [(l, True) for l in ells_div] + [(l, False) for l in ells_nodiv]:
        if (l^2 - 1)/2 * n > 40000:   # keep the factorisations cheap
            continue
        c = Mod(t, l) / 2
        if c == 0:
            continue
        r = c.multiplicative_order()
        half = (r % 2 == 0 and c^(r//2) == -1)
        rx = r // 2 if half else r
        psi = E.division_polynomial(l)
        facs = psi.factor()
        degs = sorted(set(h.degree() for h, _ in facs))
        # y-field: for x0 root of h, y^2 + x0 y = x0^3 + 1 solvable in F_{2^n}(x0) iff Tr((x0^3+1)/x0^2) = 0
        yin = []
        for h, _ in facs[:3]:
            if h.degree() * n > 2000:
                yin.append(None); continue
            L = K.extension(h.degree(), 'w') if h.degree() > 1 else K
            x0 = h.change_ring(L).roots(multiplicities=False)[0]
            yin.append(bool(((x0^3 + 1) / x0^2).trace() == 0) if hasattr(((x0^3 + 1)/x0^2), 'trace') else None)
        # expected: y defined over F_{2^n}(x0) iff point field degree r == rx
        pred_y = (r == rx)
        yok = all(v is None or v == pred_y for v in yin)
        pred_ok = (degs == [rx]) and yok
        rec = {"n": n, "l": int(l), "l_divides_f": divides, "kron(-7,l)": int(kronecker(-7, l)),
               "c": int(c), "r": int(r), "r_x": int(rx), "divpoly_factor_degrees": [int(d) for d in degs],
               "y_in_x_field(per factor, sample)": yin[:4], "prediction_holds": bool(pred_ok)}
        # (iv) point counts: ellgroup when n r is small, Lucas mod l^3 otherwise
        def Nk_mod(k, m):
            e = (tau^n)^k
            tk = ZZ(2*e[0] - e[1])
            return (2^(n*k) + 1 - tk) % m
        rec["l^2 | N_(n r)"] = bool(Nk_mod(r, l^2) == 0)
        rec["l nmid N_(n r/s) for s|r"] = bool(all(Nk_mod(r//s, l) != 0 for s, _ in factor(r))) if r > 1 else True
        if n * r <= 90:
            Kr = GF(2^(n*r), 'u')
            Er = EllipticCurve(Kr, [1, 0, 0, 0, 1])
            inv = [ZZ(v) for v in pari(Er).ellgroup()] if False else [ZZ(v) for v in Er.abelian_group().invariants()]
            rec["group invariants over F_2^(n r)"] = [str(v) for v in inv]
            rec["E[l] subset E(F_2^(n r)) (l | both invariants)"] = bool(len(inv) == 2 and all(v % l == 0 for v in inv))
        if divides:
            results.append(rec)
            assert pred_ok, rec
            assert rec["l^2 | N_(n r)"] and rec["l nmid N_(n r/s) for s|r"], rec
            if "E[l] subset E(F_2^(n r)) (l | both invariants)" in rec:
                assert rec["E[l] subset E(F_2^(n r)) (l | both invariants)"], rec
        else:
            neg_control.append(rec)
        cases_done += 1
        rec["t_elapsed"] = round(time.time() - T0, 1)
        print(rec, flush=True)
        json.dump({"partial": True, "positive": results, "negative_control": neg_control},
                  open("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C1-audit/c1_toy_theory_out.json", "w"), indent=1, default=str)

summary = {
    "n_positive_cases (l | f_n)": len(results),
    "n_positive_inert": sum(1 for r_ in results if r_["kron(-7,l)"] == -1),
    "n_positive_split": sum(1 for r_ in results if r_["kron(-7,l)"] == 1),
    "n_positive_with_c^(r/2)=-1": sum(1 for r_ in results if r_["r"] == 2 * r_["r_x"]),
    "n_positive_with_explicit_group_structure": sum(1 for r_ in results if "group invariants over F_2^(n r)" in r_),
    "all positive predictions hold": all(r_["prediction_holds"] for r_ in results),
    "n_negative_control (l nmid f_n)": len(neg_control),
    "negative controls where the scalar prediction FAILS (expected > 0)": sum(1 for r_ in neg_control if not r_["prediction_holds"]),
    "elapsed_s": round(time.time() - T0, 1),
}
print(summary)
json.dump({"summary": summary, "positive": results, "negative_control": neg_control},
          open("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C1-audit/c1_toy_theory_out.json", "w"),
          indent=1, default=str)
print("DONE")
