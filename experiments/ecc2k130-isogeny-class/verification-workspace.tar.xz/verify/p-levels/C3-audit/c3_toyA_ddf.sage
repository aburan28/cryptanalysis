# Toy A (m=15, l=89 inert, r=22, x-degree 11, (l-1)/r = 4) done with distinct-degree tests in PARI
# instead of a full factorization of the degree-3960 division polynomial (the machine is heavily loaded).
load("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C3-audit/c3_common.sage")
T0 = time.time()
m, l = 15, 89
q = 2^m; t = trace_kob(m); D = t^2 - 4*q; f = isqrt(D // -7); assert -7*f^2 == D and f % l == 0 and (f//l) % l != 0
c = GF(l)(t)/2; r = c.multiplicative_order()
rx = r//2 if (r % 2 == 0 and c^(r//2) == -1) else r
L1 = lcm(rx, l)
res = {"m": m, "l": l, "t": int(t), "f": str(factor(f)), "(-7|l)": int(kronecker(-7, l)), "c": int(c), "r": int(r), "r_x": int(rx), "lcm(r_x,l)": int(L1)}
L = GF(2^(m*r), 'w'); Fq, emb = L.subfield(m, 'z', map=True); sec = emb.section()
E0 = EllipticCurve(Fq, [1, 0, 0, 0, 1]); assert E0.trace_of_frobenius() == t

def ddf_profile(E, ks):
    """Return {k: deg gcd(psi_l, X^{q^k} - X)} and helpers, computed in PARI."""
    psi = E.division_polynomial(l)
    P = pari(psi)
    v = P.variable()
    X = pari(f"Mod({v}, {P})") if False else pari("Mod")(pari(v), P)
    out = {}; Y = X; k = 0; Ys = {}
    for kk in sorted(ks):
        while k < kk:
            Y = Y ** q; k += 1
        Ys[kk] = Y
    return psi, P, v, Ys

# ---- E0 (crater): every x-orbit has size r_x ----
psi0, P0, v0, Ys0 = ddf_profile(E0, [1, rx])
d0 = {}
d0["deg psi_l(E0)"] = int(pari.poldegree(P0))
d0["deg gcd(psi, X^q - X)"] = int(pari.poldegree(pari.gcd(P0, Ys0[1].lift() - pari(v0))))
d0["psi | X^{q^r_x} - X"] = bool((Ys0[rx].lift() - pari(v0)) == 0)
d0["=> all irreducible factors of psi_l(E0) have degree r_x (r_x prime)"] = bool(is_prime(rx) and d0["deg gcd(psi, X^q - X)"] == 0 and d0["psi | X^{q^r_x} - X"])
res["E0"] = d0
print(json.dumps(res, indent=1, default=str)); sys.stdout.flush()

# ---- descend to a level-l curve ----
E1, _ = descend_via_points(E0, l, L, emb, sec, [Fq(1)], Nk_formula(t, q, r))
res["E1"] = str(E1.a_invariants()); res["j1"] = str(E1.j_invariant())
psi1, P1, v1, Ys1 = ddf_profile(E1, [1, rx, l, L1])
x_ = pari(v1)
d1 = {}
d1["deg psi_l(E1)"] = int(pari.poldegree(P1))
d1["squarefree"] = bool(pari.poldegree(pari.gcd(P1, pari.deriv(P1))) == 0)
g = pari.gcd(P1, Ys1[rx].lift() - x_)
d1["deg gcd(psi, X^q - X)"] = int(pari.poldegree(pari.gcd(P1, Ys1[1].lift() - x_)))
d1["deg g = gcd(psi, X^{q^r_x} - X)  [predicted (l-1)/2]"] = int(pari.poldegree(g))
Rr = P1 / g
Rr = pari.denominator(Rr) if False else Rr
d1["deg R = psi/g  [predicted (l^2-l)/2]"] = int(pari.poldegree(Rr))
d1["deg gcd(R, X^{q^l} - X)"] = int(pari.poldegree(pari.gcd(Rr, Ys1[l].lift() - x_)))
d1["R | X^{q^lcm(r_x,l)} - X"] = bool(pari.lift(pari("Mod")(Ys1[L1].lift() - x_, Rr)) == 0)
ok = (d1["squarefree"] and d1["deg gcd(psi, X^q - X)"] == 0 and d1["deg g = gcd(psi, X^{q^r_x} - X)  [predicted (l-1)/2]"] == (l-1)//2
      and d1["deg R = psi/g  [predicted (l^2-l)/2]"] == (l^2 - l)//2 and d1["deg gcd(R, X^{q^l} - X)"] == 0 and d1["R | X^{q^lcm(r_x,l)} - X"])
# r_x = 11 and l = 89 prime: factor degrees of g divide 11 and are not 1 -> all 11 ; factor degrees of R divide 979,
# are not in {1, 11} (gcd with X^{q^11}-X is 1 since g took all of it) and not 89 (gcd with X^{q^89}-X trivial) -> all 979
d1["=> psi_l(E1) = (4 irreducibles of degree 11) * (4 irreducibles of degree 979)"] = bool(ok)
d1["predicted counts"] = {str(rx): ((l-1)//2)//rx, str(L1): ((l^2 - l)//2)//L1}
# ---- ascending isogeny over F_q from the kernel polynomial g ----
Rq = PolynomialRing(Fq, 'x')
gq = Rq([Fq(cf) for cf in pari.Vecrev(g)])
gq = gq / gq.leading_coefficient()
phi = E1.isogeny(gq)
d1["codomain j of isogeny with kernel poly g"] = str(phi.codomain().j_invariant())
d1["goes up to E0 (j = 1)"] = bool(phi.codomain().j_invariant() == 1)
rts = phi_roots_count(l, E1.j_invariant(), Fq)
d1["roots of Phi_l(j1,Y) in F_q (with mult)"] = rts
d1["exactly one F_q-rational l-isogeny"] = bool(len(rts) == 1 and rts[0][1] == 1)
res["E1 (level l)"] = d1
print(json.dumps(d1, indent=1, default=str)); sys.stdout.flush()
# ---- over L = F_{q^r}: cyclic l-part, point / x degrees, Velu kernel poly == g ----
EL = EllipticCurve(L, [emb(x) for x in E1.a_invariants()])
nL = Nk_formula(t, q, r); vl = valuation(nL, l); cof = nL // l^vl
maxe = 0; lpts = []
for _ in range(8):
    R_ = cof * EL.random_point(); e = order_lpower(R_, l); maxe = max(maxe, e)
    if e >= 1: lpts.append(l^(e-1)*R_)
d2 = {"v_l(#E1(F_{q^r}))": int(vl), "max l-power exponent (8 samples)": int(maxe), "cyclic Z/l^v": bool(maxe == vl),
      "Lenstra O_l/(pi^r-1) l-part": list(lenstra_lpart(t, q, f, l, r, l)),
      "v_l(#E(F_{q^k})) k|r, k<r": {str(k): int(valuation(Nk_formula(t, q, k), l)) for k in divisors(r) if k < r}}
P = lpts[0]
fr = lambda Q, k: EL(Q[0]^(q^k), Q[1]^(q^k))
d2["pi(P) == c P"] = bool(fr(P, 1) == int(c)*P)
d2["field degree of P"] = int(min(k for k in divisors(r) if fr(P, k) == P))
d2["field degree of x(P)"] = int(min(k for k in divisors(r) if P[0]^(q^k) == P[0]))
kp = EL.isogeny(P).kernel_polynomial()
d2["Velu kernel poly of <P> == g"] = bool(kp == kp.parent()([emb(cf) for cf in gq.list()]))
res["E1 over F_{q^r}"] = d2
res["time_s"] = round(time.time() - T0, 1)
print(json.dumps(d2, indent=1, default=str))
json.dump(res, open("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C3-audit/c3_toyA_ddf.json", "w"), indent=1, default=str)
print("DONE", res["time_s"])
