# Extra inert toys replacing the timed-out m=15,l=89 case (full factorization of psi_l, full analysis)
load("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C3-audit/c3_common.sage")
EX = {}
for (m, l, tag) in [(16, 31, "toyE_m16_l31"), (18, 17, "toyF_m18_l17")]:
    log("==", tag)
    EX[tag] = toy_single(m, l, tag)
    log(json.dumps(EX[tag], indent=1, default=str))
    json.dump(EX, open("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C3-audit/c3_toys_extra.json", "w"), indent=1, default=str)
log("DONE")
