# Search toy analogues: y^2+xy=x^3+1 over F_{2^m} (End = O_K, disc -7), any m (not only prime).
# For each prime l || f_m (exponent 1), report (-7|l), r = ord_l(t/2), whether -1 in <c>, ext degree m*r.
def trace(m):
    t0, t1 = 2, -1
    for k in range(1, m):
        t0, t1 = t1, -t1 - 2*t0
    return t1
rows = []
for m in range(3, 61):
    t = trace(m); q = 2^m; D = t^2 - 4*q
    f2 = D // -7; f = isqrt(f2)
    if f*f != f2 or f == 0: continue
    fac = factor(f)
    ls = [(l, e) for l, e in fac if l not in (2, 7)]
    info = []
    for l, e in ls:
        c = Mod(t, l)/2; r = c.multiplicative_order()
        info.append((l, e, kronecker(-7, l), r, bool(r % 2 == 0 and c^(r//2) == -1), m*r))
    rows.append((m, t, f, info))
for m, t, f, info in rows:
    small = [x for x in info if x[1] == 1 and x[5] <= 1400 and x[0] <= 800]
    if small:
        print("m=%d f=%s" % (m, factor(f)), small)
