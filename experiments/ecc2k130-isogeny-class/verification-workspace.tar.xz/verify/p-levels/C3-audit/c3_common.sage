# C3 audit: toy analogues that exercise EVERY sub-statement of claim C3, with toy parameters chosen
# differently from the sweep (sweep used m=37,l=73 on the twist, where the eigenvalue has ODD order so
# the "points over F_{q^r}, x over F_{q^(r/2)}" distinction was never exercised, and m=11,l=23 with r=1).
#
# Curves: E0: y^2+xy = x^3+1 over F_{2^m} (End = O_K, disc -7, j = 1).
#  Toy A  m=15, l=89 inert  (like p: (-7|l) = -1), r = ord_l(t/2) = 22, c^11 = -1 -> x-degree 11, (l-1)/r = 4 factors
#  Toy B  m=42, l=13 inert,  r = 4, -> x-degree 2, (l-1)/r = 3 factors
#  Toy C  m=28: two-prime analogue of level 263p: l_s = 29 split (r=1, like 263), l_i = 13 inert (r=6, x-deg 3, 2 factors)
#         E0 --29--> Ea (conductor 29) --13--> Eb (conductor 29*13)
#  Toy D  m=6, l=5 inert, r=4: full E1[l] only over F_{q^(r l)} = F_{2^120}, checked with explicit points.
# Predictions tested for the level-l curve E1 (floor of the l-volcano):
#  (P1) psi_l(E1) over F_q factors as (l-1)/r irreducibles of degree r_x (the line) and
#       (l^2-l)/2 / lcm(r_x,l) irreducibles of degree lcm(r_x, l) (everything else)   [Jordan block]
#       whereas psi_l(E0) = all factors of degree r_x                                   [scalar]
#  (P2) the product of the degree-r_x factors (degree (l-1)/2) is a kernel polynomial over F_q of an
#       isogeny that goes UP (codomain j = j of the level above) ; it equals Velu's kernel poly of ker(pi - c)
#  (P3) exactly one F_q-rational l-isogeny from E1 (roots of Phi_l(j1, Y) in F_q)
#  (P4) E1(F_{q^r}) l-primary part is cyclic of order l^2 ; E1(F_{q^k})[l] = 0 for r !| k
#  (P5) kernel point P: field of definition F_{q^r} exactly, x(P) in F_{q^(r/2)} exactly, pi(P) = cP
#  (P6) Lenstra-module prediction O/(pi^k-1) (same code as the real-scale script) matches (P4)
import json, time, sys
set_random_seed(20260924)
pari.allocatemem(2^31, 2^34, silent=True)
OUT = {}
def log(*a):
    print(*a); sys.stdout.flush()

def trace_kob(m):
    t0, t1 = 2, -1
    for k in range(1, m):
        t0, t1 = t1, -t1 - 2*t0
    return t1

def lenstra_lpart(t, q, f, g, k, l, prec=8):
    """l-primary part (e1,e2) of O_g/(pi^k-1), O_g = Z + g O_K, pi = a + f w (same formulas as real-scale script)."""
    a = (t - f)//2
    assert 2*a + f == t and a^2 + a*f + 2*f^2 == q
    M = (f*l)^prec
    R = Zmod(M)
    def mul(u, v):
        (x1, y1), (x2, y2) = u, v
        return (x1*x2 - 2*y1*y2, x1*y2 + x2*y1 + y1*y2)
    res = (R(1), R(0)); b = (R(a), R(f)); kk = k
    while kk:
        if kk & 1: res = mul(res, b)
        b = mul(b, b); kk >>= 1
    A, B = ZZ(res[0]) - 1, ZZ(res[1])
    assert B % g == 0
    ents = [A % M, (B//g) % M, (-2*g*B) % M, (A + B) % M]
    det = (A*(A + B) + 2*B*B) % M
    def v(n):
        n = ZZ(n) % M
        return prec - 1 if n == 0 else min(valuation(n, l), prec - 1)
    e1 = min(v(x) for x in ents); vd = v(det)
    assert vd < prec - 1
    return (e1, vd - e1)

def order_lpower(P, l, cap=10):
    e = 0; Q = P
    while not Q.is_zero():
        Q = l*Q; e += 1
        assert e <= cap
    return e

def phi_roots_count(l, jval, Fq):
    Phi = pari(f"polmodular({l})")          # integer Phi_l(x,y)
    R2 = PolynomialRing(GF(2), 2, 'x,y')
    PhiZ = PolynomialRing(ZZ, 2, 'x,y')(str(Phi))
    Phi2 = R2(PhiZ)
    RY = PolynomialRing(Fq, 'Y')
    poly = RY(Phi2(jval, RY.gen()))
    rts = poly.roots()
    return [(str(r), int(mu)) for r, mu in rts]

def analyse_level_curve(E1, E0q, l, m, t, f, g_cond, eig, r, L, emb, sec, j_up_expected, tag):
    """E1: curve over Fq at level with l || conductor. Returns dict of checks."""
    Fq = E1.base_ring(); q = 2^m
    d = {}
    rx = r//2 if (r % 2 == 0 and GF(l)(eig)^(r//2) == -1) else r
    d["r"] = int(r); d["r_x"] = int(rx)
    # (P1) division polynomial factorization over F_q
    T = time.time()
    psi = E1.division_polynomial(l)
    fac = psi.factor()
    degs = sorted([int(h.degree()) for h, e in fac for _ in range(e)])
    d["psi_l(E1) factor degrees (multiset)"] = {str(k): degs.count(k) for k in sorted(set(degs))}
    L1 = lcm(rx, l)
    pred = {rx: (l - 1)//r if rx == r//2 or rx == r else None}
    pred = {str(rx): int(((l - 1)//2)//rx), str(L1): int(((l^2 - l)//2)//L1)}
    d["psi_l(E1) predicted (Jordan block)"] = pred
    d["(P1) psi factorization matches Jordan prediction"] = (d["psi_l(E1) factor degrees (multiset)"] == pred)
    d["time psi factor s"] = round(time.time() - T, 1)
    # (P2) kernel polynomial from the small factors, isogeny over F_q
    small = prod(h for h, e in fac if h.degree() == rx)
    d["(P2) deg of product of degree-r_x factors"] = int(small.degree())
    assert small.degree() == (l - 1)//2
    T = time.time()
    phi = E1.isogeny(small)
    jup = phi.codomain().j_invariant()
    d["(P2) codomain j of isogeny with that kernel poly"] = str(jup)
    d["(P2) codomain j == expected upper-level j"] = bool(jup == j_up_expected) if j_up_expected is not None else "n/a (checked separately)"
    d["time isogeny s"] = round(time.time() - T, 1)
    # (P3) number of F_q-rational l-isogenies via Phi_l(j1, Y)
    T = time.time()
    rts = phi_roots_count(l, E1.j_invariant(), Fq)
    d["(P3) roots of Phi_l(j1,Y) in F_q (with mult)"] = rts
    d["(P3) exactly one rational l-isogeny"] = bool(len(rts) == 1 and rts[0][1] == 1)
    d["time Phi s"] = round(time.time() - T, 1)
    # (P4)/(P5) over L = F_{q^r}
    if L is not None:
        EL = E1.base_extend(emb) if False else EllipticCurve(L, [emb(x) for x in E1.a_invariants()])
        nL = EL.order() if False else None
        # #E1(F_{q^k}) from the trace (isogeny invariant); verify on EL by a random point
        def Nk(k):
            a0, a1 = 2, t
            for i in range(1, k):
                a0, a1 = a1, t*a1 - q*a0
            tk = a1 if k >= 1 else 2
            return q^k + 1 - tk
        ext = L.degree() // m
        assert ext % r == 0
        nL = Nk(ext)
        assert all((nL * EL.random_point()).is_zero() for _ in range(3))
        vl = valuation(nL, l)
        cof = nL // l^vl
        d["ext degree over F_q"] = int(ext)
        d["(P4) v_l(#E1(F_{q^ext}))"] = int(vl)
        maxe = 0; lpts = []
        for _ in range(10):
            R = cof * EL.random_point()
            e = order_lpower(R, l)
            maxe = max(maxe, e)
            if e >= 1: lpts.append(l^(e-1)*R)
        d["(P4) max l-power order exponent among 10 samples"] = int(maxe)
        d["(P4) l-part cyclic Z/l^v (max order == l^v)"] = bool(maxe == vl)
        d["(P4) sampled l-torsion pairwise Weil-trivial"] = bool(all(A.weil_pairing(B, l) == 1 for A in lpts for B in lpts))
        d["(P4) v_l(#E1(F_{q^k})) for k | ext, k < ext"] = {str(k): int(valuation(Nk(k), l)) for k in divisors(ext) if k < ext}
        # (P6) Lenstra prediction
        d["(P6) Lenstra O_g/(pi^ext - 1) l-part"] = list(lenstra_lpart(t, q, f, g_cond, ext, l))
        d["(P6) Lenstra O_1/(pi^ext - 1) l-part (crater curve)"] = list(lenstra_lpart(t, q, f, 1, ext, l))
        d["(P6) matches: cyclic of order l^v"] = bool(tuple(d["(P6) Lenstra O_g/(pi^ext - 1) l-part"]) == (0, vl))
        # (P5) kernel point
        P = lpts[0]
        def frob(Q, k=1):
            if Q.is_zero(): return Q
            return EL(Q[0]^(q^k), Q[1]^(q^k))
        d["(P5) pi(P) == eig*P"] = bool(frob(P) == int(eig)*P)
        kpt = min(k for k in divisors(ext) if frob(P, k) == P)
        kx = min(k for k in divisors(ext) if P[0]^(q^k) == P[0])
        d["(P5) field degree of P over F_q"] = int(kpt); d["(P5) field degree of x(P) over F_q"] = int(kx)
        d["(P5) matches (r, r_x)"] = bool(kpt == r and kx == rx)
        # Velu kernel polynomial of <P> equals `small` mapped to L
        kp = EL.isogeny(P).kernel_polynomial()
        d["(P2) Velu kernel poly of <P> == product of degree-r_x factors of psi_l"] = bool(kp == kp.parent()([emb(cf) for cf in small.list()]))
    return d

def descend_via_points(E, l, L, emb, sec, avoid_js, Nk_ext):
    """E over Fq; returns (E', ker point) for an l-isogeny from E whose codomain j (in F_q) is not in avoid_js."""
    EL = EllipticCurve(L, [emb(x) for x in E.a_invariants()])
    vl = valuation(Nk_ext, l); cof = Nk_ext // l^vl
    for _ in range(200):
        R = cof * EL.random_point()
        if R.is_zero(): continue
        while not (l*R).is_zero(): R = l*R
        C = EL.isogeny(R).codomain()
        jL = C.j_invariant()
        jq = sec(jL)
        assert emb(jq) == jL
        if jq in avoid_js: continue
        # model over F_q with a2 in {0,1} isomorphic to C over L -> pick the one with the same trace as E
        Fq = E.base_ring()
        for a2 in (0, 1):
            cand = EllipticCurve(Fq, [1, a2, 0, 0, 1/jq])
            if cand.trace_of_frobenius() == E.trace_of_frobenius():
                return cand, R
    raise RuntimeError("no descending kernel found")

def Nk_formula(t, q, k):
    a0, a1 = 2, t
    for i in range(1, k):
        a0, a1 = a1, t*a1 - q*a0
    return q^k + 1 - (a1 if k >= 1 else 2)

def toy_single(m, l, tag):
    T0 = time.time()
    q = 2^m; t = trace_kob(m); D = t^2 - 4*q; f = isqrt(D // -7); assert -7*f^2 == D and f % l == 0 and (f//l) % l != 0
    c = GF(l)(t)/2; r = c.multiplicative_order()
    res = {"m": m, "l": l, "t": int(t), "f": str(factor(f)), "(-7|l)": int(kronecker(-7, l)), "c": int(c), "r": int(r)}
    L = GF(2^(m*r), 'w'); Fq, emb = L.subfield(m, 'z', map=True); sec = emb.section()
    E0 = EllipticCurve(Fq, [1, 0, 0, 0, 1]); assert E0.trace_of_frobenius() == t
    # crater check: psi_l(E0) all factors of degree r_x
    rx = r//2 if (r % 2 == 0 and c^(r//2) == -1) else r
    fac0 = E0.division_polynomial(l).factor()
    degs0 = sorted(int(h.degree()) for h, e in fac0 for _ in range(e))
    res["psi_l(E0) factor degrees"] = {str(k): degs0.count(k) for k in sorted(set(degs0))}
    res["psi_l(E0) all degree r_x (scalar action)"] = bool(set(degs0) == {rx})
    E1, _ = descend_via_points(E0, l, L, emb, sec, [Fq(1)], Nk_formula(t, q, r))
    res["E1"] = str(E1.a_invariants()); res["j1"] = str(E1.j_invariant())
    res["E1 analysis"] = analyse_level_curve(E1, E0, l, m, t, f, l, c, r, L, emb, sec, Fq(1), tag)
    res["time_s"] = round(time.time() - T0, 1)
    return res

