#!/usr/bin/env python3
"""C3 audit, real scale, plain python3 (no Sage, no ground-truth import).

Independent method: Lenstra (J. Number Theory 56, 1996), Thm 1: for an ordinary E/F_q with
O = End(E) (all endomorphisms are F_q-rational for ordinary E), E(F_{q^k}) = O/(pi^k - 1)O as
O-modules, and E[n] = O/nO.  So for each order O_g = Z + g*O_K (g = 1, 263, p, 263p) we compute
  * the matrix of pi on E[p] = O_g/p O_g  (scalar vs Jordan block),
  * the p-primary part of O_g/(pi^k - 1) as an abelian group, via p-adic elementary divisors
    of the 2x2 integer matrix of multiplication by pi^k - 1 on the Z-basis {1, g*w}.
O_K = Z[w], w = (1+sqrt(-7))/2, w^2 = w - 2.
"""
import json, math, random, sys, time
T0 = time.time()
out = {}

def is_prime(n):
    if n < 2: return False
    small = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]
    for sp in small:
        if n % sp == 0: return n == sp
    d, s = n - 1, 0
    while d % 2 == 0: d //= 2; s += 1
    # deterministic for n < 3.3e24 with these 13 bases; for larger n it is a strong probable-prime test
    for a in small:
        x = pow(a, d, n)
        if x in (1, n - 1): continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1: break
        else:
            return False
    return True

def pollard(n):
    if n % 2 == 0: return 2
    while True:
        x = random.randrange(2, n); y = x; cc = random.randrange(1, n); d = 1
        while d == 1:
            x = (x * x + cc) % n; y = (y * y + cc) % n; y = (y * y + cc) % n
            d = math.gcd(abs(x - y), n)
        if d != n: return d

def factor(n):
    fs = {}
    def rec(m):
        if m == 1: return
        if is_prime(m): fs[m] = fs.get(m, 0) + 1; return
        for sp in range(2, 10**5):
            if m % sp == 0:
                rec(sp); rec(m // sp); return
            if sp * sp > m: break
        d = pollard(m); rec(d); rec(m // d)
    rec(n)
    return dict(sorted(fs.items()))

def mult_order(a, n, fac_phi, phi):
    o = phi
    for l, e in fac_phi.items():
        for _ in range(e):
            if o % l == 0 and pow(a, o // l, n) == 1: o //= l
    return o

# ---- constants from scratch ----
q = 2**131
t0, t1 = 2, -1                        # traces of tau^k, tau^2 + tau + 2 = 0; t_1 = -1 as #E0(F_2) = 4
for _ in range(130):
    t0, t1 = t1, -t1 - 2 * t0
t = t1
Dpi = t * t - 4 * q
assert Dpi % 7 == 0
f = math.isqrt(Dpi // -7); assert -7 * f * f == Dpi
assert f % 263 == 0
p = f // 263
assert is_prime(p) and is_prime(263) and p < 3 * 10**24   # MR with 13 bases is a proof below 3.3e24
N = (q + 1 - t) // 4; assert 4 * N == q + 1 - t
out["t"] = str(t); out["f"] = str(f); out["p"] = str(p); out["log2_p"] = math.log2(p)
out["kernel_poly_degree (p-1)/2"] = str((p - 1) // 2)
assert (p - 1) // 2 == 73252881940764360

# Legendre (-7|p) by Euler
leg = pow(-7 % p, (p - 1) // 2, p)
out["(-7|p) Euler"] = -1 if leg == p - 1 else leg

# pi in Z[w]: pi = a + f*w with a = (t - f)/2 ; check Tr, Nm
assert (t - f) % 2 == 0
a = (t - f) // 2
# N(x + y w) = x^2 + x y + 2 y^2 ; Tr(x + y w) = 2x + y
assert 2 * a + f == t and a * a + a * f + 2 * f * f == q
out["pi = a + f*w, a"] = str(a)

# c = eigenvalue of pi on E[p]
c = (t * pow(2, -1, p)) % p
assert (c * c - q) % p == 0 and (a - c) % p == 0
out["c = t/2 mod p"] = c
fac = factor(p - 1)
out["factor(p-1)"] = {str(k): v for k, v in fac.items()}
r = mult_order(c, p, fac, p - 1)
out["r = ord_p(c)"] = r
out["(p-1)/r"] = (p - 1) // r
out["r even"] = r % 2 == 0
out["c^(r/2) == -1 mod p"] = pow(c, r // 2, p) == p - 1
out["ord_p(-c)"] = mult_order((-c) % p, p, fac, p - 1)
# orbit structure of <c> on F_p^*/{+-1}: size of image of <c> in F_p^*/{+-1}
img = r // 2 if (r % 2 == 0 and pow(c, r // 2, p) == p - 1) else r
out["orbit size of <c> on F_p^*/+-1 (= deg of each F_q-irreducible factor of ascending kernel poly)"] = img
out["number of orbits = number of F_q-irreducible factors"] = ((p - 1) // 2) // img
assert ((p - 1) // 2) % img == 0

# ---- arithmetic in Z[w] modulo M ----
def zmul(u, v, M):
    (x1, y1), (x2, y2) = u, v
    # (x1 + y1 w)(x2 + y2 w) = x1x2 + (x1y2 + x2y1) w + y1y2 (w - 2)
    return ((x1 * x2 - 2 * y1 * y2) % M, (x1 * y2 + x2 * y1 + y1 * y2) % M)
def zpow(u, k, M):
    res = (1 % M, 0); b = (u[0] % M, u[1] % M)
    while k:
        if k & 1: res = zmul(res, b, M)
        b = zmul(b, b, M); k >>= 1
    return res
def vp(n, l, cap):
    if n == 0: return cap
    v = 0
    while n % l == 0 and v < cap: n //= l; v += 1
    return v

PREC = 8                                  # p-adic precision (enough: all valuations found are < PREC)
M = (263 * p) ** PREC                    # work modulo (263 p)^PREC so divisibility by g | 263p is exact
def group_p_part(g, k, ell=None):
    """p-primary (or ell-primary) part of O_g/(pi^k - 1) as (e1, e2): Z/ell^e1 x Z/ell^e2."""
    ell = ell or p
    A, B = zpow((a, f), k, M)
    A = (A - 1) % M                         # alpha = pi^k - 1 = A + B w
    assert B % g == 0, "pi^k must lie in O_g"
    Bg = (B // g)
    # matrix of mult-by-alpha on basis {1, g w}:  alpha*1 = A + Bg*(g w);  alpha*(g w) = -2 g B + (A + B)(g w)
    ents = [A, Bg, (-2 * g * B), (A + B)]
    det = (A * (A + B) + 2 * B * B)         # = N(alpha) (mod M)
    cap = PREC - 1
    e1 = min(vp(x % M, ell, cap) for x in ents)
    vdet = vp(det % M, ell, cap)
    assert vdet < cap and e1 < cap, "precision too low"
    return (e1, vdet - e1), vdet

def pi_on_Ep(g):
    """matrix of pi on O_g/p O_g in basis {1, g w}: pi = a + (f/g)(g w)."""
    assert f % g == 0
    u = (f // g)
    # pi*1 = a*1 + u*(gw);  pi*(gw) = g(a w + f w^2) = g(a w + f w - 2 f) = -2 g f + (a + f)(g w)
    Mx = [[a % p, (-2 * g * f) % p], [u % p, (a + f) % p]]
    scalar = (Mx[0][1] == 0 and Mx[1][0] == 0 and Mx[0][0] == Mx[1][1])
    nil = [[(Mx[0][0] - c) % p, Mx[0][1]], [Mx[1][0], (Mx[1][1] - c) % p]]
    nil2 = [[sum(nil[i][k] * nil[k][j] for k in range(2)) % p for j in range(2)] for i in range(2)]
    return {"matrix mod p": [[str(x) for x in row] for row in Mx], "scalar": scalar,
            "(pi-c) != 0": any(x for row in nil for x in row), "(pi-c)^2 == 0": all(x == 0 for row in nil2 for x in row),
            "dim ker(pi-c) (=2 - rank)": 2 - (0 if all(x == 0 for row in nil for x in row) else 1)}

conductors = {"1": 1, "263": 263, "p": p, "263p": 263 * p}
res = {}
fr = factor(r)
for name, g in conductors.items():
    d = {"pi on E[p]": pi_on_Ep(g)}
    (e1, e2), v = group_p_part(g, r)
    d["k=r: p-part of E(F_{q^r}) = Z/p^e1 x Z/p^e2"] = [e1, e2]
    d["k=r: v_p(#E)"] = v
    d["k=r/l, l|r: v_p(#E)"] = {str(l): group_p_part(g, r // l)[1] for l in fr}
    d["k=r/2 (x-field): v_p(#E)"] = group_p_part(g, r // 2)[1]
    (e1, e2), v = group_p_part(g, r * p)
    d["k=r*p: p-part (e1,e2)"] = [e1, e2]
    # E[p] subset E(F_{q^k}) iff e1 >= 1 (both elementary divisors divisible by p)
    d["k=r*p: E[p] contained"] = e1 >= 1
    # minimality of F_{q^(rp)} for the full E[p]: for every prime l | r p, E[p] not inside E(F_{q^(rp/l)})
    mins = {}
    for l in list(fr) + [p]:
        (x1, x2), _v = group_p_part(g, r * p // l)
        mins[str(l)] = {"p-part": [x1, x2], "E[p] contained": x1 >= 1}
    d["k=r*p/l for primes l | r*p"] = mins
    d["F_{q^(rp)} minimal for E[p]"] = (e1 >= 1) and not any(v["E[p] contained"] for v in mins.values())
    (e1, e2), v = group_p_part(g, r * p // 2)  # rp/2 not an integer multiple of r -> just record
    d["k=r*p/2: p-part (e1,e2)"] = [e1, e2]
    res[name] = d
out["per_conductor"] = res
# sanity: #E(F_{q^k}) is an isogeny invariant -> all conductors give the same v_p
vs = {res[n]["k=r: v_p(#E)"] for n in res}
assert len(vs) == 1

# check (p-1)/2 x-values -> 12 factors: brute orbit count on a random sample of x-classes would be 2^57, skip;
# the orbit statement is group theory (free action of <c>/{+-1} on F_p^*/{+-1}).
out["elapsed_s"] = round(time.time() - T0, 2)
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C3-audit/c3_real_scale.json", "w"), indent=1, default=str)
print(json.dumps(out, indent=1, default=str))
