\\ C3 cross-check in PARI/GP (independent of the python script): c, r, (p-1)/r, v_p(#E(F_{q^k})) for k = r, r/l
q = 2^131; t0 = 2; t1 = -1; for(k = 1, 130, [t0, t1] = [t1, -t1 - 2*t0]); t = t1;
f = sqrtint((4*q - t^2)/7); p = f/263;
print("t = ", t, "  f = ", f, "  p = ", p, "  isprime(p) = ", isprime(p), "  (-7|p) = ", kronecker(-7, p));
c = Mod(t, p)/2; print("c = ", lift(c), "  c^2 == q: ", c^2 == Mod(q, p));
r = znorder(c); print("r = ", r, "  factor(r) = ", factor(r), "  (p-1)/r = ", (p-1)/r, "  c^(r/2) = ", lift(c^(r/2)), " (p-1 = ", p-1, ")");
print("ord(-c) = ", znorder(-c), "  (p-1)/2 = ", (p-1)/2);
\\ #E(F_{q^k}) = Norm(1 - pi^k), pi = (t + f*sqrt(-7))/2, computed in (Z/p^4)[y]/(y^2+7)
m = p^4; y = Mod(Mod(1, m)*'y, 'y^2 + 7); pi = (Mod(t, m) + Mod(f, m)*y)/2;
vN(k) = { my(a = lift(lift(1 - pi^k)), X = polcoef(a, 0, 'y), Y = polcoef(a, 1, 'y), n = lift(X^2 + 7*Y^2)); if(n == 0, ">=4", valuation(n, p)) };
print("v_p(#E(F_{q^r})) = ", vN(r));
fr = factor(r)[, 1]; for(i = 1, #fr, print("  v_p(#E(F_{q^(r/", fr[i], ")})) = ", vN(r/fr[i])));
\\ y-coordinate of pi^r - 1 in basis {1, sqrt(-7)}: 1 - pi^r = X + Y sqrt(-7); v_p(Y) = 1 => not divisible by p in O_K
a = 1 - pi^r; Y = polcoef(lift(lift(a)), 1, 'y); X = polcoef(lift(lift(a)), 0, 'y);
print("v_p(X) = ", valuation(lift(X), p), "  v_p(Y) = ", valuation(lift(Y), p));
\\ direct brute check of the 12-orbit statement on F_p^*/{+-1} is impossible (2^56 elements); count via group theory:
print("orbit size on F_p^*/+-1 = ", r/2, "  #orbits = ", ((p-1)/2)/(r/2));
