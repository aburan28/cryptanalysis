"""
Part B of the C2 recompute (Sage 10.9):
  B1. PARI quadclassunit (Buchmann subexponential algorithm; GRH-conditional)
      for D = -7 p^2, -7*263^2, -7*263^2 p^2  -- a different algorithm from
      qfbclassno / the conductor formula.
  B2. Sage's own factorization of x^2+x+2 over GF(p) and GF(p) is_prime.
  B3. Toy inert-prime volcano built by explicit Velu isogenies (not modular
      polynomials): m = 37, l = 73 (the only toy with l | f_m, l inert and a
      feasible field of definition of E[l]; found by toy_search.py). We work on
      the quadratic twist, whose l-torsion is rational over a smaller field.
"""
import json, time, sys
from sage.all import (GF, EllipticCurve, ZZ, pari, PolynomialRing, is_prime,
                      Hom, Integer, lcm, factor)

T0 = time.time()
out = {}
p = ZZ(146505763881528721)

# ---------------- B1 ----------------
for name, D in (("O_p", -7 * p**2), ("O_263", -7 * 263**2),
                ("O_263p", -7 * 263**2 * p**2)):
    t1 = time.time()
    try:
        r = pari.quadclassunit(D)
        out["quadclassunit_" + name] = {
            "D": str(D), "h": str(r[0]), "cyc": [str(c) for c in r[1]],
            "secs": round(time.time() - t1, 2)}
    except Exception as e:
        out["quadclassunit_" + name] = {"D": str(D), "error": str(e)}
    print(name, out["quadclassunit_" + name], flush=True)

# ---------------- B2 ----------------
R = PolynomialRing(GF(p), "x")
x = R.gen()
out["sage_factor_x^2+x+2_mod_p"] = str((x**2 + x + 2).factor())
out["sage_is_irreducible"] = bool((x**2 + x + 2).is_irreducible())
out["sage_is_prime_p_proof"] = bool(p.is_prime(proof=True))
out["sage_factor_p+1"] = str(factor(p + 1))
print(out, flush=True)

# ---------------- B3: toy volcano via Velu ----------------
m, l = 37, 73
a_, b_ = 2, -1
for _ in range(m - 1):
    a_, b_ = b_, -b_ - 2 * a_
tm = b_
qm = 2**m
fm2 = (4 * qm - tm * tm) // 7
fm = ZZ(fm2).isqrt()
assert fm * fm == fm2 and fm % l == 0
K = GF(2**m, "z")
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
E0t = EllipticCurve(K, [1, 1, 0, 0, 1])
assert E0.order() == qm + 1 - tm
assert E0t.order() == qm + 1 + tm
# pi = A + B tau ; scalar on E[l] is A mod l (B = +-f_m)
A, B = 1, 0
for _ in range(m):
    A, B = -2 * B, A - B
assert 2 * A - B == tm and abs(B) == fm
u = ZZ(A) % l
ut = (-u) % l                      # Frobenius of the twist acts as -pi
k = ZZ(ut).multiplicative_order() if False else Integer(pari.znorder(pari.Mod(ut, l)))
out["toy"] = {"m": m, "l": l, "t_m": str(tm), "f_m": str(fm),
              "(-7|l)": int(pari.kronecker(-7, l)), "u": int(u),
              "twist_scalar": int(ut), "ext_degree_for_twist_E[l]": int(m * k),
              "h(-7 l^2) qfbclassno": int(pari.qfbclassno(-7 * l * l))}
print(out["toy"], flush=True)
L = GF(2**(m * k), "w")
emb = Hom(K, L).an_element()      # some embedding K -> L
assert emb(K.gen()).minpoly() == K.modulus()
EL = EllipticCurve(L, [1, 1, 0, 0, 1])
# order over L via Frobenius recurrence of -pi (trace -tm, norm qm)
s0, s1 = 2, -tm
tr = s1
for _ in range(k - 1):
    s0, s1 = s1, (-tm) * s1 - qm * s0
tr = s1 if k > 1 else -tm
nL = ZZ(2**(m * k) + 1 - tr)
assert nL % (l * l) == 0
cof = nL
while cof % l == 0:
    cof //= l
v = nL.valuation(l)

def point_of_order_l():
    while True:
        P = EL.random_point() * cof
        if P.is_zero():
            continue
        while not (l * P).is_zero():
            P = l * P
        return P

P1 = point_of_order_l()
while True:
    P2 = point_of_order_l()
    if P1.weil_pairing(P2, l) != 1:
        break
out["toy"]["weil_pairing_nontrivial"] = True
# Frobenius over K (x -> x^(2^m)) acts on E[l] as scalar ut ?
def frob(P):
    return EL(P[0]**qm, P[1]**qm)
scalar_ok = all(frob(P) == ut * P for P in (P1, P2, P1 + P2))
out["toy"]["frobenius_is_scalar_on_E[l]"] = scalar_ok
gens = [P1] + [P2 + i * P1 for i in range(l)]
js = []
t1 = time.time()
for G in gens:
    phi = EL.isogeny(G)
    j = phi.codomain().j_invariant()
    js.append(j)
out["toy"]["velu_secs"] = round(time.time() - t1, 1)
# which lie in K (fixed by x -> x^(2^m))?
inK = [j**qm == j for j in js]
out["toy"]["n_kernels"] = len(gens)
out["toy"]["all_codomain_j_in_F_2^m"] = all(inK)
out["toy"]["n_codomain_j_equal_1 (horizontal)"] = sum(1 for j in js if j == 1)
out["toy"]["n_distinct_j"] = len(set(js))
# degree over F_2 and orbits under squaring
def deg_F2(j):
    d, y = 1, j**2
    while y != j:
        y = y**2
        d += 1
    return d
degs = [deg_F2(j) for j in js]
out["toy"]["degrees_over_F2"] = sorted(set(degs))
orbits = set()
for j in js:
    orb = [j]
    y = j**2
    while y != j:
        orb.append(y)
        y = y**2
    orbits.add(frozenset(orb))
out["toy"]["n_orbits"] = len(orbits)
out["toy"]["orbit_sizes"] = sorted(len(o) for o in orbits)
out["toy"]["orbits_closed_under_squaring_within_set"] = all(o <= set(js) for o in orbits)
# level check: each codomain curve (as curve over K, a2 chosen to match the
# twist class) has l-part of E'(F_{2^{mk}})... simpler: check a descended curve
# is NOT F_2^m-isomorphic to E0/E0t and its l-isogeny graph degree over K is 1:
# count F_{2^m}-rational l-subgroups on one codomain via its l-torsion over L.
phi = EL.isogeny(gens[1])
E1 = phi.codomain()
Q1 = phi(P1)                       # generates the dual kernel direction
out["toy"]["sample_codomain_j_in_K"] = bool(E1.j_invariant()**qm == E1.j_invariant())
out["secs_total"] = round(time.time() - T0, 1)
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C2-recompute/c2_sage.json", "w"), indent=1, default=str)
print(json.dumps(out, indent=1, default=str))
