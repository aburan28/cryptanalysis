#!/usr/bin/env python3
"""
Independent recomputation of claim C2 using ONLY hand-written integer code
(plain python3, no PARI / Sage / sweep scripts).

Checks:
  1. t, #E0 = 4N, f^2 = (4q - t^2)/7, f = 263*p        (Lucas recurrence)
  2. p prime: deterministic Miller-Rabin + Pocklington/Lucas proof with own
     Pollard-rho factorization of p-1
  3. (-7|p): own Jacobi symbol; independently x^2+x+2 irreducible mod p by
     computing x^p in F_p[x]/(x^2+x+2)  (== -1-x  <=> irreducible)
  4. Frobenius pi is a scalar on E0[p] (so all p+1 kernels are F_q-rational)
  5. Class group of O_p via (O_K/p)^*/F_p^* = F_{p^2}^*/F_p^* :
       - order of tau (prime above 2) in the quotient == 131
       - factor p+1, exhibit an element of order exactly p+1 in the quotient
  6. Own binary-quadratic-form arithmetic (Dirichlet composition + reduction):
       - prime form above 2 has order exactly 131 for D=-7p^2, -7*263^2, -7*263^2 p^2
       - a form of order exactly p+1 in Cl(-7p^2)  (=> h >= p+1; exact sequence
         gives h <= p+1)
       - exponent/structure evidence for Cl(-7*263^2*p^2)
  7. Class-number arithmetic: p+1, 262(p+1), log2 values, (p+1)/131
"""
import json, math, random, sys, time

random.seed(20260923)
out = {}
t0 = time.time()

q = 2 ** 131
# ---------- 1. trace by Lucas recurrence of tau^2 + tau + 2 = 0 ----------
# t_k = tau^k + taubar^k;  t_0 = 2, t_1 = -1, t_{k+1} = -t_k - 2 t_{k-1}
a, b = 2, -1
for _ in range(130):
    a, b = b, -b - 2 * a
t = b
card = q + 1 - t
N = 680564733841876926932320129493409985129
assert card == 4 * N, "card != 4N"
disc = t * t - 4 * q
assert disc % 7 == 0
f2 = -disc // 7
f = math.isqrt(f2)
assert f * f == f2
assert f % 263 == 0
p = f // 263
out["t"] = str(t)
out["card"] = str(card)
out["f"] = str(f)
out["p"] = str(p)
assert p == 146505763881528721

# ---------- 2. primality of p ----------
def mr(n, bases=(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41)):
    if n < 2:
        return False
    for sp in bases:
        if n % sp == 0:
            return n == sp
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    for a_ in bases:
        x = pow(a_, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True

def rho(n):
    if n % 2 == 0:
        return 2
    while True:
        y, c, m = random.randrange(1, n), random.randrange(1, n), 128
        g, r, qq = 1, 1, 1
        while g == 1:
            x = y
            for _ in range(r):
                y = (y * y + c) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(m, r - k)):
                    y = (y * y + c) % n
                    qq = qq * abs(x - y) % n
                g = math.gcd(qq, n)
                k += m
            r *= 2
        if g == n:
            g = 1
            while g == 1:
                ys = (ys * ys + c) % n
                g = math.gcd(abs(x - ys), n)
        if g != n:
            return g

def factor(n):
    fs = {}
    for sp in range(2, 1000):
        while n % sp == 0:
            fs[sp] = fs.get(sp, 0) + 1
            n //= sp
    stack = [n] if n > 1 else []
    while stack:
        m_ = stack.pop()
        if m_ == 1:
            continue
        if mr(m_):
            fs[m_] = fs.get(m_, 0) + 1
            continue
        d = rho(m_)
        stack += [d, m_ // d]
    return dict(sorted(fs.items()))

# MR with the first 13 prime bases is deterministic for n < 3.3e24 (> 2^57)
assert mr(p)
fpm1 = factor(p - 1)
prod = 1
for r, e in fpm1.items():
    prod *= r ** e
    assert mr(r)
assert prod == p - 1
# Lucas / Pocklington certificate: find a witness of order p-1
for a_ in range(2, 200):
    if pow(a_, p - 1, p) != 1:
        raise SystemExit("p composite (Fermat)")
    if all(pow(a_, (p - 1) // r, p) != 1 for r in fpm1):
        lucas_witness = a_
        break
else:
    raise SystemExit("no Lucas witness found")
out["p_minus_1_factorization"] = {str(k): v for k, v in fpm1.items()}
out["p_lucas_witness"] = lucas_witness

# ---------- 3. (-7|p) ----------
def jacobi(a_, n):
    assert n > 0 and n % 2 == 1
    a_ %= n
    res = 1
    while a_:
        while a_ % 2 == 0:
            a_ //= 2
            if n % 8 in (3, 5):
                res = -res
        a_, n = n, a_
        if a_ % 4 == 3 and n % 4 == 3:
            res = -res
        a_ %= n
    return res if n == 1 else 0

out["jacobi_-7_p"] = jacobi(-7, p)
out["p_mod_7"] = p % 7
out["qr_mod_7"] = sorted({(x * x) % 7 for x in range(1, 7)})

# F_p[x]/(x^2 + x + 2): elements (c0, c1) = c0 + c1 x,  x^2 = -x - 2
def mul(u, v, n=p):
    a0, a1 = u
    b0, b1 = v
    c0 = a0 * b0
    c1 = a0 * b1 + a1 * b0
    c2 = a1 * b1
    return ((c0 - 2 * c2) % n, (c1 - c2) % n)

def pw(u, e, n=p):
    r_ = (1, 0)
    while e:
        if e & 1:
            r_ = mul(r_, u, n)
        u = mul(u, u, n)
        e >>= 1
    return r_

xp = pw((0, 1), p)
out["x^p mod (p, x^2+x+2)"] = [xp[0], xp[1]]
irreducible = xp == ((-1) % p, (-1) % p)   # conjugate root -1-x
out["x^2+x+2_irreducible_mod_p"] = irreducible
assert irreducible and out["jacobi_-7_p"] == -1

# ---------- 4. pi scalar on E0[p] ----------
# pi = tau^131 in O_K; compute it in Z[x]/(x^2+x+2) exactly: pi = A + B x
def mul_Z(u, v):
    a0, a1 = u
    b0, b1 = v
    c2 = a1 * b1
    return (a0 * b0 - 2 * c2, a0 * b1 + a1 * b0 - c2)

pi = (1, 0)
for _ in range(131):
    pi = mul_Z(pi, (0, 1))
A, B = pi
# trace(A + B x) = 2A + B*trace(x) = 2A - B ; norm = A^2 - AB + 2B^2
assert 2 * A - B == t
assert A * A - A * B + 2 * B * B == q
out["pi_coords_in_Z[tau]"] = [str(A), str(B)]
out["abs(B)==f"] = abs(B) == f           # conductor of Z[pi] in O_K
out["B mod p"] = B % p                  # 0 => pi = A (scalar) on E0[p]
out["A mod p (scalar)"] = A % p
out["A^2 == q mod p"] = (A * A - q) % p == 0
out["A != 1 mod p (E0[p] not F_q-rational pointwise)"] = (A - 1) % p != 0

# ---------- 5. Cl(O_p) = F_{p^2}^* / F_p^* ----------
def in_Fp(u):
    return u[1] % p == 0

tau = (0, 1)
out["tau in F_p"] = in_Fp(tau)
tau131 = pw(tau, 131)
out["tau^131 in F_p"] = in_Fp(tau131)
out["tau^131 == A mod p"] = tau131 == (A % p, 0)
fpp1 = factor(p + 1)
out["p_plus_1_factorization"] = {str(k): v for k, v in fpp1.items()}
out["131 | p+1"] = (p + 1) % 131 == 0
out["(p+1)/131"] = str((p + 1) // 131)
# order of tau in the quotient
def order_in_quot(u, n_ord, fs):
    o = n_ord
    for r in fs:
        while o % r == 0 and in_Fp(pw(u, o // r)):
            o //= r
    return o
out["order_tau_in_F_p2*/F_p*"] = order_in_quot(tau, p + 1, fpp1)
# element of order exactly p+1 (cyclic quotient)
for c in range(1, 100):
    g = (c, 1)
    if order_in_quot(g, p + 1, fpp1) == p + 1:
        out["generator_of_quotient"] = f"{c}+tau"
        break

# ---------- 6. own binary quadratic form arithmetic ----------
def reduce_form(a_, b_, c_):
    while True:
        if a_ > c_:
            a_, b_, c_ = c_, -b_, a_
            continue
        if b_ > a_ or b_ <= -a_:
            # normalize b into (-a, a]
            k = (a_ - b_) // (2 * a_)
            nb = b_ + 2 * k * a_
            c_ = (nb * nb - (b_ * b_ - 4 * a_ * c_)) // (4 * a_)
            b_ = nb
            continue
        if a_ == c_ and b_ < 0:
            b_ = -b_
        return (a_, b_, c_)

def xgcd(x, y):
    x0, x1, y0, y1 = 1, 0, 0, 1
    while y:
        qq = x // y
        x, y = y, x - qq * y
        x0, x1 = x1, x0 - qq * x1
        y0, y1 = y1, y0 - qq * y1
    return x, x0, y0

def compose(F, G, D):
    # Cohen, Alg. 5.4.7 (Shanks composition), written from scratch
    a1, b1, c1 = F
    a2, b2, c2 = G
    if a1 > a2:
        a1, b1, c1, a2, b2, c2 = a2, b2, c2, a1, b1, c1
    s = (b1 + b2) // 2
    n = b2 - s
    if a2 % a1 == 0:
        y1, d = 0, a1
    else:
        d, u, v = xgcd(a2, a1)
        y1 = u
    if s % d == 0:
        y2, x2, d1 = -1, 0, d
    else:
        d1, x2, y2 = xgcd(s, d)
        y2 = -y2
    v1 = a1 // d1
    v2 = a2 // d1
    r = (y1 * y2 * n - x2 * c2) % v1
    b3 = b2 + 2 * v2 * r
    a3 = v1 * v2
    c3 = (c2 * d1 + r * (b2 + v2 * r)) // v1
    assert b3 * b3 - 4 * a3 * c3 == D
    return reduce_form(a3, b3, c3)

def form_pow(F, e, D):
    ident = reduce_form(1, 1, (1 - D) // 4)
    R = ident
    while e:
        if e & 1:
            R = compose(R, F, D)
        F = compose(F, F, D)
        e >>= 1
    return R

def sqrt_mod_prime(a_, l):
    a_ %= l
    for x in range(l):
        if x * x % l == a_:
            return x
    return None

def prime_form(D, l):
    # l odd prime (or 2) with (D|l) = 1; returns reduced (l, b, c)
    if l == 2:
        assert D % 8 == 1
        b_ = 1
    else:
        b_ = sqrt_mod_prime(D, l)
        if b_ is None or b_ == 0:
            return None
        if (b_ - D) % 2:
            b_ = l - b_
    c_ = (b_ * b_ - D) // (4 * l)
    assert b_ * b_ - 4 * l * c_ == D
    return reduce_form(l, b_, c_)

def order_of(F, D, n_ord, fs):
    ident = reduce_form(1, 1, (1 - D) // 4)
    assert form_pow(F, n_ord, D) == ident
    o = n_ord
    for r in fs:
        while o % r == 0 and form_pow(F, o // r, D) == ident:
            o //= r
    return o

forms = {}
for name, D in (("O_p", -7 * p * p), ("O_263", -7 * 263 * 263),
                ("O_263p", -7 * 263 * 263 * p * p)):
    ident = reduce_form(1, 1, (1 - D) // 4)
    P2 = prime_form(D, 2)
    rec = {"D": str(D), "prime_form_2": [str(x) for x in P2],
           "P2_is_identity": P2 == ident,
           "P2^131_is_identity": form_pow(P2, 131, D) == ident}
    rec["order_P2"] = order_of(P2, D, 131, {131: 1})
    forms[name] = rec

# Cl(O_p): find a prime form of order exactly p+1
D = -7 * p * p
ords = []
found = None
for l in range(3, 400):
    if not mr(l) or l == 7 or jacobi(D % l, l) != 1:
        continue
    F = prime_form(D, l)
    o = order_of(F, D, p + 1, fpp1)
    ords.append((l, o))
    if o == p + 1 and found is None:
        found = l
L = 1
for _, o in ords:
    L = L * o // math.gcd(L, o)
forms["O_p"]["split_primes_tested"] = len(ords)
forms["O_p"]["first_prime_form_of_order_p+1"] = found
forms["O_p"]["lcm_orders"] = str(L)
forms["O_p"]["lcm==p+1"] = L == p + 1

# Cl(O_263): order 262, check a form of order 262 exists (cyclic) and exponent
D = -7 * 263 * 263
f262 = {2: 1, 131: 1}
ords = []
for l in range(3, 400):
    if not mr(l) or l in (7, 263) or jacobi(D % l, l) != 1:
        continue
    ords.append(order_of(prime_form(D, l), D, 262, f262))
forms["O_263"]["max_order_split_primes"] = max(ords)

# Cl(O_263p): predicted Z/262 x Z/(p+1); exponent p+1 (since 262 | p+1).
D = -7 * 263 * 263 * p * p
ords = []
for l in range(3, 400):
    if not mr(l) or l in (7, 263) or jacobi(D % l, l) != 1:
        continue
    ords.append(order_of(prime_form(D, l), D, p + 1, fpp1))
L = 1
for o in ords:
    L = L * o // math.gcd(L, o)
forms["O_263p"]["exponent_lcm_split_primes"] = str(L)
forms["O_263p"]["exponent==p+1"] = L == p + 1
# 2-rank / 131-rank evidence: Z/262 x Z/(p+1) has two independent elements of
# order 131. Test: take forms F,G of order divisible by 131; project to the
# 131-torsion (raise to (p+1)/131); check independence (G' not in <F'>).
proj = []
for l in range(3, 400):
    if not mr(l) or l in (7, 263) or jacobi(D % l, l) != 1:
        continue
    X = form_pow(prime_form(D, l), (p + 1) // 131, D)
    proj.append((l, X))
ident = reduce_form(1, 1, (1 - D) // 4)
nontriv = [(l, X) for l, X in proj if X != ident]
indep = None
if nontriv:
    l0, X0 = nontriv[0]
    span = set()
    Y = ident
    for _ in range(131):
        span.add(Y)
        Y = compose(Y, X0, D)
    assert Y == ident
    for l, X in nontriv[1:]:
        if X not in span:
            indep = (l0, l)
            break
forms["O_263p"]["131_rank_ge_2_witness"] = indep
# same for 2-torsion: number of ambiguous classes; test 2-rank via (p+1)/2 powers
proj2 = set()
for l in range(3, 400):
    if not mr(l) or l in (7, 263) or jacobi(D % l, l) != 1:
        continue
    proj2.add(form_pow(prime_form(D, l), (p + 1) // 2, D))
forms["O_263p"]["distinct_2-torsion_projections"] = len(proj2)
out["forms"] = forms

# ---------- 7. class-number arithmetic ----------
h_p = p - jacobi(-7, p)            # h(O_K)=1, w=2 -> O_K^* = O_f^*
h_263 = 263 - jacobi(-7, 263)
h_263p = h_263 * h_p
out["h(O_p)"] = str(h_p)
out["h(O_263)"] = h_263
out["h(O_263p)"] = str(h_263p)
out["log2 h(O_p)"] = round(math.log2(h_p), 4)
out["log2 h(O_263p)"] = round(math.log2(h_263p), 4)
out["claimed h(O_p) matches"] = h_p == 146505763881528722
out["claimed h(O_263p) matches"] = h_263p == 38384510136960525164
# group-order count of (O_K/f)^*/(Z/f)^* directly from local factors
# 263 split: (F_263^*)^2 / F_263^*  ; p inert: F_{p^2}^*/F_p^*
out["|(O_K/263p)^*|/|(Z/263p)^*|"] = str((262 * 262 * (p * p - 1)) // (262 * (p - 1)))
out["elapsed_s"] = round(time.time() - t0, 2)
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/p-levels/C2-recompute/c2_plain.json", "w"), indent=1)
print(json.dumps(out, indent=1))
