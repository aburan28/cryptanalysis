from sympy import isprime, n_order, factorint
res=[]
for m in range(5,80):
    if not isprime(m): continue
    a,b=2,-1
    for _ in range(m-1): a,b=b,-b-2*a
    t=b; q=2**m
    f2=(4*q-t*t)//7; import math; f=math.isqrt(f2); assert f*f==f2
    for l,e in factorint(f).items():
        if l in (2,7): continue
        # inert?
        if pow(-7 % l,(l-1)//2,l)!=l-1: continue
        # scalar u = A mod l : pi = A + B tau ; compute
        A,B=1,0
        for _ in range(m):
            A,B=-2*B, A-B   # (A+B x)*x = A x + B x^2 = -2B + (A-B) x
        assert 2*A-B==t
        u=A%l
        k=n_order(u,l)
        res.append((m,l,e,t,k,m*k))
for r in sorted(res,key=lambda r:r[5])[:30]: print(r)
