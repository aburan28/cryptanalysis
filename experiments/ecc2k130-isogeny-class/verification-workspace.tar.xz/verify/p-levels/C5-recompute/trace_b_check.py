#!/usr/bin/env python3
"""Own GF(2^131) trace: check Tr(b)=1 and a2=0 for all 263 ground-truth curves
(consistent with 4 || #E = 4N, the a2=0 / Tr(b)=1 sampler refinement)."""
import json
M = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
def mulmod(a, b):
    r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1; a <<= 1
        if a >> 131 & 1: a ^= M
    return r
def trace(x):
    acc, y = 0, x
    for _ in range(131):
        acc ^= y; y = mulmod(y, y)
    assert acc in (0, 1)
    return acc
# trace mask for speed, cross-checked on random elements
TM = sum(trace(1 << i) << i for i in range(131))
import random
rnd = random.Random(5)
for _ in range(50):
    x = rnd.getrandbits(131)
    assert trace(x) == bin(x & TM).count("1") & 1
gt = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
assert int(gt["meta"]["modulus_int"]) == M
cnt = {"curves": 0, "a2==0": 0, "Tr(b)==1": 0}
for cv in gt["curves"]:
    b = int(cv["b_int"]); cnt["curves"] += 1
    cnt["a2==0"] += int(str(cv["a2"]) == "0")
    cnt["Tr(b)==1"] += bin(b & TM).count("1") & 1
print("Tr(1) =", trace(1)); print(cnt)
json.dump({"Tr(1)": trace(1), **cnt}, open("trace_b_check.json", "w"), indent=1)
