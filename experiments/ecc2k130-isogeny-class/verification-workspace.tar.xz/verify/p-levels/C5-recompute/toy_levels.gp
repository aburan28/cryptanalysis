\\ Toy level split: for the brute-force list of trace-t curves (a2 = 0, b listed),
\\ classify j = 1/b by the ring class polynomial H_{-7c^2} (mod 2) it is a root of.
\\ usage (from shell): gp -q -f toy_levels.gp with N, MODINT, LISTFILE, CONDS set via -e or default()
toylevels(N, MODINT, LISTFILE, CONDS) =
{
  my(T = Pol(Vecrev(binary(MODINT)), 'y), F, a, pw, B, js, res, cnt, tot = 0, hit, H, tt);
  T = Pol(binary(MODINT), 'y) * Mod(1, 2);
  a = ffgen(T, 'a);
  pw = vector(N, i, a^(i-1));
  B = readvec(LISTFILE);
  js = vector(#B, k, my(v = binary(B[k]), e = 0); for(i = 1, #v, if(v[i], e += pw[#v - i + 1])); 1/e);
  hit = vector(#B);
  res = List();
  for(ci = 1, #CONDS,
    my(c = CONDS[ci], D = -7*c^2, n0 = 0);
    tt = getabstime();
    H = if(c == 1, 'x - 1, polclass(D));
    H = lift(H * Mod(1, 2));
    for(k = 1, #js, if(subst(H, 'x, js[k]) == 0, hit[k]++; n0++));
    listput(res, [c, poldegree(H), n0, (getabstime() - tt) / 1000.]);
    tot += n0);
  [Vec(res), #B, tot, vecmax(hit), vecmin(hit)];
}
