#!/usr/bin/env python3
"""
Toy check of the class-count identity used in C5:
  #{F_q-classes with trace t} = sum_{c | f} h(Z + c O_K)
for the Koblitz analogue E0: y^2+xy=x^3+1 over F_{2^n} (n odd), by brute force
over all 2(q-1) curves (b, a2 in {0,1}) with toy_wht.c (Walsh-Hadamard counting).
Also checks: every trace-t curve has a2 = 0 and Tr(b) = 1 (the sampler refinement).
Pure python3 + the C program; no Sage/PARI.
"""
import json, math, os, subprocess, sys, time
from fractions import Fraction
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c5_lib import factor, jacobi, lucas_UV

HERE = os.path.dirname(os.path.abspath(__file__))

def polymulmod(a, b, m, deg):
    r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1; a <<= 1
        if a >> deg & 1: a ^= m
    return r
def polypowmod(a, e, m, deg):
    r = 1
    while e:
        if e & 1: r = polymulmod(r, a, m, deg)
        a = polymulmod(a, a, m, deg); e >>= 1
    return r
def pgcd(a, b):
    while b:
        while a and a.bit_length() >= b.bit_length():
            a ^= b << (a.bit_length() - b.bit_length())
        a, b = b, a
    return a
def is_irreducible(m, deg):
    # Rabin: x^(2^deg) = x mod m, and gcd(x^(2^(deg/l)) - x, m) = 1 for primes l | deg
    x = 2
    if polypowmod(x, 1 << deg, m, deg) != x: return False
    for l in factor(deg):
        y = polypowmod(x, 1 << (deg // l), m, deg) ^ x
        if pgcd(m, y) != 1: return False
    return True
def is_primitive(m, deg):
    if not is_irreducible(m, deg): return False
    order = (1 << deg) - 1
    for l in factor(order):
        if polypowmod(2, order // l, m, deg) == 1: return False
    return True
def find_primitive(deg):
    # low-weight search: trinomials then pentanomials
    for a in range(1, deg):
        m = (1 << deg) | (1 << a) | 1
        if is_primitive(m, deg): return m
    for a in range(3, deg):
        for b in range(2, a):
            for c in range(1, b):
                m = (1 << deg) | (1 << a) | (1 << b) | (1 << c) | 1
                if is_primitive(m, deg): return m
    raise ValueError

def h_order(cond):
    h = Fraction(cond)
    for l in factor(cond):
        h *= 1 - Fraction(jacobi(-7 % l, l) if l != 7 else 0, l)
    return h.numerator

def divisors(fac):
    ds = [1]
    for l, e in fac.items():
        ds = [d * l ** k for d in ds for k in range(e + 1)]
    return sorted(ds)

def main(ns):
    subprocess.run(["clang", "-O3", "-march=native", "-o", os.path.join(HERE, "toy_wht"),
                    os.path.join(HERE, "toy_wht.c")], check=True)
    results = {}
    for n in ns:
        T = time.time()
        U, V = lucas_UV(-1, 2, n)
        t = V; q = 2 ** n; f = abs(U)
        assert t * t - 4 * q == -7 * f * f
        ff = factor(f) if f > 1 else {}
        levels = {str(c): h_order(c) if c > 1 else 1 for c in divisors(ff)}
        Hsum = sum(levels.values())
        m = find_primitive(n)
        listfile = os.path.join(HERE, f"toy_trace_t_b_n{n}.txt")
        out = subprocess.run([os.path.join(HERE, "toy_wht"), str(n), str(m), str(t), listfile],
                             capture_output=True, text=True, timeout=2400).stdout
        kv = dict(line.split("=", 1) for line in out.strip().splitlines())
        res = {"n": n, "t": t, "f": f, "factor(f)": {str(k): v for k, v in ff.items()},
               "modulus": m, "h_per_conductor": levels, "sum_h": Hsum,
               "brute": kv, "S(1) == -t (E0 point count)": int(kv["S(1)"]) == -t,
               "count == sum_h": int(kv["count_trace_t_total"]) == Hsum,
               "twist count == sum_h": int(kv["count_trace_minus_t_total"]) == Hsum,
               "all trace-t curves have a2=0": int(kv["count_a2_1_trace_t"]) == 0,
               "all trace-t curves have Tr(b)=1": int(kv["count_a2_0_trace_t_with_Tr_b_1"]) == Hsum,
               "log2 Pr[uniform (b,a2) has trace t]": math.log2(Hsum) - math.log2(2 * (q - 1)),
               "time_s": round(time.time() - T, 1)}
        ok = (res["S(1) == -t (E0 point count)"] and res["count == sum_h"] and res["twist count == sum_h"]
              and res["all trace-t curves have a2=0"] and res["all trace-t curves have Tr(b)=1"]
              and kv["table_mul_mismatches"] == "0" and kv["Lmap_mismatches"] == "0"
              and kv["direct_count_mismatches"] == "0" and kv["violations_4divE_iff_Tra2_is_0"] == "0"
              and kv["violations_8divE_b0_iff_Trb_is_0"] == "0" and kv["Tr(1)"] == "1")
        res["ALL_OK"] = ok
        print(json.dumps(res), flush=True)
        results[str(n)] = res
    json.dump(results, open(os.path.join(HERE, "toy_counts.json"), "w"), indent=1)
    print("ALL_OK" if all(r["ALL_OK"] for r in results.values()) else "SOME_FAILED")

if __name__ == "__main__":
    main([int(a) for a in sys.argv[1:]] or [11, 17, 19, 21, 23, 27, 29])
