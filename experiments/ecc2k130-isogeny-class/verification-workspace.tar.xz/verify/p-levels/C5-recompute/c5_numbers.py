#!/usr/bin/env python3
"""
C5 independent recompute (pure python3, no Sage / PARI / sympy).

Re-derives every number used in claim C5 by code paths different from
p-levels/p_levels_numbers.sage:
  * t and f from the Lucas U/V doubling ladder (not the plain recurrence, not isqrt);
  * factorisation by own trial division + Pollard-Brent, primality by an own
    recursive Pratt certificate (Lucas n-1 test) plus Miller-Rabin;
  * Kronecker/Jacobi symbols by an own binary-reciprocity routine;
  * Frobenius eigenvalue on E0[p] via explicit arithmetic in F_{p^2} = F_p[tau];
  * multiplicative orders by an own order routine;
  * minimal extension degree with p | #E0(F_{q^k}) via Lucas-V ladder mod p^2;
  * class-group checks with an own implementation of binary quadratic form
    composition (Cohen Alg. 5.4.7) and reduction, unit-tested on small D against
    brute-force enumeration of reduced forms;
  * probabilities / log2 values from exact integers (math.log2 on ints and Fraction).
Writes c5_numbers.json next to this file.
"""
import json, math, os, random, sys, time
from fractions import Fraction
from math import gcd

T0 = time.time()
OUT = {}
def rec(k, v):
    OUT[k] = v
    print(f"{k} = {v}", flush=True)

# ---------------------------------------------------------------- primality
SMALL_PRIMES = []
def _sieve(n):
    s = bytearray([1]) * (n + 1); s[0] = s[1] = 0
    for i in range(2, int(n ** 0.5) + 1):
        if s[i]: s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i in range(n + 1) if s[i]]
SMALL_PRIMES = _sieve(10**6)

def miller_rabin(n, bases=(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41)):
    if n < 2: return False
    for p in SMALL_PRIMES[:50]:
        if n % p == 0: return n == p
    d, s = n - 1, 0
    while d % 2 == 0: d //= 2; s += 1
    for a in bases:
        x = pow(a, d, n)
        if x in (1, n - 1): continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1: break
        else:
            return False
    return True   # deterministic for n < 3.3e24 with these bases

def pollard_brent(n):
    if n % 2 == 0: return 2
    rnd = random.Random(n)
    while True:
        y, c, m = rnd.randrange(1, n), rnd.randrange(1, n), 128
        g = r = qq = 1
        while g == 1:
            x = y
            for _ in range(r): y = (y*y + c) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(m, r - k)):
                    y = (y*y + c) % n; qq = qq * abs(x - y) % n
                g = gcd(qq, n); k += m
            r *= 2
        if g == n:
            while True:
                ys = (ys*ys + c) % n; g = gcd(abs(x - ys), n)
                if g > 1: break
        if g != n: return g

def factor(n):
    """own factorisation: trial division to 1e6, then Pollard-Brent + MR."""
    fac = {}
    for p in SMALL_PRIMES:
        if p * p > n: break
        while n % p == 0: fac[p] = fac.get(p, 0) + 1; n //= p
    stack = [n] if n > 1 else []
    while stack:
        m = stack.pop()
        if m == 1: continue
        if miller_rabin(m): fac[m] = fac.get(m, 0) + 1; continue
        d = pollard_brent(m); stack += [d, m // d]
    return dict(sorted(fac.items()))

def pratt(n, depth=0, cert=None):
    """recursive Pratt certificate; returns list of (prime, witness, factors of n-1)."""
    if cert is None: cert = []
    if n == 2: cert.append((2, None, {})); return cert
    fac = factor(n - 1)
    for a in range(2, 1000):
        if pow(a, n - 1, n) != 1: raise ValueError(f"{n} composite (Fermat)")
        if all(pow(a, (n - 1) // l, n) != 1 for l in fac):
            break
    else:
        raise ValueError("no witness found")
    cert.append((n, a, fac))
    for l in fac:
        if l > 2: pratt(l, depth + 1, cert)
    return cert

def jacobi(a, n):
    assert n > 0 and n % 2 == 1
    a %= n; s = 1
    while a:
        while a % 2 == 0:
            a //= 2
            if n % 8 in (3, 5): s = -s
        a, n = n, a
        if a % 4 == 3 and n % 4 == 3: s = -s
        a %= n
    return s if n == 1 else 0

def mult_order(g, m, fac_phi):
    """order of g in (Z/m)^*, given factorisation of the group order phi."""
    phi = 1
    for l, e in fac_phi.items(): phi *= l ** e
    assert pow(g, phi, m) == 1
    o = phi
    for l, e in fac_phi.items():
        for _ in range(e):
            if pow(g, o // l, m) == 1: o //= l
            else: break
    return o

# ---------------------------------------------------------------- Lucas ladder
def lucas_UV(P, Q, n, mod=None):
    """(U_n, V_n) for x^2 - P x + Q by the doubling ladder; exact if mod is None."""
    def md(x): return x % mod if mod else x
    U, V, Qk = 0, 2, 1          # U_0, V_0, Q^0
    D = P * P - 4 * Q
    for bit in bin(n)[2:]:
        # double: U_2k = U_k V_k, V_2k = V_k^2 - 2 Q^k
        U, V, Qk = md(U * V), md(V * V - 2 * Qk), md(Qk * Qk)
        if bit == '1':
            # k -> k+1: U_{k+1} = (P U_k + V_k)/2, V_{k+1} = (D U_k + P V_k)/2
            U2, V2 = P * U + V, D * U + P * V
            if mod:
                inv2 = pow(2, -1, mod)
                U, V = U2 * inv2 % mod, V2 * inv2 % mod
            else:
                assert U2 % 2 == 0 and V2 % 2 == 0
                U, V = U2 // 2, V2 // 2
            Qk = md(Qk * Q)
    return U, V

# ================================================================ 1. constants
n = 131
q = 2 ** n
U131, V131 = lucas_UV(-1, 2, n)                 # tau^2 + tau + 2 = 0 : P=-1, Q=2
t = V131                                        # trace of pi = tau^131
# second path: naive recurrence of V only
a0, a1 = 2, -1
for _ in range(n - 1): a0, a1 = a1, -a1 - 2 * a0
assert a1 == t
rec("t (Lucas V_131, ladder)", str(t))
assert t == -22283658519494248867
f = abs(U131)                                    # t^2 - 4q = (tau^n - taubar^n)^2 = -7 U_n^2
assert t * t - 4 * q == -7 * U131 * U131
rec("f = |U_131| (Lucas U, ladder), t^2-4q == -7 f^2", str(f))
card = q + 1 - t
assert card % 4 == 0
N = card // 4
rec("#E0 = q+1-t", str(card)); rec("N = #E0/4", str(N))
rec("N Miller-Rabin(13 bases) probable prime", miller_rabin(N))
ff = factor(f)
rec("factor(f) own", {str(k): v for k, v in ff.items()})
assert ff == {263: 1, 146505763881528721: 1}
p = 146505763881528721
rec("p", str(p)); rec("log2 p", math.log2(p))
cert_p = pratt(p)
rec("Pratt certificate for p verified (primes certified)", [str(c[0]) for c in cert_p])
assert pratt(263)
fac_pm1 = factor(p - 1); fac_pp1 = factor(p + 1)
rec("factor(p-1) own", {str(k): v for k, v in fac_pm1.items()})
rec("factor(p+1) own", {str(k): v for k, v in fac_pp1.items()})
rec("p mod 131", p % 131); rec("263 mod 131", 263 % 131)

# ================================================================ 2. splitting of p and 263 in K = Q(sqrt(-7))
kp = jacobi(-7 % p, p); k263 = jacobi(-7 % 263, 263)
euler_p = pow(-7 % p, (p - 1) // 2, p)
rec("jacobi(-7,p) own", kp); rec("Euler criterion (-7)^((p-1)/2) mod p == p-1", euler_p == p - 1)
rec("jacobi(-7,263) own", k263)
assert kp == -1 and euler_p == p - 1 and k263 == 1
# primitive-divisor consistency: every prime l | U_131 has l = (−7|l) mod 131
assert (p - kp) % 131 == 0 and (263 - k263) % 131 == 0
rec("p == jacobi(-7,p) mod 131 and 263 == jacobi(-7,263) mod 131", True)

# ================================================================ 3. Frobenius on E0[p] via F_{p^2} = F_p[tau]
# elements a + b*tau, tau^2 = -tau - 2
def f2mul(x, y, m):
    a, b = x; c, d = y
    # (a + b tau)(c + d tau) = ac + (ad+bc) tau + bd tau^2 = (ac - 2bd) + (ad + bc - bd) tau
    return ((a*c - 2*b*d) % m, (a*d + b*c - b*d) % m)
def f2pow(x, e, m):
    r = (1, 0)
    while e:
        if e & 1: r = f2mul(r, x, m)
        x = f2mul(x, x, m); e >>= 1
    return r
tau = (0, 1)
tau131 = f2pow(tau, 131, p)
c = t * pow(2, -1, p) % p
rec("tau^131 in F_{p^2} (a + b tau)", [str(tau131[0]), str(tau131[1])])
assert tau131[1] == 0 and tau131[0] == c
rec("tau^131 in F_p and equals c = t/2 mod p", True)
rec("c = t/2 mod p", str(c))
assert c * c % p == q % p            # double root of x^2 - t x + q mod p
# order of tau in F_{p^2}^*/F_p^*: smallest k | p+1 with tau^k in F_p
o = p + 1
for l, e in fac_pp1.items():
    for _ in range(e):
        if f2pow(tau, o // l, p)[1] == 0: o //= l
        else: break
rec("order of tau in F_{p^2}^*/F_p^* (own)", o)
assert o == 131
# norm check: tau^(p+1) = N(tau) = 2
assert f2pow(tau, p + 1, p) == (2, 0)
r = mult_order(c, p, fac_pm1)
r_neg = mult_order((-c) % p, p, fac_pm1)
o2 = mult_order(2, p, fac_pm1)
# order of c in F_p^*/{+-1}
r_x = r // 2 if (r % 2 == 0 and pow(c, r // 2, p) == p - 1) else r
rec("r = ord_p(c) (own)", str(r)); rec("factor(r)", {str(k): v for k, v in factor(r).items()})
rec("log2 r", math.log2(r))
rec("ord_p(-c) (twist)", str(r_neg)); rec("ord_p(2)", str(o2))
rec("r_x = order of c in F_p^*/{+-1}", str(r_x)); rec("log2 r_x", math.log2(r_x))
rec("(p-1)/r", (p - 1) // r)
# minimal field of the x-coordinate of ANY point of E0[p] (pi acts as scalar c): F_{q^{r_x}}
# independent check via #E0(F_{q^k}) = q^k + 1 - V_k(t, q): p | N_k iff r | k
def Nk(k, m):
    _, Vk = lucas_UV(t, q, k, m)
    return (pow(q, k, m) + 1 - Vk) % m
def Ntw(k, m):
    _, Vk = lucas_UV(-t, q, k, m)
    return (pow(q, k, m) + 1 - Vk) % m
chk = {"N_r mod p^2": str(Nk(r, p * p)),
       "N_r mod p^3 != 0": Nk(r, p ** 3) != 0,
       "N_(r/l) mod p != 0 for all l | r": all(Nk(r // l, p) != 0 for l in factor(r)),
       "twist: Ntw_(ord(-c)) mod p^2": str(Ntw(r_neg, p * p)),
       "twist: Ntw_(ord(-c)/l) mod p != 0 for all l": all(Ntw(r_neg // l, p) != 0 for l in factor(r_neg))}
assert Nk(r, p * p) == 0 and chk["N_(r/l) mod p != 0 for all l | r"]
assert Ntw(r_neg, p * p) == 0 and chk["twist: Ntw_(ord(-c)/l) mod p != 0 for all l"]
# the same as brute force over small k via the order-1 recurrence mod p (first 10^6 k)
tk0, tk1, qk = 2 % p, t % p, q % p
first = None
for k in range(1, 10**6 + 1):
    if (qk + 1 - tk1) % p == 0 or (qk + 1 + (tk1 if k % 2 else -tk1)) % p == 0:
        first = k; break
    tk0, tk1 = tk1, (t * tk1 - q * tk0) % p
    qk = qk * q % p
chk["first k <= 1e6 with p | #E0(F_q^k) or #E0'(F_q^k)"] = first
assert first is None
rec("point-count checks for r (Lucas ladder mod p^2)", chk)

# sizes
bits_elt = 131 * r_x
rec("bits per element of F_{q^{r_x}} = 131 r_x", str(bits_elt))
rec("log2 bits per element", math.log2(bits_elt))
rec("bytes per element", bits_elt / 8)
rec("kernel polynomial degree (p-1)/2", str((p - 1) // 2))
rec("irreducible factors of each kernel polynomial over F_q ((p-1)/2 / r_x)", ((p - 1) // 2) // r_x)
rec("log2 sqrt(p)", 0.5 * math.log2(p))

# ================================================================ 4. class numbers (formula, own)
def h_order(cond):
    """h(Z + cond*O_K) for K = Q(sqrt(-7)): h_K=1, [O_K^*:O^*]=1."""
    h = Fraction(cond)
    for l in factor(cond):
        h *= 1 - Fraction(jacobi(-7 % l, l) if l != 7 else 0, l)
    assert h.denominator == 1
    return h.numerator
H = {"1": 1, "263": h_order(263), "p": h_order(p), "263p": h_order(263 * p)}
rec("h per level (formula)", {k: str(v) for k, v in H.items()})
assert H["263"] == 262 and H["p"] == p + 1 and H["263p"] == 262 * (p + 1)
tot = sum(H.values())
rec("total F_q-classes with trace t = sum h", str(tot)); rec("== 263(p+2)", tot == 263 * (p + 2))
rec("log2 total", math.log2(tot))
rec("sigma-orbits of size 131 at level p: (p+1)/131", str((p + 1) // 131))
assert (p + 1) % 131 == 0 and (262 * (p + 1)) % 131 == 0

# ================================================================ 5. own binary quadratic forms
def normalize(F):
    a, b, c = F
    if -a < b <= a: return F
    k = (a - b) // (2 * a)
    return (a, b + 2 * k * a, a * k * k + b * k + c)
def reduce_form(F):
    F = normalize(F)
    a, b, c = F
    while a > c or (a == c and b < 0):
        a, b, c = normalize((c, -b, a))
    return (a, b, c)
def xgcd(a, b):
    x0, x1, y0, y1 = 1, 0, 0, 1
    while b:
        qq, a, b = a // b, b, a % b
        x0, x1 = x1, x0 - qq * x1; y0, y1 = y1, y0 - qq * y1
    return a, x0, y0
def compose(F1, F2):
    """Cohen, Alg. 5.4.7 (composition of primitive positive definite forms)."""
    a1, b1, c1 = F1; a2, b2, c2 = F2
    if a1 > a2: a1, b1, c1, a2, b2, c2 = a2, b2, c2, a1, b1, c1
    s = (b1 + b2) // 2; nn = b2 - s
    if a2 % a1 == 0:
        y1, d = 0, a1
    else:
        d, u, v = xgcd(a2, a1); y1 = u
    if s % d == 0:
        y2, x2, d1 = -1, 0, d
    else:
        d1, x2, y2 = xgcd(s, d); y2 = -y2
    v1, v2 = a1 // d1, a2 // d1
    rr = (y1 * y2 * nn - x2 * c2) % v1
    b3 = b2 + 2 * v2 * rr
    a3 = v1 * v2
    c3 = (c2 * d1 + rr * (b2 + v2 * rr)) // v1
    return reduce_form((a3, b3, c3))
def disc(F): return F[1] ** 2 - 4 * F[0] * F[2]
def identity(D): return (1, 1, (1 - D) // 4) if D % 4 == 1 else (1, 0, -D // 4)
def fpow(F, e, D):
    R = identity(D); F = reduce_form(F)
    while e:
        if e & 1: R = compose(R, F)
        F = compose(F, F); e >>= 1
    return R
def sqrt_mod_prime(a, l):
    a %= l
    for x in range(l):
        if x * x % l == a: return x
    return None
def prime_form(D, l):
    if l == 2:
        assert D % 8 == 1
        return reduce_form((2, 1, (1 - D) // 8))
    b = sqrt_mod_prime(D, l)
    if b is None: return None
    if (b - D) % 2: b = l - b
    assert (b * b - D) % (4 * l) == 0
    return reduce_form((l, b, (b * b - D) // (4 * l)))
def form_order(F, D, mult, fac_mult):
    Id = identity(D)
    assert fpow(F, mult, D) == Id
    o = mult
    for l, e in fac_mult.items():
        for _ in range(e):
            if fpow(F, o // l, D) == Id: o //= l
            else: break
    return o

# --- unit tests on small discriminants against brute-force enumeration of reduced forms
def reduced_forms(D):
    out = []
    a = 1
    while 3 * a * a <= -D:
        for b in range(-a + 1, a + 1):
            if (b * b - D) % (4 * a): continue
            c = (b * b - D) // (4 * a)
            if c < a or (c == a and b < 0): continue
            if gcd(gcd(a, abs(b)), c) != 1: continue
            out.append((a, b, c))
        a += 1
    return out
unit = {}
for cond in (3, 5, 11, 17, 23, 263, 5 * 11, 17 * 3, 263 * 3):
    D = -7 * cond * cond
    forms = reduced_forms(D)
    hb = len(forms)
    assert hb == h_order(cond), (cond, hb, h_order(cond))
    # group checks: closure, identity, every element^h = id, 2-form order
    S = set(forms)
    rnd = random.Random(cond)
    for _ in range(200):
        A, B, C = rnd.choice(forms), rnd.choice(forms), rnd.choice(forms)
        AB = compose(A, B)
        assert AB in S and disc(AB) == D
        assert compose(AB, C) == compose(A, compose(B, C))
        assert compose(A, B) == compose(B, A)
        assert fpow(A, hb, D) == identity(D)
    unit[str(cond)] = hb
rec("unit test: #reduced forms == h formula, assoc/comm/closure OK for conductors", unit)

def cl_checks(name, D, h, expo, fac_expo):
    res = {"D": str(D), "log2|D|": math.log2(-D), "h_formula": str(h)}
    g2 = prime_form(D, 2)
    res["order of prime form above 2"] = form_order(g2, D, expo, fac_expo)
    orders = []
    l_count = 0
    L = 1
    for l in SMALL_PRIMES[1:200]:
        if l == 7 or D % l == 0: continue
        F = prime_form(D, l)
        if F is None: continue
        o = form_order(F, D, expo, fac_expo)
        orders.append((l, str(o))); L = L * o // gcd(L, o); l_count += 1
        if l_count >= 25: break
    res["split primes tested"] = l_count
    res["all tested prime forms satisfy F^expo = 1"] = True
    res["lcm of orders"] = str(L)
    res["some prime form has order == expo"] = any(int(o) == expo for _, o in orders)
    res["sample orders"] = orders[:6]
    return res
clp = cl_checks("p", -7 * p * p, p + 1, p + 1, fac_pp1)
rec("class group D=-7p^2 (own forms)", clp)
assert clp["order of prime form above 2"] == 131 and clp["lcm of orders"] == str(p + 1)
cl263p = cl_checks("263p", -7 * 263**2 * p * p, 262 * (p + 1), p + 1, fac_pp1)
rec("class group D=-7*263^2*p^2 (own forms; exponent p+1 since 262 | p+1)", cl263p)
assert cl263p["order of prime form above 2"] == 131
rec("262 divides p+1", (p + 1) % 262 == 0)

# ================================================================ 6. random-search probabilities
Pp = Fraction(p + 1, 2 * (q - 1))
Pboth = Fraction(263 * (p + 1), 2 * (q - 1))
Pany = Fraction(tot, 2 * (q - 1))
def lg(x): return math.log2(x.numerator) - math.log2(x.denominator)
rec("log2 Pr[uniform (b in F_q^*, a2 in {0,1}) is level p]", lg(Pp))
rec("log2 Pr[... level p or 263p]", lg(Pboth))
rec("log2 Pr[... trace t at all]", lg(Pany))
# refinement: trace-t curves have 4 || #E, i.e. Tr(a2)=0 and Tr(b)=1 (verified on toys by toy_wht.c)
Pp_ref = Fraction(p + 1, q // 2); Pboth_ref = Fraction(263 * (p + 1), q // 2)
rec("log2 Pr[level p | a2=0, Tr(b)=1 sampler]", lg(Pp_ref))
rec("log2 Pr[level p or 263p | a2=0, Tr(b)=1 sampler]", lg(Pboth_ref))
rec("log2 |D| = log2(7 p^2)", math.log2(7 * p * p))
rec("log2 |D_263p| = log2(7 263^2 p^2)", math.log2(7 * 263**2 * p * p))
rec("deg H_{-7p^2} = h(O_p)", str(p + 1))
# rho baselines for comparison
rec("log2 rho E0 sqrt(pi N/(4*131))", 0.5 * math.log2(math.pi * N / (4 * 131)))
rec("log2 rho neg-only sqrt(pi N/4)", 0.5 * math.log2(math.pi * N / 4))
rec("elapsed_s", round(time.time() - T0, 1))
json.dump(OUT, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "c5_numbers.json"), "w"), indent=1)
print("ALL ASSERTIONS PASSED")
