read("toy_levels.gp");
default(parisizemax, 4000000000);
print("n21 ", toylevels(21, 2097157, "toy_trace_t_b_n21.txt", [1, 7, 41, 287]));
print("n11 ", toylevels(11, 2053, "toy_trace_t_b_n11.txt", [1, 23]));
print("n17 ", toylevels(17, 131081, "toy_trace_t_b_n17.txt", [1, 271]));
print("n27_partial(conductor 8279 = complement) ", toylevels(27, 134217767, "toy_trace_t_b_n27.txt", [1, 17, 487]));
quit;
