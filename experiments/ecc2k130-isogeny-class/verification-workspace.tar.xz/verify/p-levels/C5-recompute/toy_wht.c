/*
 * toy_wht.c -- count, for every b in F_{2^n}^*, the trace of
 *   E_{b,a2}: y^2 + xy = x^3 + a2 x^2 + b   (a2 in {0,1}, n odd)
 * with a fast Walsh-Hadamard transform, and report how many curves have a
 * prescribed trace t.  Written for the C5 recompute (independent of Sage/PARI).
 *
 * #E_{b,0} = q + 1 + S(b),  S(b) = sum_{x != 0} (-1)^{Tr(x + b/x^2)}
 *          = sum_{w != 0} (-1)^{Tr(1/w)} (-1)^{Tr(b w)}           (w = 1/x^2, Tr(x)=Tr(x^2))
 *          = WHT of H(v) where H(L(w)) = (-1)^{Tr(1/w)}, L(w)_i = Tr(z^i w).
 * #E_{b,1} = q + 1 - S(b) for odd n (Tr(1) = 1).
 *
 * usage: toy_wht n modulus_int t [list_file]
 *   modulus must be a PRIMITIVE polynomial (z generates F_q^*); checked.
 * prints key=value lines.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

static int n;
static uint64_t MOD, Q;
static uint32_t *EXP, *LOG;

static inline uint32_t mulz(uint32_t x) {
    uint64_t y = (uint64_t)x << 1;
    if (y >> n & 1) y ^= MOD;
    return (uint32_t)y;
}
static inline uint32_t fmul(uint32_t a, uint32_t b) {
    if (!a || !b) return 0;
    uint64_t e = (uint64_t)LOG[a] + LOG[b];
    if (e >= Q - 1) e -= Q - 1;
    return EXP[e];
}
static inline uint32_t finv(uint32_t a) {
    uint64_t e = (Q - 1 - LOG[a]) % (Q - 1);
    return EXP[e];
}
/* slow carry-less multiply mod MOD, used only to cross-check the tables */
static uint32_t clmul_mod(uint32_t a, uint32_t b) {
    uint64_t r = 0, x = a;
    for (int i = 0; i < n; i++) {
        if (b >> i & 1) r ^= x;
        x <<= 1; if (x >> n & 1) x ^= MOD;
    }
    return (uint32_t)r;
}
static uint32_t TMASK;
static inline int tr(uint32_t x) { return __builtin_popcount(x & TMASK) & 1; }

int main(int argc, char **argv) {
    if (argc < 4) { fprintf(stderr, "usage\n"); return 1; }
    n = atoi(argv[1]);
    MOD = strtoull(argv[2], 0, 10);
    long long t = atoll(argv[3]);
    const char *listfile = argc > 4 ? argv[4] : NULL;
    if (n < 3 || n > 30 || !(n & 1)) { fprintf(stderr, "n must be odd, 3..29\n"); return 1; }
    Q = 1ULL << n;
    EXP = malloc(sizeof(uint32_t) * Q);
    LOG = malloc(sizeof(uint32_t) * Q);
    int32_t *H = calloc(Q, sizeof(int32_t));
    if (!EXP || !LOG || !H) { fprintf(stderr, "oom\n"); return 1; }
    memset(LOG, 0xff, sizeof(uint32_t) * Q);
    uint32_t x = 1;
    for (uint64_t k = 0; k < Q - 1; k++) {
        if (LOG[x] != 0xffffffffu) { printf("error=z not primitive (repeat at k=%llu)\n", (unsigned long long)k); return 2; }
        EXP[k] = x; LOG[x] = (uint32_t)k; x = mulz(x);
    }
    if (x != 1) { printf("error=z^(q-1) != 1\n"); return 2; }
    EXP[Q - 1] = 1;
    /* cross-check table multiplication against schoolbook on a sample */
    uint64_t s = 88172645463325252ULL; int bad = 0;
    for (int i = 0; i < 200000; i++) {
        s ^= s << 13; s ^= s >> 7; s ^= s << 17;
        uint32_t a = (uint32_t)(s % (Q - 1)) + 1, b = (uint32_t)((s >> 32) % (Q - 1)) + 1;
        if (fmul(a, b) != clmul_mod(a, b)) bad++;
        if (fmul(a, finv(a)) != 1) bad++;
    }
    printf("table_mul_mismatches=%d\n", bad);
    /* trace of z^k for k < 2n: Tr(y) = sum_{j<n} y^(2^j) */
    uint32_t trz[64];
    for (int k = 0; k < 2 * n; k++) {
        uint32_t y = EXP[k % (Q - 1)], acc = 0;
        for (int j = 0; j < n; j++) { acc ^= y; y = fmul(y, y); }
        if (acc > 1) { printf("error=trace not in F_2\n"); return 2; }
        trz[k] = acc;
    }
    TMASK = 0;
    for (int i = 0; i < n; i++) TMASK |= trz[i] << i;
    printf("Tr(1)=%d\n", tr(1));
    /* L(z^j)_i = Tr(z^{i+j}) ; byte tables for L */
    uint32_t col[32];
    for (int j = 0; j < n; j++) { col[j] = 0; for (int i = 0; i < n; i++) col[j] |= trz[i + j] << i; }
    static uint32_t LT[4][256];
    for (int byte = 0; byte < 4; byte++)
        for (int v = 0; v < 256; v++) {
            uint32_t acc = 0;
            for (int bit = 0; bit < 8; bit++) {
                int j = byte * 8 + bit;
                if ((v >> bit & 1) && j < n) acc ^= col[j];
            }
            LT[byte][v] = acc;
        }
    #define LMAP(w) (LT[0][(w)&255] ^ LT[1][((w)>>8)&255] ^ LT[2][((w)>>16)&255] ^ LT[3][((w)>>24)&255])
    /* check L(w) = (Tr(z^i w))_i on a sample */
    for (int i = 0; i < 1000; i++) {
        s ^= s << 13; s ^= s >> 7; s ^= s << 17;
        uint32_t w = (uint32_t)(s % (Q - 1)) + 1, lw = LMAP(w), ref = 0;
        for (int k = 0; k < n; k++) ref |= (uint32_t)tr(fmul(EXP[k], w)) << k;
        if (lw != ref) bad++;
    }
    printf("Lmap_mismatches=%d\n", bad);
    for (uint64_t w = 1; w < Q; w++) {
        uint32_t lw = LMAP((uint32_t)w);
        H[lw] = tr(finv((uint32_t)w)) ? -1 : 1;
    }
    /* in-place Walsh-Hadamard transform */
    for (uint64_t len = 1; len < Q; len <<= 1)
        for (uint64_t i = 0; i < Q; i += len << 1)
            for (uint64_t j = i; j < i + len; j++) {
                int32_t u = H[j], v = H[j + len];
                H[j] = u + v; H[j + len] = u - v;
            }
    /* validate S(b) against direct point counts for a few b */
    int direct_bad = 0;
    for (int i = 0; i < (n <= 23 ? 6 : 2); i++) {
        s ^= s << 13; s ^= s >> 7; s ^= s << 17;
        uint32_t b = i == 0 ? 1 : (uint32_t)(s % (Q - 1)) + 1;
        long long S = 0;
        for (uint64_t xx = 1; xx < Q; xx++) {
            uint32_t xi = finv((uint32_t)xx);
            uint32_t val = (uint32_t)xx ^ fmul(b, fmul(xi, xi));
            S += tr(val) ? -1 : 1;
        }
        if (S != H[b]) direct_bad++;
    }
    printf("direct_count_mismatches=%d\n", direct_bad);
    printf("S(1)=%d\n", H[1]);
    /* statistics */
    long long cnt0 = 0, cnt1 = 0, cnt0_tw = 0, cnt1_tw = 0, cnt0_trb1 = 0, mod8_bad = 0, a2eq0_mod4_bad = 0;
    FILE *lf = listfile ? fopen(listfile, "w") : NULL;
    for (uint64_t b = 1; b < Q; b++) {
        long long S = H[b];
        long long E0 = (long long)Q + 1 + S;      /* #E_{b,0} */
        long long E1 = (long long)Q + 1 - S;      /* #E_{b,1} */
        if (-S == t) { cnt0++; if (tr((uint32_t)b)) cnt0_trb1++; if (lf) fprintf(lf, "%llu\n", (unsigned long long)b); }
        if (S == t) cnt1++;
        if (-S == -t) cnt0_tw++;
        if (S == -t) cnt1_tw++;
        if (E0 % 4 != 0) a2eq0_mod4_bad++;
        if (E1 % 4 == 0) a2eq0_mod4_bad++;
        /* claim: for a2=0, 8 | #E  <=>  Tr(b) = 0 */
        if (((E0 % 8) == 0) != (tr((uint32_t)b) == 0)) mod8_bad++;
    }
    if (lf) fclose(lf);
    printf("count_a2_0_trace_t=%lld\n", cnt0);
    printf("count_a2_1_trace_t=%lld\n", cnt1);
    printf("count_trace_t_total=%lld\n", cnt0 + cnt1);
    printf("count_trace_minus_t_total=%lld\n", cnt0_tw + cnt1_tw);
    printf("count_a2_0_trace_t_with_Tr_b_1=%lld\n", cnt0_trb1);
    printf("violations_4divE_iff_Tra2_is_0=%lld\n", a2eq0_mod4_bad);
    printf("violations_8divE_b0_iff_Trb_is_0=%lld\n", mod8_bad);
    return 0;
}
