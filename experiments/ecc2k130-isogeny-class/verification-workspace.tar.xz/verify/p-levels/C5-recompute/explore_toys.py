# exploration only: which toy n (odd prime) give f_n = |U_n| with structure like 263*p
from sympy import factorint, isprime, jacobi_symbol, n_order
def lucas(n):
    # tau^2 + tau + 2 = 0  -> x^2 - P x + Q with P=-1, Q=2
    P,Q=-1,2
    U0,U1=0,1; V0,V1=2,P
    for _ in range(n-1):
        U0,U1=U1,P*U1-Q*U0; V0,V1=V1,P*V1-Q*V0
    return U1,V1
for n in [p for p in range(5,60) if isprime(p)]:
    U,t=lucas(n); q=2**n
    assert t*t-4*q==-7*U*U
    f=abs(U); fac=factorint(f)
    info=[]
    for l in fac:
        k=jacobi_symbol(-7,l) if l!=7 else 0
        c=(t*pow(2,-1,l))%l
        info.append((l,k,c if c<l//2 else c-l, n_order(c,l) if c else None))
    print(n,t,f,info)
print("composite odd n")
for n in [9,15,21,25,27,33,35]:
    U,t=lucas(n); f=abs(U); fac=factorint(f)
    info=[]
    for l in fac:
        k=jacobi_symbol(-7,l) if l!=7 else 0
        c=(t*pow(2,-1,l))%l
        info.append((l,fac[l],k,c if c<l//2 else c-l))
    print(n,t,f,info)
