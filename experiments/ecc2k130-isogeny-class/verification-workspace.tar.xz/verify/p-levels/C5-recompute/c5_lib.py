"""Helpers extracted verbatim from c5_numbers.py (own factor / primality / jacobi / Lucas ladder)."""
import math, random
from math import gcd
# ---------------------------------------------------------------- primality
SMALL_PRIMES = []
def _sieve(n):
    s = bytearray([1]) * (n + 1); s[0] = s[1] = 0
    for i in range(2, int(n ** 0.5) + 1):
        if s[i]: s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i in range(n + 1) if s[i]]
SMALL_PRIMES = _sieve(10**6)

def miller_rabin(n, bases=(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41)):
    if n < 2: return False
    for p in SMALL_PRIMES[:50]:
        if n % p == 0: return n == p
    d, s = n - 1, 0
    while d % 2 == 0: d //= 2; s += 1
    for a in bases:
        x = pow(a, d, n)
        if x in (1, n - 1): continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1: break
        else:
            return False
    return True   # deterministic for n < 3.3e24 with these bases

def pollard_brent(n):
    if n % 2 == 0: return 2
    rnd = random.Random(n)
    while True:
        y, c, m = rnd.randrange(1, n), rnd.randrange(1, n), 128
        g = r = qq = 1
        while g == 1:
            x = y
            for _ in range(r): y = (y*y + c) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(m, r - k)):
                    y = (y*y + c) % n; qq = qq * abs(x - y) % n
                g = gcd(qq, n); k += m
            r *= 2
        if g == n:
            while True:
                ys = (ys*ys + c) % n; g = gcd(abs(x - ys), n)
                if g > 1: break
        if g != n: return g

def factor(n):
    """own factorisation: trial division to 1e6, then Pollard-Brent + MR."""
    fac = {}
    for p in SMALL_PRIMES:
        if p * p > n: break
        while n % p == 0: fac[p] = fac.get(p, 0) + 1; n //= p
    stack = [n] if n > 1 else []
    while stack:
        m = stack.pop()
        if m == 1: continue
        if miller_rabin(m): fac[m] = fac.get(m, 0) + 1; continue
        d = pollard_brent(m); stack += [d, m // d]
    return dict(sorted(fac.items()))

def pratt(n, depth=0, cert=None):
    """recursive Pratt certificate; returns list of (prime, witness, factors of n-1)."""
    if cert is None: cert = []
    if n == 2: cert.append((2, None, {})); return cert
    fac = factor(n - 1)
    for a in range(2, 1000):
        if pow(a, n - 1, n) != 1: raise ValueError(f"{n} composite (Fermat)")
        if all(pow(a, (n - 1) // l, n) != 1 for l in fac):
            break
    else:
        raise ValueError("no witness found")
    cert.append((n, a, fac))
    for l in fac:
        if l > 2: pratt(l, depth + 1, cert)
    return cert

def jacobi(a, n):
    assert n > 0 and n % 2 == 1
    a %= n; s = 1
    while a:
        while a % 2 == 0:
            a //= 2
            if n % 8 in (3, 5): s = -s
        a, n = n, a
        if a % 4 == 3 and n % 4 == 3: s = -s
        a %= n
    return s if n == 1 else 0

def mult_order(g, m, fac_phi):
    """order of g in (Z/m)^*, given factorisation of the group order phi."""
    phi = 1
    for l, e in fac_phi.items(): phi *= l ** e
    assert pow(g, phi, m) == 1
    o = phi
    for l, e in fac_phi.items():
        for _ in range(e):
            if pow(g, o // l, m) == 1: o //= l
            else: break
    return o

# ---------------------------------------------------------------- Lucas ladder
def lucas_UV(P, Q, n, mod=None):
    """(U_n, V_n) for x^2 - P x + Q by the doubling ladder; exact if mod is None."""
    def md(x): return x % mod if mod else x
    U, V, Qk = 0, 2, 1          # U_0, V_0, Q^0
    D = P * P - 4 * Q
    for bit in bin(n)[2:]:
        # double: U_2k = U_k V_k, V_2k = V_k^2 - 2 Q^k
        U, V, Qk = md(U * V), md(V * V - 2 * Qk), md(Qk * Qk)
        if bit == '1':
            # k -> k+1: U_{k+1} = (P U_k + V_k)/2, V_{k+1} = (D U_k + P V_k)/2
            U2, V2 = P * U + V, D * U + P * V
            if mod:
                inv2 = pow(2, -1, mod)
                U, V = U2 * inv2 % mod, V2 * inv2 % mod
            else:
                assert U2 % 2 == 0 and V2 % 2 == 0
                U, V = U2 // 2, V2 // 2
            Qk = md(Qk * Q)
    return U, V

