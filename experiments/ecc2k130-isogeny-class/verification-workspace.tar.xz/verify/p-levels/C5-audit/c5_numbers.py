# C5 audit: independent recomputation (plain python3, no Sage/PARI) of the numbers behind claim C5.
# Run: python3 c5_numbers.py   -> writes c5_numbers_out.json
import json, math, random

def is_prime(n):
    # deterministic Miller-Rabin for n < 3.3e24 with these bases
    if n < 2: return False
    small = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]
    for s in small:
        if n % s == 0: return n == s
    d, s = n - 1, 0
    while d % 2 == 0: d //= 2; s += 1
    for a in small:
        x = pow(a, d, n)
        if x in (1, n - 1): continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1: break
        else:
            return False
    return True

def factor(n):
    out = {}
    d = 2
    while d * d <= n and d < 2_000_000:
        while n % d == 0:
            out[d] = out.get(d, 0) + 1; n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        assert is_prime(n), ("cofactor not prime", n)
        out[n] = out.get(n, 0) + 1
    return out

def mult_order(a, n, fac_phi):   # order of a mod prime n; fac_phi = factorisation of n-1
    o = n - 1
    for l, e in fac_phi.items():
        for _ in range(e):
            if o % l == 0 and pow(a, o // l, n) == 1: o //= l
    return o

res = {}
q = 2**131
# trace via tau^2 + tau + 2 = 0 : t_k = tau^k + taubar^k, t_{k+1} = -t_k - 2 t_{k-1}, t_0 = 2, t_1 = -1
t0, t1 = 2, -1
for _ in range(130):
    t0, t1 = t1, -t1 - 2 * t0
t = t1
res["t"] = str(t)
D = t * t - 4 * q
assert D % -7 == 0
f2 = D // -7
f = math.isqrt(f2); assert f * f == f2
assert f % 263 == 0
p = f // 263
assert is_prime(p) and is_prime(263)
N = (q + 1 - t) // 4
assert 4 * N == q + 1 - t
res.update({"f": str(f), "p": str(p), "log2 p": math.log2(p), "N": str(N)})
# Legendre (-7|p) by Euler, (-7|263)
res["(-7|p) Euler"] = "+1" if pow(-7 % p, (p - 1) // 2, p) == 1 else "-1"
res["(-7|263) Euler"] = "+1" if pow(-7 % 263, 131, 263) == 1 else "-1"
res["p mod 7"] = p % 7
# eigenvalue of pi on E0[p]: pi = a + f*w, w = (1+sqrt(-7))/2, a = (t-f)/2  -> pi = a mod p O_K
a = (t - f) // 2
assert (t - f) % 2 == 0
c = a % p
c2 = t * pow(2, -1, p) % p
assert c == c2 and c * c % p == q % p
res["c = pi mod p O_K"] = c
fpm1 = factor(p - 1)
res["factor(p-1)"] = {str(k): v for k, v in fpm1.items()}
r = mult_order(c, p, fpm1)
res["r = ord_p(c)"] = r; res["log2 r"] = math.log2(r); res["(p-1)/r"] = (p - 1) // r
res["factor(r)"] = {str(k): v for k, v in factor(r).items()}
res["c^(r/2) == -1"] = (r % 2 == 0 and pow(c, r // 2, p) == p - 1)
res["r_x = r/2"] = r // 2; res["log2 r_x"] = math.log2(r // 2)
res["ord_p(-c)"] = mult_order(p - c, p, fpm1)
res["ord_p(q)"] = mult_order(q % p, p, fpm1)
# independent route through tau: O_K/p = F_p[x]/(x^2+x+2), compute tau^131 and check it is c (a scalar)
def mul2(u, v):  # (u0 + u1 x)(v0 + v1 x), x^2 = -x - 2
    u0, u1 = u; v0, v1 = v
    w0 = u0 * v0; w1 = u0 * v1 + u1 * v0; w2 = u1 * v1
    return ((w0 - 2 * w2) % p, (w1 - w2) % p)
def pow2(u, e):
    rres = (1, 0)
    while e:
        if e & 1: rres = mul2(rres, u)
        u = mul2(u, u); e >>= 1
    return rres
tau = (0, 1)
t131 = pow2(tau, 131)
res["tau^131 mod p (as a0 + a1*tau)"] = [t131[0], t131[1]]
res["tau^131 == c (scalar)"] = (t131 == (c, 0))
# points of E0[p] over F_{q^k}  <=>  pi^k = 1 on E0[p] <=> c^k = 1 ; check minimality over all divisors of r
divs_ok = all(pow(c, r // l, p) != 1 for l in factor(r))
res["c^(r/l) != 1 for all primes l | r"] = divs_ok
# #E0(F_{q^k}) mod p^2 via Lucas sequence of pi at k = r (should be 0 mod p^2) and k = r/l (nonzero mod p)
def Nk_mod(k, m):
    # t_k via 2x2 matrix power mod m
    def mm(A, B):
        return [[(A[0][0]*B[0][0] + A[0][1]*B[1][0]) % m, (A[0][0]*B[0][1] + A[0][1]*B[1][1]) % m],
                [(A[1][0]*B[0][0] + A[1][1]*B[1][0]) % m, (A[1][0]*B[0][1] + A[1][1]*B[1][1]) % m]]
    M = [[t % m, (-q) % m], [1, 0]]; R = [[1, 0], [0, 1]]; e = k
    while e:
        if e & 1: R = mm(R, M)
        M = mm(M, M); e >>= 1
    tk = (R[0][0] + R[1][1]) % m
    return (pow(q, k, m) + 1 - tk) % m
res["#E0(F_q^r) mod p^2"] = Nk_mod(r, p * p)
res["#E0(F_q^(r/l)) mod p, l | r"] = {str(l): Nk_mod(r // l, p) for l in factor(r)}
# class numbers h(Z + c O_K) = c * prod_{l|c} (1 - (-7|l)/l), h(O_K)=1, units {+-1}
def leg(l):
    return 1 if pow(-7 % l, (l - 1) // 2, l) == 1 else -1
h = {"1": 1, "263": 263 - leg(263), "p": p - leg(p), "263p": (263 - leg(263)) * (p - leg(p))}
res["h"] = {k: str(v) for k, v in h.items()}
tot = sum(h.values())
res["sum h"] = str(tot); res["sum h == 263(p+2)"] = (tot == 263 * (p + 2)); res["log2 sum h"] = math.log2(tot)
res["factor(p+1)"] = {str(k): v for k, v in factor(p + 1).items()}
res["(p+1) % 131"] = (p + 1) % 131
# probabilities
L2 = math.log2
res["log2 Pr[(b,a2) uniform over 2(q-1) classes is level p]"] = L2(p + 1) - L2(2 * (q - 1))
res["log2 Pr[... level p or 263p]"] = L2(263 * (p + 1)) - L2(2 * (q - 1))
res["log2 Pr[... trace t at all]"] = L2(tot) - L2(2 * (q - 1))
res["log2 Pr[random j, both twists tested, level p or 263p]"] = L2(263 * (p + 1)) - L2(q - 1)
res["log2 Pr[a2=0, Tr(b)=1 prefilter (q/2 candidates), level p or 263p]"] = L2(263 * (p + 1)) - L2(q // 2)
res["log2 Pr[a2=0, Tr(b)=1 prefilter, level p only]"] = L2(p + 1) - L2(q // 2)
res["Pr[level p or 263p | trace t] = 263(p+1)/(263(p+2))  (1 - this)"] = 1 / (p + 2)
# CM discriminants
res["log2 |D| level p = 7p^2"] = L2(7 * p * p)
res["log2 |D| level 263p = 7(263p)^2"] = L2(7 * (263 * p) ** 2)
res["deg H_D level p"] = str(p + 1); res["deg H_D level 263p"] = str(262 * (p + 1))
# rho baselines
res["log2 rho E0 neg+tau"] = 0.5 * L2(math.pi * N / (4 * 131))
res["log2 rho neg only"] = 0.5 * L2(math.pi * N / 4)
json.dump(res, open("c5_numbers_out.json", "w"), indent=1)
for k, v in res.items(): print(k, "=", v)
print("OK")
