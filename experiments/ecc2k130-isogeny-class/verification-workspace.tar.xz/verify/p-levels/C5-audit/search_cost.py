# C5 audit: expected cost of the only generic construction (random search), with the free 2-adic filter.
# ASSUMPTION (not measured): an x-only Montgomery-ladder test [4N]P == O costs ~ 6 F_q-mults per bit of 4N;
# a rho iteration on E0 costs ~ 2^3 F_q-mults (order of magnitude only).
import math, json
q = 2**131; p = 146505763881528721
N = 680564733841876926932320129493409985129
cands = q // 2                      # a2 = 0, Tr(b) = 1 : every curve with #E = 4N is among these
good = 263 * (p + 1)                # classes at level p or 263p
E_trials = cands / good
bits4N = (4 * N).bit_length()
test_mults = 6 * bits4N
out = {"log2 expected trials (a2=0, Tr b=1)": math.log2(E_trials),
       "bits of 4N": bits4N, "assumed F_q mults per test": test_mults,
       "log2 F_q mults random search": math.log2(E_trials * test_mults),
       "log2 rho iterations E0": 0.5 * math.log2(math.pi * N / (4 * 131)),
       "log2 F_q mults rho E0 (8/iter assumed)": 0.5 * math.log2(math.pi * N / (4 * 131)) + 3}
out["log2 ratio search/rho"] = out["log2 F_q mults random search"] - out["log2 F_q mults rho E0 (8/iter assumed)"]
print(json.dumps(out, indent=1)); json.dump(out, open("search_cost_out.json", "w"), indent=1)
