# C5 audit: 2-adic prefilter on the real class. Every curve with #E = 4N (N odd) has 2-part exactly Z/4,
# so it must have Tr(a2) = 0 (4 | #E) and, for the a2 = 0 model, Tr(b) = 1 (no point of order 8).
# Check on the 263 explicit curves, and check the lemma "a2=0: 8 | #E  <=>  Tr(b)=0" on random b.
import sys, json
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
K, curves = ecc2k.load()
out = {}
tr_b = {}
for lab, E in curves.items():
    a = E.a_invariants()
    assert a[0] == 1 and a[2] == 0 and a[3] == 0
    tr_b.setdefault((int(a[1].trace()), int(a[4].trace())), []).append(lab)
out["(Tr a2, Tr b) over the 263 curves"] = {str(k): len(v) for k, v in tr_b.items()}
# lemma on random b: #E mod 8 from PARI point count vs Tr(b)
set_random_seed(5)
ok = 0; tot = 0
for _ in range(200):
    b = K.random_element()
    if b == 0: continue
    n = EllipticCurve(K, [1, 0, 0, 0, b]).cardinality()
    tot += 1
    if ((n % 8 == 0) == (b.trace() == 0)) and n % 4 == 0: ok += 1
out["lemma a2=0: (8|#E <=> Tr b = 0) and 4|#E, random b"] = f"{ok}/{tot}"
print(out)
json.dump(out, open("real_2adic_out.json", "w"), indent=1)
