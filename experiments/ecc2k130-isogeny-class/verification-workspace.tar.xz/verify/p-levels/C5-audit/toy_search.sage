# C5 audit: find toy isogeny classes over F_{2^m} (m <= 20) whose Frobenius conductor f contains
#  - an INERT prime l (analogue of p), v_l(f) = 1, with Frobenius eigenvalue c = t/2 mod l of order r >= 3
#  - ideally a SPLIT prime s (analogue of 263), v_s(f) = 1
# small h(d_K) preferred.
out = []
for m in range(8, 21):
    q = 2^m
    B = floor(2*sqrt(q))
    for t in range(-B, B+1):
        if t % 2 == 0: continue
        D = t^2 - 4*q
        d = fundamental_discriminant(D)
        f = isqrt(D // d)
        if f^2 * d != D or f == 1: continue
        fa = factor(f)
        inert = [(l, e) for l, e in fa if l > 3 and kronecker(d, l) == -1 and e == 1]
        split = [(l, e) for l, e in fa if l > 3 and kronecker(d, l) == 1 and e == 1]
        for l, e in inert:
            c = GF(l)(t) / 2
            r = c.multiplicative_order()
            if r < 3: continue
            hK = pari(d).qfbclassno()
            H = sum(pari(d*g^2).qfbclassno() for g in divisors(f))
            out.append((m, t, d, f, l, r, [s for s, _ in split], int(hK), int(H)))
out.sort(key=lambda x: (x[7], len(x[6]) == 0, x[8]))
for x in out[:60]:
    print("m=%d t=%d d=%d f=%d inert l=%d r=%d split=%s h(d)=%d H=%d" % x)
