\\ C5 audit toy: enumerate ALL curves y^2+xy=x^3+b over F_{2^20} (modulus x^20+x^3+1), record those
\\ with trace +-1201 (the Koblitz class, f = 627 = 3*11*19).  Also histogram of 2-adic data for the
\\ 2-adic prefilter check (Tr(b) vs #E mod 8).
P = Mod(1,2)*(x^20+x^3+1); g = ffgen(P, 'z); q = 2^20; tt = 1201;
w = ffprimroot(g);
print("trace(g) type: ", type(trace(g)), " value ", trace(g));
{
b = g^0; hits = List(); n8 = matrix(2,8);
T=getabstime();
for(k=0, q-2,
  if(k, b*=w);
  E=ellinit([1,0,0,0,b],g); nn=ellcard(E); tr=q+1-nn;
  trb = lift(trace(b)); if(type(trb)=="t_POL", trb=polcoef(trb,0));
  n8[trb+1, (nn%8)+1]++;
  if(abs(tr)==tt, listput(hits, [subst(b.pol,'z,2), tr]))
);
print("seconds ", (getabstime()-T)/1000.);
print("hits ", #hits);
print("rows Tr(b)=0,1 ; cols #E mod 8 = 0..7 (a2=0 model): ", n8);
write("toy_enum_hits.txt", Vec(hits));
}
