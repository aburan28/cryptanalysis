# SUPERSEDED by toy_levels.gp (this Sage version was killed: too slow on the loaded machine; never completed).
# C5 audit toy (full enumeration). Isogeny class of the Koblitz curve E0: y^2+xy=x^3+1 over F_{2^20}:
#   t = 1201, t^2 - 4q = -7 * 627^2, 627 = 3 * 11 * 19;  (-7|3) = -1, (-7|11) = +1, (-7|19) = -1.
#   19 plays the role of p (inert, v=1), 11 the role of 263 (split), 3 is an extra inert prime.
# Checks (all from the brute-force list toy_enum_hits.txt written by toy_enum.gp, PARI ellcard on all 2^20-1 b):
#  (1) #classes with trace t = sum_{c | f} h(Z + c O_K)   (analogue of 263(p+2))
#  (2) level of each j from roots of H_{-7c^2} mod 2  AND independently from the number of F_q-rational
#      l-isogenies (roots of Phi_l(j,Y) in F_q) for l = 3, 11, 19; both classifications must agree
#  (3) the isogeny graph on all classes using every prime degree l' <= 97 EXCEPT 19 (plus Frobenius j->j^2):
#      no component mixes 19 | cond and 19 not| cond; E0's component contains no curve with 19 | cond.
#      Then adding 19-isogenies connects the two sides.
#  (4) on E0: kernel points of the 19-isogenies only over F_{q^r}, r = ord_19(t/2); the 19-division
#      polynomial factors over F_q into irreducibles of degree r_x only.
#  (5) random-search analogue: Pr[random (b,a2) is at a level with 19 | cond] = (#such classes)/(2(q-1)).
import json, time
T0 = time.time()
res = {}
R.<x> = GF(2)[]
K.<z> = GF(2^20, modulus=x^20 + x^3 + 1)
q = 2^20; t = 1201; f = 627
assert t^2 - 4*q == -7*f^2
hits = sage_eval(open("toy_enum_hits.txt").read().strip())
bs = [K.from_integer(Integer(bi)) for bi, tr in hits]
J = set(1/b for b in bs)
res["#j with trace +-t (brute force over all b)"] = len(J)
assert len(J) == len(hits)
def h_of(c):
    h = c
    for l, _ in factor(c): h = h * (1 - QQ(kronecker(-7, l))/l)
    return ZZ(h)
conds = divisors(f)
hs = {c: h_of(c) for c in conds}
res["h(c) for c | 627"] = {str(c): int(hs[c]) for c in conds}
res["sum h"] = int(sum(hs.values()))
res["(1) count matches sum h"] = bool(len(J) == sum(hs.values()))
assert res["(1) count matches sum h"]
# (2a) levels via class polynomials
KY.<Y> = K[]
level = {}
for c in conds:
    H = pari(f"polclass({-7*c^2})")
    Hc = [Integer(a) % 2 for a in H.Vec()][::-1]   # Vec is high->low
    Hmod2 = KY([K(a) for a in Hc])
    assert Hmod2.degree() == hs[c]
    rts = Hmod2.roots(multiplicities=True)
    assert all(mu == 1 for _, mu in rts) and len(rts) == hs[c], (c, len(rts))
    for rt, _ in rts:
        assert rt in J and rt not in level
        level[rt] = c
res["(2a) every j in exactly one H_{-7c^2} mod 2, all roots in F_q"] = bool(set(level) == J)
assert set(level) == J
# (2b) levels via number of F_q-rational l-isogenies (roots of Phi_l(j, Y) in F_q, with multiplicity)
def phi_mod2(l):
    Phi = pari(f"polmodular({l})")  # classical, in x,y
    return Phi
cache = {}
def Phi_at(l, j):
    # classical modular polynomial Phi_l(X,Y) reduced mod 2 (PARI polmodular), evaluated at X = j
    if l not in cache:
        s2 = str(pari(f"lift(polmodular({l}) * Mod(1,2))"))
        R2 = PolynomialRing(GF(2), ["x", "y"])
        P = R2(s2)
        dct = {}
        for (i, k), cf in P.dict().items():
            if cf: dct.setdefault(k, []).append(i)
        cache[l] = dct
    dct = cache[l]
    deg = max(dct)
    coeffs = [K(0)] * (deg + 1)
    for k, ilist in dct.items():
        coeffs[k] = sum(jpow(j, i) for i in ilist)
    return KY(coeffs)
_jp = {}
def jpow(j, i):
    key = (j, i)
    if key not in _jp: _jp[key] = j^i
    return _jp[key]
def n_rational_roots(l, j):
    g = Phi_at(l, j)
    return sum(mu for _, mu in g.roots(multiplicities=True)), [rt for rt, _ in g.roots(multiplicities=True)]
agree = True; counts = {}
for j in J:
    c = level[j]
    for l in (3, 11, 19):
        n, _ = n_rational_roots(l, j)
        # prediction: l does not divide c  -> pi scalar on E[l] -> all l+1 subgroups rational -> l+1 roots
        #             l divides c (v_l(f)=1, floor) -> exactly one rational subgroup -> 1 root
        pred = l + 1 if c % l else 1
        counts.setdefault((l, c % l == 0), set()).add(int(n))
        if n != pred: agree = False
res["(2b) #F_q-roots of Phi_l(j,Y) by (l, l|cond)"] = {f"l={l}, l|cond={b}": sorted(v) for (l, b), v in counts.items()}
res["(2b) root counts agree with levels from H_D"] = agree
assert agree
# (3) isogeny graph without 19
parent = {j: j for j in J}
def find(a):
    while parent[a] != a:
        parent[a] = parent[parent[a]]; a = parent[a]
    return a
def union(a, b):
    ra, rb = find(a), find(b)
    if ra != rb: parent[ra] = rb
degs = [l for l in prime_range(3, 98) if l != 19]
nedges = 0; bad_targets = 0; cross = 0
for j in J:
    union(j, j^2)                 # Frobenius (a purely inseparable 2-isogeny) -- keeps End
    for l in degs:
        _, rts = n_rational_roots(l, j)
        for j2 in rts:
            if j2 not in J: bad_targets += 1; continue
            nedges += 1
            if (level[j] % 19 == 0) != (level[j2] % 19 == 0): cross += 1
            union(j, j2)
comps = {}
for j in J: comps.setdefault(find(j), []).append(j)
comp_info = []
for rt, mem in comps.items():
    comp_info.append({"size": len(mem), "conductors": sorted(set(int(level[j]) for j in mem))})
comp_info.sort(key=lambda d: -d["size"])
res["(3) degrees used"] = [2] + degs
res["(3) edges, targets outside J"] = [nedges, bad_targets]
res["(3) edges crossing 19-levels"] = cross
res["(3) components (size, conductors)"] = comp_info
E0c = find(K(1))
res["(3) component of E0: conductors"] = sorted(set(int(level[j]) for j in J if find(j) == E0c))
res["(3) component of E0: size"] = sum(1 for j in J if find(j) == E0c)
mixed = [d for d in comp_info if len(set(c % 19 == 0 for c in d["conductors"])) > 1]
res["(3) any component mixing 19|cond and 19 not| cond"] = bool(mixed)
assert not mixed and cross == 0
# now add 19-isogenies
cross19 = 0
for j in J:
    _, rts = n_rational_roots(19, j)
    for j2 in rts:
        if (level[j] % 19 == 0) != (level[j2] % 19 == 0): cross19 += 1
        union(j, j2)
res["(3b) 19-isogeny edges crossing 19-levels"] = cross19
res["(3b) components after adding 19-edges"] = len(set(find(j) for j in J))
# (4) E0[19] field of definition and division polynomial factorisation
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
assert E0.order() == q + 1 - t
F19 = GF(19); c19 = F19(t) / 2
r = c19.multiplicative_order()
rx = min(k for k in range(1, 19) if c19^k in (F19(1), F19(-1)))
res["(4) c = t/2 mod 19, r = ord(c), r_x"] = [int(c19), int(r), int(rx)]
# #E0(F_{q^k}) mod 19 via Lucas
def tk(k):
    a, b = 2, t
    for _ in range(k - 1): a, b = b, t*b - q*a
    return b if k >= 1 else 2
res["(4) k in 1..2r with 19 | #E0(F_q^k)"] = [k for k in range(1, 2*r + 1) if (q^k + 1 - tk(k)) % 19 == 0]
res["(4) v_19(#E0(F_q^r))"] = int(valuation(q^r + 1 - tk(r), 19))
psi = E0.division_polynomial(19)
fdeg = sorted(set(g.degree() for g, _ in psi.factor()))
res["(4) degrees of F_q-irreducible factors of psi_19(E0)"] = fdeg
res["(4) psi_19 degree"] = int(psi.degree())
# (5) random-search analogue
n19 = sum(hs[c] for c in conds if c % 19 == 0)
res["(5) #classes with 19 | cond"] = int(n19)
res["(5) log2 Pr[random (b,a2) has 19 | cond]"] = float(log(n19 / (2*(q - 1)), 2))
res["elapsed_s"] = round(time.time() - T0, 1)
json.dump(res, open("toy_levels_out.json", "w"), indent=1, default=str)
for k, v in res.items(): print(k, "=", v)
print("ALL TOY ASSERTIONS PASSED")
