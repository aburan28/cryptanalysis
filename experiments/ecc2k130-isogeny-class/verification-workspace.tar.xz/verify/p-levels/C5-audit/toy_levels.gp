\\ C5 audit toy (full enumeration), GP version of toy_levels.sage (that Sage version was too slow on the loaded machine).
\\ Isogeny class of the Koblitz curve E0: y^2+xy=x^3+1 over F_{2^20} (modulus x^20+x^3+1): t = 1201,
\\ t^2 - 4q = -7*627^2, 627 = 3*11*19; (-7|3) = -1, (-7|11) = +1, (-7|19) = -1.
\\ 19 plays the role of p (inert, v=1), 11 the role of 263 (split).
\\ Input: toy_enum_hits.txt from toy_enum.gp (all 2^20-1 values of b point-counted with ellcard).
\\ Checks:
\\ (1) #classes with trace t == sum_{c|627} h(Z + c O_K)
\\ (2a) level of every j from roots of H_{-7c^2} mod 2 (polclass); every root in F_q, each j in exactly one
\\ (2b) independent level test: #F_q-roots (with multiplicity) of Phi_l(j,Y) for l = 3, 11, 19
\\      predicted l+1 if l does not divide the conductor (pi scalar on E[l]) and 1 if it does
\\ (3) isogeny graph with every prime degree 3..97 except 19, plus Frobenius j -> j^2:
\\      no edge / component crosses between 19 | cond and 19 not| cond; then (3b) add 19-edges
\\ (4) E0: 19-torsion only over F_{q^r}; psi_19(E0) factors into F_q-irreducibles of degree r_x only
default(parisizemax, 2000000000);
P = Mod(1,2)*(x^20+x^3+1); g = ffgen(P, 'z); q = 2^20; tt = 1201; f = 627;
if(tt^2 - 4*q != -7*f^2, error("disc"));
hits = read("toy_enum_hits.txt");
toint(u) = subst(lift(u.pol), 'z, 2);
fromint(n) = {my(v = binary(n), s = 0*g); for(i = 1, #v, if(v[i], s += g^(#v - i))); s;}
\\ sanity of the int <-> field conversion
{if(toint(fromint(537598)) != 537598, error("conv"));}
{nJ = #hits; Jv = vector(nJ, i, 1/fromint(hits[i][1])); idx = Map();
for(i = 1, nJ, mapput(idx, toint(Jv[i]), i));
print("(1) #j with trace +-t = ", nJ, "   distinct = ", #idx);}
hK(c) = {my(h = c, F = factor(c)); for(k = 1, #F~, h *= (1 - kronecker(-7, F[k,1]) / F[k,1])); h;}
{conds = divisors(f); H = vector(#conds, k, hK(conds[k]));
print("h(c), c | 627: ", conds, " -> ", H, "   sum = ", vecsum(H));
if(vecsum(H) != nJ, error("count mismatch"));
lev = vector(nJ);
for(k = 1, #conds,
  c = conds[k]; Hc = polclass(-7*c^2, 0, 'y) * Mod(1,2) * g^0;
  if(poldegree(Hc) != H[k], error("deg"));
  rts = polrootsmod(Hc);
  if(#rts != H[k], error(Str("not split / not squarefree for c = ", c)));
  for(i = 1, #rts, n = toint(rts[i]); if(!mapisdefined(idx, n, &ii), error("root outside J"));
     if(lev[ii], error("j in two H_D")); lev[ii] = c));
if(#select(v -> v == 0, lev), error("unlabelled j"));
print("(2a) every j is a root of exactly one H_{-7c^2} mod 2; level counts: ",
      vector(#conds, k, [conds[k], #select(v -> v == conds[k], lev)]));
}
\\ modular polynomials mod 2
PL = Map();
Phi(l) = {my(M); if(!mapisdefined(PL, l, &M), M = lift(polmodular(l, 0, 'x, 'y) * Mod(1,2)); mapput(PL, l, M)); M;}
\\ roots in F_q with multiplicity of Phi_l(j, Y)
rootsmult(l, j) = {
  my(F = subst(Phi(l), 'x, j) * g^0, rts = polrootsmod(F), out = List(), m, G);
  for(i = 1, #rts, m = 0; G = F; while(subst(G, 'y, rts[i]) == 0, G = G \ ('y - rts[i]); m++); listput(out, [rts[i], m]));
  Vec(out);
}
\\ (2b)
{
agree = 1; tally = Map();
for(i = 1, nJ,
  for(a = 1, 3, l = [3, 11, 19][a];
    R = rootsmult(l, Jv[i]); n = sum(k = 1, #R, R[k][2]);
    pred = if(lev[i] % l, l + 1, 1);
    key = Str("l=", l, " l|cond=", lev[i] % l == 0, " roots=", n);
    mapput(tally, key, if(mapisdefined(tally, key, &cc), cc + 1, 1));
    if(n != pred, agree = 0)));
print("(2b) tally of #F_q-roots of Phi_l(j,Y): ", Mat(tally));
print("(2b) agrees with H_D levels: ", agree);
if(!agree, error("2b"));
}
\\ (3) union-find
{par = vector(nJ, i, i);}
find(a) = {while(par[a] != a, par[a] = par[par[a]]; a = par[a]); a;}
unite(a, b) = {my(ra = find(a), rb = find(b)); if(ra != rb, par[ra] = rb);}
{degs = select(l -> l != 19, primes([3, 97]));}
{
nedges = 0; outside = 0; cross = 0; T = getabstime();
for(i = 1, nJ,
  n2 = toint(Jv[i]^2); if(!mapisdefined(idx, n2, &i2), error("frob")); unite(i, i2);
  for(a = 1, #degs,
    R = rootsmult(degs[a], Jv[i]);
    for(k = 1, #R,
      n = toint(R[k][1]);
      if(!mapisdefined(idx, n, &i2), outside++; next);
      nedges++;
      if((lev[i] % 19 == 0) != (lev[i2] % 19 == 0), cross++);
      unite(i, i2))));
print("(3) degrees: 2 (Frobenius) and ", degs, "  time ms ", getabstime() - T);
print("(3) edges = ", nedges, "  targets outside J = ", outside, "  edges crossing 19-levels = ", cross);
}
{comps = Map();
for(i = 1, nJ, r = find(i); L = if(mapisdefined(comps, r, &L), L, List()); listput(L, i); mapput(comps, r, L));
CM = Mat(comps); info = vector(#CM~, k, my(L = CM[k,2]); [#L, Set(vector(#L, m, lev[L[m]]))]);
info = vecsort(info, 1, 4);
print("(3) components [size, set of conductors]: ", info);
mixed = #select(v -> #Set(apply(c -> c % 19 == 0, v[2])) > 1, info);
print("(3) components mixing 19|cond and 19 not| cond: ", mixed);
i0 = idx; e0 = mapget(idx, toint(g^0)); r0 = find(e0);
compE0 = select(i -> find(i) == r0, [1..nJ]);
print("(3) E0 component: size ", #compE0, "  conductors ", Set(vector(#compE0, m, lev[compE0[m]])));
if(mixed || cross, error("3"));
}
{
cross19 = 0;
for(i = 1, nJ, R = rootsmult(19, Jv[i]);
  for(k = 1, #R, i2 = mapget(idx, toint(R[k][1]));
    if((lev[i] % 19 == 0) != (lev[i2] % 19 == 0), cross19++); unite(i, i2)));
print("(3b) 19-isogeny edges crossing 19-levels: ", cross19, "   components after adding 19-edges: ",
      #Set(vector(nJ, i, find(i))));
}
\\ (4) E0[19]
tk(k) = {my(a = 2, b = tt); for(i = 1, k - 1, [a, b] = [b, tt*b - q*a]); b;}
{
E0 = ellinit([1,0,0,0,1], g); if(ellcard(E0) != q + 1 - tt, error("E0"));
c19 = Mod(tt, 19) / 2; r = znorder(c19);
rx = 1; while(c19^rx != 1 && c19^rx != -1, rx++);
ks = select(k -> (q^k + 1 - tk(k)) % 19 == 0, [1..2*r]);
print("(4) c = t/2 mod 19 = ", lift(c19), "  r = ", r, "  r_x = ", rx, "  k<=2r with 19 | #E0(F_{q^k}): ", ks,
      "  v_19(#E0(F_{q^r})) = ", valuation(q^r + 1 - tk(r), 19));
dpsi = elldivpol(E0, 19); Fa = factor(dpsi);
print("(4) deg psi_19 = ", poldegree(dpsi), "  F_q-irreducible factor degrees (with counts): ",
      matreduce(vector(#Fa~, k, poldegree(Fa[k,1]))));
}
{n19 = sum(k = 1, #conds, if(conds[k] % 19 == 0, H[k], 0));
print("(5) #classes with 19 | cond = ", n19, "  log2 Pr[random (b,a2)] = ", log(n19 / (2*(q - 1))) / log(2));
print("END (any error above means a check did not run)");}
