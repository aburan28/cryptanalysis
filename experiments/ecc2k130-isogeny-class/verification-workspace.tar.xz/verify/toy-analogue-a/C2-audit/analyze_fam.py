"""usage: python3 analyze_fam.py <n> <N> <tag_native> <tag_transport>  -> ratio of per-instance mean steps."""
import sys, math, json
from statistics import mean, stdev
n, N = int(sys.argv[1]), int(sys.argv[2])
th = math.sqrt(math.pi * N / (4 * n))
res = {}
for tag in sys.argv[3:]:
    rows = [l.split() for l in open(f'runs/{tag}/all.txt')]
    ok = sum(1 for r in rows if r[4] == '1' and r[5] == '1')
    per = {}
    for r in rows:
        per.setdefault(r[0], []).append(int(r[2]))
    im = [mean(v) for v in per.values()]
    m = mean(im); sem = stdev(im) / math.sqrt(len(im))
    res[tag] = dict(runs=len(rows), instances=len(per), solved_and_matched=ok, mean_steps=m, sem=sem, over_theory=m / th)
    print(f'{tag:16s} runs={len(rows)} inst={len(per)} ok={ok} mean={m:.2f} +- {sem:.2f} over sqrt(pi N/4n)={m/th:.4f}')
a, b = res[sys.argv[4]], res[sys.argv[3]]
r = a['mean_steps'] / b['mean_steps']; se = r * math.sqrt((a['sem'] / a['mean_steps'])**2 + (b['sem'] / b['mean_steps'])**2)
res['ratio'] = dict(ratio=r, se=se)
print(f'ratio transport/native = {r:.4f} +- {se:.4f}')
json.dump(res, open(f'myrho_{sys.argv[3]}_{sys.argv[4]}.json', 'w'), indent=1)
