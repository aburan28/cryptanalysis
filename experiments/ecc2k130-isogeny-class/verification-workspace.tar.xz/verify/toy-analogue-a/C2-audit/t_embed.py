import time
from sage.all import *
t0=time.time()
R = PolynomialRing(GF(2),'z'); z=R.gen()
tail=123
modK = z**59 + R([(tail>>i)&1 for i in range(8)])
print(modK, modK.is_irreducible())
K = GF(2**59,'z',modulus=modK)
L = GF(2**2891,'w')
print('L modulus', L.modulus().hamming_weight() if hasattr(L.modulus(),'hamming_weight') else len(L.modulus().exponents()), L.modulus().exponents(), time.time()-t0)
pa = pari('ffgen(Mod(1,2)*(%s),\'a)' % str(modK).replace('z','y'))
pb = pari('ffgen(Mod(1,2)*(%s),\'b)' % str(L.modulus()).replace('x','t').replace('w','t'))
print('pari fields', time.time()-t0)
m = pari.ffembed(pa, pb)
print('ffembed', time.time()-t0)
img = pari.ffmap(m, pa)
coeffs = img.pol_lift() if hasattr(img,'pol_lift') else None
getpol = pari('(x)->Vecrev(lift(x.pol))')
v = getpol(img)
print(len(v), [int(c) % 2 for c in v][:20])
bits = [int(c) % 2 for c in v]
zeta = L(PolynomialRing(GF(2),'w')(bits))
print('modK(zeta)==0', modK.change_ring(L)(zeta) == 0, time.time()-t0)
save(zeta, '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C2-audit/zeta_T59.sobj')
