#!/bin/bash
# usage: runfam.sh <n> <tail> <a2> <N> <s> <instfile> <tag> <reps> <seed> [chunks]   (mode 2 = negtau)
set -e
cd /Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C2-audit
n=$1; tail=$2; a2=$3; N=$4; s=$5; f=$6; tag=$7; reps=$8; seed=$9; ch=${10:-6}
mkdir -p runs/$tag; rm -f runs/$tag/part.*
gsplit -n l/$ch -d "$f" runs/$tag/part.
ls runs/$tag/part.* | grep -v '\.out$' | xargs -P $ch -I{} sh -c "timeout 2400 ./myrho $n $tail $a2 $N $s 2 $reps $seed < {} > {}.out"
for p in runs/$tag/part.??; do i=${p##*.}; awk -v i=$i '{ $1 = i*100000 + $1; print }' $p.out; done > runs/$tag/all.txt
wc -l runs/$tag/all.txt
