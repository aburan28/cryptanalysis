"""Compare my-rho costs on native E0 instances vs transported instances (T59, negtau).
usage: python3 analyze_myrho.py <tagA> <tagB> [...]; prints mean steps, SEM, ratio of each tag to the first."""
import sys, math, json
from statistics import mean, stdev
N = 10063074221; n = 59
M = N / (2 * n)
th = math.sqrt(math.pi * M / 2)
res = {}
for tag in sys.argv[1:]:
    rows = [l.split() for l in open(f'runs/{tag}/all.txt')]
    steps = [int(r[2]) for r in rows]
    ok = sum(1 for r in rows if r[4] == '1' and r[5] == '1')
    fr = sum(int(r[3]) for r in rows)
    # per-instance mean over reps (instances are the independent unit)
    per = {}
    for r in rows:
        per.setdefault(r[0], []).append(int(r[2]))
    inst_means = [mean(v) for v in per.values()]
    m = mean(inst_means); sem = stdev(inst_means) / math.sqrt(len(inst_means))
    res[tag] = dict(runs=len(rows), instances=len(per), solved_and_matched=ok, fruitless=fr, mean_steps=m, sem=sem,
                    over_theory=m / th)
    print(f'{tag:24s} runs={len(rows)} inst={len(per)} ok={ok} fruitless={fr} mean={m:.1f} +- {sem:.1f}  mean/sqrt(pi M/2)={m/th:.4f}')
base = sys.argv[1]
for tag in sys.argv[2:]:
    a, b = res[tag], res[base]
    r = a['mean_steps'] / b['mean_steps']
    se = r * math.sqrt((a['sem'] / a['mean_steps'])**2 + (b['sem'] / b['mean_steps'])**2)
    print(f'ratio {tag}/{base} = {r:.4f} +- {se:.4f}')
    res[f'ratio_{tag}_over_{base}'] = dict(ratio=r, se=se)
print('theory sqrt(pi*N/(4n)) =', th)
json.dump(res, open('myrho_' + '_'.join(sys.argv[1:]) + '.json', 'w'), indent=1)
