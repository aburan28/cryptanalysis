/* myrho.c -- C2 audit: an independent, deliberately simple Pollard rho on E0 : y^2 + xy = x^3 + a2 x^2 + 1
 * over F_{2^n} (n <= 63, modulus z^n + tail), in the prime-order-N subgroup, with the class
 * {+-tau^i P} (tau(x,y) = (x^2,y^2) acting as the scalar s), or {+-P}, or plain points.
 * Written from scratch for the audit (does not share code with the sweep's rho.c):
 *   - single walk, r-adding walk (r = 256, table entries c_j P + d_j Q), every visited class
 *     representative stored in a hash table (no distinguished points), so the first repeat is
 *     seen exactly;
 *   - a repeat with the same b-coefficient is a fruitless cycle: leave it via canon(2X);
 *   - a repeat with a different b solves Q = kP; the result is checked (kP == Q) and compared
 *     with the planted k.
 * Output: one line per run: <line#> <rep> <steps> <fruitless> <ok> <match>
 * steps = group operations (additions + escape doublings + the start point), the cost measure.
 *
 * usage: myrho n tail a2 N s mode(0 none,1 neg,2 negtau) reps seed < instances
 * instance lines: Px Py Qx Qy k   (hex hex hex hex dec)
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <arm_neon.h>
typedef uint64_t u64;
typedef unsigned __int128 u128;

static int NB; static u64 TAIL, FMASK, A2, NORD, SEIG; static int MODE;

static inline u128 clmul(u64 a, u64 b) {
    poly128_t r = vmull_p64((poly64_t)a, (poly64_t)b);
    u128 out; memcpy(&out, &r, 16); return out;
}
static inline u64 fred(u128 p) {
    while (p >> NB) {
        u64 hi = (u64)(p >> NB);
        p = (p & FMASK) ^ clmul(hi, TAIL);
    }
    return (u64)p;
}
static inline u64 fmul(u64 a, u64 b) { return fred(clmul(a, b)); }
static inline u64 fsq(u64 a) { return fred(clmul(a, a)); }
static u64 finv(u64 a) {                 /* a^(2^n - 2) */
    u64 r = a;
    for (int i = 1; i < NB - 1; i++) r = fmul(fsq(r), a);   /* r = a^(2^i+...+1) = a^(2^(i+1)-1) */
    return fsq(r);                                        /* a^(2^n - 2) */
}

typedef struct { u64 x, y; int inf; } Pt;
static int oncurve(Pt P) {
    if (P.inf) return 1;
    u64 x = P.x, y = P.y;
    u64 lhs = fsq(y) ^ fmul(x, y);
    u64 x2 = fsq(x);
    u64 rhs = fmul(x2, x) ^ (A2 ? x2 : 0) ^ 1;
    return lhs == rhs;
}
static Pt pneg(Pt P) { Pt R = P; if (!P.inf) R.y = P.x ^ P.y; return R; }
static Pt pdbl(Pt P) {
    Pt R; if (P.inf || P.x == 0) { R.inf = 1; R.x = R.y = 0; return R; }
    u64 lam = P.x ^ fmul(P.y, finv(P.x));
    u64 x3 = fsq(lam) ^ lam ^ (A2 ? 1 : 0);
    u64 y3 = fsq(P.x) ^ fmul(lam ^ 1, x3);
    R.x = x3; R.y = y3; R.inf = 0; return R;
}
static Pt padd(Pt P, Pt Q) {
    if (P.inf) return Q;
    if (Q.inf) return P;
    if (P.x == Q.x) {
        if (P.y == Q.y) return pdbl(P);
        Pt R; R.inf = 1; R.x = R.y = 0; return R;   /* Q = -P */
    }
    u64 lam = fmul(P.y ^ Q.y, finv(P.x ^ Q.x));
    u64 x3 = fsq(lam) ^ lam ^ P.x ^ Q.x ^ (A2 ? 1 : 0);
    u64 y3 = fmul(lam, P.x ^ x3) ^ x3 ^ P.y;
    Pt R; R.x = x3; R.y = y3; R.inf = 0; return R;
}
static Pt pmul(Pt P, u64 k) {
    Pt R; R.inf = 1; R.x = R.y = 0;
    for (int i = 63; i >= 0; i--) { R = pdbl(R); if ((k >> i) & 1) R = padd(R, P); }
    return R;
}
static int peq(Pt a, Pt b) { if (a.inf || b.inf) return a.inf == b.inf; return a.x == b.x && a.y == b.y; }

static inline u64 mulm(u64 a, u64 b) { return (u64)(((u128)a * b) % NORD); }
static inline u64 addm(u64 a, u64 b) { u64 c = a + b; return c >= NORD ? c - NORD : c; }
static u64 powm(u64 a, u64 e) { u64 r = 1; while (e) { if (e & 1) r = mulm(r, a); a = mulm(a, a); e >>= 1; } return r; }
static u64 invm(u64 a) { return powm(a, NORD - 2); }

static u64 SPOW[64];
/* canonical representative; returns multiplier m with canon(P) = m P */
static u64 canon(Pt *P) {
    if (P->inf) return 1;
    u64 m = 1;
    if (MODE == 2) {
        u64 x = P->x, best = x; int bi = 0;
        for (int i = 1; i < NB; i++) { x = fsq(x); if (x < best) { best = x; bi = i; } }
        u64 y = P->y;
        for (int i = 0; i < bi; i++) y = fsq(y);
        P->x = best; P->y = y; m = SPOW[bi];
    }
    if (MODE >= 1) {
        u64 y2 = P->x ^ P->y;
        if (y2 < P->y) { P->y = y2; m = NORD - m; if (m == NORD) m = 0; }
    }
    return m;
}

static u64 rs;
static u64 rnd(void) { u64 z = (rs += 0x9e3779b97f4a7c15ULL); z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL; z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL; return z ^ (z >> 31); }

#define RR 256
typedef struct { u64 x, y, a, b; int used; } HE;
static HE *H; static u64 HCAP;
static HE *hfind(u64 x, u64 y, int *found) {
    u64 h = (x * 0x9e3779b97f4a7c15ULL) ^ (y * 0xc2b2ae3d27d4eb4fULL);
    u64 i = (h >> 7) & (HCAP - 1);
    for (;;) {
        if (!H[i].used) { *found = 0; return &H[i]; }
        if (H[i].x == x && H[i].y == y) { *found = 1; return &H[i]; }
        i = (i + 1) & (HCAP - 1);
    }
}

int main(int argc, char **argv) {
    if (argc < 9) { fprintf(stderr, "usage\n"); return 1; }
    NB = atoi(argv[1]); TAIL = strtoull(argv[2], 0, 10); A2 = strtoull(argv[3], 0, 10);
    NORD = strtoull(argv[4], 0, 10); SEIG = strtoull(argv[5], 0, 10); MODE = atoi(argv[6]);
    int reps = atoi(argv[7]); u64 seed = strtoull(argv[8], 0, 10);
    FMASK = (NB == 64) ? ~0ULL : ((1ULL << NB) - 1);
    SPOW[0] = 1; for (int i = 1; i < 64; i++) SPOW[i] = mulm(SPOW[i - 1], SEIG);
    /* field self-test: a * a^-1 == 1 */
    rs = 12345;
    for (int i = 0; i < 100; i++) { u64 a = rnd() & FMASK; if (!a) continue; if (fmul(a, finv(a)) != 1) { fprintf(stderr, "finv failed\n"); return 3; } }
    HCAP = 1; while (HCAP < 16 * (u64)(1024 + __builtin_sqrt(3.14159265 * (double)NORD / (2.0 * (MODE == 2 ? 2 * NB : MODE == 1 ? 2 : 1))))) HCAP <<= 1;
    H = calloc(HCAP, sizeof(HE));
    u64 *USED = malloc(sizeof(u64) * HCAP); u64 nused = 0;
    char line[1024]; int ln = 0;
    while (fgets(line, sizeof line, stdin)) {
        char px[64], py[64], qx[64], qy[64]; unsigned long long k;
        if (sscanf(line, "%63s %63s %63s %63s %llu", px, py, qx, qy, &k) != 5) continue;
        ln++;
        Pt P0 = {strtoull(px, 0, 16), strtoull(py, 0, 16), 0}, Q0 = {strtoull(qx, 0, 16), strtoull(qy, 0, 16), 0};
        if (!oncurve(P0) || !oncurve(Q0)) { fprintf(stderr, "line %d: not on curve\n", ln); return 4; }
        if (!pmul(P0, NORD).inf) { fprintf(stderr, "line %d: order != N\n", ln); return 4; }
        if (MODE == 2) { Pt T = {fsq(P0.x), fsq(P0.y), 0}; if (!peq(T, pmul(P0, SEIG))) { fprintf(stderr, "line %d: tau != s\n", ln); return 4; } }
        for (int rep = 0; rep < reps; rep++) {
            rs = seed * 1000003ULL + (u64)ln * 7919ULL + (u64)rep * 104729ULL;
            Pt Rt[RR]; u64 ca[RR], cb[RR];
            for (int j = 0; j < RR; j++) {
                do { ca[j] = rnd() % NORD; cb[j] = rnd() % NORD; Rt[j] = padd(pmul(P0, ca[j]), pmul(Q0, cb[j])); } while (Rt[j].inf);
            }
            for (u64 u = 0; u < nused; u++) H[USED[u]].used = 0;
            nused = 0;
            u64 a, b; Pt X;
            do { a = rnd() % NORD; b = rnd() % NORD; X = padd(pmul(P0, a), pmul(Q0, b)); } while (X.inf);
            u64 m = canon(&X); a = mulm(m, a); b = mulm(m, b);
            u64 steps = 1, fruitless = 0, ksol = 0; int solved = 0;
            for (;;) {
                int found; HE *e = hfind(X.x, X.y, &found);
                if (found) {
                    if (e->b != b) {
                        /* aP + bQ = a'P + b'Q -> k = (a - a') / (b' - b) */
                        ksol = mulm((a + NORD - e->a) % NORD, invm((e->b + NORD - b) % NORD));
                        solved = 1; break;
                    }
                    /* fruitless cycle: escape with canon(2X) */
                    fruitless++;
                    X = pdbl(X); a = addm(a, a); b = addm(b, b); steps++;
                    if (X.inf) { do { a = rnd() % NORD; b = rnd() % NORD; X = padd(pmul(P0, a), pmul(Q0, b)); } while (X.inf); steps++; }
                    m = canon(&X); a = mulm(m, a); b = mulm(m, b);
                    continue;
                }
                e->used = 1; e->x = X.x; e->y = X.y; e->a = a; e->b = b; USED[nused++] = (u64)(e - H);
                if (nused > HCAP / 2) { fprintf(stderr, "line %d rep %d: table full\n", ln, rep); break; }
                int j = (int)((X.x * 0x9e3779b97f4a7c15ULL) >> 56);   /* 8 bits -> RR = 256 */
                X = padd(X, Rt[j]); a = addm(a, ca[j]); b = addm(b, cb[j]); steps++;
                if (X.inf) { do { a = rnd() % NORD; b = rnd() % NORD; X = padd(pmul(P0, a), pmul(Q0, b)); } while (X.inf); steps++; }
                m = canon(&X); a = mulm(m, a); b = mulm(m, b);
            }
            int ok = solved && peq(pmul(P0, ksol), Q0);
            int match = ksol == (u64)(k % NORD);
            printf("%d %d %llu %llu %d %d\n", ln, rep, (unsigned long long)steps, (unsigned long long)fruitless, ok, match);
        }
        fflush(stdout);
    }
    return 0;
}
