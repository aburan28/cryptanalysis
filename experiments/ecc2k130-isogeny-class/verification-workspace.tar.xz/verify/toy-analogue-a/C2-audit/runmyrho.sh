#!/bin/bash
# usage: runmyrho.sh <instfile> <tag> <reps> <seed> [chunks]
# T59 parameters: n=59 tail=123 a2=0 N=10063074221 s=7715620412 (s re-derived in verify_T59_isogeny.py), mode 2 = negtau
set -e
cd /Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C2-audit
f=$1; tag=$2; reps=$3; seed=$4; ch=${5:-8}
mkdir -p runs/$tag
rm -f runs/$tag/part.*
gsplit -n l/$ch -d "$f" runs/$tag/part.
ls runs/$tag/part.* | grep -v '\.out$' | xargs -P $ch -I{} sh -c "timeout 2400 ./myrho 59 123 0 10063074221 7715620412 2 $reps $seed < {} > {}.out"
# re-number: part index * 100000 + line
for p in runs/$tag/part.??; do i=${p##*.}; awk -v i=$i '{ $1 = i*100000 + $1; print }' $p.out; done > runs/$tag/all.txt
wc -l runs/$tag/all.txt
