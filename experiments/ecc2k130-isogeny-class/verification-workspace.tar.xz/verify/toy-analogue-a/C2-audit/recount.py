"""Independent recount of the C2 statistics straight from the rho TSVs (not from summary.json)."""
import csv, os, math, json
W = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/raw'
out = {}
def load(p):
    with open(p) as fh:
        return list(csv.DictReader(fh, delimiter='\t'))
def ms(x):
    n = len(x); m = sum(x)/n; sd = math.sqrt(sum((v-m)**2 for v in x)/(n-1)); return n, m, sd/math.sqrt(n)
tot_tr = tot_tr_ok = 0
ratios = {}
for F in ['T11', 'T19', 'T23', 'T59', 'T109']:
    d = os.path.join(W, F, 'out')
    tr_rows = []
    for fn in sorted(os.listdir(d)):
        if fn.endswith('__transport_negtau.tsv'):
            tr_rows += load(os.path.join(d, fn))
    e0 = load(os.path.join(d, 'E0__negtau.tsv'))
    ok = sum(1 for r in tr_rows if r['verified'] == '1' and r['match'] == '1' and r['k_true'] == r['k_found'])
    e0ok = sum(1 for r in e0 if r['verified'] == '1' and r['match'] == '1')
    ids = [r['id'] for r in tr_rows]
    dup = len(ids) - len(set(ids))
    tot_tr += len(tr_rows); tot_tr_ok += ok
    for metric in ('merge_steps', 'iters'):
        n3, m3, s3 = ms([int(r[metric]) for r in tr_rows])
        n2, m2, s2 = ms([int(r[metric]) for r in e0])
        r = m3 / m2; se = r * math.sqrt((s3/m3)**2 + (s2/m2)**2)
        ratios.setdefault(metric, {})[F] = (r, se)
        print(F, metric, 'iii n=%d mean=%.2f  ii n=%d mean=%.2f  ratio=%.4f +- %.4f' % (n3, m3, n2, m2, r, se))
    mo = sum(1 for r in tr_rows if r['merge_ok'] != '1')
    print(F, 'transported rows', len(tr_rows), 'verified+match', ok, 'dup ids', dup, 'merge_ok!=1', mo, 'E0 rows', len(e0), 'E0 ok', e0ok)
    out[F] = dict(transported_rows=len(tr_rows), transported_ok=ok, E0_negtau_rows=len(e0), E0_ok=e0ok, merge_ok_not1=mo)
print('TOTAL transported rows', tot_tr, 'ok', tot_tr_ok)
for metric, rr in ratios.items():
    for fams in (['T19', 'T23', 'T59', 'T109'], ['T11', 'T19', 'T23', 'T59', 'T109']):
        w = [1/rr[f][1]**2 for f in fams]
        m = sum(wi*rr[f][0] for wi, f in zip(w, fams))/sum(w)
        se = 1/math.sqrt(sum(w))
        chi2 = sum(((rr[f][0]-m)/rr[f][1])**2 for f in fams)
        print(metric, 'pooled IVW', fams, '%.4f +- %.4f  chi2=%.2f dof=%d' % (m, se, chi2, len(fams)-1))
out['ratios'] = ratios
out['total_transported_rows'] = tot_tr; out['total_transported_ok'] = tot_tr_ok
json.dump(out, open('recount.json', 'w'), indent=1)
