"""C2 audit: independent recomputation of the ascending 5783-isogeny E_f -> E0 for the T59 floor
curve O00-000 (and optionally others), without the sweep's code paths:
  * field embedding K = F_{2^59} -> L = F_{2^2891} from PARI ffembed (sweep: its own tensor-model
    linear algebra in toylib.make_ext),
  * #E(F_q) from Sage/PARI point counting, #E(F_{q^49}) from the F_q-trace recurrence (sweep: the
    F_2 Lucas sequence),
  * the isogeny evaluated by summing Velu's formulas directly over the (l-1)/2 kernel points in L
    (sweep: kernel polynomial psi over F_q + Hasse-derivative closed form in make_floor_fast.py).
Then the stored instances in raw/T59/instances.json are mapped and compared with the sweep's
P_E0/Q_E0, logs are checked, and fresh instances (native E0 and transported) are written for an
independent rho (myrho.c).

usage: sage -python verify_T59_isogeny.py <label> <n_fresh_transport> <n_fresh_native>
"""
import sys, json, time, os
from sage.all import (GF, PolynomialRing, EllipticCurve, Integer, ZZ, factor, is_prime, kronecker,
                      set_random_seed, randint, pari, matrix, vector, load, save)

T0 = time.time()
LAB = sys.argv[1] if len(sys.argv) > 1 else 'O00-000'
NFT = int(sys.argv[2]) if len(sys.argv) > 2 else 0
NFN = int(sys.argv[3]) if len(sys.argv) > 3 else 0
HERE = os.path.dirname(os.path.abspath(__file__))
SW = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
set_random_seed(4242 + sum(map(ord, LAB)))
log = {}


def say(*a):
    print(*a, round(time.time() - T0, 1), flush=True)


fam = json.load(open(os.path.join(SW, 'data', 'T59_family.json')))
meta = fam['meta']
n, l, tail = 59, 5783, 123
assert meta['n'] == n and meta['l'] == l and meta['modulus_tail'] == tail and meta['a'] == 0
R2 = PolynomialRing(GF(2), 'z')
z = R2.gen()
modK = z**n + R2([(tail >> i) & 1 for i in range(8)])
assert modK.is_irreducible()
K = GF(2**n, 'z', modulus=modK)
q = Integer(2)**n
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
cinfo = fam['curves'][LAB]
bf = K.from_integer(int(cinfo['b_int']))
Ef = EllipticCurve(K, [1, 0, 0, 0, bf])
assert Ef.j_invariant() == K.from_integer(int(cinfo['j_int'])) and bf * Ef.j_invariant() == 1

# --- point counts (Sage -> PARI SEA), trace, conductor
c0 = E0.cardinality()
cf = Ef.cardinality()
t = q + 1 - c0
D = t * t - 4 * q
f2 = -D / 7
f = ZZ(f2).isqrt()
fac = factor(c0)
N = max(p for p, e in fac)
h = c0 // N
log['E0_card'] = int(c0); log['Ef_card'] = int(cf); log['t'] = int(t); log['N'] = int(N); log['card_factor'] = str(fac)
log['f'] = int(f); log['f_factor'] = str(factor(f))
assert cf == c0, 'isogenous curves must have equal order'
assert f * f == f2 and f % l == 0 and (f // l) % l != 0 and kronecker(-7, l) == 1
assert is_prime(N) and h % N != 0
assert int(N) == int(meta['N'])
say('counts ok', dict(t=t, N=N, h=h, f=factor(f)))

# tau eigenvalue on <P>, recomputed
Rn = PolynomialRing(GF(N), 'X')
Pg = h * E0.random_point()
while Pg == 0:
    Pg = h * E0.random_point()
tP = E0(Pg[0]**2, Pg[1]**2)
s = [Integer(r) for r in (Rn.gen()**2 + Rn.gen() + 2).roots(multiplicities=False) if Integer(r) * Pg == tP]
assert len(s) == 1
s = s[0]
log['tau_eigen_s'] = int(s)
assert int(s) == int(meta['tau_eigen_s'])

# --- extension field
lam = GF(l)(t) / 2
kT = int(lam.multiplicative_order())
log['lambda'] = int(lam); log['kT'] = kT
assert kT == 49
L = GF(Integer(2)**(n * kT), 'w')
zeta = load(os.path.join(HERE, 'zeta_T59.sobj'))
zeta = L(zeta)
assert modK.change_ring(L)(zeta) == 0
emb = K.hom([zeta], L)
# down map by linear algebra on the powers of zeta
Z = [L(1)]
for i in range(1, n):
    Z.append(Z[-1] * zeta)


def lvec(x):
    c = x.polynomial().list()
    return c + [0] * (n * kT - len(c))


Mz = matrix(GF(2), [lvec(x) for x in Z])


def down(x):
    sol = Mz.solve_left(vector(GF(2), lvec(x)))
    return K(R2(list(sol)))


tt = [Integer(2), Integer(t)]
for m in range(2, kT + 1):
    tt.append(t * tt[-1] - q * tt[-2])
cardL = q**kT + 1 - tt[kT]
vL = cardL.valuation(l)
cofL = cardL // l**vL
log['v_l_cardL'] = int(vL)
EfL = EllipticCurve(L, [1, 0, 0, 0, emb(bf)])
E0L = EllipticCurve(L, [1, 0, 0, 0, 1])
Rr = EfL.random_point()
assert cardL * Rr == 0
say('extension ready, v_l(#E_f(L)) =', vL)


def lpoint():
    while True:
        U = cofL * EfL.random_point()
        if U == 0:
            continue
        while l * U != 0:
            U = l * U
        return U


T = lpoint()
half = (l - 1) // 2
xs, ys = [], []
S = T
for i in range(half):
    xs.append(S[0]); ys.append(S[1])
    S = S + T
assert (S + T) != 0 and l * T == 0          # order exactly l (l prime, T != 0)
xset = set(xs)
assert len(xset) == half
# Galois stability of <T>: pi(T) = (x^q, y^q) must lie in <T>
xq = T[0]**q
assert xq in xset
idx = xs.index(xq) + 1
lam_obs = idx if EfL(xq, T[1]**q) == idx * T else l - idx
log['pi_on_T_multiplier'] = int(lam_obs)
assert GF(l)(lam_obs) == lam
# floor check: a second, independent l-point lies in <T> (E_f(L)[l] is one line)
line_hits = 0
for _ in range(3):
    T2 = lpoint()
    line_hits += (T2[0] in xset)
log['second_l_points_in_line'] = f'{line_hits}/3'
assert line_hits == 3
# codomain
v = sum(xs)
bcod = emb(bf) + v + v * v
log['codomain_b_is_1'] = bool(bcod == 1)
assert bcod == 1
say('kernel ready; pi acts on <T> as', lam_obs, 'codomain b = 1')

# Velu terms (char 2, a1 = 1, a3 = a4 = 0): t_Q = x_Q, u_Q = x_Q^2, g^x_Q = x_Q^2 + y_Q, g^y_Q = x_Q
gx = [xq_ * xq_ + yq_ for xq_, yq_ in zip(xs, ys)]
cterm = [xq_ * xq_ + gxq * xq_ for xq_, gxq in zip(xs, gx)]      # a1 u_Q - g^x_Q g^y_Q


def phi(Pt):
    """Velu's map, summed over the kernel representatives, then (X, Y) -> (X, Y + v)."""
    x, y = emb(Pt[0]), emb(Pt[1])
    ds = [x + xq_ for xq_ in xs]
    # batch inversion
    pref = [L(1)]
    for d in ds:
        pref.append(pref[-1] * d)
    inv = ~pref[-1]
    invs = [None] * half
    for i in range(half - 1, -1, -1):
        invs[i] = inv * pref[i]
        inv = inv * ds[i]
    X = x
    Y = y
    for i in range(half):
        iv = invs[i]
        iv2 = iv * iv
        xq_, yq_ = xs[i], ys[i]
        tq, uq = xq_, xq_ * xq_
        X += tq * iv + uq * iv2
        Y += uq * x * iv2 * iv + tq * ((x + xq_) + y + yq_) * iv2 + cterm[i] * iv2
    return E0L(X, Y + v)        # raises if not on E0


# homomorphism sanity
P1 = h * Ef.random_point(); P2 = h * Ef.random_point()
hom_ok = phi(P1 + P2) == phi(P1) + phi(P2)
log['hom_check'] = bool(hom_ok)
assert hom_ok
say('Velu map ok (on-curve, additive)')

# --- stored instances
inst = json.load(open(os.path.join(SW, 'raw', 'T59', 'instances.json')))
mine = {k_: r for k_, r in inst.items() if r['curve'] == LAB and 'P_E0' in r}
signs = {'+': 0, '-': 0, 'none': 0}
logs_ok = stored_ok = 0
for iid, r in sorted(mine.items()):
    P = Ef(K.from_integer(r['P'][0]), K.from_integer(r['P'][1]))
    Q = Ef(K.from_integer(r['Q'][0]), K.from_integer(r['Q'][1]))
    k = Integer(r['k'])
    assert N * P == 0 and P != 0 and k * P == Q
    Pe = E0(K.from_integer(r['P_E0'][0]), K.from_integer(r['P_E0'][1]))
    Qe = E0(K.from_integer(r['Q_E0'][0]), K.from_integer(r['Q_E0'][1]))
    stored_ok += (N * Pe == 0 and Pe != 0 and k * Pe == Qe)
    fP, fQ = phi(P), phi(Q)
    logs_ok += (k * fP == fQ)
    PeL = E0L(emb(Pe[0]), emb(Pe[1]))
    QeL = E0L(emb(Qe[0]), emb(Qe[1]))
    if fP == PeL and fQ == QeL:
        signs['+'] += 1
    elif fP == -PeL and fQ == -QeL:
        signs['-'] += 1
    else:
        signs['none'] += 1
log['stored_instances'] = len(mine)
log['stored_P_E0_order_N_and_log_ok'] = stored_ok
log['my_phi_preserves_log'] = logs_ok
log['my_phi_vs_stored_sign_counts'] = signs
say('stored instances', len(mine), 'stored ok', stored_ok, 'my log ok', logs_ok, 'signs', signs)

# --- fresh instances for the independent rho
def rand_inst(E):
    while True:
        P = h * E.random_point()
        if P != 0:
            break
    k = randint(1, int(N) - 1)
    return P, k, k * P


fi = lambda u: int(u.to_integer())
lines_tr, lines_nat = [], []
for i in range(NFT):
    P, k, Q = rand_inst(Ef)
    fP, fQ = phi(P), phi(Q)
    Pd = E0(down(fP[0]), down(fP[1]))
    Qd = E0(down(fQ[0]), down(fQ[1]))
    assert k * Pd == Qd and N * Pd == 0
    lines_tr.append(f'{fi(Pd[0]):x} {fi(Pd[1]):x} {fi(Qd[0]):x} {fi(Qd[1]):x} {k}\n')
for i in range(NFN):
    P, k, Q = rand_inst(E0)
    lines_nat.append(f'{fi(P[0]):x} {fi(P[1]):x} {fi(Q[0]):x} {fi(Q[1]):x} {k}\n')
# the sweep's stored transported pairs for this label (for solving with my rho)
lines_sw = []
for iid, r in sorted(mine.items()):
    lines_sw.append(f"{r['P_E0'][0]:x} {r['P_E0'][1]:x} {r['Q_E0'][0]:x} {r['Q_E0'][1]:x} {r['k']}\n")
os.makedirs(os.path.join(HERE, 'inst'), exist_ok=True)
open(os.path.join(HERE, 'inst', f'T59_{LAB}_fresh_transport.txt'), 'w').writelines(lines_tr)
open(os.path.join(HERE, 'inst', f'T59_{LAB}_sweep_transport.txt'), 'w').writelines(lines_sw)
if NFN:
    open(os.path.join(HERE, 'inst', 'T59_fresh_native.txt'), 'w').writelines(lines_nat)
log['fresh_transport_written'] = len(lines_tr); log['fresh_native_written'] = len(lines_nat)
log['secs'] = round(time.time() - T0, 1)
json.dump(log, open(os.path.join(HERE, f'verify_T59_{LAB}.json'), 'w'), indent=1)
say('done', log)
