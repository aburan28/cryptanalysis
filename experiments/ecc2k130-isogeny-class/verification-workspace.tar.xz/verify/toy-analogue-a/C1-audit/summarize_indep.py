"""Collect indep_*.json and form floor_neg / E0_negtau ratios (independent rho), next to the
sweep's own numbers (recompute.json)."""
import json, math, os, glob

OUT = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C1-audit'
rec = json.load(open(os.path.join(OUT, 'recompute.json')))['per_family']
res = {}
for fam in ('T19', 'T23', 'T59', 'T109'):
    e = os.path.join(OUT, f'indep_{fam}_E0_negtau.json')
    if not os.path.exists(e):
        continue
    E = json.load(open(e))
    for tag in ('floor_neg', 'floor_neg_fresh'):
        f = os.path.join(OUT, f'indep_{fam}_{tag}.json')
        if not os.path.exists(f):
            continue
        F = json.load(open(f))
        r = F['mean_T'] / E['mean_T']
        se = r * math.sqrt((F['sem_T'] / F['mean_T']) ** 2 + (E['sem_T'] / E['mean_T']) ** 2)
        n = F['class_size'] and json.load(open(e))['class_size'] // 2
        exact_ratio = F['theory_exact'] / E['theory_exact']
        res[f'{fam}:{tag}'] = dict(n=n, floor_instances=F['n_instances'], E0_instances=E['n_instances'],
                                   floor_all_ok=F['all_ok'], E0_all_ok=E['all_ok'],
                                   floor_mean=F['mean_T'], floor_sem=F['sem_T'], floor_over_exact=F['mean_over_exact'],
                                   E0_mean=E['mean_T'], E0_sem=E['sem_T'], E0_over_exact=E['mean_over_exact'],
                                   ratio=r, se=se, sqrt_n=math.sqrt(n), ratio_over_sqrt_n=r / math.sqrt(n),
                                   z_vs_sqrt_n=(r - math.sqrt(n)) / se, exact_finite_M_ratio=exact_ratio,
                                   sweep_ratio=rec[fam]['ratio'] if fam in rec else None,
                                   sweep_se=rec[fam]['se'] if fam in rec else None,
                                   fruitless_per_step_floor=F['fruitless_total'] / (F['mean_steps'] * F['n_instances']))
        print(fam, tag, {k: (round(v, 4) if isinstance(v, float) else v) for k, v in res[f'{fam}:{tag}'].items()})
keys = [k for k in res if k.endswith(':floor_neg')]
if keys:
    w = [1 / (res[k]['se'] / res[k]['sqrt_n']) ** 2 for k in keys]
    x = [res[k]['ratio_over_sqrt_n'] for k in keys]
    m = sum(a * b for a, b in zip(w, x)) / sum(w)
    res['pooled_ratio_over_sqrt_n'] = dict(families=keys, value=m, se=1 / math.sqrt(sum(w)))
    print('pooled', res['pooled_ratio_over_sqrt_n'])
json.dump(res, open(os.path.join(OUT, 'indep_summary.json'), 'w'), indent=1)
