"""Check indep_rho.py's affine arithmetic against Sage's EllipticCurve on random points,
and check the floor curves used by the sweep: #E(F_q) (Sage/PARI), j not in F_2, j != 0, 1."""
import sys, json, random
sys.path.insert(0, '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C1-audit')
import indep_rho as I
from sage.all import EllipticCurve
out = {}
for fam in ('T19', 'T23', 'T59', 'T109'):
    I.init(fam, 'x')
    K = I.G['K']
    fj = json.load(open(f'{I.WORK}/data/{fam}_family.json'))
    meta, curves = fj['meta'], fj['curves']
    inst = json.load(open(f'{I.WORK}/raw/{fam}/instances.json'))
    used = sorted(set(v['curve'] for v in inst.values()))
    res = {}
    for lab in used:
        b = K.from_integer(curves[lab]['b_int'])
        E = EllipticCurve(K, [1, meta['a'], 0, 0, b])
        j = E.j_invariant()
        # arithmetic check
        bad = 0
        for _ in range(50):
            P, Q = E.random_point(), E.random_point()
            if P == 0 or Q == 0: continue
            p, q = (P[0], P[1]), (Q[0], Q[1])
            S = I.add(p, q); D = I.dbl(p)
            SS, DD = P + Q, 2 * P
            bad += (S is None) != (SS == 0) or (S is not None and S != (SS[0], SS[1]))
            bad += (D is None) != (DD == 0) or (D is not None and D != (DD[0], DD[1]))
            Nn = I.neg(p); bad += Nn != ((-P)[0], (-P)[1])
        order = int(E.order()) if meta['n'] <= 64 else None
        res[lab] = dict(arith_mismatches=bad, j_int=int(j.to_integer()), j_in_F2=bool(j ** 2 == j), j_is_0=bool(j == 0),
                        j_is_1=bool(j == 1), order=order, order_matches_card=(order == int(meta['card'])) if order else None,
                        j_minpoly_degree=int(j.minpoly().degree()), b_is_1=bool(b == 1))
        print(fam, lab, res[lab], flush=True)
    out[fam] = res
json.dump(out, open('/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C1-audit/arith_check.json', 'w'), indent=1)
