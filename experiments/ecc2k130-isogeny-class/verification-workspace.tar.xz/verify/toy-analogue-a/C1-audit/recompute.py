"""C1 audit, part 1: recompute (i)/(ii) from the raw TSVs with plain Python (no numpy/scipy,
no reuse of analyze.py).  Also: integrity flags, merge_ok, per-curve homogeneity, pooled
ratio/sqrt(n), weighted log-log slope, with and without T11, and a bootstrap CI.

usage: python3 recompute.py
"""
import csv, json, math, os, random

WORK = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
OUT = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C1-audit'
FAMS = ['T11', 'T19', 'T23', 'T59', 'T109']


def rows(fam, cfg):
    with open(os.path.join(WORK, 'raw', fam, 'out', cfg + '.tsv')) as fh:
        return list(csv.DictReader(fh, delimiter='\t'))


def ms(x):
    n = len(x)
    m = sum(x) / n
    v = sum((u - m) ** 2 for u in x) / (n - 1)
    return m, math.sqrt(v / n), n


res = {}
for fam in FAMS:
    meta = json.load(open(os.path.join(WORK, 'data', f'{fam}_family.json')))['meta']
    n, N = meta['n'], int(meta['N'])
    cfgs = sorted(f[:-4] for f in os.listdir(os.path.join(WORK, 'raw', fam, 'out')) if f.endswith('.tsv'))
    # number of instance lines in each input file vs rows in output
    integrity = {}
    floor_neg, e0_negtau, e0_neg = [], [], []
    floor_neg_it, e0_negtau_it = [], []
    percurve = {}
    for c in cfgs:
        R = rows(fam, c)
        ninst = sum(1 for L in open(os.path.join(WORK, 'raw', fam, 'inputs', c + '.txt')) if L.startswith('inst '))
        ids = [r['id'] for r in R]
        integrity[c] = dict(rows=len(R), inputs=ninst, unique_ids=len(set(ids)),
                            verified=sum(r['verified'] == '1' for r in R), match=sum(r['match'] == '1' for r in R),
                            merge_ok=sum(r['merge_ok'] == '1' for r in R),
                            selfsolve=sum(int(r['selfsolve']) for r in R),
                            abandoned=sum(int(r['abandoned']) for r in R),
                            merge_gt_steps=sum(int(r['merge_steps']) > int(r['steps']) for r in R))
        curve, mode = c.split('__')
        mv = [int(r['merge_steps']) for r in R]
        iv = [int(r['iters']) for r in R]
        if mode == 'neg' and curve != 'E0':
            floor_neg += mv; floor_neg_it += iv
            percurve[c] = ms(mv)
        if c == 'E0__negtau':
            e0_negtau += mv; e0_negtau_it += iv
        if c == 'E0__neg':
            e0_neg += mv
    a, sa, na = ms(floor_neg)
    b, sb, nb = ms(e0_negtau)
    r = a / b
    se = r * math.sqrt((sa / a) ** 2 + (sb / b) ** 2)
    ai, sai, _ = ms(floor_neg_it)
    bi, sbi, _ = ms(e0_negtau_it)
    # bootstrap of the ratio of means (2000 resamples, fixed seed)
    rng = random.Random(20260924)
    bs = []
    for _ in range(2000):
        xa = [floor_neg[rng.randrange(na)] for _ in range(na)]
        xb = [e0_negtau[rng.randrange(nb)] for _ in range(nb)]
        bs.append((sum(xa) / na) / (sum(xb) / nb))
    bs.sort()
    th_floor = math.sqrt(math.pi * N / 4)
    th_e0 = math.sqrt(math.pi * N / (4 * n))
    e0n = ms(e0_neg)
    res[fam] = dict(n=n, N=N, n_floor=na, n_E0=nb, mean_floor_neg=a, sem_floor_neg=sa, mean_E0_negtau=b, sem_E0_negtau=sb,
                    ratio=r, se=se, sqrt_n=math.sqrt(n), ratio_over_sqrt_n=r / math.sqrt(n), se_over_sqrt_n=se / math.sqrt(n),
                    z_vs_sqrt_n=(r - math.sqrt(n)) / se,
                    ratio_iters=ai / bi, ratio_iters_se=(ai / bi) * math.sqrt((sai / ai) ** 2 + (sbi / bi) ** 2),
                    bootstrap_ci95=[bs[50], bs[1949]],
                    floor_over_theory=a / th_floor, E0negtau_over_theory=b / th_e0,
                    E0neg_mean=e0n[0], E0neg_sem=e0n[1], E0neg_over_floorneg=e0n[0] / a,
                    percurve_floor_neg={k: dict(mean=v[0], sem=v[1], n=v[2], over_theory=v[0] / th_floor) for k, v in percurve.items()},
                    integrity=integrity)


def pool(fams):
    w = [1 / res[f]['se_over_sqrt_n'] ** 2 for f in fams]
    x = [res[f]['ratio_over_sqrt_n'] for f in fams]
    m = sum(wi * xi for wi, xi in zip(w, x)) / sum(w)
    chi2 = sum(wi * (xi - m) ** 2 for wi, xi in zip(w, x))
    # weighted least squares of log(ratio) on log(n), sigma(log r) = se/r
    X = [math.log(res[f]['n']) for f in fams]
    Y = [math.log(res[f]['ratio']) for f in fams]
    W = [(res[f]['ratio'] / res[f]['se']) ** 2 for f in fams]
    Sw = sum(W); Sx = sum(wi * xi for wi, xi in zip(W, X)); Sy = sum(wi * yi for wi, yi in zip(W, Y))
    Sxx = sum(wi * xi * xi for wi, xi in zip(W, X)); Sxy = sum(wi * xi * yi for wi, xi, yi in zip(W, X, Y))
    det = Sw * Sxx - Sx * Sx
    slope = (Sw * Sxy - Sx * Sy) / det
    icpt = (Sxx * Sy - Sx * Sxy) / det
    slope_se = math.sqrt(Sw / det)
    chi2_fit = sum(wi * (yi - icpt - slope * xi) ** 2 for wi, xi, yi in zip(W, X, Y))
    return dict(families=fams, pooled_ratio_over_sqrt_n=m, pooled_se=1 / math.sqrt(sum(w)), chi2_homog=chi2, dof=len(fams) - 1,
                loglog_slope=slope, loglog_slope_se=slope_se, loglog_intercept=icpt, loglog_chi2=chi2_fit)


out = dict(per_family=res, pooled_T19_T109=pool(['T19', 'T23', 'T59', 'T109']), pooled_all_incl_T11=pool(FAMS))
json.dump(out, open(os.path.join(OUT, 'recompute.json'), 'w'), indent=1)
for f in FAMS:
    r = res[f]
    print(f"{f}: floor n={r['n_floor']} mean={r['mean_floor_neg']:.1f}+-{r['sem_floor_neg']:.1f}  E0negtau n={r['n_E0']} mean={r['mean_E0_negtau']:.1f}+-{r['sem_E0_negtau']:.1f}"
          f"  ratio={r['ratio']:.3f}+-{r['se']:.3f} sqrt(n)={r['sqrt_n']:.3f} r/sqrt(n)={r['ratio_over_sqrt_n']:.4f} z={r['z_vs_sqrt_n']:.2f}"
          f"  boot95=[{r['bootstrap_ci95'][0]:.3f},{r['bootstrap_ci95'][1]:.3f}]  iters ratio={r['ratio_iters']:.3f}+-{r['ratio_iters_se']:.3f}"
          f"  floor/th={r['floor_over_theory']:.4f} E0tau/th={r['E0negtau_over_theory']:.4f} E0neg/floorneg={r['E0neg_over_floorneg']:.4f}")
    bad = {k: v for k, v in r['integrity'].items() if not (v['rows'] == v['inputs'] == v['unique_ids'] == v['verified'] == v['match'])}
    mo = {k: (v['merge_ok'], v['rows'], v['selfsolve'], v['abandoned'], v['merge_gt_steps']) for k, v in r['integrity'].items()}
    print('   integrity problems:', bad)
    print('   (merge_ok, rows, selfsolve, abandoned, merge>steps):', mo)
    print('   per-curve floor neg / theory:', {k: round(v['over_theory'], 4) for k, v in r['percurve_floor_neg'].items()})
print('pooled T19..T109:', out['pooled_T19_T109'])
print('pooled incl T11:', out['pooled_all_incl_T11'])
