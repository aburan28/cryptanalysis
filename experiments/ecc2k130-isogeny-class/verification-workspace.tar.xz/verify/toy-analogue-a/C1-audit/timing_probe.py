import time
from sage.all import GF, PolynomialRing, EllipticCurve
R = PolynomialRing(GF(2), 'z'); z = R.gen()
for n, mod in ((19, z**19+z**5+z**2+z+1), (23, z**23+z**5+1), (59, z**59+z**6+z**5+z**4+z**3+z+1)):
    K = GF(2**n, 'z', modulus=mod)
    a = K.random_element(); b = K.random_element()
    t = time.time()
    for _ in range(100000): c = a*b
    tm = (time.time()-t)/1e5
    t = time.time()
    for _ in range(100000): c = ~a
    ti = (time.time()-t)/1e5
    t = time.time()
    for _ in range(100000): c = a.to_integer()
    tt = (time.time()-t)/1e5
    t = time.time()
    for _ in range(100000): c = a+b
    ta = (time.time()-t)/1e5
    t = time.time()
    for _ in range(100000): c = a**2
    ts = (time.time()-t)/1e5
    print(n, type(K), 'mul %.2fus inv %.2fus toint %.2fus add %.2fus sq %.2fus' % (tm*1e6, ti*1e6, tt*1e6, ta*1e6, ts*1e6))
