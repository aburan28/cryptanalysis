"""Real ECC2K-130 floor curves: scalars of the endomorphisms psi_k = dual(phi) o tau^k o phi
(phi: floor -> E0 of degree 263) on the order-N subgroup are 263*s^k; report their
multiplicative orders mod N (an equivalence class built from psi_k has that size)."""
import sys, json
sys.path.insert(0, '/Volumes/SSD990/ecdlp-hardness-work/ground_truth')
import ecc2k
from sage.all import Integer, Mod, factor
N = Integer(ecc2k.N); s = Integer(ecc2k.TAU_EIGEN)
F = factor(N - 1)
out = dict(N_minus_1_factorization=str(F))
o263 = Mod(263, N).multiplicative_order()
out['ord_263_mod_N'] = str(o263); out['log2_ord_263'] = float(Integer(o263).nbits())
mins = []
for k in range(131):
    o = Mod(263 * s**k, N).multiplicative_order()
    mins.append(int(o))
out['min_ord_263_s^k_over_k'] = str(min(mins)); out['log2_min'] = float(Integer(min(mins)).nbits())
out['ord_s'] = str(Mod(s, N).multiplicative_order())
print(out)
json.dump(out, open('/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C1-audit/endo_orders.json', 'w'), indent=1)
