"""canon() must be a class function: same output (and consistent multiplier) for every member."""
import sys, json, random
sys.path.insert(0, '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C1-audit')
import indep_rho as I
from sage.all import EllipticCurve, GF, PolynomialRing
for fam in ('T19', 'T23'):
    I.init(fam, 'x'); K = I.G['K']; meta = I.G['meta']; N = I.G['N']; n = I.G['n']
    E = EllipticCurve(K, [1, meta['a'], 0, 0, 1]); h = int(meta['card']) // N
    P = h * E.random_point(); p = (P[0], P[1])
    mu = 1 if meta['a'] == 1 else -1
    X = PolynomialRing(GF(N), 'X').gen()
    s = [int(r) for r in (X**2 - mu*X + 2).roots(multiplicities=False) if I.smul(p, int(r)) == (p[0]**2, p[1]**2)][0]
    I.G['SPOW'] = [pow(s, i, N) for i in range(n)]
    bad = 0
    for mode_tau in (True, False):
        I.G['tau'] = mode_tau
        for _ in range(200):
            c = random.randrange(1, N)
            R = I.smul(p, c)
            ref, mref = I.canon(R)
            mem = [R, I.neg(R)] if not mode_tau else []
            if mode_tau:
                x, y = R
                for i in range(n):
                    mem += [(x, y), I.neg((x, y))]
                    x, y = x*x, y*y
            for M_ in mem:
                cm, mm = I.canon(M_)
                bad += cm != ref
            # multiplier consistency: canon(R) == mref * R
            bad += I.smul(R, mref) != ref
    print(fam, 's=', s, 'meta s=', meta['tau_eigen_s'], 'bad=', bad)
