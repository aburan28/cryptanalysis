"""C1 audit, part 2: an independent Pollard-rho birthday-time measurement (Sage/Python).

Nothing from the sweep's rho.c / analyze.py is reused.  Differences from the sweep's solver:
  * field arithmetic: Sage/NTL GF(2^n) with the modulus string from data/<F>_family.json
    (the sweep uses its own NEON carry-less C arithmetic);
  * class representative: chosen by a salted murmur3-fmix64 hash of x (resp. y), NOT by the
    integer order of x^(2^i) / y (the sweep's rule);
  * walk: r-adding walk with r = 256 and a different index hash, NO Wiener-Zuccherato
    look-ahead, NO doubling escape, NO distinguished points;
  * collision detection: every generated class is stored in a dict (exact birthday time);
    a repeat with identical b is a fruitless cycle -> the walk is abandoned and a fresh
    random walk is started (the repeated point is not counted as a new class);
  * tau eigenvalue s: recomputed here from X^2 - mu X + 2 mod N and checked on every P.
Birthday time T = (#distinct classes generated before the first useful repeat) + 1, which for
uniform sampling from M classes has E[T] = sum_k prod_{i<k} (1 - i/M) ~ sqrt(pi M / 2) + 2/3.

usage: sage -python indep_rho.py <FAM> <mode:floor_neg|E0_negtau|E0_neg> <max_instances> <workers> [fresh]
  'fresh' = plant NEW random instances with Sage instead of reading raw/<F>/instances.json.
writes indep_<FAM>_<mode>.json
"""
import sys, os, json, math, time, random
from multiprocessing import Pool

WORK = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
OUT = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C1-audit'
M64 = (1 << 64) - 1
SALT_X, SALT_Y, SALT_J = 0x5DEECE66D1234567, 0x2545F4914F6CDD1D, 0x9E3779B185EBCA87
R_ADD = 256

G = {}   # per-process globals


def fmix(k):
    k &= M64
    k ^= k >> 33
    k = (k * 0xff51afd7ed558ccd) & M64
    k ^= k >> 33
    k = (k * 0xc4ceb9fe1a85ec53) & M64
    k ^= k >> 33
    return k


def init(fam, mode):
    from sage.all import GF, PolynomialRing, Integer
    meta = json.load(open(os.path.join(WORK, 'data', f'{fam}_family.json')))['meta']
    R = PolynomialRing(GF(2), 'x')
    mod = R(meta['modulus'])
    assert mod.is_irreducible() and mod.degree() == meta['n']
    K = GF(2 ** meta['n'], 'z', modulus=mod)
    G.update(K=K, n=meta['n'], N=int(meta['N']), A2=K(meta['a']), mode=mode, meta=meta)


def fe(v):
    K = G['K']
    return K.from_integer(int(v))


def add(P, Q):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y1 == y2:
            return dbl(P)
        return None
    lam = (y1 + y2) / (x1 + x2)
    x3 = lam * lam + lam + x1 + x2 + G['A2']
    return (x3, lam * (x1 + x3) + x3 + y1)


def dbl(P):
    if P is None:
        return None
    x1, y1 = P
    if x1 == 0:
        return None
    lam = x1 + y1 / x1
    x3 = lam * lam + lam + G['A2']
    return (x3, x1 * x1 + (lam + 1) * x3)


def neg(P):
    return (P[0], P[0] + P[1])


def smul(P, k):
    R = None
    for bit in bin(k)[2:]:
        R = dbl(R)
        if bit == '1':
            R = add(R, P)
    return R


def canon(P):
    """returns (canonical member, multiplier m) with canonical = m * P."""
    N = G['N']
    x, y = P
    m = 1
    if G['tau']:
        best = None
        xi, yi = x, y
        for i in range(G['n']):
            h = fmix(xi.to_integer() ^ SALT_X)
            if best is None or h < best[0]:
                best = (h, i, xi, yi)
            xi = xi * xi
            yi = yi * yi
        _, i, x, y = best
        m = G['SPOW'][i]
    y2 = x + y
    if fmix(y2.to_integer() ^ SALT_Y) < fmix(y.to_integer() ^ SALT_Y):
        y = y2
        m = (N - m) % N
    return (x, y), m


def solve(task):
    iid, b_int, Pxy, Qxy, k_true, seed = task
    N = G['N']
    K = G['K']
    b = fe(b_int)
    P = (fe(Pxy[0]), fe(Pxy[1]))
    Q = (fe(Qxy[0]), fe(Qxy[1]))
    A2 = G['A2']
    for X, Y in (P, Q):
        assert Y * Y + X * Y == X ** 3 + A2 * X * X + b, 'point not on curve'
    if G['tau']:
        assert b == 1
        # tau eigenvalue from X^2 - mu X + 2 = 0 mod N, mu = (-1)^(1-a)
        mu = 1 if G['meta']['a'] == 1 else -1
        from sage.all import GF as _GF, PolynomialRing as _PR
        Rn = _PR(_GF(N), 'X')
        Xn = Rn.gen()
        roots = [int(r) for r in (Xn ** 2 - mu * Xn + 2).roots(multiplicities=False)]
        tP = (P[0] * P[0], P[1] * P[1])
        s = [r for r in roots if smul(P, r) == tP]
        assert len(s) == 1
        s = s[0]
        G['SPOW'] = [pow(s, i, N) for i in range(G['n'])]
        # class size check: the 2n members +-tau^i P are distinct
        mem = set()
        xi, yi = P
        for i in range(G['n']):
            mem.add((xi.to_integer(), yi.to_integer()))
            mem.add((xi.to_integer(), (xi + yi).to_integer()))
            xi, yi = xi * xi, yi * yi
        assert len(mem) == 2 * G['n']
        assert (xi, yi) == P  # tau^n = 1 on E(F_q)
    rng = random.Random(seed)
    nb = N.bit_length()
    TP = [P]
    TQ = [Q]
    for _ in range(nb):
        TP.append(dbl(TP[-1]))
        TQ.append(dbl(TQ[-1]))
    assert TP[0] is not None

    def comb(a, bb):
        R = None
        for i in range(nb):
            if (a >> i) & 1:
                R = add(R, TP[i])
            if (bb >> i) & 1:
                R = add(R, TQ[i])
        return R
    assert smul(P, N) is None, 'P order != N'
    assert comb(k_true % N, 0) == Q, 'Q != kP'
    RA, RB, RT = [], [], []
    while len(RT) < R_ADD:
        a, bb = rng.randrange(N), rng.randrange(N)
        T = comb(a, bb)
        if T is not None:
            RA.append(a)
            RB.append(bb)
            RT.append(T)
    seen = {}
    distinct = 0
    steps = 0
    fruitless = 0
    walks = 0
    inf_hits = 0
    k_found = None
    t0 = time.process_time()
    while k_found is None:
        walks += 1
        a, bb = rng.randrange(1, N), rng.randrange(1, N)
        C = comb(a, bb)
        if C is None:
            continue
        C, m = canon(C)
        a, bb = a * m % N, bb * m % N
        while True:
            key = (C[0].to_integer(), C[1].to_integer())
            old = seen.get(key)
            if old is not None:
                if old[1] != bb:
                    k_found = (a - old[0]) * pow(old[1] - bb, -1, N) % N
                    distinct += 1       # the repeating point itself
                else:
                    fruitless += 1
                break
            seen[key] = (a, bb)
            distinct += 1
            j = fmix(key[0] ^ SALT_J) % R_ADD
            C = add(C, RT[j])
            steps += 1
            if C is None:
                inf_hits += 1
                break
            a, bb = (a + RA[j]) % N, (bb + RB[j]) % N
            C, m = canon(C)
            a, bb = a * m % N, bb * m % N
    cpu = time.process_time() - t0
    ok = (k_found == k_true % N)
    return dict(id=iid, T=distinct, steps=steps, walks=walks, fruitless=fruitless, inf=inf_hits, ok=ok, cpu=cpu)


def exact_ET(M):
    if M > 1e7:
        return math.sqrt(math.pi * M / 2) + 2.0 / 3
    tot, p, k = 0.0, 1.0, 0
    while p > 1e-18:
        tot += p
        p *= (1 - k / M)
        k += 1
    return tot


def worker_init(fam, mode):
    init(fam, mode)
    G['tau'] = (mode == 'E0_negtau')


if __name__ == '__main__':
    fam, mode, maxi, workers = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
    fresh = 'fresh' in sys.argv[5:]
    fj = json.load(open(os.path.join(WORK, 'data', f'{fam}_family.json')))
    meta, curves = fj['meta'], fj['curves']
    N, n = int(meta['N']), meta['n']
    tasks = []
    if not fresh:
        inst = json.load(open(os.path.join(WORK, 'raw', fam, 'instances.json')))
        sel = [(k, v) for k, v in inst.items() if (v['curve'] == 'E0') == mode.startswith('E0')]
        # interleave floor curves so that a truncated run still samples all of them
        if not mode.startswith('E0'):
            bycurve = {}
            for k, v in sel:
                bycurve.setdefault(v['curve'], []).append((k, v))
            sel = [x for tup in zip(*bycurve.values()) for x in tup]
        sel = sel[:maxi]
        for i, (k, v) in enumerate(sel):
            tasks.append((k, curves[v['curve']]['b_int'], v['P'], v['Q'], v['k'], 7919 * i + 1))
    else:
        from sage.all import EllipticCurve, set_random_seed, randint
        init(fam, mode)
        set_random_seed(424242 + n)
        K = G['K']
        labs = ['E0'] if mode.startswith('E0') else [l for l in curves if l != 'E0']
        rr = random.Random(99 + n)
        for i in range(maxi):
            lab = labs[i % len(labs)] if mode.startswith('E0') else rr.choice(labs)
            bint = curves[lab]['b_int']
            E = EllipticCurve(K, [1, meta['a'], 0, 0, K.from_integer(bint)])
            h = int(meta['card']) // N
            while True:
                Pp = h * E.random_point()
                if Pp != 0:
                    break
            kk = int(randint(1, N - 1))
            Qp = kk * Pp
            tasks.append((f'{fam}:{lab}:fresh{i:04d}', bint, [int(Pp[0].to_integer()), int(Pp[1].to_integer())],
                          [int(Qp[0].to_integer()), int(Qp[1].to_integer())], kk, 104729 * i + 3))
    t0 = time.time()
    with Pool(workers, initializer=worker_init, initargs=(fam, mode)) as pool:
        res = pool.map(solve, tasks, chunksize=max(1, len(tasks) // (8 * workers)))
    Ts = [r['T'] for r in res]
    cnt = len(Ts)
    mean = sum(Ts) / cnt
    sem = math.sqrt(sum((x - mean) ** 2 for x in Ts) / (cnt - 1) / cnt)
    c = 2 * n if mode == 'E0_negtau' else 2
    M = (N - 1) / c + 1
    out = dict(family=fam, mode=mode, fresh=fresh, n_instances=cnt, all_ok=all(r['ok'] for r in res),
               n_ok=sum(r['ok'] for r in res), mean_T=mean, sem_T=sem, class_size=c, M=M,
               theory_sqrt=math.sqrt(math.pi * N / (2 * c)), theory_exact=exact_ET(M),
               mean_over_exact=mean / exact_ET(M), mean_steps=sum(r['steps'] for r in res) / cnt,
               fruitless_total=sum(r['fruitless'] for r in res), walks_total=sum(r['walks'] for r in res),
               inf_total=sum(r['inf'] for r in res), wall_s=round(time.time() - t0, 1),
               cpu_s=round(sum(r['cpu'] for r in res), 1), r_add=R_ADD, rows=res)
    tag = f'indep_{fam}_{mode}' + ('_fresh' if fresh else '')
    json.dump(out, open(os.path.join(OUT, tag + '.json'), 'w'))
    print(tag, {k: v for k, v in out.items() if k != 'rows'}, flush=True)
