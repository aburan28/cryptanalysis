#!/usr/bin/env python3
"""Summarize the birthday_rho runs (own code).  For each family & walk:
  floor_neg      : pooled over all floor curves, mode neg
  E0_negtau      : E0 with negation + tau classes
  E0_neg         : control (E0 with negation only)
ratio floor_neg / E0_negtau vs sqrt(n) and vs the exact finite-M expectation."""
import csv, glob, json, math, os, random

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'


def exact_ET(M):
    if M > 5e7:
        return math.sqrt(math.pi * M / 2) + 2.0 / 3
    tot, p, k = 0.0, 1.0, 0
    while p > 1e-18:
        tot += p; p *= (1 - k / M); k += 1
    return tot


def ms(v):
    m = sum(v) / len(v)
    return m, math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1) / len(v))


def ks_exp(z):
    # one-sample KS statistic of z against Exp(1), with asymptotic p-value
    z = sorted(z); n = len(z); D = 0.0
    for i, x in enumerate(z):
        F = 1 - math.exp(-x)
        D = max(D, (i + 1) / n - F, F - i / n)
    lam = (math.sqrt(n) + 0.12 + 0.11 / math.sqrt(n)) * D
    p = 2 * sum((-1) ** (j - 1) * math.exp(-2 * j * j * lam * lam) for j in range(1, 101))
    return D, max(0.0, min(1.0, p))


res = {}
for d in sorted(glob.glob(f'{HERE}/runs/*_*')):
    F, walk = os.path.basename(d).split('_', 1)
    meta = json.load(open(f'{ROOT}/data/{F}_family.json'))['meta']
    n, N = int(meta['n']), int(meta['N'])
    groups = {}
    bad = 0; oncurve_bad = 0; tau_bad = 0; restarts = 0; degen = 0
    for f in sorted(glob.glob(f'{d}/*.tsv')):
        cn, rest = os.path.basename(f).split('__'); mode = rest.split('.')[0]
        g = 'E0_' + mode if cn == 'E0' else 'floor_' + mode
        with open(f) as fh:
            for r in csv.DictReader(fh, delimiter='\t'):
                if r['ok'] != '1': bad += 1
                if r['on_curve'] != '1': oncurve_bad += 1
                if r['tau_ok'] == '0': tau_bad += 1
                restarts += int(r['restarts']); degen += int(r['degenerate'])
                groups.setdefault(g, {}).setdefault(cn, []).append(int(r['T']))
    out = dict(n=n, N=N, not_ok=bad, oncurve_or_order_fail=oncurve_bad, tau_check_fail=tau_bad,
               restarts=restarts, degenerate=degen, groups={})
    for g, per in groups.items():
        allv = [x for v in per.values() for x in v]
        c = 2 * n if g.endswith('negtau') else 2
        M = (N - 1) / c + 1
        m, s = ms(allv)
        D, p = ks_exp([t * t / (2 * M) for t in allv])
        out['groups'][g] = dict(count=len(allv), per_curve={k: dict(count=len(v), mean=ms(v)[0]) for k, v in per.items()},
                                mean=m, sem=s, exact_ET=exact_ET(M), mean_over_exact=m / exact_ET(M),
                                ks_T2_over_2M_vs_Exp1=dict(D=D, p=p))
    G = out['groups']
    if 'floor_neg' in G and 'E0_negtau' in G:
        a, b = G['floor_neg'], G['E0_negtau']
        r = a['mean'] / b['mean']
        se = r * math.sqrt((a['sem'] / a['mean']) ** 2 + (b['sem'] / b['mean']) ** 2)
        out['ratio_floor_neg_over_E0_negtau'] = dict(ratio=r, se=se, sqrt_n=math.sqrt(n),
                                                     exact_finite_M=a['exact_ET'] / b['exact_ET'],
                                                     z_vs_sqrt_n=(r - math.sqrt(n)) / se,
                                                     z_vs_exact=(r - a['exact_ET'] / b['exact_ET']) / se)
    if 'floor_neg' in G and 'E0_neg' in G:
        a, b = G['floor_neg'], G['E0_neg']
        r = a['mean'] / b['mean']
        se = r * math.sqrt((a['sem'] / a['mean']) ** 2 + (b['sem'] / b['mean']) ** 2)
        out['control_floor_neg_over_E0_neg'] = dict(ratio=r, se=se)
    res[f'{F}_{walk}'] = out

# pooled ratio/sqrt(n) and log-log slope per walk
for walk in ('randfunc', 'dbladd'):
    ks = [k for k in res if k.endswith('_' + walk) and 'ratio_floor_neg_over_E0_negtau' in res[k]]
    if not ks: continue
    vals = [(res[k]['ratio_floor_neg_over_E0_negtau']['ratio'] / math.sqrt(res[k]['n']),
             res[k]['ratio_floor_neg_over_E0_negtau']['se'] / math.sqrt(res[k]['n']), res[k]['n'],
             res[k]['ratio_floor_neg_over_E0_negtau']['ratio'], res[k]['ratio_floor_neg_over_E0_negtau']['se']) for k in ks]
    W = sum(1 / v[1] ** 2 for v in vals)
    pooled = sum(v[0] / v[1] ** 2 for v in vals) / W
    entry = dict(families=ks, pooled_ratio_over_sqrt_n=pooled, pooled_se=math.sqrt(1 / W))
    if len(vals) >= 2:
        xs = [math.log(v[2]) for v in vals]; ys = [math.log(v[3]) for v in vals]; ws = [(v[3] / v[4]) ** 2 for v in vals]
        Wt = sum(ws); xb = sum(w * x for w, x in zip(ws, xs)) / Wt; yb = sum(w * y for w, y in zip(ws, ys)) / Wt
        Sxx = sum(w * (x - xb) ** 2 for w, x in zip(ws, xs)); Sxy = sum(w * (x - xb) * (y - yb) for w, x, y in zip(ws, xs, ys))
        entry.update(loglog_alpha=Sxy / Sxx, loglog_alpha_se=math.sqrt(1 / Sxx))
    res['pooled_' + walk] = entry

json.dump(res, open(f'{HERE}/analyze_mine.json', 'w'), indent=1)
for k, v in res.items():
    if k.startswith('pooled'):
        print(k, json.dumps(v)); continue
    print(f"== {k}: not_ok={v['not_ok']} oncurve/order_fail={v['oncurve_or_order_fail']} tau_fail={v['tau_check_fail']} restarts={v['restarts']} degenerate={v['degenerate']}")
    for g, s in v['groups'].items():
        print(f"   {g:10s} count={s['count']:5d} mean_T={s['mean']:.2f}±{s['sem']:.2f} exact_E[T]={s['exact_ET']:.2f} mean/exact={s['mean_over_exact']:.4f} KS_D={s['ks_T2_over_2M_vs_Exp1']['D']:.4f} p={s['ks_T2_over_2M_vs_Exp1']['p']:.3f}")
    if 'ratio_floor_neg_over_E0_negtau' in v:
        r = v['ratio_floor_neg_over_E0_negtau']
        print(f"   ratio floor_neg/E0_negtau = {r['ratio']:.4f} ± {r['se']:.4f}; sqrt(n)={r['sqrt_n']:.4f} (z={r['z_vs_sqrt_n']:+.2f}); exact finite-M={r['exact_finite_M']:.4f} (z={r['z_vs_exact']:+.2f})")
    if 'control_floor_neg_over_E0_neg' in v:
        r = v['control_floor_neg_over_E0_neg']
        print(f"   control floor_neg/E0_neg = {r['ratio']:.4f} ± {r['se']:.4f}")
