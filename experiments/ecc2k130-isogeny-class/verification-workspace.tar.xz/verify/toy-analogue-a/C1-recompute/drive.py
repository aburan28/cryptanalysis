#!/usr/bin/env python3
"""Driver: build inputs for birthday_rho from the sweep's instances.json/family.json and run
chunks in parallel.  usage: drive.py FAMILY WALK WBITS JOBS CHUNK [curve:mode:limit ...]
e.g. drive.py T19 randfunc 6 8 250 E0:negtau:2000 E0:neg:2000 floor:neg:1000
'floor' expands to every non-E0 curve in instances.json (limit = per curve)."""
import json, os, subprocess, sys, concurrent.futures as cf

ROOT = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
HERE = os.path.dirname(os.path.abspath(__file__))
F, WALK, WBITS, JOBS, CHUNK = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
specs = sys.argv[6:]
fam = json.load(open(f'{ROOT}/data/{F}_family.json'))
meta, curves = fam['meta'], fam['curves']
inst = json.load(open(f'{ROOT}/raw/{F}/instances.json'))
n = int(meta['n']); N = int(meta['N']); s = int(meta['tau_eigen_s'])
mod = meta['modulus']            # e.g. 'x^19 + x^5 + x^2 + x + 1'
terms = [t.strip() for t in mod.split('+')]
tail = 0
for t in terms:
    if t == '1': tail |= 1
    elif t == 'x': tail |= 2
    else:
        e = int(t.split('^')[1])
        if e != n: tail |= 1 << e
assert tail == int(meta['modulus_tail']), (tail, meta['modulus_tail'])
outdir = f'{HERE}/runs/{F}_{WALK}'
os.makedirs(outdir, exist_ok=True)
jobs = []
for sp in specs:
    cname, mode, lim = sp.split(':'); lim = int(lim)
    names = sorted({v['curve'] for v in inst.values() if v['curve'] != 'E0'}) if cname == 'floor' else [cname]
    for cn in names:
        c = curves[cn]
        a2 = int(c['a2']); b = int(c['b_int'])
        if mode == 'negtau':
            assert cn == 'E0' and b == 1 and a2 in (0, 1)
        ids = sorted(k for k, v in inst.items() if v['curve'] == cn)[:lim]
        for ci in range(0, len(ids), CHUNK):
            part = ids[ci:ci + CHUNK]
            tag = f'{cn}__{mode}.{ci:05d}'
            hdr = f'{n} {tail:x} {a2} {b:x} {N} {s} {mode} {WALK} {WBITS} 20260924\n'
            body = ''.join(f"{i} {inst[i]['P'][0]:x} {inst[i]['P'][1]:x} {inst[i]['Q'][0]:x} {inst[i]['Q'][1]:x} {inst[i]['k']}\n" for i in part)
            fin = f'{outdir}/{tag}.in'
            open(fin, 'w').write(hdr + body)
            jobs.append((tag, fin))


def run(job):
    tag, fin = job
    fout = fin[:-3] + '.tsv'
    if os.path.exists(fout) and os.path.getsize(fout) > 0:
        nexp = sum(1 for _ in open(fin)) - 1
        if sum(1 for _ in open(fout)) - 1 == nexp:
            return tag, 'cached'
    with open(fin) as fi, open(fout + '.tmp', 'w') as fo, open(fin[:-3] + '.err', 'w') as fe:
        r = subprocess.run([f'{HERE}/birthday_rho'], stdin=fi, stdout=fo, stderr=fe)
    os.replace(fout + '.tmp', fout)
    return tag, r.returncode


with cf.ThreadPoolExecutor(JOBS) as ex:
    for tag, rc in ex.map(run, jobs):
        print(tag, rc, flush=True)
