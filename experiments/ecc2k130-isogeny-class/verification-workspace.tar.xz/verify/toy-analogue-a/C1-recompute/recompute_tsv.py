#!/usr/bin/env python3
"""Independent recomputation of the C1 statistics directly from the sweep's raw TSVs.

Own code (does not import or reuse analyze.py).  For each family:
  (i)  pooled floor 'neg' merge_steps  (all O??-???__neg.tsv)
  (ii) E0 'negtau' merge_steps
ratio = mean(i)/mean(ii); SE two ways: delta method, and a nonparametric bootstrap
(resampling instances inside each group, 4000 reps, fixed seed).
Also: pooled ratio/sqrt(n) (inverse-variance weighted, and unweighted), and a
weighted least-squares log-log slope of ratio vs n.  Plus finite-M exact expectation
E[T] = sum_k prod_{i<k}(1 - i/M) for M = (N-1)/c + 1 classes.
"""
import csv, glob, json, math, os, random

ROOT = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
FAMS = ['T19', 'T23', 'T59', 'T109']


def col(path, name):
    with open(path) as fh:
        rd = csv.DictReader(fh, delimiter='\t')
        rows = list(rd)
    bad = [r['id'] for r in rows if not (r['verified'] == '1' and r['match'] == '1')]
    return [int(r[name]) for r in rows], bad, len(rows)


def mean_sem(v):
    m = sum(v) / len(v)
    var = sum((x - m) ** 2 for x in v) / (len(v) - 1)
    return m, math.sqrt(var / len(v))


def exact_ET(M):
    # E[T], T = index (1-based) of the first repeat when sampling uniformly from M classes
    if M > 5e7:
        return math.sqrt(math.pi * M / 2) + 2.0 / 3
    tot, p, k = 0.0, 1.0, 0
    while p > 1e-18:
        tot += p
        p *= (1 - k / M)
        k += 1
    return tot


out = {}
rng = random.Random(12345)
for F in FAMS:
    meta = json.load(open(f'{ROOT}/data/{F}_family.json'))['meta']
    n, N = int(meta['n']), int(meta['N'])
    d = f'{ROOT}/raw/{F}/out'
    floor_files = sorted(f for f in glob.glob(f'{d}/O*__neg.tsv'))
    fl, fl_bad, fl_it = [], [], []
    for f in floor_files:
        v, bad, _ = col(f, 'merge_steps'); fl += v; fl_bad += bad
        fl_it += col(f, 'iters')[0]
    e0, e0_bad, _ = col(f'{d}/E0__negtau.tsv', 'merge_steps')
    e0_it = col(f'{d}/E0__negtau.tsv', 'iters')[0]
    m1, s1 = mean_sem(fl); m2, s2 = mean_sem(e0)
    r = m1 / m2
    se_delta = r * math.sqrt((s1 / m1) ** 2 + (s2 / m2) ** 2)
    # bootstrap
    B = 4000
    bs = []
    for _ in range(B):
        a = sum(fl[rng.randrange(len(fl))] for _ in range(len(fl))) / len(fl)
        b = sum(e0[rng.randrange(len(e0))] for _ in range(len(e0))) / len(e0)
        bs.append(a / b)
    bm = sum(bs) / B
    se_boot = math.sqrt(sum((x - bm) ** 2 for x in bs) / (B - 1))
    bs.sort()
    ci_boot = [bs[int(0.025 * B)], bs[int(0.975 * B) - 1]]
    mi1, _ = mean_sem(fl_it); mi2, _ = mean_sem(e0_it)
    Mneg = (N - 1) / 2 + 1
    Mnt = (N - 1) / (2 * n) + 1
    ET_neg, ET_nt = exact_ET(Mneg), exact_ET(Mnt)
    out[F] = dict(n=n, N=N, floor_files=[os.path.basename(f) for f in floor_files],
                  n_floor=len(fl), n_E0=len(e0), floor_unverified=len(fl_bad), E0_unverified=len(e0_bad),
                  mean_floor_neg_merge=m1, sem_floor=s1, mean_E0_negtau_merge=m2, sem_E0=s2,
                  ratio=r, se_delta=se_delta, se_boot=se_boot, ci95_boot=ci_boot,
                  sqrt_n=math.sqrt(n), ratio_over_sqrt_n=r / math.sqrt(n),
                  iters_ratio=mi1 / mi2,
                  exact_ET_floor_neg=ET_neg, exact_ET_E0_negtau=ET_nt,
                  exact_ratio_finite_M=ET_neg / ET_nt,
                  floor_over_exact=m1 / ET_neg, E0_over_exact=m2 / ET_nt)

# pooled ratio / sqrt(n)
ws = [(out[F]['ratio_over_sqrt_n'], out[F]['se_delta'] / out[F]['sqrt_n']) for F in FAMS]
wsum = sum(1 / s ** 2 for _, s in ws)
pooled = sum(v / s ** 2 for v, s in ws) / wsum
pooled_se = math.sqrt(1 / wsum)
unweighted = sum(v for v, _ in ws) / len(ws)
# WLS log-log fit: log r = logC + alpha log n, weights 1/var(log r) = (r/se)^2
xs = [math.log(out[F]['n']) for F in FAMS]
ys = [math.log(out[F]['ratio']) for F in FAMS]
wts = [(out[F]['ratio'] / out[F]['se_delta']) ** 2 for F in FAMS]
W = sum(wts); xb = sum(w * x for w, x in zip(wts, xs)) / W; yb = sum(w * y for w, y in zip(wts, ys)) / W
Sxx = sum(w * (x - xb) ** 2 for w, x in zip(wts, xs)); Sxy = sum(w * (x - xb) * (y - yb) for w, x, y in zip(wts, xs, ys))
alpha = Sxy / Sxx; alpha_se = math.sqrt(1 / Sxx); C = math.exp(yb - alpha * xb)
# OLS unweighted too
xm = sum(xs) / 4; ym = sum(ys) / 4
alpha_ols = sum((x - xm) * (y - ym) for x, y in zip(xs, ys)) / sum((x - xm) ** 2 for x in xs)
out['pooled'] = dict(pooled_ratio_over_sqrt_n_ivw=pooled, pooled_se=pooled_se,
                     unweighted_mean_ratio_over_sqrt_n=unweighted,
                     loglog_alpha_wls=alpha, loglog_alpha_wls_se=alpha_se, loglog_C=C,
                     loglog_alpha_ols=alpha_ols)
json.dump(out, open(os.path.join(os.path.dirname(__file__), 'recompute_tsv.json'), 'w'), indent=1)
for F in FAMS:
    o = out[F]
    print(f"{F}: floor n={o['n_floor']} mean={o['mean_floor_neg_merge']:.3f}±{o['sem_floor']:.3f}  "
          f"E0 n={o['n_E0']} mean={o['mean_E0_negtau_merge']:.3f}±{o['sem_E0']:.3f}  ratio={o['ratio']:.4f} "
          f"se_delta={o['se_delta']:.4f} se_boot={o['se_boot']:.4f} sqrt_n={o['sqrt_n']:.4f} "
          f"exact_finiteM={o['exact_ratio_finite_M']:.4f} iters_ratio={o['iters_ratio']:.4f} "
          f"unverified={o['floor_unverified']}+{o['E0_unverified']}")
print(json.dumps(out['pooled'], indent=1))
