/*
 * birthday_rho.c -- independent Pollard-rho birthday-time measurement (written for the
 * C1 verification; shares no code with toy-analogue-a/scripts/rho.c).
 *
 * Curve  y^2 + x y = x^3 + a2 x^2 + b  over F_{2^n} = F_2[z]/(z^n + tail), n <= 120,
 * DLP Q = kP in the prime-order-N subgroup (N < 2^62).
 *
 * Classes:  mode 1 "neg"    : {X, -X}
 *           mode 2 "negtau" : {+-tau^i X}, tau(x,y) = (x^2,y^2) acting as the scalar s
 * Canonical representative: the class element whose x is the smallest integer bitmask
 * (x^(2^i) over i), then of the two signs the one whose y is the smaller integer.
 *
 * Walks (one single walk per instance, NO distinguished points, every generated class
 * stored in a hash table keyed by a 64-bit fingerprint of the canonical x; (A,B) with
 * X = A P + B Q stored with it):
 *   walk 1 "randfunc": X_{i+1} = canon(c P + d Q), (c,d) = PRF(salt, x(X_i))
 *                      -> an honest random function on classes (no additive structure,
 *                         no fruitless cycles); scalar mults via fixed-base window tables.
 *   walk 2 "dbladd"  : X_{i+1} = canon(2 X_i + R_{h(X_i)}), r = 64 random R_j = c_j P + d_j Q.
 * T (birthday time) = number of points generated, up to and including the first one whose
 * class was already generated.  The repeat gives A_i + B_i k = A_j + B_j k; the recovered
 * k is checked by computing kP == Q, and against the planted k.  A degenerate repeat
 * (B_i == B_j) is counted and the walk restarts from a fresh random point, keeping the table.
 *
 * stdin:  line 1: n tail(hex) a2 b(hex) N s mode walk wbits seed
 *         then:   id Px Py Qx Qy k    (coordinates hex, k decimal)
 * stdout: id k_true k_found ok T group_ops restarts degenerate on_curve tau_ok
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <arm_neon.h>

typedef unsigned __int128 u128;
typedef uint64_t u64;

static int NB; static u128 MASK; static u64 TAIL; static int TAILBITS[8]; static int NTB;
static u128 A2, BC; static u64 NORD, SEIG; static int MODE, WALK, WBITS;
static u64 SPOW[128];
static u64 OPS;   /* group operations counter */

/* ---------------- F_{2^n} ---------------- */
static inline u128 cl64(u64 a, u64 b) {
    poly128_t p = vmull_p64((poly64_t)a, (poly64_t)b);
    u128 r; memcpy(&r, &p, 16); return r;
}
static inline u128 mulsmall(u128 h) { u128 r = 0; for (int i = 0; i < NTB; i++) r ^= h << TAILBITS[i]; return r; }
static inline u128 reduce(u128 lo, u128 hi) {
    u128 H = (hi << (128 - NB)) | (lo >> NB);
    u128 t = (lo & MASK) ^ mulsmall(H);
    u128 H2 = t >> NB;
    return (t & MASK) ^ mulsmall(H2);
}
static inline u128 fmul(u128 a, u128 b) {
    u64 a0 = (u64)a, a1 = (u64)(a >> 64), b0 = (u64)b, b1 = (u64)(b >> 64);
    if (NB <= 64) { return reduce(cl64(a0, b0), 0); }
    u128 p00 = cl64(a0, b0), p11 = cl64(a1, b1), pm = cl64(a0, b1) ^ cl64(a1, b0);
    u128 lo = p00 ^ (pm << 64), hi = p11 ^ (pm >> 64);
    return reduce(lo, hi);
}
static inline u128 fsqr(u128 a) {    /* cross terms vanish in characteristic 2 */
    u64 a0 = (u64)a, a1 = (u64)(a >> 64);
    if (NB <= 64) return reduce(cl64(a0, a0), 0);
    return reduce(cl64(a0, a0), cl64(a1, a1));
}
static u128 finv(u128 a) {           /* Itoh-Tsujii: a^(2^n-2) */
    int m = NB - 1, top = 63 - __builtin_clzll((u64)m);
    u128 b = a; int k = 1;
    for (int bit = top - 1; bit >= 0; bit--) {
        u128 t = b; for (int i = 0; i < k; i++) t = fsqr(t);
        b = fmul(t, b); k <<= 1;
        if ((m >> bit) & 1) { b = fmul(fsqr(b), a); k += 1; }
    }
    return fsqr(b);
}

/* ---------------- curve ---------------- */
typedef struct { u128 x, y; int inf; } pt;
static pt pinf(void) { pt r; r.x = r.y = 0; r.inf = 1; return r; }
static int oncurve(pt P) {
    if (P.inf) return 1;
    u128 x2 = fsqr(P.x);
    u128 l = fsqr(P.y) ^ fmul(P.x, P.y);
    u128 r = fmul(x2, P.x) ^ fmul(A2, x2) ^ BC;
    return l == r;
}
static pt pdbl(pt P) {
    OPS++;
    if (P.inf || P.x == 0) return pinf();
    u128 lam = P.x ^ fmul(P.y, finv(P.x));
    pt R; R.inf = 0;
    R.x = fsqr(lam) ^ lam ^ A2;
    R.y = fsqr(P.x) ^ fmul(lam, R.x) ^ R.x;
    return R;
}
static pt padd(pt P, pt Q) {
    if (P.inf) return Q;
    if (Q.inf) return P;
    if (P.x == Q.x) { if (P.y == Q.y) return pdbl(P); OPS++; return pinf(); }
    OPS++;
    u128 lam = fmul(P.y ^ Q.y, finv(P.x ^ Q.x));
    pt R; R.inf = 0;
    R.x = fsqr(lam) ^ lam ^ P.x ^ Q.x ^ A2;
    R.y = fmul(lam, P.x ^ R.x) ^ R.x ^ P.y;
    return R;
}
static pt pneg(pt P) { if (!P.inf) P.y ^= P.x; return P; }
static pt pmul(pt P, u64 k) {        /* plain double-and-add, used only for checks */
    pt R = pinf();
    for (int i = 63; i >= 0; i--) { R = pdbl(R); if ((k >> i) & 1) R = padd(R, P); }
    return R;
}
static int peq(pt P, pt Q) { if (P.inf || Q.inf) return P.inf == Q.inf; return P.x == Q.x && P.y == Q.y; }

/* ---------------- mod N ---------------- */
static inline u64 mmul(u64 a, u64 b) { return (u64)(((u128)a * b) % NORD); }
static inline u64 madd(u64 a, u64 b) { u128 s = (u128)a + b; return (u64)(s % NORD); }
static inline u64 msub(u64 a, u64 b) { return a >= b ? a - b : (u64)((u128)a + NORD - b); }
static u64 mpow(u64 a, u64 e) { u64 r = 1 % NORD; while (e) { if (e & 1) r = mmul(r, a); a = mmul(a, a); e >>= 1; } return r; }
static u64 minv(u64 a) { return mpow(a, NORD - 2); }   /* N prime */

/* canonicalize X (in place); returns multiplier mu with canon(X) = mu * X on <P> */
static u64 canon(pt *X) {
    if (X->inf) return 1;
    int ibest = 0; u128 xb = X->x;
    if (MODE == 2) {
        u128 t = X->x;
        for (int i = 1; i < NB; i++) { t = fsqr(t); if (t < xb) { xb = t; ibest = i; } }
        u128 y = X->y; for (int i = 0; i < ibest; i++) y = fsqr(y);
        X->x = xb; X->y = y;
    }
    u64 mu = SPOW[ibest];
    u128 y2 = X->y ^ X->x;           /* -X = (x, x+y) */
    if (y2 < X->y) { X->y = y2; mu = (NORD - mu) % NORD; }
    return mu;
}

/* ---------------- PRNG / hash ---------------- */
static inline u64 mix64(u64 z) {
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}
static u64 rngstate;
static u64 rnd64(void) { rngstate += 0x9e3779b97f4a7c15ULL; return mix64(rngstate); }
static u64 rndmod(void) { return (u64)((((u128)rnd64() << 64) | rnd64()) % NORD); }
static inline u64 xfp(u128 x, u64 salt) { return mix64((u64)x ^ mix64((u64)(x >> 64) ^ salt)); }

/* ---------------- fixed-base window tables ---------------- */
static int NWIN; static pt *TP, *TQ;
static void build_table(pt *T, pt P) {
    int W = 1 << WBITS; pt base = P;
    for (int j = 0; j < NWIN; j++) {
        T[j * W] = pinf();
        for (int v = 1; v < W; v++) T[j * W + v] = padd(T[j * W + v - 1], base);
        for (int b = 0; b < WBITS; b++) base = pdbl(base);
    }
}
static pt tmul(pt *T, u64 c) {
    int W = 1 << WBITS; pt R = pinf();
    for (int j = 0; j < NWIN; j++) { int v = (c >> (j * WBITS)) & (W - 1); if (v) R = padd(R, T[j * W + v]); }
    return R;
}

/* ---------------- hash table ---------------- */
typedef struct { u64 fp, A, B; } ent;
static ent *HT; static u64 HCAP, HCNT;
static void ht_reset(u64 cap) { if (HCAP != cap) { free(HT); HT = malloc(cap * sizeof(ent)); HCAP = cap; } memset(HT, 0, cap * sizeof(ent)); HCNT = 0; }
static void ht_grow(void) {
    ent *old = HT; u64 oc = HCAP; HCAP *= 2; HT = calloc(HCAP, sizeof(ent));
    for (u64 i = 0; i < oc; i++) if (old[i].fp) { u64 h = old[i].fp & (HCAP - 1); while (HT[h].fp) h = (h + 1) & (HCAP - 1); HT[h] = old[i]; }
    free(old);
}
/* returns pointer to the existing entry with this fp, or inserts and returns NULL */
static ent *ht_find_or_insert(u64 fp, u64 A, u64 B) {
    if (!fp) fp = 1;
    if (2 * (HCNT + 1) > HCAP) ht_grow();
    u64 h = fp & (HCAP - 1);
    while (HT[h].fp) { if (HT[h].fp == fp) return &HT[h]; h = (h + 1) & (HCAP - 1); }
    HT[h].fp = fp; HT[h].A = A; HT[h].B = B; HCNT++; return NULL;
}

static u128 parsehex(const char *s) { u128 r = 0; for (; *s; s++) { int c = *s, v = (c >= '0' && c <= '9') ? c - '0' : (c | 32) - 'a' + 10; r = (r << 4) | (u128)v; } return r; }

int main(void) {
    char tailh[64], bh[64], mode[16], walk[16]; u64 seed; unsigned long long N_, s_;
    long long a2in;
    if (scanf("%d %63s %lld %63s %llu %llu %15s %15s %d %llu", &NB, tailh, &a2in, bh, &N_, &s_, mode, walk, &WBITS, (unsigned long long *)&seed) != 10) { fprintf(stderr, "bad header\n"); return 1; }
    A2 = (u128)a2in;
    NORD = N_; SEIG = s_;
    TAIL = (u64)parsehex(tailh); BC = parsehex(bh);
    MASK = (((u128)1) << NB) - 1;
    NTB = 0; for (int b = 0; b < 64; b++) if ((TAIL >> b) & 1) TAILBITS[NTB++] = b;
    MODE = !strcmp(mode, "negtau") ? 2 : 1;
    WALK = !strcmp(walk, "randfunc") ? 1 : 2;
    SPOW[0] = 1 % NORD; for (int i = 1; i < 128; i++) SPOW[i] = mmul(SPOW[i - 1], SEIG);
    if (MODE == 2 && SPOW[NB] != 1) { fprintf(stderr, "s^n != 1 mod N\n"); return 1; }
    int nbits = 64 - __builtin_clzll(NORD);
    NWIN = (nbits + WBITS - 1) / WBITS;
    TP = malloc(sizeof(pt) * NWIN << WBITS); TQ = malloc(sizeof(pt) * NWIN << WBITS);
    HCAP = 0; HT = NULL;
    char id[128], px[64], py[64], qx[64], qy[64]; unsigned long long ktrue;
    printf("id\tk_true\tk_found\tok\tT\tgroup_ops\trestarts\tdegenerate\ton_curve\ttau_ok\n");
    while (scanf("%127s %63s %63s %63s %63s %llu", id, px, py, qx, qy, &ktrue) == 6) {
        pt P = {parsehex(px), parsehex(py), 0}, Q = {parsehex(qx), parsehex(qy), 0};
        int on = oncurve(P) && oncurve(Q) && pmul(P, NORD).inf && !P.inf && peq(pmul(P, ktrue), Q);
        int tauok = -1;
        if (MODE == 2) { pt tP = {fsqr(P.x), fsqr(P.y), 0}; tauok = oncurve(tP) && peq(tP, pmul(P, SEIG)); }
        u64 salt = mix64(seed ^ mix64(xfp(P.x, 7) ^ xfp(Q.x, 11)));
        rngstate = salt;
        OPS = 0;
        pt R[64]; u64 Rc[64], Rd[64];
        if (WALK == 1) { build_table(TP, P); build_table(TQ, Q); }
        else for (int j = 0; j < 64; j++) {
            Rc[j] = rndmod(); Rd[j] = rndmod();
            /* plain double-and-add for the 64 fixed steps */
            R[j] = padd(pmul(P, Rc[j]), pmul(Q, Rd[j]));
        }
        u64 ops0 = OPS; OPS = 0;
        ht_reset(1 << 12);
        u64 T = 0, kfound = 0; int restarts = 0, degenerate = 0, solved = 0;
        pt X; u64 A, B;
        { u64 c = rndmod(), d = rndmod(); X = (WALK == 1) ? padd(tmul(TP, c), tmul(TQ, d)) : padd(pmul(P, c), pmul(Q, d));
          u64 mu = canon(&X); A = mmul(mu, c); B = mmul(mu, d); }
        u64 LIMIT = (u64)1 << 40;
        while (!solved && T < LIMIT) {
            T++;
            u64 fp = X.inf ? 0xffffffffffffffffULL : xfp(X.x, 0x5bd1e995);
            ent *e = ht_find_or_insert(fp, A, B);
            if (e) {
                /* confirm it is a true class repeat: recompute the stored point */
                pt Y = padd(pmul(P, e->A), pmul(Q, e->B));
                pt Xc = X;
                int same = peq(Y, Xc);
                if (!same) { fprintf(stderr, "%s: fingerprint clash at T=%llu\n", id, (unsigned long long)T); }
                else if (e->B == B) { degenerate++; }
                else {
                    kfound = mmul(msub(e->A, A), minv(msub(B, e->B)));
                    solved = 1; break;
                }
                /* degenerate or clash: restart from a fresh random point (table kept) */
                restarts++;
                u64 c = rndmod(), d = rndmod();
                X = (WALK == 1) ? padd(tmul(TP, c), tmul(TQ, d)) : padd(pmul(P, c), pmul(Q, d));
                u64 mu = canon(&X); A = mmul(mu, c); B = mmul(mu, d);
                continue;
            }
            /* step */
            if (WALK == 1) {
                u64 h = X.inf ? 0x1234567ULL : xfp(X.x, salt);
                u64 c = mix64(h ^ 0xa5a5a5a5ULL) % NORD, d = mix64(h ^ 0x3c3c3c3cULL) % NORD;
                pt Y = padd(tmul(TP, c), tmul(TQ, d));
                u64 mu = canon(&Y); X = Y; A = mmul(mu, c); B = mmul(mu, d);
            } else {
                int j = X.inf ? 0 : (int)(xfp(X.x, salt ^ 0x77) & 63);
                pt Y = padd(pdbl(X), R[j]);
                u64 A2_ = madd(madd(A, A), Rc[j]), B2_ = madd(madd(B, B), Rd[j]);
                u64 mu = canon(&Y); X = Y; A = mmul(mu, A2_); B = mmul(mu, B2_);
            }
        }
        int ok = solved && kfound == ktrue && peq(pmul(P, kfound), Q);
        printf("%s\t%llu\t%llu\t%d\t%llu\t%llu\t%d\t%d\t%d\t%d\n", id, ktrue, (unsigned long long)kfound, ok,
               (unsigned long long)T, (unsigned long long)OPS, restarts, degenerate, on, tauok);
        fflush(stdout);
        (void)ops0;
    }
    return 0;
}
