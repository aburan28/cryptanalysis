#!/usr/bin/env python3
"""Own GF(2^n) arithmetic: check that the floor curves used in C1 have b outside F_2,
j != 0 (so Aut = {+-1}), and that x->x^2 sends curve X-k to X-(k+1) (a different curve),
i.e. tau is not an endomorphism of a floor curve over F_q.  Also j*b == 1 (a2-model)."""
import json
ROOT = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
def mulmod(a, b, n, tail):
    r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1; a <<= 1
        if a >> n & 1: a ^= (1 << n) | tail
    return r
out = {}
for F in ['T19', 'T23', 'T59', 'T109']:
    fam = json.load(open(f'{ROOT}/data/{F}_family.json')); m = fam['meta']; C = fam['curves']
    n, tail = int(m['n']), int(m['modulus_tail'])
    inst = json.load(open(f'{ROOT}/raw/{F}/instances.json'))
    used = sorted({v['curve'] for v in inst.values() if v['curve'] != 'E0'})
    rep = {}
    for cn in used:
        c = C[cn]; b = int(c['b_int']); j = int(c['j_int'])
        orb, k = cn.split('-'); k = int(k)
        nxt = f"{orb}-{(k + 1) % n:03d}"
        b2 = mulmod(b, b, n, tail)
        rep[cn] = dict(b_in_F2=b in (0, 1), j_is_0=(j == 0), jb_is_1=(mulmod(j, b, n, tail) == 1),
                       b_squared_is_next=(b2 == int(C[nxt]['b_int'])), a2=c['a2'], same_a2_next=(C[nxt]['a2'] == c['a2']),
                       b_squared_equals_self=(b2 == b))
    out[F] = rep
    print(F, {k: v for k, v in rep.items()})
json.dump(out, open('frob_check.json', 'w'), indent=1)
