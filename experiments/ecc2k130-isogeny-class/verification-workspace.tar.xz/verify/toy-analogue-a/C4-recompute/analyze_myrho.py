#!/usr/bin/env python3
"""Summarise the independent myrho.c runs and compare them with (a) the random-mapping law and
(b) the sweep's own T59 samples (two-sample KS).  Own code; reuses only recompute.py's helpers."""
import os, sys, glob, math, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from recompute import mean_sd, ks_stat, ks_stat_discrete, mtw_pvalue, kolmogorov_asym_pvalue, log_surv_exact, read_tsv

HERE = os.path.dirname(os.path.abspath(__file__))
SWEEP = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/raw/T59/out'
N = 10063074221
CS = {'none': 1, 'neg': 2, 'negtau': 118}


def ks2(x, y):
    xs, ys = sorted(x), sorted(y)
    i = j = 0; d = 0.0
    while i < len(xs) and j < len(ys):
        v = min(xs[i], ys[j])
        while i < len(xs) and xs[i] == v: i += 1
        while j < len(ys) and ys[j] == v: j += 1
        d = max(d, abs(i / len(xs) - j / len(ys)))
    ne = len(xs) * len(ys) / (len(xs) + len(ys))
    lam = (math.sqrt(ne) + 0.12 + 0.11 / math.sqrt(ne)) * d
    p = min(1.0, max(0.0, sum(2 * (-1) ** (k - 1) * math.exp(-2 * k * k * lam * lam) for k in range(1, 200))))
    return d, p


def main():
    cfgs = sorted(set(os.path.basename(f).split('.')[0] for f in glob.glob(os.path.join(HERE, 'runs', '*.tsv'))))
    out = {}
    for cfg in cfgs:
        curve, mode = cfg.split('__')
        rows = []
        errs = 0
        for f in sorted(glob.glob(os.path.join(HERE, 'runs', cfg + '.*.tsv'))):
            for line in open(f):
                p = line.split()
                if len(p) == 8:
                    rows.append(p)
            e = f[:-4] + '.err'
            errs += sum(1 for l in open(e) if 'tau eigenvalue' not in l) if os.path.exists(e) else 0
        T = [int(r[4]) for r in rows]
        ok = sum(int(r[3]) for r in rows)
        fr = sum(int(r[6]) for r in rows)
        c = CS[mode]; M = N / c; Mx = (N - 1) / c + 1
        th = math.sqrt(math.pi * M / 2)
        m, sd = mean_sd(T); se = sd / math.sqrt(len(T))
        z = [t * t / (2 * M) for t in T]
        D1 = ks_stat(z, lambda x: 1 - math.exp(-x))
        D2 = ks_stat_discrete(T, lambda x: 1 - math.exp(log_surv_exact(x, Mx)), lambda x: 1 - math.exp(log_surv_exact(x - 1, Mx)))
        rec = dict(n_inst=len(T), logs_verified=ok, err_lines=errs, fruitless_total=fr, mean=m, se=se, theory=th,
                   ratio=m / th, ci95=[(m - 1.96 * se) / th, (m + 1.96 * se) / th], cv=sd / m,
                   ks_exp1_D=D1, ks_exp1_p=mtw_pvalue(len(z), D1) if len(z) <= 5000 else kolmogorov_asym_pvalue(len(z), D1),
                   ks_exact_D=D2, ks_exact_p=kolmogorov_asym_pvalue(len(T), D2))
        # compare with the sweep's sample(s)
        comp = {}
        cands = [cfg] + ([f'{x}__transport_negtau' for x in ['O00-000', 'O00-001', 'O00-029', 'O01-000', 'O01-001', 'O01-029']] if cfg == 'E0__negtau' else [])
        allsw = []
        for cc in cands:
            fp = os.path.join(SWEEP, cc + '.tsv')
            if os.path.exists(fp):
                _, rr = read_tsv(fp)
                Ts = [int(r['merge_steps']) for r in rr]
                allsw += Ts
                d, p = ks2(T, Ts)
                ms, sds = mean_sd(Ts)
                comp[cc] = dict(n=len(Ts), sweep_ratio=ms / th, ks2_D=d, ks2_p=p)
        rec['vs_sweep'] = comp
        out[cfg] = rec
        print(f"{cfg:16s} n={len(T):6d} verified={ok} errs={errs} fruitless={fr} mean={m:10.1f} th={th:10.1f} "
              f"ratio={m/th:.4f} [{rec['ci95'][0]:.4f},{rec['ci95'][1]:.4f}] cv={sd/m:.3f} "
              f"KS(Exp1) D={D1:.4f} p={rec['ks_exp1_p']:.3f}  KS(exact) p={rec['ks_exact_p']:.3f}")
        for k, v in comp.items():
            print(f"     vs sweep {k:28s} n={v['n']:5d} sweep ratio={v['sweep_ratio']:.4f}  2-sample KS D={v['ks2_D']:.4f} p={v['ks2_p']:.3f}")
    json.dump(out, open(os.path.join(HERE, 'myrho_summary.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
