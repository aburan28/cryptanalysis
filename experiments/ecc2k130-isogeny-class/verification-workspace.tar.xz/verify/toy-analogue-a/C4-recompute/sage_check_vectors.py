# Sage cross-check of myrho.c field / curve arithmetic test vectors
from sage.all import GF, PolynomialRing, EllipticCurve, Integer
R = PolynomialRing(GF(2), 'z'); z = R.gen()
mod = z**59 + z**6 + z**5 + z**4 + z**3 + z + 1
assert mod.is_irreducible()
K = GF(2**59, 'z', modulus=mod); g = K.gen()
def fe(h): v = int(h, 16); return sum(((v >> i) & 1) * g**i for i in range(59))
def ie(e): return sum(int(c) << i for i, c in enumerate(e.polynomial().list()))
N = 10063074221
for fn, b in [('selftest_E0.txt', 1), ('selftest_O00-001.txt', 543369226825274510)]:
    E = EllipticCurve(K, [1, 0, 0, 0, fe(hex(b)[2:])])
    ok = True
    for line in open(fn):
        f = line.split()
        if f[0] == 'mul': ok &= (fe(f[1]) * fe(f[2]) == fe(f[3]))
        elif f[0] == 'inv': ok &= (fe(f[1]) * fe(f[2]) == 1)
        elif f[0] == 'pt':
            P = E(fe(f[1]), fe(f[2])); k = int(f[4]); kP = E(fe(f[6]), fe(f[7]))
            ok &= (k * P == kP); ok &= (P + kP == E(fe(f[9]), fe(f[10]))); ok &= (2 * P == E(fe(f[12]), fe(f[13])))
            ok &= (N * P == E(0))
    card = None
    print(fn, "all vectors ok:", ok)
