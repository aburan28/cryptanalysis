#!/bin/bash
# Launch independent myrho runs in parallel chunks (500 instances per chunk, distinct seeds).
export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
cd /Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C4-recompute
S1=2347453808; S2=7715620412
B_E0=1
B_O00_001=$(python3 -c "print(hex(543369226825274510)[2:])")
B_O00_029=$(python3 -c "print(hex(233255939816144906)[2:])")
B_O01_029=$(python3 -c "print(hex(349861000990993930)[2:])")
: > jobs.txt
add() { # cfg b mode nchunks seedbase
  for i in $(seq 0 $(($4-1))); do echo "$1 $2 $3 $(($5+i))" >> jobs.txt; done; }
add E0__none      $B_E0      none   24 1000
add E0__neg       $B_E0      neg    24 2000
add E0__negtau    $B_E0      negtau 40 3000
add O00-001__neg  $B_O00_001 neg    16 4000
add O00-029__neg  $B_O00_029 neg    16 5000
add O01-029__neg  $B_O01_029 neg    16 6000
cat jobs.txt | xargs -P 12 -L 1 bash -c 'timeout 2400 ./myrho $1 0 $2 500 $3 '$S1' '$S2' > runs/$0.$3.tsv 2> runs/$0.$3.err; echo "$0 $3 rc=$?"' > run_all.log 2>&1
echo done >> run_all.log
