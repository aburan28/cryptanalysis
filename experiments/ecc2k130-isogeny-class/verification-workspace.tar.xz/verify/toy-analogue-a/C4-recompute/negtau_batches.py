import glob, math, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from recompute import mean_sd, ks_stat, kolmogorov_asym_pvalue
N = 10063074221; M = N / 118; th = math.sqrt(math.pi * M / 2)
def load(d):
    T = []; ok = 0
    for f in sorted(glob.glob(d + '/E0__negtau.*.tsv')):
        for l in open(f):
            p = l.split()
            if len(p) == 8: T.append(int(p[4])); ok += int(p[3])
    return T, ok
for name, T, ok in [('batch1', *load('runs')), ('batch2', *load('runs2'))] + [('pooled', *[a + b for a, b in zip(load('runs'), load('runs2'))])]:
    m, sd = mean_sd(T); se = sd / math.sqrt(len(T))
    z = [t * t / (2 * M) for t in T]; D = ks_stat(z, lambda x: 1 - math.exp(-x))
    print(f'{name}: n={len(T)} verified={ok} mean={m:.1f} theory={th:.1f} ratio={m/th:.4f} +- {1.96*se/th:.4f} (z={(m-th)/se:+.2f}) cv={sd/m:.4f} KS D={D:.4f} p={kolmogorov_asym_pvalue(len(z), D):.3f}')
