#!/usr/bin/env python3
"""C4 recompute: independent re-derivation of the T59 birthday-time statistics.

Own code path (does NOT import or reuse analyze.py / make_tables.py):
  * pure-Python TSV parsing and moment statistics,
  * own Kolmogorov-Smirnov statistic and own exact p-value
    (Marsaglia-Tsang-Wang 2003 matrix algorithm; numpy only for the matrix product),
  * a second KS test against the EXACT finite-M first-repeat law
    P(T > k) = prod_{i=0}^{k-1} (1 - i/M), instead of the Exp(1) approximation,
  * provenance checks: every row verified/match/merge_ok, abandoned == 0,
    out/*.tsv == concatenation of the chunk outputs, chunk .err files empty.
"""
import os, sys, math, json, glob
import numpy as np
np.seterr(all='raise')

ROOT = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/raw/T59'
N = 10063074221
n = 59
CSIZE = {'none': 1, 'neg': 2, 'negtau': 2 * n, 'transport_negtau': 2 * n}


def read_tsv(path):
    with open(path) as fh:
        hdr = fh.readline().rstrip('\n').split('\t')
        rows = []
        for line in fh:
            line = line.rstrip('\n')
            if not line:
                continue
            f = line.split('\t')
            assert len(f) == len(hdr), (path, line)
            rows.append(dict(zip(hdr, f)))
    return hdr, rows


def mean_sd(xs):
    m = math.fsum(xs) / len(xs)
    v = math.fsum((x - m) ** 2 for x in xs) / (len(xs) - 1)
    return m, math.sqrt(v)


# ---------------- Kolmogorov distribution (own implementation) ----------------
def mtw_pvalue(nobs, d):
    """P(D_n >= d) via Marsaglia, Tsang & Wang (2003), J. Stat. Softw. 8(18)."""
    k = int(nobs * d) + 1
    m = 2 * k - 1
    h = k - nobs * d
    H = np.zeros((m, m))
    for i in range(m):
        for j in range(m):
            if i - j + 1 >= 0:
                H[i, j] = 1.0
    for i in range(m):
        H[i, 0] -= h ** (i + 1)
        H[m - 1, i] -= h ** (m - i)
    H[m - 1, 0] += (2 * h - 1) ** m if 2 * h - 1 > 0 else 0.0
    for i in range(m):
        for j in range(m):
            if i - j + 1 > 0:
                H[i, j] /= math.factorial(i - j + 1)
    # matrix power with exponent tracking
    def mpow(A, e):
        if e == 1:
            return A.copy(), 0
        B, eB = mpow(A, e // 2)
        B = np.einsum('ij,jk->ik', B, B)  # einsum: avoids spurious FP flags from Accelerate BLAS
        eB *= 2
        if e % 2 == 1:
            B = np.einsum('ij,jk->ik', A, B)
        mx = float(np.max(np.abs(B)))
        if mx > 1e100:
            sh = int(math.floor(math.log10(mx)))
            B *= 10.0 ** (-sh)
            eB += sh
        return B, eB
    Q, eQ = mpow(H, nobs)
    s = Q[k - 1, k - 1]
    for i in range(1, nobs + 1):
        s = s * i / nobs
        if s < 1e-140:
            s *= 1e140
            eQ -= 140
    cdf = s * 10.0 ** eQ
    return max(0.0, 1.0 - cdf)


def kolmogorov_asym_pvalue(nobs, d):
    """Stephens-corrected asymptotic Kolmogorov tail (second, independent approximation)."""
    lam = (math.sqrt(nobs) + 0.12 + 0.11 / math.sqrt(nobs)) * d
    s = 0.0
    for j in range(1, 200):
        s += 2 * (-1) ** (j - 1) * math.exp(-2 * j * j * lam * lam)
    return min(1.0, max(0.0, s))


def ks_stat(sample, cdf):
    xs = sorted(sample)
    nn = len(xs)
    d = 0.0
    for i, x in enumerate(xs):
        F = cdf(x)
        d = max(d, (i + 1) / nn - F, F - i / nn)
    return d


def ks_stat_discrete(sample, cdf_le, cdf_lt):
    """Two-sided KS distance for an integer-valued sample against a discrete law,
    using F(x) = P(T <= x) and F(x-) = P(T < x)."""
    xs = sorted(sample)
    nn = len(xs)
    d = 0.0
    i = 0
    while i < nn:
        j = i
        while j + 1 < nn and xs[j + 1] == xs[i]:
            j += 1
        x = xs[i]
        d = max(d, (j + 1) / nn - cdf_le(x), cdf_lt(x) - i / nn)
        i = j + 1
    return d


def log_surv_exact(k, M):
    """log P(T > k) = sum_{i=0}^{k-1} log(1 - i/M) via power sums (3 terms; k << M)."""
    m = k - 1
    if m <= 0:
        return 0.0
    S1 = m * (m + 1) / 2
    S2 = m * (m + 1) * (2 * m + 1) / 6
    S3 = S1 * S1
    return -(S1 / M + S2 / (2 * M * M) + S3 / (3 * M ** 3))


def exact_mean_T(M):
    """E[T] = sum_{k>=0} P(T>k), summed numerically."""
    s = 0.0
    k = 0
    while True:
        p = math.exp(log_surv_exact(k, M))
        s += p
        if p < 1e-18:
            break
        k += 1
    return s


def main():
    out = {}
    files = sorted(glob.glob(os.path.join(ROOT, 'out', '*.tsv')))
    prov = {}
    per = {}
    for f in files:
        cfg = os.path.basename(f)[:-4]
        curve, mode = cfg.split('__')
        hdr, rows = read_tsv(f)
        # provenance: out == concat(chunks) ?
        chunks = sorted(glob.glob(os.path.join(ROOT, 'chunks', cfg + '.*.out')))
        chunk_rows = []
        err_bytes = 0
        for c in chunks:
            _, r = read_tsv(c) if open(c).readline().startswith('id\t') else (None, None)
            if r is None:
                with open(c) as fh:
                    r = [dict(zip(hdr, l.rstrip('\n').split('\t'))) for l in fh if l.strip()]
            chunk_rows += r
            e = c[:-4] + '.err'
            if os.path.exists(e):
                err_bytes += os.path.getsize(e)
        same = sorted(tuple(sorted(r.items())) for r in rows) == sorted(tuple(sorted(r.items())) for r in chunk_rows)
        prov[cfg] = dict(rows=len(rows), chunks=len(chunks), chunk_rows=len(chunk_rows), equal_to_chunks=same,
                         chunk_err_bytes=err_bytes)
        c = CSIZE[mode]
        M = N / c
        th = math.sqrt(math.pi * M / 2)
        Mx = (N - 1) / c + 1  # classes incl. the identity
        T = [int(r['merge_steps']) for r in rows]
        it = [int(r['iters']) for r in rows]
        chk = dict(
            verified_all=all(r['verified'] == '1' for r in rows),
            match_all=all(r['match'] == '1' for r in rows),
            merge_ok_all=all(r['merge_ok'] == '1' for r in rows),
            abandoned_sum=sum(int(r['abandoned']) for r in rows),
            fruitless_sum=sum(int(r['fruitless']) for r in rows),
            selfsolve_sum=sum(int(r['selfsolve']) for r in rows),
            degenerate_sum=sum(int(r['degenerate']) for r in rows),
            inf_sum=sum(int(r['inf']) for r in rows),
            k_found_eq_true=all(r['k_true'] == r['k_found'] for r in rows),
            merge_le_steps=all(int(r['merge_steps']) <= int(r['steps']) for r in rows),
            ids_unique=len(set(r['id'] for r in rows)) == len(rows),
        )
        m, sd = mean_sd(T)
        se = sd / math.sqrt(len(T))
        # KS 1: T^2/(2M) vs Exp(1)
        z = [t * t / (2 * M) for t in T]
        D1 = ks_stat(z, lambda x: 1 - math.exp(-x))
        # KS 2: T vs exact discrete first-repeat law on Mx classes
        D2 = ks_stat_discrete(T, lambda x: 1 - math.exp(log_surv_exact(x, Mx)),
                              lambda x: 1 - math.exp(log_surv_exact(x - 1, Mx)))
        per[cfg] = dict(curve=curve, mode=mode, c=c, M=M, n_inst=len(T), mean=m, sd=sd, se=se, theory=th,
                        ratio=m / th, ci95=[(m - 1.96 * se) / th, (m + 1.96 * se) / th],
                        ratio_exact_ET=m / exact_mean_T(Mx),
                        cv=sd / m, cv_theory=math.sqrt(4 / math.pi - 1),
                        mean_iters=math.fsum(it) / len(it),
                        ks_exp1=dict(D=D1, p_mtw=mtw_pvalue(len(z), D1), p_asym=kolmogorov_asym_pvalue(len(z), D1)),
                        ks_exact_law=dict(D=D2, p_mtw=mtw_pvalue(len(T), D2)),
                        checks=chk, T=T)
    groups = {
        '(i) floor, neg': [k for k in per if per[k]['curve'] != 'E0' and per[k]['mode'] == 'neg'],
        '(ii) E0, neg+tau': ['E0__negtau'],
        '(iii) floor->E0, neg+tau': [k for k in per if per[k]['mode'] == 'transport_negtau'],
        '(iv) E0, neg only': ['E0__neg'],
        '(v) E0, no classes': ['E0__none'],
    }
    G = {}
    for g, ks in groups.items():
        T = sum((per[k]['T'] for k in ks), [])
        c = per[ks[0]]['c']
        M = N / c
        th = math.sqrt(math.pi * M / 2)
        m, sd = mean_sd(T)
        se = sd / math.sqrt(len(T))
        z = [t * t / (2 * M) for t in T]
        D = ks_stat(z, lambda x: 1 - math.exp(-x))
        G[g] = dict(configs=ks, n_inst=len(T), c=c, mean=m, se=se, theory=th, ratio=m / th,
                    half95=1.96 * se / th, ci95=[(m - 1.96 * se) / th, (m + 1.96 * se) / th],
                    pooled_ks_exp1=dict(D=D, p_mtw=mtw_pvalue(len(z), D)))
    for k in per:
        del per[k]['T']
    res = dict(N=N, n=n, provenance=prov, per_config=per, groups=G)
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'recompute_out.json'), 'w') as fh:
        json.dump(res, fh, indent=1)
    print('provenance:')
    for k, v in prov.items():
        print(f'  {k:32s} {v}')
    print('\nper config:')
    for k, v in per.items():
        print(f"  {k:32s} n={v['n_inst']:5d} c={v['c']:3d} mean={v['mean']:10.1f} th={v['theory']:10.1f} "
              f"ratio={v['ratio']:.4f} [{v['ci95'][0]:.3f},{v['ci95'][1]:.3f}] cv={v['cv']:.3f}(th {v['cv_theory']:.3f}) "
              f"KSexp D={v['ks_exp1']['D']:.4f} p={v['ks_exp1']['p_mtw']:.3f}/{v['ks_exp1']['p_asym']:.3f} "
              f"KSexact p={v['ks_exact_law']['p_mtw']:.3f} chk={v['checks']}")
    print('\ngroups:')
    for k, v in G.items():
        print(f"  {k:26s} n={v['n_inst']:5d} mean={v['mean']:10.1f} se={v['se']:7.1f} th={v['theory']:10.1f} "
              f"ratio={v['ratio']:.4f} +- {v['half95']:.4f}  pooled KS p={v['pooled_ks_exp1']['p_mtw']:.3f}")


if __name__ == '__main__':
    main()
