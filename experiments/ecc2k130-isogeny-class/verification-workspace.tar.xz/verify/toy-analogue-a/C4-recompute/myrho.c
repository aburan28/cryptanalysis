/*
 * myrho.c -- independent Pollard-rho birthday-time measurement for the T59 toy family
 * (C4 verification; written from scratch, shares no code with toy-analogue-a/scripts/rho.c).
 *
 * Curve: y^2 + x y = x^3 + a2 x^2 + b over F_{2^59}, modulus z^59 + z^6 + z^5 + z^4 + z^3 + z + 1.
 * Prime subgroup order N = 10063074221, cofactor h = 57284756 (#E = h N).
 *
 * Design differences from the sweep's rho.c (deliberate):
 *   - ONE long walk per instance, no distinguished points, no Brent: every visited class
 *     representative is stored in a hash table, so the FIRST genuine repeated class is found
 *     exactly (no re-walk reconstruction needed).
 *   - r = 2^RB adding table built from a fixed-base comb; walk index from a multiplicative hash.
 *   - canonical representative: neg -> the sign with the LARGER y; negtau -> the Frobenius
 *     conjugate with the LARGEST x as integer, then the larger y  (sweep uses min / smaller).
 *   - no look-ahead: fruitless cycles are caught exactly by the table (same (a,b)) and left
 *     via canon(2P).
 *   - inversion by the binary extended Euclidean algorithm over F_2[z].
 *   - P is a fresh random point of order N per instance (random x, half-trace, cofactor).
 *
 * Output per instance (TSV): id  k  k_found  ok  T_distinct_plus1  steps  fruitless
 *   T = number of distinct classes generated up to and including the first point whose class
 *       was generated before with a different (a,b)  (the birthday time).
 * Usage: myrho <b_hex> <a2> <mode: none|neg|negtau> <ninst> <seed> <s1> <s2> [selftest]
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <arm_neon.h>

typedef uint64_t u64;
typedef unsigned __int128 u128;

#define NBITS 59
#define FMASK ((1ULL << NBITS) - 1)
#define FTAIL 0x7bULL           /* z^6+z^5+z^4+z^3+z+1 */
#define FPOLY ((1ULL << NBITS) | FTAIL)
static const u64 NORD = 10063074221ULL;
static const u64 COF = 57284756ULL;
#define RB 11
#define RSZ (1 << RB)

static u64 A2, BB;
static int MODE;

/* ---------- F_{2^59} ---------- */
static inline u64 fmul(u64 a, u64 b) {
    u128 p = (u128)vmull_p64((poly64_t)a, (poly64_t)b);
    u64 lo = (u64)p & FMASK;
    u64 hi = (u64)(p >> NBITS);            /* degree <= 57 */
    u128 t = (u128)vmull_p64((poly64_t)hi, (poly64_t)FTAIL);   /* degree <= 63 */
    u64 t0 = (u64)t;
    lo ^= t0 & FMASK;
    u64 h2 = t0 >> NBITS;                  /* degree <= 4 */
    /* h2 * tail has degree <= 10 < 59 */
    u64 r = 0;
    for (int i = 0; i < 5; i++) if ((h2 >> i) & 1) r ^= FTAIL << i;
    return lo ^ r;
}
static inline u64 fsq(u64 a) { return fmul(a, a); }
static inline int pdeg(u64 a) { return a ? 63 - __builtin_clzll(a) : -1; }
static u64 finv(u64 a) {            /* binary EEA: returns a^{-1} mod FPOLY */
    u64 u = a, v = FPOLY, g1 = 1, g2 = 0;
    while (u != 1) {
        int j = pdeg(u) - pdeg(v);
        if (j < 0) { u64 t = u; u = v; v = t; t = g1; g1 = g2; g2 = t; j = -j; }
        u ^= v << j; g1 ^= g2 << j;
    }
    return g1 & FMASK;
}
static u64 ftrace(u64 c) { u64 t = c, x = c; for (int i = 1; i < NBITS; i++) { x = fsq(x); t ^= x; } return t; }
static u64 fhalftrace(u64 c) { u64 t = c, x = c; for (int i = 1; i <= (NBITS - 1) / 2; i++) { x = fsq(fsq(x)); t ^= x; } return t; }

/* ---------- curve ---------- */
typedef struct { u64 x, y; int inf; } Pt;
static Pt padd(Pt P, Pt Q) {
    if (P.inf) return Q; if (Q.inf) return P;
    u64 lam, x3;
    if (P.x == Q.x) {
        if (P.y != Q.y || P.x == 0) { Pt O = {0, 0, 1}; return O; }   /* Q = -P or 2-torsion */
        lam = P.x ^ fmul(P.y, finv(P.x));
        x3 = fsq(lam) ^ lam ^ A2;
        Pt R = {x3, fsq(P.x) ^ fmul(lam ^ 1, x3), 0};
        return R;
    }
    lam = fmul(P.y ^ Q.y, finv(P.x ^ Q.x));
    x3 = fsq(lam) ^ lam ^ P.x ^ Q.x ^ A2;
    Pt R = {x3, fmul(lam, P.x ^ x3) ^ x3 ^ P.y, 0};
    return R;
}
static Pt pneg(Pt P) { Pt R = P; if (!P.inf) R.y = P.x ^ P.y; return R; }
static Pt pmul(Pt P, u64 k) { Pt R = {0, 0, 1}; for (int i = 63; i >= 0; i--) { R = padd(R, R); if ((k >> i) & 1) R = padd(R, P); } return R; }
static int oncurve(Pt P) {
    if (P.inf) return 1;
    u64 l = fsq(P.y) ^ fmul(P.x, P.y), r = fmul(fsq(P.x), P.x) ^ fmul(A2, fsq(P.x)) ^ BB;
    return l == r;
}
static int peq(Pt P, Pt Q) { return (P.inf && Q.inf) || (!P.inf && !Q.inf && P.x == Q.x && P.y == Q.y); }

/* ---------- mod N ---------- */
static inline u64 addn(u64 a, u64 b) { u64 s = a + b; return s >= NORD ? s - NORD : s; }
static inline u64 muln(u64 a, u64 b) { return (u64)(((u128)a * b) % NORD); }
static u64 powmodn(u64 a, u64 e) { u64 r = 1; while (e) { if (e & 1) r = muln(r, a); a = muln(a, a); e >>= 1; } return r; }
static u64 invn(u64 a) { return powmodn(a, NORD - 2); }

/* ---------- rng (splitmix64) ---------- */
static u64 rs;
static u64 rnd(void) { u64 z = (rs += 0x9E3779B97F4A7C15ULL); z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL; return z ^ (z >> 31); }

static Pt randpoint_orderN(void) {
    for (;;) {
        u64 x = rnd() & FMASK; if (!x) continue;
        u64 rhs = fmul(fsq(x), x) ^ fmul(A2, fsq(x)) ^ BB;
        u64 c = fmul(rhs, finv(fsq(x)));
        if (ftrace(c)) continue;
        u64 z = fhalftrace(c);
        Pt P = {x, fmul(x, z), 0};
        if (!oncurve(P)) { fprintf(stderr, "halftrace failure\n"); exit(2); }
        Pt Q = pmul(P, COF);
        if (Q.inf) continue;
        if (!pmul(Q, NORD).inf) { fprintf(stderr, "order check failed\n"); exit(3); }
        return Q;
    }
}

/* ---------- canonical forms ---------- */
static u64 SEIG, SPOW[NBITS];
/* returns multiplier m with canon(P) = m * P */
static inline u64 canon(Pt *P) {
    if (MODE == 0) return 1;
    if (MODE == 1) { u64 y2 = P->x ^ P->y; if (y2 > P->y) { P->y = y2; return NORD - 1; } return 1; }
    /* negtau: largest x^(2^i) */
    u64 x = P->x, bx = x; int bi = 0;
    for (int i = 1; i < NBITS; i++) { x = fsq(x); if (x > bx) { bx = x; bi = i; } }
    u64 y = P->y; for (int i = 0; i < bi; i++) y = fsq(y);
    u64 m = SPOW[bi];
    P->x = bx; P->y = y;
    u64 y2 = bx ^ y; if (y2 > y) { P->y = y2; m = NORD - m; }
    return m;
}

/* ---------- hash table of visited classes ---------- */
#define HBITS 21
#define HCAP (1u << HBITS)
typedef struct { u64 x, y, a, b; uint32_t stamp; } Ent;
static Ent *HT; static uint32_t STAMP = 0;
static inline uint32_t hidx(u64 x, u64 y) { u64 h = (x ^ (y * 0xD6E8FEB86659FD93ULL)); h ^= h >> 31; h *= 0xBF58476D1CE4E5B9ULL; h ^= h >> 29; return (uint32_t)(h & (HCAP - 1)); }
/* returns entry if present, else inserts and returns NULL */
static Ent *lookup_insert(u64 x, u64 y, u64 a, u64 b, u64 *count) {
    uint32_t i = hidx(x, y);
    for (;;) {
        Ent *e = &HT[i];
        if (e->stamp != STAMP) { e->stamp = STAMP; e->x = x; e->y = y; e->a = a; e->b = b; (*count)++; return NULL; }
        if (e->x == x && e->y == y) return e;
        i = (i + 1) & (HCAP - 1);
    }
}

int main(int argc, char **argv) {
    if (argc < 8) { fprintf(stderr, "usage\n"); return 1; }
    BB = strtoull(argv[1], NULL, 16); A2 = strtoull(argv[2], NULL, 10);
    MODE = !strcmp(argv[3], "none") ? 0 : !strcmp(argv[3], "neg") ? 1 : 2;
    int ninst = atoi(argv[4]); rs = strtoull(argv[5], NULL, 10) * 0xA0761D6478BD642FULL + 12345;
    u64 s1 = strtoull(argv[6], NULL, 10), s2 = strtoull(argv[7], NULL, 10);
    int selftest = argc > 8;
    HT = calloc(HCAP, sizeof(Ent));
    if (selftest) {
        /* print test vectors for an external (Sage) check */
        for (int i = 0; i < 5; i++) { u64 a = rnd() & FMASK, b = rnd() & FMASK; printf("mul %llx %llx %llx\n", (unsigned long long)a, (unsigned long long)b, (unsigned long long)fmul(a, b)); printf("inv %llx %llx\n", (unsigned long long)a, (unsigned long long)finv(a)); }
        Pt P = randpoint_orderN(); u64 k = rnd() % NORD; Pt Q = pmul(P, k); Pt R = padd(P, Q); Pt D = padd(P, P);
        printf("pt %llx %llx k %llu kP %llx %llx P+kP %llx %llx 2P %llx %llx\n", (unsigned long long)P.x, (unsigned long long)P.y, (unsigned long long)k,
               (unsigned long long)Q.x, (unsigned long long)Q.y, (unsigned long long)R.x, (unsigned long long)R.y, (unsigned long long)D.x, (unsigned long long)D.y);
        /* full group order check on random points */
        int bad = 0; for (int i = 0; i < 200; i++) { u64 x; Pt X; for (;;) { x = rnd() & FMASK; u64 rhs = fmul(fsq(x), x) ^ fmul(A2, fsq(x)) ^ BB; u64 c = fmul(rhs, finv(fsq(x))); if (!x || ftrace(c)) continue; X.x = x; X.y = fmul(x, fhalftrace(c)); X.inf = 0; break; }
            if (!pmul(pmul(X, COF), NORD).inf) bad++; }
        printf("order_check_bad %d / 200\n", bad);
    }
    /* Frobenius eigenvalue (only meaningful on a curve over F_2) */
    SEIG = 0;
    if (MODE == 2) {
        Pt P = randpoint_orderN(); Pt T = {fsq(P.x), fsq(P.y), 0};
        if (peq(T, pmul(P, s1))) SEIG = s1; else if (peq(T, pmul(P, s2))) SEIG = s2;
        else { fprintf(stderr, "no tau eigenvalue\n"); return 4; }
        SPOW[0] = 1; for (int i = 1; i < NBITS; i++) SPOW[i] = muln(SPOW[i - 1], SEIG);
        if (muln(SPOW[NBITS - 1], SEIG) != 1) { fprintf(stderr, "s^59 != 1\n"); return 5; }
        fprintf(stderr, "tau eigenvalue s = %llu\n", (unsigned long long)SEIG);
    }
    for (int inst = 0; inst < ninst; inst++) {
        STAMP++;
        Pt P = randpoint_orderN();
        u64 k = 1 + rnd() % (NORD - 1);
        Pt Q = pmul(P, k);
        /* fixed-base comb tables */
        Pt TP[36], TQ[36]; TP[0] = P; TQ[0] = Q;
        for (int i = 1; i < 36; i++) { TP[i] = padd(TP[i - 1], TP[i - 1]); TQ[i] = padd(TQ[i - 1], TQ[i - 1]); }
        static Pt R[RSZ]; static u64 RA[RSZ], RBc[RSZ];
        for (int j = 0; j < RSZ; j++) {
            for (;;) {
                u64 a = rnd() % NORD, b = rnd() % NORD; Pt S = {0, 0, 1};
                for (int i = 0; i < 34; i++) { if ((a >> i) & 1) S = padd(S, TP[i]); if ((b >> i) & 1) S = padd(S, TQ[i]); }
                if (S.inf) continue;
                R[j] = S; RA[j] = a; RBc[j] = b; break;
            }
        }
        /* start */
        u64 a, b; Pt X;
        for (;;) {
            a = rnd() % NORD; b = rnd() % NORD; X = (Pt){0, 0, 1};
            for (int i = 0; i < 34; i++) { if ((a >> i) & 1) X = padd(X, TP[i]); if ((b >> i) & 1) X = padd(X, TQ[i]); }
            if (!X.inf) break;
        }
        u64 m = canon(&X); a = muln(a, m); b = muln(b, m);
        u64 count = 0, steps = 1, fruitless = 0, restarts = 0;
        lookup_insert(X.x, MODE ? 0 : X.y, a, b, &count);
        u64 kf = 0; int ok = 0;
        for (;;) {
            uint32_t j = (uint32_t)((X.x * 0x9E3779B97F4A7C15ULL) >> (64 - RB));
            Pt Y = padd(X, R[j]); u64 ya = addn(a, RA[j]), yb = addn(b, RBc[j]);
            steps++;
            if (Y.inf) { restarts++; Y = padd(X, X); ya = addn(a, a); yb = addn(b, b); if (Y.inf) { fprintf(stderr, "inf\n"); return 6; } }
            u64 mm = canon(&Y); ya = muln(ya, mm); yb = muln(yb, mm);
            Ent *e = lookup_insert(Y.x, MODE ? 0 : Y.y, ya, yb, &count);
            if (e) {
                if (e->b == yb && e->a == ya) {        /* fruitless cycle: leave via canon(2Y) */
                    fruitless++;
                    Pt Z = padd(Y, Y); u64 za = addn(ya, ya), zb = addn(yb, yb);
                    u64 m2 = canon(&Z); za = muln(za, m2); zb = muln(zb, m2);
                    steps++;
                    Ent *e2 = lookup_insert(Z.x, MODE ? 0 : Z.y, za, zb, &count);
                    if (e2 && !(e2->b == zb && e2->a == za)) { Y = Z; ya = za; yb = zb; e = e2; goto genuine; }
                    if (e2) { fprintf(stderr, "double fruitless\n"); return 7; }
                    X = Z; a = za; b = zb; continue;
                }
            genuine:
                /* stored: e->a + e->b k == ya + yb k  (same canonical point) */
                if (e->b == yb) { fprintf(stderr, "degenerate\n"); return 8; }
                kf = muln((e->a + NORD - ya) % NORD, invn((yb + NORD - e->b) % NORD));
                ok = peq(pmul(P, kf), Q) && kf == k;
                break;
            }
            X = Y; a = ya; b = yb;
        }
        printf("I%05d\t%llu\t%llu\t%d\t%llu\t%llu\t%llu\t%llu\n", inst, (unsigned long long)k, (unsigned long long)kf, ok,
               (unsigned long long)(count + 1), (unsigned long long)steps, (unsigned long long)fruitless, (unsigned long long)restarts);
        fflush(stdout);
    }
    return 0;
}
