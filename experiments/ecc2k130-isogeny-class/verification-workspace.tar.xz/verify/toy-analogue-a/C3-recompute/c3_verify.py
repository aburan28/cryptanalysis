#!/usr/bin/env python3
"""C3 recompute: independent re-check of every solver row of the toy-analogue-a sweep.

Plain python3 only (no Sage, no toylib, no verify.py).  Own GF(2^n) arithmetic on int bitmasks
(bit i = z^i), own affine arithmetic on y^2 + x y = x^3 + a2 x^2 + b, scalar multiplication by a
width-2 NAF (different algorithm from Sage's generic double-and-add).

Per row (raw/<F>/out/*.tsv):
  - id -> base instance (strip ':tr'); instance exists in raw/<F>/instances.json
  - curve label of the instance == label encoded in the id == label encoded in the file name
  - curve (a2, b) taken from data/<F>_family.json; b != 0; j_int * b_int == 1 in F_q
  - P, Q on the curve; P != O; [N]P == O (so ord P == N, N prime)
  - [k_found]P == Q                         (sage_verified analogue)
  - k_found == k_planted mod N, 0 <= k_found < N  (matches_planted analogue)
  - [k_planted]P == Q (the plant itself is right)
  - tsv k_true column == k_planted mod N
Input files (raw/<F>/inputs/*.txt):
  - every 'inst' line has exactly one tsv row and vice versa
  - direct configs: header (tail, a2, b, N) == family data; inst points/k == instances.json
  - transport configs: header == E0's curve; transported P', Q' on E0; [N]P' == O;
    [k_planted]P' == Q' and [k_found]P' == Q'
Field modulus: x^n + tail irreducibility is proved by own code (n prime: x^(2^n) == x mod f and
f(0) = f(1) = 1).
"""
import json, os, sys, csv, time
from multiprocessing import Pool

WORK = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
OUT = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C3-recompute'


# ---------------------------------------------------------------- GF(2^n) on ints
class Field:
    def __init__(self, n, tail):
        self.n = n
        self.tail = tail
        self.mod = (1 << n) | tail
        self.mask = (1 << n) - 1
        self.tail_bits = [j for j in range(tail.bit_length()) if (tail >> j) & 1]

    def clmul(self, a, b):
        # 4-bit window carry-less multiply
        tab = [0] * 16
        tab[1] = a
        for i in range(2, 16):
            tab[i] = (tab[i >> 1] << 1) if (i & 1) == 0 else (tab[i - 1] ^ a)
        r = 0
        sh = 0
        while b:
            d = b & 15
            if d:
                r ^= tab[d] << sh
            b >>= 4
            sh += 4
        return r

    def red(self, r):
        n = self.n
        while r >> n:
            h = r >> n
            r &= self.mask
            for j in self.tail_bits:
                r ^= h << j
        return r

    def mul(self, a, b):
        return self.red(self.clmul(a, b))

    def sqr(self, a):
        # spread bits (squaring is linear over F_2)
        r = 0
        i = 0
        while a:
            if a & 1:
                r |= 1 << (2 * i)
            a >>= 1
            i += 1
        return self.red(r)

    def inv(self, a):
        # extended Euclid in F_2[x]
        if a == 0:
            raise ZeroDivisionError
        u, v = a, self.mod
        g1, g2 = 1, 0
        while u != 1:
            j = u.bit_length() - v.bit_length()
            if j < 0:
                u, v = v, u
                g1, g2 = g2, g1
                j = -j
            u ^= v << j
            g1 ^= g2 << j
        return self.red(g1)


def polymulmod_generic(a, b, mod):
    """schoolbook F_2[x] multiply mod `mod` (used only for the irreducibility proof)."""
    m = mod.bit_length() - 1
    r = 0
    while b:
        if b & 1:
            r ^= a
        b >>= 1
        a <<= 1
        if (a >> m) & 1:
            a ^= mod
    return r


def is_prime_small(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True


def irreducible_prime_degree(n, tail):
    """x^n + tail over F_2 with n prime: irreducible iff it has no linear factor and
    x^(2^n) == x mod f (then every irreducible factor has degree dividing n, i.e. 1 or n)."""
    assert is_prime_small(n)
    f = (1 << n) | tail
    if (f & 1) == 0:           # f(0) = 0
        return False
    if bin(f).count('1') % 2 == 0:  # f(1) = 0
        return False
    x = 2
    y = x
    for _ in range(n):
        y = polymulmod_generic(y, y, f)
    return y == x


# ---------------------------------------------------------------- curve y^2+xy = x^3+a2 x^2+b
O = None


class Curve:
    def __init__(self, K, a2, b):
        self.K, self.a2, self.b = K, a2, b

    def on(self, P):
        if P is O:
            return True
        K = self.K
        x, y = P
        lhs = K.sqr(y) ^ K.mul(x, y)
        x2 = K.sqr(x)
        rhs = K.mul(x2, x) ^ (x2 if self.a2 else 0) ^ self.b
        return lhs == rhs

    def neg(self, P):
        if P is O:
            return O
        return (P[0], P[0] ^ P[1])

    def dbl(self, P):
        if P is O:
            return O
        K = self.K
        x, y = P
        if x == 0:
            return O
        lam = x ^ K.mul(y, K.inv(x))
        x3 = K.sqr(lam) ^ lam ^ (1 if self.a2 else 0)
        y3 = K.sqr(x) ^ K.mul(lam ^ 1, x3)
        return (x3, y3)

    def add(self, P, Q):
        if P is O:
            return Q
        if Q is O:
            return P
        K = self.K
        x1, y1 = P
        x2, y2 = Q
        if x1 == x2:
            if y1 == y2:
                return self.dbl(P)
            return O  # Q == -P
        lam = K.mul(y1 ^ y2, K.inv(x1 ^ x2))
        x3 = K.sqr(lam) ^ lam ^ x1 ^ x2 ^ (1 if self.a2 else 0)
        y3 = K.mul(lam, x1 ^ x3) ^ x3 ^ y1
        return (x3, y3)

    def mul(self, k, P):
        """[k]P via NAF, left to right."""
        if k < 0:
            return self.mul(-k, self.neg(P))
        naf = []
        while k:
            if k & 1:
                d = 2 - (k & 3)
                k -= d
            else:
                d = 0
            naf.append(d)
            k >>= 1
        R = O
        nP = self.neg(P)
        for d in reversed(naf):
            R = self.dbl(R)
            if d == 1:
                R = self.add(R, P)
            elif d == -1:
                R = self.add(R, nP)
        return R


# ---------------------------------------------------------------- data loading
def load_family(F):
    fam = json.load(open(os.path.join(WORK, 'data', f'{F}_family.json')))
    inst = json.load(open(os.path.join(WORK, 'raw', F, 'instances.json')))
    return fam, inst


def parse_input(path):
    hdr = {}
    insts = []
    with open(path) as fh:
        for line in fh:
            p = line.split()
            if not p:
                continue
            if p[0] == 'inst':
                insts.append((p[1], int(p[2], 16), int(p[3], 16), int(p[4], 16), int(p[5], 16), int(p[6])))
            else:
                hdr[p[0]] = p[1]
    return hdr, insts


def check_config(args):
    F, cfg = args
    fam, inst = load_family(F)
    meta = fam['meta']
    n = int(meta['n'])
    tail = int(meta['modulus_tail'])
    N = int(meta['N'])
    K = Field(n, tail)
    curves = {}

    def curve(lab):
        if lab not in curves:
            c = fam['curves'][lab]
            curves[lab] = Curve(K, int(c['a2']), int(c['b_int']))
        return curves[lab]

    cur_lab, mode = cfg.split('__')
    transport = mode.startswith('transport')
    # tsv rows
    rows = list(csv.DictReader(open(os.path.join(WORK, 'raw', F, 'out', cfg + '.tsv')), delimiter='\t'))
    hdr, insts = parse_input(os.path.join(WORK, 'raw', F, 'inputs', cfg + '.txt'))
    r = dict(rows=len(rows), my_kP_eq_Q=0, my_match_planted=0, my_plant_ok=0, P_order_N=0,
             P_Q_on_curve=0, label_consistent=0, ktrue_col_ok=0, kfound_in_range=0,
             tsv_verified_flag=0, tsv_match_flag=0,
             input_lines=len(insts), input_rows_bijection=None, input_header_ok=None,
             input_points_ok=0, transported_kP_eq_Q=0, transported_plant_ok=0, transported_on_E0_orderN=0,
             distinct_base_ids=0, failures=[])
    ids_rows = [row['id'] for row in rows]
    ids_in = [t[0] for t in insts]
    r['input_rows_bijection'] = (sorted(ids_rows) == sorted(ids_in) and len(set(ids_rows)) == len(ids_rows))
    # header check
    E0c = fam['curves']['E0']
    hdr_lab = 'E0' if transport else cur_lab
    hc = fam['curves'][hdr_lab]
    r['input_header_ok'] = (int(hdr['n']) == n and int(hdr['tail'], 16) == tail and int(hdr['a2']) == int(hc['a2'])
                            and int(hdr['b'], 16) == int(hc['b_int']) and int(hdr['N']) == N)
    in_by_id = {t[0]: t for t in insts}
    bases = set()
    for row in rows:
        iid = row['id']
        base = iid[:-3] if iid.endswith(':tr') else iid
        fails = []
        if transport != iid.endswith(':tr'):
            fails.append('tr-suffix')
        rec = inst.get(base)
        if rec is None:
            r['failures'].append((iid, 'no-instance'))
            continue
        bases.add(base)
        lab = rec['curve']
        id_lab = base.split(':')[1]
        if lab == id_lab == cur_lab and base.split(':')[0] == F:
            r['label_consistent'] += 1
        else:
            fails.append('label')
        E = curve(lab)
        c = fam['curves'][lab]
        if E.b == 0 or K.mul(int(c['j_int']), E.b) != 1:
            fails.append('j*b!=1')
        P = (int(rec['P'][0]), int(rec['P'][1]))
        Q = (int(rec['Q'][0]), int(rec['Q'][1]))
        kp = int(rec['k'])
        kf = int(row['k_found'])
        if E.on(P) and E.on(Q):
            r['P_Q_on_curve'] += 1
        else:
            fails.append('not-on-curve')
        if E.mul(N, P) is O:
            r['P_order_N'] += 1
        else:
            fails.append('ordP')
        if E.mul(kf, P) == Q:
            r['my_kP_eq_Q'] += 1
        else:
            fails.append('kfP!=Q')
        if kf == kp % N:
            r['my_match_planted'] += 1
        else:
            fails.append('kf!=kplanted')
        if 0 <= kf < N:
            r['kfound_in_range'] += 1
        if E.mul(kp, P) == Q:
            r['my_plant_ok'] += 1
        else:
            fails.append('plant')
        if int(row['k_true']) == kp % N:
            r['ktrue_col_ok'] += 1
        else:
            fails.append('ktrue-col')
        r['tsv_verified_flag'] += int(row['verified'])
        r['tsv_match_flag'] += int(row['match'])
        # input-file cross-checks
        t = in_by_id.get(iid)
        if t is None:
            fails.append('no-input-line')
        else:
            _, px, py, qx, qy, kin = t
            if not transport:
                if (px, py) == P and (qx, qy) == Q and kin == kp:
                    r['input_points_ok'] += 1
                else:
                    fails.append('input-points')
            else:
                E0 = curve('E0')
                P2, Q2 = (px, py), (qx, qy)
                if kin == kp:
                    r['input_points_ok'] += 1
                else:
                    fails.append('input-k')
                if E0.on(P2) and E0.on(Q2) and P2 is not O and E0.mul(N, P2) is O:
                    r['transported_on_E0_orderN'] += 1
                else:
                    fails.append('tr-pts')
                if E0.mul(kp, P2) == Q2:
                    r['transported_plant_ok'] += 1
                else:
                    fails.append('tr-plant')
                if E0.mul(kf, P2) == Q2:
                    r['transported_kP_eq_Q'] += 1
                else:
                    fails.append('tr-kfP')
        if fails:
            r['failures'].append((iid, fails))
    r['distinct_base_ids'] = len(bases)
    r['_bases'] = sorted(bases)
    return F, cfg, r


def main():
    fams = sys.argv[1:] or ['T11', 'T19', 'T23', 'T59', 'T109']
    t0 = time.time()
    jobs = []
    field_checks = {}
    for F in fams:
        fam = json.load(open(os.path.join(WORK, 'data', f'{F}_family.json')))
        meta = fam['meta']
        n, tail = int(meta['n']), int(meta['modulus_tail'])
        # modulus string check
        terms = [f'x^{n}'] + [('x^%d' % j if j > 1 else ('x' if j == 1 else '1'))
                              for j in reversed(range(tail.bit_length())) if (tail >> j) & 1]
        field_checks[F] = dict(n=n, tail=tail, modulus_string_matches=(' + '.join(terms) == meta['modulus']),
                               irreducible=irreducible_prime_degree(n, tail),
                               N_prime_trial_division=is_prime_small(int(meta['N'])))
        print(F, field_checks[F], flush=True)
        for fn in sorted(os.listdir(os.path.join(WORK, 'raw', F, 'out'))):
            if fn.endswith('.tsv'):
                jobs.append((F, fn[:-4]))
    # biggest first
    res = {}
    with Pool(12) as pool:
        for F, cfg, r in pool.imap_unordered(check_config, jobs):
            res.setdefault(F, {})[cfg] = r
            print(F, cfg, {k: v for k, v in r.items() if k not in ('failures', '_bases')},
                  'fail:', r['failures'][:3], flush=True)
    summary = {}
    for F in fams:
        inst = json.load(open(os.path.join(WORK, 'raw', F, 'instances.json')))
        tot = {}
        allb = set()
        for cfg, r in res[F].items():
            for k, v in r.items():
                if isinstance(v, bool):
                    tot[k] = tot.get(k, True) and v
                elif isinstance(v, int):
                    tot[k] = tot.get(k, 0) + v
            allb.update(r['_bases'])
        tot['n_failures'] = sum(len(r['failures']) for r in res[F].values())
        tot['distinct_planted_instances_solved'] = len(allb)
        tot['instances_json_entries'] = len(inst)
        tot['instances_never_run'] = len(set(inst) - allb)
        summary[F] = dict(field=field_checks[F], total=tot,
                          per_config={c: {k: v for k, v in r.items() if k != '_bases'} for c, r in sorted(res[F].items())})
        print('TOTAL', F, tot, flush=True)
    grand = {}
    for F in fams:
        for k, v in summary[F]['total'].items():
            if isinstance(v, int) and not isinstance(v, bool):
                grand[k] = grand.get(k, 0) + v
    summary['_grand'] = grand
    summary['_elapsed_s'] = time.time() - t0
    print('GRAND', grand, 'elapsed', time.time() - t0)
    tag = '_'.join(fams) if sys.argv[1:] else 'all'
    json.dump(summary, open(os.path.join(OUT, f'c3_result_{tag}.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
