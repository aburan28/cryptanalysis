"""Self-test of the own GF(2^n)/EC code in c3_verify.py (plain python3)."""
import random, json, sys
sys.path.insert(0, '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C3-recompute')
from c3_verify import Field, Curve, O, irreducible_prime_degree, polymulmod_generic
random.seed(7)
# field axioms vs schoolbook
for n, tail in [(11, 5), (19, 39), (23, 33), (59, 123), (109, 53), (131, (1<<13)|7)]:
    K = Field(n, tail)
    for _ in range(300):
        a, b, c = (random.getrandbits(n) for _ in range(3))
        assert K.mul(a, b) == polymulmod_generic(a, b, K.mod)
        assert K.sqr(a) == K.mul(a, a)
        assert K.mul(a, b ^ c) == K.mul(a, b) ^ K.mul(a, c)
        if a:
            assert K.mul(a, K.inv(a)) == 1
    print('field ok', n, tail, 'irreducible:', irreducible_prime_degree(n, tail))
# a reducible one must be rejected: x^11 + x + 1? (check it is found reducible or not consistently by brute force for n=11)
def brute_irred(n, tail):
    f = (1 << n) | tail
    for g in range(2, 1 << (n // 2 + 1)):
        if g.bit_length() - 1 < 1: continue
        # poly division
        r = f
        while r.bit_length() >= g.bit_length():
            r ^= g << (r.bit_length() - g.bit_length())
        if r == 0: return False
    return True
for tail in range(1, 64, 2):
    assert brute_irred(11, tail) == irreducible_prime_degree(11, tail), tail
print('irreducibility test agrees with brute force for all odd tails < 64, n = 11')
# brute-force point count for T11 E0 and a floor curve vs family data
fam = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/data/T11_family.json'))
K = Field(11, 5)
for lab in ['E0', 'O00-000', 'O01-005']:
    c = fam['curves'][lab]
    E = Curve(K, c['a2'], c['b_int'])
    cnt = 1 + sum(1 for x in range(2048) for y in range(2048) if E.on((x, y)))
    print(lab, 'brute #E =', cnt, 'family order_pari =', c.get('order_pari', fam['meta']['card']))
    # group law: [a]P+[b]P == [a+b]P, and [#E]P == O
    pts = [(x, y) for x in range(1, 2048, 97) for y in range(2048) if E.on((x, y))][:20]
    for P in pts:
        a, b = random.randrange(1, 5000), random.randrange(1, 5000)
        assert E.add(E.mul(a, P), E.mul(b, P)) == E.mul(a + b, P)
        assert E.mul(cnt, P) is O
        assert E.add(P, E.neg(P)) is O
print('group law self-test ok')
