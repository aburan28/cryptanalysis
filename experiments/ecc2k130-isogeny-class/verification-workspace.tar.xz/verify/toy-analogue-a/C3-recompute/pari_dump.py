"""Dump every tsv row (with the planted instance's curve/points) as a GP vector per line, for the
independent PARI ellmul cross-check (pari_check.gp).  plain python3."""
import json, os, csv
WORK = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
OUT = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C3-recompute/pari_in'
os.makedirs(OUT, exist_ok=True)
for F in ['T11', 'T19', 'T23', 'T59', 'T109']:
    fam = json.load(open(os.path.join(WORK, 'data', f'{F}_family.json')))
    inst = json.load(open(os.path.join(WORK, 'raw', F, 'instances.json')))
    meta = fam['meta']
    n, tail, N = int(meta['n']), int(meta['modulus_tail']), int(meta['N'])
    rows = 0
    with open(os.path.join(OUT, f'{F}.gp'), 'w') as fo:
        for fn in sorted(os.listdir(os.path.join(WORK, 'raw', F, 'out'))):
            if not fn.endswith('.tsv'):
                continue
            for row in csv.DictReader(open(os.path.join(WORK, 'raw', F, 'out', fn)), delimiter='\t'):
                iid = row['id']
                base = iid[:-3] if iid.endswith(':tr') else iid
                rec = inst[base]
                c = fam['curves'][rec['curve']]
                fo.write('[%d,%d,%d,%d,%d,%d,%d,%d]\n' % (int(c['a2']), int(c['b_int']), rec['P'][0], rec['P'][1],
                                                          rec['Q'][0], rec['Q'][1], int(row['k_found']), int(rec['k'])))
                rows += 1
    with open(os.path.join(OUT, f'{F}.hdr'), 'w') as fo:
        fo.write('[%d,%d,%d]\n' % (n, tail, N))
    print(F, rows)
