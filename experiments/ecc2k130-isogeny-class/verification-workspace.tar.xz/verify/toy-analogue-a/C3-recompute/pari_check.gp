\\ PARI/GP cross-check: for each row, ellisoncurve for P,Q; ellmul(E,P,N)==[0]; ellmul(E,P,kf)==Q; kf==kp mod N.
\\ usage: gp -q -D fam=T59 pari_check.gp  (fam passed through env via read of a file below)
checkfam(F) =
{
  my(h = readvec(Str("pari_in/", F, ".hdr"))[1], n = h[1], tail = h[2], N = h[3]);
  my(T = Mod(1,2) * Pol(binary(2^n + tail)), g = ffgen(T, 'z));
  if (!polisirreducible(T), error("modulus reducible"));
  my(pw = vector(n, i, g^(i-1)));
  my(toff = v -> my(b = binary(v), s = 0*g, L = #b); for (i = 1, L, if (b[L+1-i], s += pw[i])); s);
  my(V = readvec(Str("pari_in/", F, ".gp")));
  my(cache = Map(), cnt = vector(6));
  for (r = 1, #V,
    my(w = V[r], key = [w[1], w[2]], E);
    if (mapisdefined(cache, key, &E), , E = ellinit([1, w[1]*g^0, 0, 0, toff(w[2])]); mapput(cache, key, E));
    my(P = [toff(w[3]), toff(w[4])], Q = [toff(w[5]), toff(w[6])]);
    cnt[1]++;
    if (ellisoncurve(E, P) && ellisoncurve(E, Q), cnt[2]++);
    if (ellmul(E, P, N) == [0] && P != [0], cnt[3]++);
    if (ellmul(E, P, w[7]) == Q, cnt[4]++);
    if (w[7] == w[8] % N, cnt[5]++);
    if (ellmul(E, P, w[8]) == Q, cnt[6]++);
  );
  print(F, " rows=", cnt[1], " onCurve=", cnt[2], " ordP=N:", cnt[3], " kfP==Q:", cnt[4], " kf==kp mod N:", cnt[5], " kpP==Q:", cnt[6], " distinct curves=", #cache);
  cnt
}
res = vector(5, i, checkfam(["T11","T19","T23","T59","T109"][i]));
print("TOTAL rows=", sum(i=1,5,res[i][1]), " kfP==Q:", sum(i=1,5,res[i][4]), " match:", sum(i=1,5,res[i][5]));
quit
