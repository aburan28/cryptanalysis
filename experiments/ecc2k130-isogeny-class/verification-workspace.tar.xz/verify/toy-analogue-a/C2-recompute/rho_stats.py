# Summarise my own rho runs: transported (iii') vs native (ii') on E0 with negation+tau.
import math, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
Ns = {'T11': 991, 'T19': 262543, 'T23': 2095853, 'T59': 10063074221}
nn = {'T11': 11, 'T19': 19, 'T23': 23, 'T59': 59}
def load(tag):
    p = f'{HERE}/rho/out/{tag}.tsv'
    rows, bad = [], 0
    if not os.path.exists(p): return None, None
    for line in open(p):
        f = line.split()
        if len(f) != 8: bad += 1; continue
        rows.append(dict(id=f[0], ok=int(f[3]), steps=int(f[4]), merge=int(f[5]), walks=int(f[6]), ab=int(f[7])))
    return rows, bad
def ms(v):
    n = len(v); m = sum(v) / n; sd = math.sqrt(sum((x - m)**2 for x in v) / (n - 1)); return n, m, sd
res = {}
for F in ['T11', 'T19', 'T23', 'T59']:
    nat, bn = load(f'{F}_native'); tr, bt = load(f'{F}_transported')
    if not nat or not tr: continue
    r = dict(native_solves=len(nat), transported_solves=len(tr), bad_lines=(bn, bt),
             native_all_correct=all(x['ok'] for x in nat), transported_all_correct=all(x['ok'] for x in tr),
             theory_merge=math.sqrt(math.pi * Ns[F] / (2 * 2 * nn[F])))
    for col in ('merge', 'steps'):
        n1, m1, s1 = ms([x[col] for x in tr]); n2, m2, s2 = ms([x[col] for x in nat])
        R = m1 / m2; se = R * math.sqrt((s1 / m1)**2 / n1 + (s2 / m2)**2 / n2)
        r[col] = dict(mean_transported=m1, mean_native=m2, ratio=R, se=se, z=(R - 1) / se)
    r['abandoned'] = (sum(x['ab'] for x in nat), sum(x['ab'] for x in tr))
    res[F] = r
    print(F, 'solves nat/tr', len(nat), len(tr), 'correct', r['native_all_correct'], r['transported_all_correct'],
          'merge ratio %.4f +- %.4f (z %.2f)' % (r['merge']['ratio'], r['merge']['se'], r['merge']['z']),
          'means %.1f / %.1f theory %.1f' % (r['merge']['mean_transported'], r['merge']['mean_native'], r['theory_merge']),
          'steps ratio %.4f +- %.4f' % (r['steps']['ratio'], r['steps']['se']), 'abandoned', r['abandoned'])
json.dump(res, open(f'{HERE}/rho_stats.json', 'w'), indent=1)
