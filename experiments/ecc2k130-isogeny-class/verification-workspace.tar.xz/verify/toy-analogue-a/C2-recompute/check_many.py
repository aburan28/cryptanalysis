# Run check.py for many (family, label) pairs in one Sage process.
import sys, runpy, os
HERE = os.path.dirname(os.path.abspath(__file__))
pairs = [l.split() for l in open(sys.argv[1]) if l.strip()]
extra = sys.argv[2:]
for fam, lab in pairs:
    sys.argv = ['check.py', fam, lab] + extra
    try:
        runpy.run_path(os.path.join(HERE, 'check.py'), run_name='__main__')
    except (SystemExit, Exception) as e:
        print("ERROR", fam, lab, repr(e), flush=True)
        pass
