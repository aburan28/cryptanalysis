# Dump GP-readable inputs for one (family, floor curve).  Own code; reads only data/ and raw/instances.json.
import json, sys, os
fam, lab, nsub = sys.argv[1], sys.argv[2], int(sys.argv[3])   # nsub = #instances for definitional Velu (-1 = all)
W = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
D = json.load(open(f'{W}/data/{fam}_family.json'))
m = D['meta']
inst = json.load(open(f'{W}/raw/{fam}/instances.json'))
rows = [(iid, r) for iid, r in inst.items() if r['curve'] == lab and 'P_E0' in r]
rows.sort()
c = D['curves'][lab]
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'jobs', fam)
os.makedirs(out, exist_ok=True)
modpoly = m['modulus'].replace('x', 'y')
sub = rows if nsub < 0 else rows[:nsub]
with open(f'{out}/{lab}.in.gp', 'w') as fh:
    fh.write(f'FAM="{fam}"; LAB="{lab}"; NN={m["n"]}; AA={m["a"]}; LL={m["l"]}; MODP=Mod(1,2)*({modpoly});\n')
    fh.write(f'BF={c["b_int"]}; A2F={c["a2"]};\n')
    fh.write('INST=[' + ','.join(f'["{iid}",{r["P"][0]},{r["P"][1]},{r["Q"][0]},{r["Q"][1]},{r["k"]}]' for iid, r in sub) + '];\n')
    fh.write(f'OUTF="{out}/{lab}.out";\n')
print(fam, lab, 'transported rows', len(rows), 'definitional subset', len(sub))
