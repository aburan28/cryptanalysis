# GP input for the x-only check: psi from MY GP run (jobs/T59/<lab>.out) + all stored transported pairs.
import json, sys, os
fam, lab = sys.argv[1], sys.argv[2]
HERE = os.path.dirname(os.path.abspath(__file__))
W = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
D = json.load(open(f'{W}/data/{fam}_family.json')); m = D['meta']
G = json.loads(open(f'{HERE}/jobs/{fam}/{lab}.out').read().replace('\n', ''))
inst = json.load(open(f'{W}/raw/{fam}/instances.json'))
rows = sorted((iid, r) for iid, r in inst.items() if r['curve'] == lab and 'P_E0' in r)
c = D['curves'][lab]
with open(f'{HERE}/jobs/{fam}/{lab}.xonly.in.gp', 'w') as fh:
    fh.write(f'FAM="{fam}"; LAB="{lab}"; NN={m["n"]}; AA={m["a"]}; MODP=Mod(1,2)*({m["modulus"].replace("x", "y")}); BF={c["b_int"]}; A2F={c["a2"]}; NBIG={G["N"]};\n')
    fh.write('PSI=[' + ','.join(str(v) for v in G['psi']) + '];\n')
    fh.write('INST=[' + ','.join(f'["{iid}",{r["P"][0]},{r["P"][1]},{r["Q"][0]},{r["Q"][1]},{r["k"]},{r["P_E0"][0]},{r["P_E0"][1]},{r["Q_E0"][0]},{r["Q_E0"][1]}]' for iid, r in rows) + '];\n')
    fh.write(f'OUTF="{HERE}/jobs/{fam}/{lab}.xonly.out";\n')
print(fam, lab, len(rows))
