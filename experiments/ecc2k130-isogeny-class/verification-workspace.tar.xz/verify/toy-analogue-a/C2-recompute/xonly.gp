\\ x-only image of the ascending isogeny from MY kernel polynomial psi (built in velu_def.gp):
\\ pairing Q with -Q in Velu's definitional sum, x(P+Q) + x(P-Q) = x_P x_Q / (x_P + x_Q)^2 in char 2, so
\\ X(P) = x + x*e1 + x^2*e1^2 with e1 = sum 1/(x + x_Q) = psi'(x)/psi(x).  Checks every stored pair.
default(parisizemax, 2*10^9);
z = ffgen(MODP, 'z);
fromint(v) = if(v == 0, 0*z, subst(Pol(binary(v)), 'x, z));
kpsi = Pol(apply(fromint, PSI), 'X); dpsi = deriv(kpsi);
E0K = ellinit([1, AA, 0, 0, 1], z); EfK = ellinit([1, A2F, 0, 0, fromint(BF)], z);
Xmap(x) = my(e1 = subst(dpsi, 'X, x) / subst(kpsi, 'X, x)); x + x*e1 + x^2*e1^2;
nP = 0; nQ = 0; nlog = 0; nvalid = 0; nmyx = 0;
{for(j = 1, #INST, my(r = INST[j], P, Q, PE, QE, XP, XQ, Yr);
  P = [fromint(r[2]), fromint(r[3])]; Q = [fromint(r[4]), fromint(r[5])];
  PE = [fromint(r[7]), fromint(r[8])]; QE = [fromint(r[9]), fromint(r[10])];
  nvalid += (ellisoncurve(EfK, P) && ellmul(EfK, P, r[6]) == Q && ellisoncurve(E0K, PE) && ellisoncurve(E0K, QE));
  XP = Xmap(P[1]); XQ = Xmap(Q[1]);
  nP += (XP == PE[1]); nQ += (XQ == QE[1]);
  nlog += (ellmul(E0K, PE, r[6]) == QE && ellmul(E0K, PE, NBIG) == [0] && PE != [0]);
  \\ my own images: take either y over XP; x([k] myP) must equal XQ (log preserved up to sign by my map)
  Yr = ellordinate(E0K, XP); nmyx += (#Yr > 0 && ellmul(E0K, [XP, Yr[1]], r[6])[1] == XQ));}
write(OUTF, "{\"family\":\"", FAM, "\",\"label\":\"", LAB, "\",\"n\":", #INST, ",\"stored_instances_valid\":", nvalid, ",\"x_P_E0_match\":", nP, ",\"x_Q_E0_match\":", nQ, ",\"stored_log_preserved\":", nlog, ",\"my_x_log_preserved\":", nmyx, "}");
print(FAM, " ", LAB, " n=", #INST, " valid=", nvalid, " xP=", nP, " xQ=", nQ, " log=", nlog, " myx=", nmyx);
quit;
