/* Independent Pollard rho (own code) on E: y^2 + xy = x^3 + a2 x^2 + b over GF(2^n), n <= 63,
   in the order-N subgroup, with class = {+-tau^i R} (mode 2) or {+-R} (mode 1) or none (mode 0).
   r-adding walk with look-ahead against 2-cycles, distinguished points, serial simulation of
   parallel collision search.  Reports total steps and steps-until-merge (by retracing).
   stdin: header lines  "n a2 b tail N s mode rbits dpbits seed reps"  then per instance
          "id Px Py Qx Qy k"   (hex coords, decimal k).
   stdout: id rep k_found ok steps merge_steps walks abandoned                         */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <arm_neon.h>
typedef uint64_t fe; typedef unsigned __int128 u128;
static int n; static fe tail, mask, A2, B;
static uint64_t N, S; static int mode, rbits, dpbits, maxwalkmul = 16;
static inline u128 clmul(uint64_t a, uint64_t b){ poly128_t r = vmull_p64((poly64_t)a,(poly64_t)b); return (u128)r; }
static inline fe red(u128 v){
  for(int it=0; it<3; it++){ u128 hi = v >> n; if(!hi) break; v = (v & mask) ^ clmul((uint64_t)hi, tail); }
  return (fe)v; }
static inline fe mul(fe a, fe b){ return red(clmul(a,b)); }
static inline fe sqr(fe a){ return red(clmul(a,a)); }
static fe inv(fe a){ /* a^(2^n - 2) */ fe r = 1, x = a; for(int i=1;i<n;i++){ x = sqr(x); r = mul(r, x);} return r; }
typedef struct { fe x, y; int inf; } pt;
static inline pt padd(pt P, pt Q){
  pt R; if(P.inf) return Q; if(Q.inf) return P;
  if(P.x == Q.x){ if(P.y != Q.y || P.x == 0){ R.inf = 1; R.x = R.y = 0; return R; }
    fe l = P.x ^ mul(P.y, inv(P.x)); R.x = sqr(l) ^ l ^ A2; R.y = sqr(P.x) ^ mul(l ^ 1, R.x); R.inf = 0; return R; }
  fe l = mul(P.y ^ Q.y, inv(P.x ^ Q.x)); R.x = sqr(l) ^ l ^ P.x ^ Q.x ^ A2; R.y = mul(l, P.x ^ R.x) ^ R.x ^ P.y; R.inf = 0; return R; }
static pt pmul(pt P, uint64_t k){ pt R = {0,0,1}; while(k){ if(k&1) R = padd(R,P); P = padd(P,P); k >>= 1; } return R; }
static int oncurve(pt P){ if(P.inf) return 1; fe x=P.x,y=P.y; return (sqr(y)^mul(x,y)) == (mul(sqr(x),x)^mul(A2,sqr(x))^B); }
static inline uint64_t mulmod(uint64_t a, uint64_t b){ return (uint64_t)((u128)a*b % N); }
static uint64_t powmod(uint64_t a, uint64_t e){ uint64_t r=1; while(e){ if(e&1) r=mulmod(r,a); a=mulmod(a,a); e>>=1;} return r; }
static uint64_t invmod(uint64_t a){ return powmod(a, N-2); } /* N prime */
static uint64_t spow[64];
static pt Ptab[64], Qtab[64];
static void mktab(pt P, pt *tab){ for(int i=0;i<64;i++){ tab[i] = P; P = padd(P,P); } }
static pt tmul(pt *tab, uint64_t k){ pt R = {0,0,1}; for(int i=0; k; i++, k >>= 1) if(k&1) R = padd(R, tab[i]); return R; }
static inline pt comb(uint64_t a, uint64_t b){ return padd(tmul(Ptab,a), tmul(Qtab,b)); }
typedef struct { pt P; uint64_t a, b; } st;
static inline void canon(st *s){
  if(mode == 2){ fe x = s->P.x, best = x; int bi = 0; for(int i=1;i<n;i++){ x = sqr(x); if(x < best){ best = x; bi = i; } }
    if(bi){ fe y = s->P.y; for(int i=0;i<bi;i++) y = sqr(y); s->P.x = best; s->P.y = y; s->a = mulmod(s->a, spow[bi]); s->b = mulmod(s->b, spow[bi]); } }
  if(mode >= 1){ fe y2 = s->P.x ^ s->P.y; if(y2 < s->P.y){ s->P.y = y2; s->a = s->a ? N - s->a : 0; s->b = s->b ? N - s->b : 0; } } }
static inline uint64_t mix(uint64_t z){ z += 0x9e3779b97f4a7c15ULL; z = (z ^ (z>>30)) * 0xbf58476d1ce4e5b9ULL; z = (z ^ (z>>27)) * 0x94d049bb133111ebULL; return z ^ (z>>31); }
static uint64_t rng; static inline uint64_t rnd(void){ rng += 0x9e3779b97f4a7c15ULL; return mix(rng); }
static uint64_t rndN(void){ return (uint64_t)(((u128)rnd() << 64 | rnd()) % N); }
static int R_; static pt *M; static uint64_t *Mc, *Md;
/* one step with look-ahead: choose the first j (cyclically from h(R)) with h(canon(R+M_j)) != j */
static inline void step(st *s){
  uint32_t j0 = (uint32_t)(mix(s->P.x) & (R_-1)); st t;
  for(int d=0; d<R_; d++){ uint32_t j = (j0 + d) & (R_-1);
    t.P = padd(s->P, M[j]); t.a = s->a + Mc[j]; if(t.a >= N) t.a -= N; t.b = s->b + Md[j]; if(t.b >= N) t.b -= N;
    if(t.P.inf){ continue; } canon(&t);
    if((mix(t.P.x) & (R_-1)) != j || d == R_-1){ *s = t; return; } }
  *s = t; }
static inline int isdp(fe x){ return ((mix(x) >> 32) & ((1ULL<<dpbits)-1)) == 0; }
/* DP table: open addressing */
typedef struct { fe x, y; uint64_t a, b, a0, b0, len; int used; } dp_t;
static dp_t *H; static size_t HS;
int main(int argc, char **argv){
  uint64_t seed; int reps; unsigned long long bb, tt;
  if(scanf("%d %llx %llx %llx %llu %llu %d %d %d %llu %d", &n, (unsigned long long*)&A2, &bb, &tt, (unsigned long long*)&N, (unsigned long long*)&S, &mode, &rbits, &dpbits, (unsigned long long*)&seed, &reps) != 11){ fprintf(stderr,"bad header\n"); return 1; }
  B = bb; tail = tt; mask = (n == 64) ? ~0ULL : ((1ULL<<n)-1);
  R_ = 1 << rbits; M = malloc(sizeof(pt)*R_); Mc = malloc(8*R_); Md = malloc(8*R_);
  HS = 1<<16; H = calloc(HS, sizeof(dp_t));
  spow[0] = 1 % N; for(int i=1;i<n;i++) spow[i] = mulmod(spow[i-1], S % N);
  char id[256]; unsigned long long px, py, qx, qy, kk;
  while(scanf("%255s %llx %llx %llx %llx %llu", id, &px, &py, &qx, &qy, &kk) == 6){
    pt P = {px, py, 0}, Q = {qx, qy, 0};
    if(!oncurve(P) || !oncurve(Q)){ printf("%s BADPOINT\n", id); continue; }
    pt t1 = pmul(P, N), t2 = pmul(P, kk);
    int good = t1.inf && !(t2.inf) && t2.x == Q.x && t2.y == Q.y;
    if(mode == 2){ pt tp = {sqr(P.x), sqr(P.y), 0}, sp = pmul(P, S); good = good && sp.x == tp.x && sp.y == tp.y; }
    if(!good){ printf("%s BADINSTANCE\n", id); continue; }
    mktab(P, Ptab); mktab(Q, Qtab);
    for(int rep=0; rep<reps; rep++){
      rng = seed ^ mix(rep*0x1000193ULL + 17); for(char *c=id; *c; c++) rng = mix(rng ^ (uint64_t)*c);
      for(int j=0;j<R_;j++){ do { Mc[j] = rndN(); Md[j] = rndN(); M[j] = comb(Mc[j], Md[j]); } while(M[j].inf); }
      memset(H, 0, HS*sizeof(dp_t));
      uint64_t steps = 0, walks = 0, abandoned = 0, maxlen = (uint64_t)maxwalkmul << dpbits, merge_steps = 0; int solved = 0; uint64_t kf = 0;
      while(!solved){
        st s; s.a = rndN(); s.b = rndN(); s.P = comb(s.a, s.b); if(s.P.inf) continue; canon(&s);
        uint64_t a0 = s.a, b0 = s.b, len = 0; walks++;
        uint64_t before = steps;
        while(!isdp(s.P.x) && len < maxlen){ step(&s); len++; steps++; }
        if(len >= maxlen){ abandoned++; continue; }
        size_t h = mix(s.P.x ^ (s.P.y<<1)) & (HS-1);
        while(H[h].used && !(H[h].x == s.P.x && H[h].y == s.P.y)) h = (h+1) & (HS-1);
        if(!H[h].used){ H[h] = (dp_t){s.P.x, s.P.y, s.a, s.b, a0, b0, len, 1}; continue; }
        /* collision: a1 P + b1 Q == a2 P + b2 Q */
        uint64_t db = (H[h].b + N - s.b) % N;
        if(db == 0){ continue; } /* degenerate */
        kf = mulmod((s.a + N - H[h].a) % N, invmod(db));
        /* retrace to find the merge point of the two trails */
        st u, v; u.a = H[h].a0; u.b = H[h].b0; u.P = comb(u.a, u.b); canon(&u);
        v.a = a0; v.b = b0; v.P = comb(v.a, v.b); canon(&v);
        uint64_t lu = H[h].len, lv = len, iv = 0;
        while(lu > lv){ step(&u); lu--; } while(lv > lu){ step(&v); lv--; iv++; }
        while(!(u.P.x == v.P.x && u.P.y == v.P.y)){ step(&u); step(&v); iv++; }
        merge_steps = before + iv; solved = 1;
      }
      printf("%s %d %llu %d %llu %llu %llu %llu\n", id, rep, (unsigned long long)kf, kf == kk, (unsigned long long)steps, (unsigned long long)merge_steps, (unsigned long long)walks, (unsigned long long)abandoned);
      fflush(stdout);
    }
  }
  return 0; }
