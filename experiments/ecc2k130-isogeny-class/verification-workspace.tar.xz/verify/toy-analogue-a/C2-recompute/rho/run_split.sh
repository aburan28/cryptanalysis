#!/bin/bash
# usage: run_split.sh <input file> <tag> <nproc>   (splits instances across processes, keeps header)
IN=$1; TAG=$2; NP=$3; D=$(dirname $0)
head -1 $IN > $D/in/$TAG.hdr; tail -n +2 $IN > $D/in/$TAG.body
gsplit -n l/$NP $D/in/$TAG.body $D/in/$TAG.part_
for p in $D/in/$TAG.part_*; do
  b=$(basename $p)
  ( cat $D/in/$TAG.hdr $p | timeout 2400 $D/myrho > $D/out/$b.out 2> $D/out/$b.err ) &
done
wait
cat $D/out/$TAG.part_*.out > $D/out/$TAG.tsv
echo done > $D/out/$TAG.done
