\\ Independent ascending-isogeny recomputation (PARI/GP only; no code shared with the sweep).
\\ Kernel: the Frobenius-stable l-line of the floor curve, found as a point of order l over
\\ L = F_{q^k}, k = ord(t/2 mod l).  Map: Velu's DEFINITIONAL sums
\\   X(P) = x_P + sum_{Q in K\{0}} (x(P+Q) - x(Q)),  Y(P) = y_P + sum_{Q in K\{0}} (y(P+Q) - y(Q)),
\\ evaluated with PARI's elladd over L, then pulled back to F_q with PARI's ffembed/ffinvmap.
\\ Also writes the kernel polynomial psi (coefficients pulled back to F_q) for a Sage/Kohel cross-check.
default(parisizemax, 8*10^9);
t00 = getabstime();
z = ffgen(MODP, 'z);
fromint(v) = if(v == 0, 0*z, subst(Pol(binary(v)), 'x, z));
toint(a) = subst(a.pol, 'z, 2);
q = 2^NN;
E0K = ellinit([1, AA, 0, 0, 1], z);
EfK = ellinit([1, A2F, 0, 0, fromint(BF)], z);
c0 = ellcard(E0K); cf = ellcard(EfK);
if(c0 != cf, error("cards differ"));
t = q + 1 - c0;
Nbig = vecmax(factor(c0)[,1]);
if((t^2 - 4*q) % LL^2 != 0, error("l^2 does not divide disc"));
lam = Mod(t, LL) / 2;
k = znorder(lam);
\\ trace over F_{q^k} by the recurrence t_{i+1} = t t_i - q t_{i-1}
tk = 2; tk1 = t; for(i = 2, k, my(nx = t*tk1 - q*tk); tk = tk1; tk1 = nx); if(k == 1, tk1 = t);
U = ffinit(2, NN*k, 'w); w = ffgen(U, 'w);
emb = ffembed(z, w); dmap = ffinvmap(emb);
EfL = ellinit([1, A2F, 0, 0, ffmap(emb, fromint(BF))], w);
cardL = q^k + 1 - tk1;
vl = valuation(cardL, LL); cofL = cardL / LL^vl;
\\ sanity: random point killed by cardL
R0 = random(EfL); if(ellmul(EfL, R0, cardL) != [0], error("cardL wrong"));
lpt() = my(R); while(1, R = ellmul(EfL, random(EfL), cofL); if(R != [0], while(ellmul(EfL, R, LL) != [0], R = ellmul(EfL, R, LL)); return(R)));
T1 = lpt(); T2 = lpt();
frob_ok = ([T1[1]^q, T1[2]^q] == ellmul(EfL, T1, lift(lam)));
cyc_ok = (ellweilpairing(EfL, T1, T2, LL) == 1);
half = (LL - 1) / 2;
KX = vector(half); KY = vector(half); S = T1;
for(i = 1, half, KX[i] = S[1]; KY[i] = S[2]; S = elladd(EfL, S, T1));
\\ closure check: x(half*T1 + T1) must be x((half+1)T1) = x(-half T1) = KX[half]
clos_ok = (S[1] == KX[half]);
vsum = sum(i = 1, half, KX[i]);
\\ kernel polynomial by a product tree over L, coefficients pulled back to F_q
ptree(v) = my(n = #v, h); if(n == 1, return('X - v[1])); h = n \ 2; ptree(v[1..h]) * ptree(v[h+1..n]);
t1 = getabstime();
psiL = ptree(KX);
cl = Vec(psiL);
psiK = vector(#cl, i, ffmap(dmap, cl[i]));
down_ok = (vector(#cl, i, ffmap(emb, psiK[i])) == cl);
tpsi = getabstime() - t1;
\\ Frobenius stability of kernel as a set (coeffs in F_q) is down_ok.
\\ definitional Velu on the instance subset
{vdef(P) = my(PL = [ffmap(emb, P[1]), ffmap(emb, P[2])], X = PL[1], Y = PL[2], R1, R2);
  for(i = 1, half, R1 = elladd(EfL, PL, [KX[i], KY[i]]); R2 = elladd(EfL, PL, ellneg(EfL, [KX[i], KY[i]]));
     X += R1[1] + KX[i] + R2[1] + KX[i]; Y += R1[2] + KY[i] + R2[2] + (KY[i] + KX[i]));
  [X, Y];}
res = vector(#INST);
t2 = getabstime();
{for(j = 1, #INST, my(r = INST[j], P, Qp, fp, fq, ins);
  P = [fromint(r[2]), fromint(r[3])]; Qp = [fromint(r[4]), fromint(r[5])];
  if(!ellisoncurve(EfK, P) || !ellisoncurve(EfK, Qp), error("instance not on floor curve"));
  ins = (ellmul(EfK, P, r[6]) == Qp) && (ellmul(EfK, P, Nbig) == [0]) && (P != [0]);
  fp = vdef(P); fq = vdef(Qp);
  \\ pull back to F_q; ffmap into the image must round-trip
  my(fpk = [ffmap(dmap, fp[1]), ffmap(dmap, fp[2])], fqk = [ffmap(dmap, fq[1]), ffmap(dmap, fq[2])]);
  my(rt = ([ffmap(emb, fpk[1]), ffmap(emb, fpk[2]), ffmap(emb, fqk[1]), ffmap(emb, fqk[2])] == [fp[1], fp[2], fq[1], fq[2]]));
  res[j] = [r[1], ins, rt, toint(fpk[1]), toint(fpk[2]), toint(fqk[1]), toint(fqk[2])]);}
tdef = getabstime() - t2;
f = OUTF;
write1(f, "");
{write(f, "{\"family\":\"", FAM, "\",\"label\":\"", LAB, "\",\"card\":", c0, ",\"t\":", t, ",\"N\":", Nbig, ",\"k\":", k, ",\"lambda\":", lift(lam),
  ",\"L_bits\":", NN*k, ",\"frob_ok\":", frob_ok, ",\"cyclic_ok\":", cyc_ok, ",\"closure_ok\":", clos_ok, ",\"down_ok\":", down_ok,
  ",\"v_l_cardL\":", vl, ",\"psi_deg\":", poldegree(psiL), ",\"vsum\":", toint(ffmap(dmap, vsum)), ",\"ms_psi\":", tpsi, ",\"ms_def\":", tdef, ",\"ms_total\":", getabstime() - t00, ",");}
write(f, "\"psi\":[", strjoin(apply(a -> Str(toint(a)), psiK), ","), "],");
write(f, "\"res\":[", strjoin(apply(r -> Str("[\"", r[1], "\",", r[2], ",", r[3], ",", r[4], ",", r[5], ",", r[6], ",", r[7], "]"), res), ","), "]}");
print(FAM, " ", LAB, " done ms=", getabstime() - t00, " k=", k, " frob=", frob_ok, " cyc=", cyc_ok, " down=", down_ok);
quit;
