# Build myrho inputs (pure python3; no Sage).  Native E0 instances from instances.json (curve E0);
# transported instances = MY recomputed images (jobs/<F>/<lab>.images.json).
# N comes from my GP ellcard output (jobs/<F>/*.out); t1 from a brute-force count of E0(F_2);
# s = root of s^2 - t1 s + 2 mod N, chosen by argv (0/1); myrho checks tau(P) = sP on every instance.
import json, sys, os, glob
fam, which, reps, seed, sidx = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
mode = int(sys.argv[6]) if len(sys.argv) > 6 else 2
HERE = os.path.dirname(os.path.abspath(__file__))
W = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
D = json.load(open(f'{W}/data/{fam}_family.json')); m = D['meta']
n, a = m['n'], m['a']
terms = [tt.strip() for tt in m['modulus'].split('+')]
tail = 0
for tt in terms:
    e = 0 if tt == '1' else (1 if tt == 'x' else int(tt.split('^')[1]))
    if e < n: tail |= 1 << e
outs = [f for f in glob.glob(f'{HERE}/jobs/{fam}/*.out') if not f.endswith('.xonly.out')]
Ns = {json.loads(open(f).read().replace('\n', '').split(',"psi"')[0] + '}')['N'] for f in outs}
assert len(Ns) == 1, Ns
N = int(Ns.pop())
# #E0(F_2) by brute force: y^2 + xy = x^3 + a x^2 + 1 over F_2
cnt = 1 + sum(1 for x in (0, 1) for y in (0, 1) if (y * y + x * y) % 2 == (x**3 + a * x * x + 1) % 2)
t1 = 3 - cnt
def sqrt_mod(v, p):
    v %= p
    if p % 4 == 3: return pow(v, (p + 1) // 4, p)
    qq, ss = p - 1, 0
    while qq % 2 == 0: qq //= 2; ss += 1
    z = 2
    while pow(z, (p - 1) // 2, p) != p - 1: z += 1
    M, c, t, R = ss, pow(z, qq, p), pow(v, qq, p), pow(v, (qq + 1) // 2, p)
    while t != 1:
        i, tt2 = 0, t
        while tt2 != 1: tt2 = tt2 * tt2 % p; i += 1
        b = pow(c, 1 << (M - i - 1), p); M, c, t, R = i, b * b % p, t * b * b % p, R * b % p
    return R
d = sqrt_mod(t1 * t1 - 8, N); assert d * d % N == (t1 * t1 - 8) % N
inv2 = pow(2, N - 2, N)
roots = sorted({(t1 + d) * inv2 % N, (t1 - d) * inv2 % N})
for r in roots: assert (r * r - t1 * r + 2) % N == 0
s = roots[sidx]
rbits = {'T11': 4, 'T19': 6, 'T23': 7, 'T59': 8}[fam]
dp = {'T11': 1, 'T19': 2, 'T23': 3, 'T59': 7}[fam]
inst = json.load(open(f'{W}/raw/{fam}/instances.json'))
lines = [f'{n} {a:x} 1 {tail:x} {N} {s if mode == 2 else 0} {mode} {rbits} {dp} {seed} {reps}']
if which == 'native':
    for iid, r in sorted((iid, r) for iid, r in inst.items() if r['curve'] == 'E0'):
        lines.append(f"{iid} {r['P'][0]:x} {r['P'][1]:x} {r['Q'][0]:x} {r['Q'][1]:x} {r['k']}")
elif which == 'stored':
    # stored transported pairs, used only for curves whose x-only check (xonly.gp, my psi) passed on every pair
    for f in sorted(glob.glob(f'{HERE}/jobs/{fam}/*.xonly.out')):
        x = json.load(open(f))
        assert x['n'] == x['stored_instances_valid'] == x['x_P_E0_match'] == x['x_Q_E0_match'] == x['stored_log_preserved'] == x['my_x_log_preserved'], x
        for iid, r in sorted((iid, r) for iid, r in inst.items() if r['curve'] == x['label'] and 'P_E0' in r):
            lines.append(f"{iid}:tr {r['P_E0'][0]:x} {r['P_E0'][1]:x} {r['Q_E0'][0]:x} {r['Q_E0'][1]:x} {r['k']}")
else:
    for f in sorted(glob.glob(f'{HERE}/jobs/{fam}/*.images.json')):
        for iid, r in sorted(json.load(open(f)).items()):
            im = r['img']
            lines.append(f"{iid}:mytr {im[0]:x} {im[1]:x} {im[2]:x} {im[3]:x} {r['k']}")
print('\n'.join(lines))
print(f'# fam {fam} N {N} t1 {t1} roots {roots} s {s} tail {tail:x} count {len(lines)-1}', file=sys.stderr)
