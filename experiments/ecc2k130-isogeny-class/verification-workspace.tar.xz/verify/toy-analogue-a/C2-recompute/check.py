# Compare the GP definitional-Velu images (jobs/<F>/<lab>.out) with the sweep's stored P_E0/Q_E0.
# Optional --kohel: also evaluate Sage's Kohel isogeny from the GP-built kernel polynomial on ALL
# transported instances of the curve (different code path from both GP and the sweep).
import json, sys, os, time
from sage.all import GF, PolynomialRing, EllipticCurve, EllipticCurveIsogeny, Integer
fam, lab = sys.argv[1], sys.argv[2]
KOHEL = '--kohel' in sys.argv
HERE = os.path.dirname(os.path.abspath(__file__))
W = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
D = json.load(open(f'{W}/data/{fam}_family.json')); m = D['meta']
inst = json.load(open(f'{W}/raw/{fam}/instances.json'))
G = json.loads(open(f'{HERE}/jobs/{fam}/{lab}.out').read().replace('\n', ''))
n, a = m['n'], m['a']
R2 = PolynomialRing(GF(2), 'y'); modp = R2(m['modulus'].replace('x', 'y'))
K = GF(2**n, 'z', modulus=modp)
fe = lambda v: K.from_integer(int(v))
ie = lambda u: int(u.to_integer())
cf = D['curves'][lab]
Ef = EllipticCurve(K, [1, cf['a2'], 0, 0, fe(cf['b_int'])])
E0 = EllipticCurve(K, [1, a, 0, 0, 1])
N = Integer(G['N'])
out = dict(family=fam, label=lab, gp={k: G[k] for k in G if k not in ('psi', 'res')})
# 1) fit the codomain y^2 + xy = x^3 + a2 x^2 + A x + B from the definitional images
imgs = []
for r in G['res']:
    iid, ins, rt, px, py, qx, qy = r
    imgs.append((fe(px), fe(py))); imgs.append((fe(qx), fe(qy)))
c = lambda X, Y: Y * Y + X * Y + X**3 + cf['a2'] * X * X
(X1, Y1), (X2, Y2) = imgs[0], next(p for p in imgs if p[0] != imgs[0][0])
A = (c(X1, Y1) + c(X2, Y2)) / (X1 + X2); B = c(X1, Y1) + A * X1
fit_ok = all(c(X, Y) == A * X + B for X, Y in imgs)
cod_is_E0 = (B + A * A == 1) and (cf['a2'] == a)
out.update(codomain_fit_ok=fit_ok, codomain_A_eq_vsum=(ie(A) == G['vsum']), codomain_is_E0=cod_is_E0, n_def_images=len(imgs))
to_E0 = lambda X, Y: E0(X, Y + A)
agree = sign_consistent = logs = ins_ok = rt_ok = 0
IMG = {}
for r in G['res']:
    iid, ins, rt, px, py, qx, qy = r
    s = inst[iid]
    Pm, Qm = to_E0(fe(px), fe(py)), to_E0(fe(qx), fe(qy))
    IMG[iid] = dict(src='definitional', k=s['k'], img=[ie(Pm[0]), ie(Pm[1]), ie(Qm[0]), ie(Qm[1])])
    Ps = E0(fe(s['P_E0'][0]), fe(s['P_E0'][1])); Qs = E0(fe(s['Q_E0'][0]), fe(s['Q_E0'][1]))
    same = (Pm == Ps and Qm == Qs); neg = (Pm == -Ps and Qm == -Qs)
    agree += (same or neg) ; sign_consistent += (same or neg)
    logs += (Pm != 0 and N * Pm == 0 and s['k'] * Pm == Qm)
    ins_ok += ins; rt_ok += rt
out.update(def_compared=len(G['res']), def_agree_up_to_common_sign=agree, def_log_preserved=logs, def_instance_valid=ins_ok, def_roundtrip_ok=rt_ok)
print(json.dumps(out), flush=True)
if KOHEL:
    RX = PolynomialRing(K, 'X')
    psi = RX([fe(v) for v in reversed(G['psi'])])
    assert psi.degree() == (m['l'] - 1) // 2 and psi.is_monic()
    t0 = time.time()
    phi = EllipticCurveIsogeny(Ef, psi)
    Ec = phi.codomain()
    iso = Ec.isomorphism_to(E0)
    tb = time.time() - t0
    rows = sorted((iid, r) for iid, r in inst.items() if r['curve'] == lab and 'P_E0' in r)
    kag = klog = kdef = 0; t1 = time.time(); defd = {r[0]: r for r in G['res']}
    for iid, s in rows:
        P = Ef(fe(s['P'][0]), fe(s['P'][1])); Q = Ef(fe(s['Q'][0]), fe(s['Q'][1]))
        assert s['k'] * P == Q and N * P == 0 and P != 0
        Pk, Qk = iso(phi(P)), iso(phi(Q))
        Ps = E0(fe(s['P_E0'][0]), fe(s['P_E0'][1])); Qs = E0(fe(s['Q_E0'][0]), fe(s['Q_E0'][1]))
        if iid not in IMG: IMG[iid] = dict(src='kohel', k=s['k'], img=[ie(Pk[0]), ie(Pk[1]), ie(Qk[0]), ie(Qk[1])])
        kag += ((Pk == Ps and Qk == Qs) or (Pk == -Ps and Qk == -Qs))
        klog += (Pk != 0 and N * Pk == 0 and s['k'] * Pk == Qk)
        if iid in defd:
            r = defd[iid]; Pm = to_E0(fe(r[3]), fe(r[4]))
            kdef += (Pk == Pm or Pk == -Pm)
    out.update(kohel=dict(codomain_j=ie(Ec.j_invariant()), build_s=round(tb, 2), eval_s=round(time.time() - t1, 2),
                          compared=len(rows), agree_up_to_common_sign=kag, log_preserved=klog, agree_with_definitional=kdef))
    print(json.dumps(out['kohel']), flush=True)
json.dump(out, open(f'{HERE}/jobs/{fam}/{lab}.check.json', 'w'), indent=1)
json.dump(IMG, open(f'{HERE}/jobs/{fam}/{lab}.images.json', 'w'))
