# Independent re-statistics of the sweep TSVs (own code; does not import analyze.py).
import glob, math, os, json
BASE = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/raw'
def load(path):
    rows = []
    with open(path) as fh:
        hdr = fh.readline().rstrip('\n').split('\t')
        for line in fh:
            if not line.strip(): continue
            rows.append(dict(zip(hdr, line.rstrip('\n').split('\t'))))
    return rows
def ms(v):
    n = len(v); m = sum(v)/n; sd = math.sqrt(sum((x-m)**2 for x in v)/(n-1)); return n, m, sd
out = {}
num = den = 0.0
tot_tr = tot_bad = 0
for F in ['T11','T19','T23','T59','T109']:
    nat = load(f'{BASE}/{F}/out/E0__negtau.tsv')
    tr = []
    for p in sorted(glob.glob(f'{BASE}/{F}/out/*__transport_negtau.tsv')):
        tr += load(p)
    bad = sum(1 for r in tr if not (r['verified']=='1' and r['match']=='1' and r['k_true']==r['k_found']))
    badn = sum(1 for r in nat if not (r['verified']=='1' and r['match']=='1' and r['k_true']==r['k_found']))
    tot_tr += len(tr); tot_bad += bad
    res = {}
    for col in ['merge_steps','iters','steps']:
        n1,m1,s1 = ms([float(r[col]) for r in tr]); n2,m2,s2 = ms([float(r[col]) for r in nat])
        R = m1/m2; se = R*math.sqrt((s1/m1)**2/n1 + (s2/m2)**2/n2)
        res[col] = dict(n_tr=n1, n_nat=n2, mean_tr=m1, mean_nat=m2, ratio=R, se=se)
    res['bad_transported_rows'] = bad; res['bad_native_rows'] = badn
    out[F] = res
    r = res['merge_steps']
    print(F, 'n_tr', r['n_tr'], 'n_nat', r['n_nat'], 'ratio %.4f se %.4f' % (r['ratio'], r['se']), 'bad', bad, badn)
for fams in (['T19','T23','T59','T109'], ['T11','T19','T23','T59','T109']):
    w = [1/out[F]['merge_steps']['se']**2 for F in fams]
    m = sum(wi*out[F]['merge_steps']['ratio'] for wi,F in zip(w,fams))/sum(w)
    print('pooled', fams, '%.4f +- %.4f' % (m, 1/math.sqrt(sum(w))))
    out['pooled_'+'_'.join(fams)] = dict(ratio=m, se=1/math.sqrt(sum(w)))
print('total transported rows', tot_tr, 'bad', tot_bad)
out['total_transported_rows'] = tot_tr
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'restat.json'), 'w'), indent=1)
