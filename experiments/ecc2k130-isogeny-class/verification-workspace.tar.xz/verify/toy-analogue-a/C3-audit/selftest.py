"""Self-tests of gf2ec.py and of the family constants the C3 claim relies on.
python3 selftest.py  ->  selftest.json"""
import json, os, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gf2ec import Field, Curve, is_irreducible_gf2, is_prime

TOY = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
OUT = os.path.dirname(os.path.abspath(__file__))
rng = random.Random(20260924)
res = {}


def lucas_t(t1, m):
    a, b = 2, t1
    for _ in range(m - 1):
        a, b = b, t1 * b - 2 * a
    return b if m >= 1 else a


for fam in ['T11', 'T19', 'T23', 'T59', 'T109']:
    D = json.load(open(os.path.join(TOY, 'data', f'{fam}_family.json')))
    m = D['meta']
    n, tail, a = m['n'], m['modulus_tail'], m['a']
    r = {}
    poly = (1 << n) | tail
    r['modulus_irreducible'] = is_irreducible_gf2(n, poly)
    r['tail_is_smallest_odd'] = all(not is_irreducible_gf2(n, (1 << n) | tt) for tt in range(1, tail, 2))
    r['modulus_terms'] = [i for i in range(n + 1) if (poly >> i) & 1][::-1]
    t1 = -1 if a == 0 else 1
    # #E0(F_2) by enumeration of y^2 + x y = x^3 + a x^2 + 1 over F_2
    cnt2 = 1 + sum(1 for x in (0, 1) for y in (0, 1) if (y * y + x * y - (x ** 3 + a * x * x + 1)) % 2 == 0)
    r['E0_F2_count'] = cnt2
    r['t1_consistent'] = (cnt2 == 2 + 1 - t1)
    t = lucas_t(t1, n)
    q = 1 << n
    card = q + 1 - t
    N = int(m['N'])
    h = int(m['cofactor'])
    r['t_matches_meta'] = (t == int(m['t']))
    r['card_eq_h_N'] = (card == h * N)
    r['N_prime'] = is_prime(N)
    r['N_sq_not_div_card'] = (card % (N * N) != 0)
    r['N_bits'] = N.bit_length()
    F = Field(n, tail)
    # field sanity
    ok = True
    for _ in range(200):
        x = rng.getrandbits(n) or 1
        ok &= F.mul(x, F.inv(x)) == 1
        y, z = rng.getrandbits(n), rng.getrandbits(n)
        ok &= F.mul(x, y ^ z) == F.mul(x, y) ^ F.mul(x, z)
        ok &= F.sqr(y) == F.mul(y, y)
    r['field_axioms_sample_ok'] = bool(ok)
    # curve sanity on E0 and 5 random floor curves (+ the 6 floor curves used in the sweep)
    labs = ['E0'] + rng.sample([k for k in D['curves'] if k != 'E0'], min(5, len(D['curves']) - 1))
    used = set()
    tr = json.load(open(os.path.join(TOY, 'raw', fam, 'transport.json')))
    used.update(tr['floor_labels'])
    labs = list(dict.fromkeys(labs + sorted(used)))
    cr = {}
    for lab in labs:
        c = D['curves'][lab]
        E = Curve(F, c['a2'], c['b_int'])
        good = True
        for _ in range(4):
            P = E.random_point(rng)
            Qp = E.random_point(rng)
            Rp = E.random_point(rng)
            good &= E.mul(card, P) is None                       # #E divides card (= h N)
            good &= E.add(E.add(P, Qp), Rp) == E.add(P, E.add(Qp, Rp))   # associativity
            good &= E.on_curve(E.add(P, Qp)) and E.on_curve(E.dbl(P))
            good &= E.mul(7, P) == E.add(E.mul(3, P), E.mul(4, P))
            hP = E.mul(h, P)
            good &= E.mul(N, hP) is None
        if lab != 'E0':
            good &= int(c.get('order_pari', card)) == card
        cr[lab] = bool(good)
    r['curves_checked'] = cr
    if fam == 'T11':
        # brute-force point count on E0 and on O00-000 (validates the curve equation / encoding)
        for lab in ['E0', 'O00-000', 'O01-005']:
            c = D['curves'][lab]
            E = Curve(F, c['a2'], c['b_int'])
            pts = [None] + [(x, y) for x in range(1 << n) for y in range(1 << n) if E.on_curve((x, y))] \
                if False else None
            cnt = 1
            for x in range(1 << n):
                if x == 0:
                    cnt += 1  # y^2 = b has exactly one root
                    continue
                cc = x ^ c['a2'] ^ F.mul(c['b_int'], F.inv(F.sqr(x)))
                cnt += 0 if F.trace(cc) else 2
            r[f'bruteforce_count_{lab}'] = cnt
            r[f'bruteforce_count_{lab}_eq_card'] = (cnt == card)
    res[fam] = r
    print(fam, json.dumps(r), flush=True)

json.dump(res, open(os.path.join(OUT, 'selftest.json'), 'w'), indent=1)
