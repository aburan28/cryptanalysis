"""Independent check of claim C3 (toy-analogue-a): every row of raw/<F>/out/*.tsv is
re-verified with gf2ec.py (pure Python; no Sage, no PARI, no code from the sweep).

For each config file raw/<F>/inputs/<cfg>.txt and its output raw/<F>/out/<cfg>.tsv:
  - rows <-> input instances are a bijection (no missing / duplicated / extra ids)
  - input header curve (a2, b, N, n, tail) is the curve the instance claims to be on
  - input points/k equal the instances.json record (P,Q for direct rows; P_E0,Q_E0 for ':tr')
  - TSV k_true == planted k mod N
  - on the PLANTED curve (floor curve for transported rows) with the ORIGINAL points:
      P, Q on curve, P != O, [N]P = O (N prime => ord P = N), [k_found]P == Q,
      k_found == planted k mod N, and negative control [k_found + 1]P != Q
  - for ':tr' rows additionally on E0 with the transported points the solver saw:
      points on E0, [N]P_E0 = O, [k_found]P_E0 == Q_E0, [k_planted]P_E0 == Q_E0
Also counts distinct planted instances vs solver rows.
usage: python3 check_all.py [families...]  -> check_all.json
"""
import csv, json, os, sys, time
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gf2ec import Field, Curve

TOY = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
OUT = os.path.dirname(os.path.abspath(__file__))
FAMS = sys.argv[1:] or ['T11', 'T19', 'T23', 'T59', 'T109']


def parse_input(path):
    hdr, insts = {}, {}
    order = []
    for line in open(path):
        p = line.split()
        if not p:
            continue
        if p[0] == 'inst':
            _, iid, px, py, qx, qy, k = p
            if iid in insts:
                raise ValueError('duplicate id in input ' + iid)
            insts[iid] = (int(px, 16), int(py, 16), int(qx, 16), int(qy, 16), int(k))
            order.append(iid)
        else:
            hdr[p[0]] = p[1]
    return hdr, insts, order


def check_config(args):
    fam, cfg = args
    D = json.load(open(os.path.join(TOY, 'data', f'{fam}_family.json')))
    meta = D['meta']
    n, tail, a = meta['n'], meta['modulus_tail'], meta['a']
    N = int(meta['N'])
    F = Field(n, tail)
    inst = json.load(open(os.path.join(TOY, 'raw', fam, 'instances.json')))
    hdr, ins, order = parse_input(os.path.join(TOY, 'raw', fam, 'inputs', cfg + '.txt'))
    lab_cfg, mode_cfg = cfg.split('__')
    errs = []
    # header checks
    exp_b = 1 if (lab_cfg == 'E0' or mode_cfg.startswith('transport')) else D['curves'][lab_cfg]['b_int']
    if int(hdr['n']) != n or int(hdr['tail'], 16) != tail or int(hdr['a2']) != a or int(hdr['b'], 16) != exp_b \
            or int(hdr['N']) != N:
        errs.append(('header', hdr))
    curves = {}

    def curve(lab):
        if lab not in curves:
            c = D['curves'][lab]
            if c['a2'] != a:
                errs.append(('a2 mismatch', lab))
            curves[lab] = Curve(F, c['a2'], c['b_int'])
        return curves[lab]
    E0 = curve('E0')
    rows = list(csv.DictReader(open(os.path.join(TOY, 'raw', fam, 'out', cfg + '.tsv')), delimiter='\t'))
    ids = [r['id'] for r in rows]
    c = dict(rows=len(rows), inputs=len(ins), dup_rows=len(ids) - len(set(ids)),
             missing=len(set(ins) - set(ids)), extra=len(set(ids) - set(ins)),
             ok_planted_curve=0, eq_planted=0, neg_control_ok=0, P_order_N=0, input_matches_record=0,
             ktrue_col_ok=0, c_verified=0, c_match=0, tr_rows=0, tr_ok_on_E0=0, tr_planted_ok_on_E0=0)
    bases = set()
    for r in rows:
        iid = r['id']
        tr = iid.endswith(':tr')
        base = iid[:-3] if tr else iid
        bases.add(base)
        rec = inst[base]
        kf = int(r['k_found'])
        kp = int(rec['k'])
        c['c_verified'] += int(r['verified'])
        c['c_match'] += int(r['match'])
        c['ktrue_col_ok'] += int(int(r['k_true']) == kp % N)
        # input line vs record
        px, py, qx, qy, kin = ins[iid]
        if tr:
            same = (px, py, qx, qy) == (rec['P_E0'][0], rec['P_E0'][1], rec['Q_E0'][0], rec['Q_E0'][1])
        else:
            same = (px, py, qx, qy) == (rec['P'][0], rec['P'][1], rec['Q'][0], rec['Q'][1])
        same = same and kin == kp
        c['input_matches_record'] += int(same)
        # planted curve, original points
        E = curve(rec['curve'])
        if (lab_cfg != 'E0') and rec['curve'] != lab_cfg:
            errs.append(('curve label mismatch', iid))
        P = tuple(rec['P'])
        Q = tuple(rec['Q'])
        okc = E.on_curve(P) and E.on_curve(Q)
        ordN = okc and P is not None and E.mul(N, P) is None
        c['P_order_N'] += int(ordN)
        kP = E.mul(kf, P)
        ok = okc and kP == Q
        c['ok_planted_curve'] += int(ok)
        c['eq_planted'] += int(kf == kp % N)
        c['neg_control_ok'] += int(E.add(kP, P) != Q)
        if not (ok and ordN and kf == kp % N and same):
            errs.append(('row', iid, kf, kp))
        if tr:
            c['tr_rows'] += 1
            Pt, Qt = tuple(rec['P_E0']), tuple(rec['Q_E0'])
            okt = E0.on_curve(Pt) and E0.on_curve(Qt) and E0.mul(N, Pt) is None and E0.mul(kf, Pt) == Qt
            c['tr_ok_on_E0'] += int(okt)
            c['tr_planted_ok_on_E0'] += int(E0.mul(kp, Pt) == Qt)
            if not okt:
                errs.append(('tr', iid))
    return fam, cfg, c, sorted(bases), errs[:20]


if __name__ == '__main__':
    t0 = time.time()
    jobs = []
    for fam in FAMS:
        for f in sorted(os.listdir(os.path.join(TOY, 'raw', fam, 'inputs'))):
            if f.endswith('.txt'):
                jobs.append((fam, f[:-4]))
        outs = {f[:-4] for f in os.listdir(os.path.join(TOY, 'raw', fam, 'out')) if f.endswith('.tsv')}
        ins = {f[:-4] for f in os.listdir(os.path.join(TOY, 'raw', fam, 'inputs')) if f.endswith('.txt')}
        if outs != ins:
            print('CONFIG SET MISMATCH', fam, outs ^ ins)
    # big jobs first
    jobs.sort(key=lambda j: -os.path.getsize(os.path.join(TOY, 'raw', j[0], 'out', j[1] + '.tsv')))
    res = {}
    with Pool(int(os.environ.get('NPROC', '8'))) as pool:
        for fam, cfg, c, bases, errs in pool.imap_unordered(check_config, jobs):
            res.setdefault(fam, {})[cfg] = dict(c, bases=bases, errors=errs)
            print(fam, cfg, c, 'errors:', errs[:3], round(time.time() - t0, 1), flush=True)
    summary = {}
    grand = {}
    for fam in FAMS:
        tot = {}
        allbases = set()
        for cfg, c in res[fam].items():
            for k, v in c.items():
                if isinstance(v, int):
                    tot[k] = tot.get(k, 0) + v
            allbases.update(c['bases'])
        inst = json.load(open(os.path.join(TOY, 'raw', fam, 'instances.json')))
        tot['distinct_planted_instances_solved'] = len(allbases)
        tot['instances_json_records'] = len(inst)
        tot['planted_but_never_run'] = len(set(inst) - allbases)
        tot['n_errors'] = sum(len(c['errors']) for c in res[fam].values())
        summary[fam] = tot
        for k, v in tot.items():
            grand[k] = grand.get(k, 0) + v
    out = dict(summary=summary, grand_total=grand, secs=round(time.time() - t0, 1),
               per_config={f: {c: {k: v for k, v in d.items() if k != 'bases'} for c, d in r.items()} for f, r in res.items()})
    json.dump(out, open(os.path.join(OUT, 'check_all.json' if len(FAMS) == 5 else f'check_{"_".join(FAMS)}.json'), 'w'), indent=1)
    print(json.dumps(dict(summary=summary, grand_total=grand), indent=1))
