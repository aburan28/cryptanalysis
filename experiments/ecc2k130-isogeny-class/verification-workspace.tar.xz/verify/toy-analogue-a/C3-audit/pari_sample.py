"""Third library: re-check a random sample of rows with standalone PARI/GP (ellmul over ffgen).
Writes a gp script, runs /opt/homebrew/bin/gp, parses results.  python3 pari_sample.py"""
import csv, json, os, random, subprocess
TOY = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
HERE = os.path.dirname(os.path.abspath(__file__))
rng = random.Random(777)
gp = ['default(parisize, 10^8);']
labels = []
for fam, per in (('T11', 20), ('T19', 40), ('T23', 40), ('T59', 120), ('T109', 120)):
    D = json.load(open(os.path.join(TOY, 'data', f'{fam}_family.json')))
    m = D['meta']
    n, tail = m['n'], m['modulus_tail']
    inst = json.load(open(os.path.join(TOY, 'raw', fam, 'instances.json')))
    rows = []
    for f in sorted(os.listdir(os.path.join(TOY, 'raw', fam, 'out'))):
        if f.endswith('.tsv'):
            rows += list(csv.DictReader(open(os.path.join(TOY, 'raw', fam, 'out', f)), delimiter='\t'))
    pick = rng.sample(rows, per)
    mod = ' + '.join(f'x^{i}' for i in range(n, -1, -1) if ((1 << n) | tail) >> i & 1)
    gp.append(f'g = ffgen(Mod(1,2)*({mod}), \'z); N = {m["N"]};')
    gp.append('fe(v) = my(s = 0*g, p = 1 + 0*g); while(v, if(v % 2, s += p); v \\= 2; p *= g); s;')
    for r in pick:
        tr = r['id'].endswith(':tr')
        rec = inst[r['id'][:-3] if tr else r['id']]
        c = D['curves'][rec['curve']]
        gp.append(f'E = ellinit([1, {c["a2"]}, 0, 0, fe({c["b_int"]})], g); P = [fe({rec["P"][0]}), fe({rec["P"][1]})]; '
                  f'Q = [fe({rec["Q"][0]}), fe({rec["Q"][1]})]; '
                  f'print("R ", ellisoncurve(E,P) && ellisoncurve(E,Q), " ", ellmul(E,P,{r["k_found"]}) == Q, " ", '
                  f'ellmul(E,P,N) == [0], " ", ellmul(E,P,{int(r["k_found"]) + 1}) == Q);')
        labels.append((fam, r['id']))
gp.append('quit;')
open(os.path.join(HERE, 'pari_sample.gp'), 'w').write('\n'.join(gp) + '\n')
out = subprocess.run(['timeout', '1200', '/opt/homebrew/bin/gp', '-q', '-f', os.path.join(HERE, 'pari_sample.gp')],
                     capture_output=True, text=True)
res = [l.split()[1:] for l in out.stdout.splitlines() if l.startswith('R ')]
assert len(res) == len(labels), (len(res), len(labels), out.stderr[-2000:])
summ = {}
for (fam, iid), v in zip(labels, res):
    s = summ.setdefault(fam, dict(rows=0, on_curve=0, kP_eq_Q=0, NP_zero=0, kplus1_neq=0))
    s['rows'] += 1
    s['on_curve'] += v[0] == '1'
    s['kP_eq_Q'] += v[1] == '1'
    s['NP_zero'] += v[2] == '1'
    s['kplus1_neq'] += v[3] == '0'
print(json.dumps(summ))
json.dump(summ, open(os.path.join(HERE, 'pari_sample.json'), 'w'), indent=1)
