"""Self-contained binary-field elliptic-curve arithmetic (pure Python, no Sage/PARI, no code
shared with toy-analogue-a/scripts).  Written for the C3 audit.

Field F_{2^n} = F_2[z]/(z^n + tail), elements are ints (bit i = coefficient of z^i).
Curve y^2 + x y = x^3 + a2 x^2 + b (ordinary, b != 0).  Point at infinity = None.
Group law: standard affine chord-and-tangent formulas for this Weierstrass form
(Hankerson-Menezes-Vanstone, Guide to ECC, section 3.1.2), re-derived here:
  -P = (x, x + y)
  P != +-Q: lam = (y1 + y2)/(x1 + x2), x3 = lam^2 + lam + x1 + x2 + a2, y3 = lam (x1 + x3) + x3 + y1
  2P (x1 != 0): lam = x1 + y1/x1, x3 = lam^2 + lam + a2, y3 = x1^2 + (lam + 1) x3
"""


class Field:
    def __init__(self, n, tail):
        self.n = n
        self.m = (1 << n) | tail
        self.tail = tail

    def red(self, r):
        n, m = self.n, self.m
        bl = r.bit_length()
        while bl > n:
            r ^= m << (bl - 1 - n)
            bl = r.bit_length()
        return r

    def mul(self, a, b):
        if a.bit_length() < b.bit_length():
            a, b = b, a
        r = 0
        while b:
            if b & 1:
                r ^= a
            a <<= 1
            b >>= 1
        return self.red(r)

    def sqr(self, a):
        # spread bits (squaring is linear in char 2)
        r = 0
        i = 0
        while a:
            if a & 1:
                r |= 1 << (2 * i)
            a >>= 1
            i += 1
        return self.red(r)

    def inv(self, a):
        if a == 0:
            raise ZeroDivisionError
        # extended Euclid in F_2[z]
        u, v = a, self.m
        g1, g2 = 1, 0
        while u != 1:
            j = u.bit_length() - v.bit_length()
            if j < 0:
                u, v = v, u
                g1, g2 = g2, g1
                j = -j
            u ^= v << j
            g1 ^= g2 << j
        return self.red(g1)

    def pow(self, a, e):
        r = 1
        while e:
            if e & 1:
                r = self.mul(r, a)
            a = self.sqr(a)
            e >>= 1
        return r

    def trace(self, a):
        t, x = 0, a
        for _ in range(self.n):
            t ^= x
            x = self.sqr(x)
        return t  # 0 or 1

    def half_trace(self, c):
        # n odd: solution z of z^2 + z = c when Tr(c) = 0
        h, x = c, c
        for _ in range((self.n - 1) // 2):
            x = self.sqr(self.sqr(x))
            h ^= x
        return h


class Curve:
    def __init__(self, F, a2, b):
        self.F, self.a2, self.b = F, a2, b

    def on_curve(self, P):
        if P is None:
            return True
        F = self.F
        x, y = P
        lhs = F.sqr(y) ^ F.mul(x, y)
        x2 = F.sqr(x)
        rhs = F.mul(x2, x) ^ (F.mul(self.a2, x2) if self.a2 else 0) ^ self.b
        return lhs == rhs

    def neg(self, P):
        return None if P is None else (P[0], P[0] ^ P[1])

    def dbl(self, P):
        if P is None:
            return None
        F = self.F
        x, y = P
        if x == 0:
            return None
        lam = x ^ F.mul(y, F.inv(x))
        x3 = F.sqr(lam) ^ lam ^ self.a2
        y3 = F.sqr(x) ^ F.mul(lam ^ 1, x3)
        return (x3, y3)

    def add(self, P, Q):
        if P is None:
            return Q
        if Q is None:
            return P
        F = self.F
        x1, y1 = P
        x2, y2 = Q
        if x1 == x2:
            if y1 == y2:
                return self.dbl(P)
            return None  # Q = -P
        lam = F.mul(y1 ^ y2, F.inv(x1 ^ x2))
        x3 = F.sqr(lam) ^ lam ^ x1 ^ x2 ^ self.a2
        y3 = F.mul(lam, x1 ^ x3) ^ x3 ^ y1
        return (x3, y3)

    def mul(self, k, P):
        if k < 0:
            return self.mul(-k, self.neg(P))
        R = None
        A = P
        while k:
            if k & 1:
                R = self.add(R, A)
            A = self.dbl(A)
            k >>= 1
        return R

    def random_point(self, rng):
        F = self.F
        while True:
            x = rng.getrandbits(F.n)
            if x == 0:
                continue
            # y = x z: z^2 + z = x + a2 + b / x^2
            c = x ^ self.a2 ^ F.mul(self.b, F.inv(F.sqr(x)))
            if F.trace(c):
                continue
            z = F.half_trace(c)
            P = (x, F.mul(x, z))
            assert self.on_curve(P)
            return P


def is_irreducible_gf2(n, poly):
    """Ben-Or / Rabin: poly (int, degree n) irreducible over F_2 iff x^(2^n) = x mod poly and
    gcd(x^(2^(n/p)) - x, poly) = 1 for primes p | n."""
    F = Field(n, poly ^ (1 << n))

    def x2k(k):
        x = 2
        for _ in range(k):
            x = F.sqr(x)
        return x

    def gcd(a, b):
        while b:
            while a and a.bit_length() >= b.bit_length():
                a ^= b << (a.bit_length() - b.bit_length())
            a, b = b, a
        return a
    if x2k(n) != 2:
        return False
    ps = [p for p in range(2, n + 1) if n % p == 0 and all(p % d for d in range(2, p))]
    for p in ps:
        if gcd(x2k(n // p) ^ 2, poly) != 1:
            return False
    return True


def is_prime(N):
    if N < 2:
        return False
    small = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]
    for p in small:
        if N % p == 0:
            return N == p
    d, s = N - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for a in small:  # deterministic for N < 3.3e24
        x = pow(a, d, N)
        if x in (1, N - 1):
            continue
        for _ in range(s - 1):
            x = x * x % N
            if x == N - 1:
                break
        else:
            return False
    return True
