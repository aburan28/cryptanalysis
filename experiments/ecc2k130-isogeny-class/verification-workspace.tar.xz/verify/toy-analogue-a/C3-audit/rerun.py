"""(1) Reproduce: rerun the sweep's own rho.c (byte-identical copy) on the sweep's input files and
    compare k_found/iters/steps/merge_steps/walks with the published TSV rows.
(2) Blind re-solve: rho_blind.c (walk seed independent of k, planted-k check removed) on the same
    instances with the k field replaced by 0; the recovered logs are then checked with gf2ec.py
    (pure Python) on the planted curve with the original points, and compared with planted k.
usage: python3 rerun.py <family> <max_per_config|all> [workers]
"""
import csv, json, os, random, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gf2ec import Field, Curve

TOY = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a'
HERE = os.path.dirname(os.path.abspath(__file__))
fam = sys.argv[1]
MAXPC = None if sys.argv[2] == 'all' else int(sys.argv[2])
if fam == 'T109' and MAXPC is not None:
    MAXPC = min(MAXPC, 20)  # machine load ~60-100: keep the T109 sample at 20 per config
W = int(sys.argv[3]) if len(sys.argv) > 3 else 6
D = json.load(open(os.path.join(TOY, 'data', f'{fam}_family.json')))
meta = D['meta']
n, tail, N = meta['n'], meta['modulus_tail'], int(meta['N'])
bins = {}
for tag, src in (('orig', 'rho_orig_copy.c'), ('blind', 'rho_blind.c')):
    b = os.path.join(HERE, 'bin', f'{tag}_{fam}')
    subprocess.run(['clang', '-O3', '-mcpu=apple-m1', '-Wall', f'-DFIXN={n}', f'-DFIXTAIL={tail}', '-o', b,
                    os.path.join(HERE, src)], check=True)
    bins[tag] = b
wd = os.path.join(HERE, 'rerun', fam)
os.makedirs(wd, exist_ok=True)
rng = random.Random(4242 + len(fam))
jobs = []
for f in sorted(os.listdir(os.path.join(TOY, 'raw', fam, 'inputs'))):
    if not f.endswith('.txt'):
        continue
    cfg = f[:-4]
    lines = open(os.path.join(TOY, 'raw', fam, 'inputs', f)).read().splitlines(True)
    hdr = [x for x in lines if not x.startswith('inst ')]
    ins = [x for x in lines if x.startswith('inst ')]
    sel = ins if MAXPC is None or MAXPC >= len(ins) else sorted(rng.sample(ins, MAXPC), key=ins.index)
    # split into chunks of <= 100 for parallelism
    for ci in range(0, len(sel), 100):
        part = sel[ci:ci + 100]
        p_orig = os.path.join(wd, f'{cfg}.{ci:05d}.orig.in')
        p_blind = os.path.join(wd, f'{cfg}.{ci:05d}.blind.in')
        open(p_orig, 'w').writelines(hdr + part)
        open(p_blind, 'w').writelines(hdr + [' '.join(x.split()[:6] + ['0']) + '\n' for x in part])
        jobs.append((cfg, 'orig', p_orig))
        jobs.append((cfg, 'blind', p_blind))


def run(job):
    cfg, tag, p = job
    with open(p) as fi, open(p[:-3] + '.out', 'w') as fo, open(p[:-3] + '.err', 'w') as fe:
        r = subprocess.run(['timeout', '2000', bins[tag]], stdin=fi, stdout=fo, stderr=fe)
    return cfg, tag, p, r.returncode


t0 = time.time()
with ThreadPoolExecutor(W) as ex:
    done = list(ex.map(run, jobs))
print('solver runs done', round(time.time() - t0, 1), 'nonzero rc:', [d for d in done if d[3] != 0], flush=True)

inst = json.load(open(os.path.join(TOY, 'raw', fam, 'instances.json')))
F = Field(n, tail)
curves = {}


def curve(lab):
    if lab not in curves:
        c = D['curves'][lab]
        curves[lab] = Curve(F, c['a2'], c['b_int'])
    return curves[lab]


res = {}
for cfg, tag, p, rc in done:
    pub = {r['id']: r for r in csv.DictReader(open(os.path.join(TOY, 'raw', fam, 'out', cfg + '.tsv')), delimiter='\t')}
    want = [x.split()[1] for x in open(p) if x.startswith('inst ')]
    rows = list(csv.DictReader(open(p[:-3] + '.out'), delimiter='\t'))
    r = res.setdefault(cfg, dict(orig_run=0, orig_identical=0, orig_k_same=0, blind_run=0, blind_solved_ok=0,
                                 blind_eq_planted=0, blind_same_walk_as_pub=0, missing=0, mismatches=[]))
    got = {x['id']: x for x in rows}
    r['missing'] += len(set(want) - set(got))
    for iid in want:
        if iid not in got:
            r['mismatches'].append((tag, iid, 'missing'))
            continue
        x = got[iid]
        if tag == 'orig':
            r['orig_run'] += 1
            keys = ('k_found', 'iters', 'steps', 'merge_steps', 'walks', 'dps', 'fruitless', 'retries')
            same = all(x[k] == pub[iid][k] for k in keys)
            r['orig_identical'] += int(same)
            r['orig_k_same'] += int(x['k_found'] == pub[iid]['k_found'])
            if not same:
                r['mismatches'].append((tag, iid, {k: (x[k], pub[iid][k]) for k in keys if x[k] != pub[iid][k]}))
        else:
            r['blind_run'] += 1
            tr = iid.endswith(':tr')
            rec = inst[iid[:-3] if tr else iid]
            kf = int(x['k_found'])
            E = curve(rec['curve'])
            ok = E.mul(kf, tuple(rec['P'])) == tuple(rec['Q'])
            if tr:
                E0 = curve('E0')
                ok = ok and E0.mul(kf, tuple(rec['P_E0'])) == tuple(rec['Q_E0'])
            r['blind_solved_ok'] += int(ok)
            r['blind_eq_planted'] += int(kf == int(rec['k']) % N)
            r['blind_same_walk_as_pub'] += int(x['iters'] == pub[iid]['iters'])
            if not ok:
                r['mismatches'].append((tag, iid, kf, rec['k']))
tot = {}
for cfg, r in res.items():
    r['mismatches'] = r['mismatches'][:10]
    for k, v in r.items():
        if isinstance(v, int):
            tot[k] = tot.get(k, 0) + v
    print(fam, cfg, {k: v for k, v in r.items() if k != 'mismatches'}, r['mismatches'][:3])
print('TOTAL', fam, tot, round(time.time() - t0, 1))
json.dump(dict(family=fam, max_per_config=MAXPC, total=tot, per_config=res, secs=round(time.time() - t0, 1)),
          open(os.path.join(HERE, f'rerun_{fam}.json'), 'w'), indent=1)
