"""C5 audit: re-derive, entirely over F_q (no F_{q^2}, no Sage isogeny code, no make_ext/down,
no ecc2k.py loader), the ascending 263-isogeny of every ECC2K-130 floor curve and push planted
relations through it.

Per floor curve E = [1,0,0,0,b] (parsed straight from ground_truth.json):
  (a) twist E' = [1,1,0,0,b]; a random point killed by q+1+t; U = cof*R has order exactly
      263^2  => E'(F_q)[263^oo] = Z/263^2 (v_263(q+1+t) = 2), so E'(F_q)[263] is ONE line.
      With char poly of pi on E[263] = (X+1)^2 (t = -2, q = 1 mod 263) and E(F_q)[263] = 0,
      this line (x-coords shared with E, since E ~ E' over F_4 F_q keeps x) is the unique
      F_q-rational 263-subgroup of E, and it equals E(F_{q^2})[263] (= ker(pi+1) on E[263]).
  (b) kernel x-coords x([i]T), i = 1..131, all in F_q (by construction), distinct, nonzero,
      x([263-i]T) = x([i]T) spot-checked, [263]T = O.
  (c) hand Velu (velu_char2.py, tested against Sage Kohel on toy fields): v = sum x_Q,
      codomain j = 1/(b + v + v^2); check b + v + v^2 == 1 exactly => codomain is E0 after the
      F_q-rational substitution (X, Y) -> (X, Y + v).
  (d) planted relations: P = 4R on E, check [N]P = O, P != O; k random; Q = kP; map both; check
      images on E0, image != O, [N]image = O, k*phi(P) == phi(Q); and tau(phi(P)) = s*phi(P)
      (s = root of X^2 + X + 2 mod N, recomputed here) so the E0 tau-speedup applies to images.
  (e) additivity phi(A + B) = phi(A) + phi(B) for random full points A, B of E(F_q).
  (f) x-set compared with the third-party transport-263/kernels_all.json (not relied on).
usage: sage -python audit_c5.py [labels...]   (default: all 262 floor curves)
"""
import sys, os, json, time, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from velu_char2 import velu_codomain_b, velu_eval, add, mul, neg, on_curve
from sage.all import GF, PolynomialRing, EllipticCurve, Integer, set_random_seed, randint, is_prime

set_random_seed(777131)
GT = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json'))
meta = GT['meta']
F2 = PolynomialRing(GF(2), 'Z')
Z = F2.gen()
modpoly = Z**131 + Z**13 + Z**2 + Z + 1
assert modpoly.is_irreducible()
assert int(meta['modulus_int']) == sum(1 << i for i in (131, 13, 2, 1, 0))
K = GF(2**131, 'z', modulus=modpoly)
q = Integer(2)**131

# trace from scratch: #E0(F_2) = 4 -> t1 = 2 + 1 - 4 = -1; t_{m+1} = t1 t_m - 2 t_{m-1}
tt = [Integer(2), Integer(-1)]
for _ in range(130):
    tt.append(-tt[-1] - 2 * tt[-2])
t = tt[131]
card = q + 1 - t
twc = q + 1 + t
N = card // 4
assert card % 4 == 0 and is_prime(N)
assert str(t) == meta['t'] and str(N) == meta['N']
assert t % 263 == 261 and q % 263 == 1
assert twc % 263**2 == 0 and (twc // 263**2) % 263 != 0 and card % 263 != 0
cof = twc // 263**2
Rn = PolynomialRing(GF(N), 'S')
S_ = Rn.gen()
sroots = [Integer(r) for r in (S_**2 + S_ + 2).roots(multiplicities=False)]
assert len(sroots) == 2

E0b = K(1)
xE0 = None
third = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json'))

labels = sys.argv[1:] or [c['label'] for c in GT['curves'] if c['label'] != 'E0']
recs = {c['label']: c for c in GT['curves']}


def rand_pt(C):
    P = C.random_point()
    while P == 0:
        P = C.random_point()
    return (P[0], P[1])


# decide which root s is tau's eigenvalue on E0[N]
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
G = mul(4, rand_pt(E0), K(0))
tG = (G[0] ** 2, G[1] ** 2)
s = [r for r in sroots if mul(r, G, K(0)) == tG]
assert len(s) == 1
s = s[0]
assert str(s) == meta['E0_tau_eigenvalue'], (s, meta['E0_tau_eigenvalue'])

out = {}
t_all = time.time()
for lab in labels:
    r = recs[lab]
    t0 = time.time()
    a2 = int(r['a2'])
    b = K.from_integer(int(r['b_int']))
    j = K.from_integer(int(r['j_int']))
    chk = {}
    chk['a2_is_0'] = (a2 == 0)
    chk['b_is_1_over_j'] = (b * j == 1)
    E = EllipticCurve(K, [1, 0, 0, 0, b])
    Et = EllipticCurve(K, [1, 1, 0, 0, b])
    # orders (probabilistic sanity; the ground truth proves them)
    A = rand_pt(E)
    chk['E_killed_by_4N'] = mul(card, A, K(0)) is None
    R = rand_pt(Et)
    chk['twist_killed_by_q+1+t'] = mul(twc, R, K(1)) is None
    # (a) cyclic 263^2 part of the twist
    U = None
    for _ in range(20):
        U = mul(cof, rand_pt(Et), K(1))
        if mul(263, U, K(1)) is not None:
            break
    T = mul(263, U, K(1))
    chk['twist_has_point_of_order_263^2'] = (T is not None and mul(263, T, K(1)) is None)
    # (b) kernel x-coords
    pts = []
    P_ = None
    for i in range(1, 132):
        P_ = add(P_, T, K(1))
        pts.append(P_)
    xs = [p[0] for p in pts]
    chk['kernel_x_distinct_nonzero'] = (len(set(xs)) == 131 and all(x != 0 for x in xs))
    chk['x(263-i)T == x(iT) for i=131'] = (add(pts[-1], T, K(1))[0] == pts[-1][0])
    chk['263T == O'] = (mul(263, T, K(1)) is None)
    # (c) codomain
    v, bnew = velu_codomain_b(b, xs)
    chk['codomain_is_E0_exactly (b+v+v^2 == 1)'] = (bnew == 1)
    # (d) planted relations
    ok_rel = 0
    ok_tau = 0
    NREL = 3
    for _ in range(NREL):
        P = mul(4, rand_pt(E), K(0))
        while P is None:
            P = mul(4, rand_pt(E), K(0))
        k = randint(1, int(N) - 1)
        Q = mul(k, P, K(0))
        Pi = velu_eval(P, xs, v)
        Qi = velu_eval(Q, xs, v)
        good = (mul(N, P, K(0)) is None and Pi is not None and on_curve(Pi, K(0), E0b) and on_curve(Qi, K(0), E0b)
                and mul(N, Pi, K(0)) is None and mul(k, Pi, K(0)) == Qi)
        ok_rel += bool(good)
        ok_tau += bool(Pi is not None and mul(s, Pi, K(0)) == (Pi[0] ** 2, Pi[1] ** 2))
    # (e) additivity on full points (incl. 4-torsion components)
    A1, A2 = rand_pt(E), rand_pt(E)
    lhs = velu_eval(add(A1, A2, K(0)), xs, v)
    rhs = add(velu_eval(A1, xs, v), velu_eval(A2, xs, v), K(0))
    chk['additive_on_random_full_points'] = (lhs == rhs)
    # (f) third-party kernel x-set
    th = third.get(lab)
    mine_hex = sorted('%x' % x.to_integer() for x in xs)
    chk['x_set_equals_transport263'] = (th is not None and sorted(th) == mine_hex)
    rec = dict(checks=chk, planted_ok=f'{ok_rel}/{NREL}', tau_eigen_on_image_ok=f'{ok_tau}/{NREL}',
               v_hex='%x' % v.to_integer(), secs=round(time.time() - t0, 2))
    rec['all_ok'] = all(chk.values()) and ok_rel == NREL and ok_tau == NREL
    out[lab] = rec
    print(lab, rec['all_ok'], rec['planted_ok'], rec['secs'], '' if rec['all_ok'] else chk, flush=True)

n_ok = sum(r['all_ok'] for r in out.values())
tot_rel = sum(int(r['planted_ok'].split('/')[0]) for r in out.values())
log2 = lambda c: (math.log2(math.pi) + math.log2(int(N)) - math.log2(2 * c)) / 2
summary = dict(curves=len(out), all_ok=n_ok, planted_relations_ok=tot_rel, planted_relations_total=3 * len(out),
               t=str(t), N=str(N), log2N=math.log2(int(N)), tau_eigenvalue=str(s),
               log2_rho_E0_neg_tau=log2(262), log2_rho_neg_only=log2(2), gap=log2(2) - log2(262),
               wall_s=round(time.time() - t_all, 1))
print(summary)
name = 'audit_c5_all.json' if not sys.argv[1:] else 'audit_c5_' + '_'.join(labels[:4]) + '.json'
json.dump(dict(summary=summary, per_curve=out), open(os.path.join(HERE, name), 'w'), indent=1)
