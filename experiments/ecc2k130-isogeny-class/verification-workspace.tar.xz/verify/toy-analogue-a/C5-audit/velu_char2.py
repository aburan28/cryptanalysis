"""Hand-written odd-degree Velu isogeny for y^2 + x y = x^3 + a2 x^2 + b over F_{2^n},
using only the x-coordinates of a half-set S of the kernel (kernel x-coords must lie in the
base field; the kernel points themselves need not be rational).

Derivation (Velu 1971, char 2, a1 = 1, a3 = a4 = 0): for Q in S,
  g^x_Q = x_Q^2 + y_Q, g^y_Q = x_Q, v_Q = x_Q, u_Q = x_Q^2
  v = sum v_Q = sum x_Q,  w = sum (u_Q + x_Q v_Q) = 0
  codomain  [1, a2, 0, v, b + v]   (A4 = a4 - 5v, A6 = a6 - b2 v - 7w, b2 = 1)
  X = x + sum_Q ( x_Q/d + x_Q^2/d^2 ),  d = x + x_Q
  Y = y + sum_Q ( x x_Q^2/d^3 + x_Q/d + x_Q (y + x_Q + x_Q^2)/d^2 )
      (the y_Q terms of Velu's Y-formula cancel in pairs in characteristic 2)
  [1, a2, 0, v, b+v] -> [1, a2, 0, 0, b + v + v^2] by (X, Y) -> (X, Y + v).
No Sage isogeny code is used here; points are plain (x, y) tuples, None = infinity.
"""


def velu_codomain_b(b, xs):
    v = sum(xs)
    return v, b + v + v * v


def velu_eval(pt, xs, v):
    """image of pt under the normalized Velu isogeny, composed with (X,Y)->(X,Y+v)."""
    if pt is None:
        return None
    x, y = pt
    X = x
    Y = y
    for xq in xs:
        d = x + xq
        if d == 0:
            return None  # pt in kernel (up to sign)
        di = ~d
        di2 = di * di
        X += xq * di + xq * xq * di2
        Y += x * xq * xq * di2 * di + xq * di + xq * (y + xq + xq * xq) * di2
    return (X, Y + v)


# --- plain affine arithmetic on y^2 + x y = x^3 + a2 x^2 + b (char 2) -------------------
def on_curve(P, a2, b):
    if P is None:
        return True
    x, y = P
    return y * y + x * y == x ** 3 + a2 * x * x + b


def neg(P):
    return None if P is None else (P[0], P[0] + P[1])


def add(P, Q, a2):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y1 + y2 == x2:   # Q = -P
            return None
        # doubling
        if x1 == 0:
            return None
        lam = x1 + y1 / x1
        x3 = lam * lam + lam + a2
        y3 = x1 * x1 + (lam + 1) * x3
        return (x3, y3)
    lam = (y1 + y2) / (x1 + x2)
    x3 = lam * lam + lam + x1 + x2 + a2
    y3 = lam * (x1 + x3) + x3 + y1
    return (x3, y3)


def mul(k, P, a2):
    k = int(k)
    if k < 0:
        return mul(-k, neg(P), a2)
    R = None
    A = P
    while k:
        if k & 1:
            R = add(R, A, a2)
        A = add(A, A, a2)
        k >>= 1
    return R
