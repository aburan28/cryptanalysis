"""Check the hand Velu formulas of velu_char2.py against Sage's own isogeny code (Kohel's
kernel-polynomial algorithm) on small binary fields, for kernels whose points are rational
(l | #E) and kernels whose x-coords are rational but points are not (l | #twist only),
which is the ECC2K-130 floor situation.
usage: sage -python test_velu_toy.py
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from velu_char2 import velu_codomain_b, velu_eval, add, mul, neg, on_curve
from sage.all import GF, EllipticCurve, factor, set_random_seed, randint, Integer, PolynomialRing

set_random_seed(20260924)
results = []
for n in (13, 17, 19, 23):
    K = GF(2 ** n, 'z')
    R = PolynomialRing(K, 'X')
    X = R.gen()
    done = {'rational': 0, 'twist': 0}
    tries = 0
    while min(done.values()) < 2 and tries < 400:
        tries += 1
        b = K.random_element()
        if b == 0:
            continue
        E = EllipticCurve(K, [1, 0, 0, 0, b])
        Et = EllipticCurve(K, [1, 1, 0, 0, b])
        cE, cT = E.order(), Et.order()
        for kind, C, cC, cO in (('rational', E, cE, cT), ('twist', Et, cT, cE)):
            if done[kind] >= 2:
                continue
            ells = [l for l, e in factor(cC) if 3 <= l <= 61 and cO % l != 0 and e == 1]
            if not ells:
                continue
            l = ells[-1]
            T = None
            while T is None or T == 0:
                T = (cC // l) * C.random_point()
            xs = [(Integer(i) * T)[0] for i in range(1, (l - 1) // 2 + 1)]
            h = R.one()
            for xx in xs:
                h *= (X - xx)
            phi = E.isogeny(h)          # Sage Kohel, over K
            cod = phi.codomain()
            v, bnew = velu_codomain_b(b, xs)
            E2 = EllipticCurve(K, [1, 0, 0, 0, bnew])
            ok_j = cod.j_invariant() == E2.j_invariant()
            iso = cod.isomorphism_to(E2)
            ok_pts = 0
            ok_add = 0
            for _ in range(10):
                P = E.random_point()
                Q = E.random_point()
                mine = velu_eval((P[0], P[1]), xs, v)
                sage_img = iso(phi(P))
                ok_pts += (mine is not None and on_curve(mine, K(0), bnew) and E2(mine[0], mine[1]) == sage_img)
                # my point arithmetic vs Sage's
                S = add((P[0], P[1]), (Q[0], Q[1]), K(0))
                ok_add += ((S is None and P + Q == 0) or (S is not None and E(S[0], S[1]) == P + Q))
            rec = dict(n=n, kind=kind, l=int(l), sage_codomain_ainvs=str(cod.a_invariants()), mine_v=str(v),
                       j_match=bool(ok_j), images_match=f'{ok_pts}/10', add_match=f'{ok_add}/10',
                       iso_is_identity_plus_shift=str(iso.tuple()))
            print(rec, flush=True)
            results.append(rec)
            done[kind] += 1
allok = all(r['j_match'] and r['images_match'] == '10/10' and r['add_match'] == '10/10' for r in results)
print('ALL OK' if allok else 'FAIL', len(results))
json.dump(dict(all_ok=allok, cases=results), open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_velu_toy.json'), 'w'), indent=1)
