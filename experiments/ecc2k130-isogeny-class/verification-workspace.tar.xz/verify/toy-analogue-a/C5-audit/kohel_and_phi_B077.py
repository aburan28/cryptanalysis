"""Two further independent checks for selected labels (default B077 A000 A130 B000):
 1. Sage's own isogeny code (Kohel, kernel polynomial over F_q) with the kernel polynomial
    prod(X - x_Q) from the twist construction: codomain j, F_q-isomorphism to E0 (Sage
    is_isomorphic over K, and NOT isomorphic to the F_q-twist of E0), images of planted pairs,
    agreement with the hand Velu map of velu_char2.py.
 2. Number of F_q-roots of Phi_263(j_E, Y): Phi_263 recomputed here with PARI polmodular(263)
    over Z, reduced mod 2, evaluated at j_E in F_{2^131} (PARI t_FFELT), then
    deg gcd(Y^q - Y, g) and the multiplicity of Y = 1.
usage: sage -python kohel_and_phi_B077.py [labels...]
"""
import sys, os, json, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from velu_char2 import velu_codomain_b, velu_eval
from sage.all import GF, PolynomialRing, EllipticCurve, Integer, set_random_seed, randint, pari

set_random_seed(99263)
GT = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json'))
F2 = PolynomialRing(GF(2), 'Z')
Z = F2.gen()
K = GF(2**131, 'z', modulus=Z**131 + Z**13 + Z**2 + Z + 1)
q = Integer(2)**131
t = Integer(GT['meta']['t'])
N = Integer(GT['meta']['N'])
twc = q + 1 + t
cof = twc // 263**2
recs = {c['label']: c for c in GT['curves']}
R = PolynomialRing(K, 'X')
X = R.gen()
labels = sys.argv[1:] or ['B077', 'A000', 'A130', 'B000']
out = {}

# ---- Phi_263 mod 2 (own computation) ----
pari.allocatemem(6 * 10**9)
t0 = time.time()
LEVEL = int(os.environ.get('LEVEL', '263'))
P = pari.polmodular(LEVEL)                     # Z[x, y]
Pl = pari.lift(P * pari('Mod(1,2)'))            # 0/1 coefficients
phi_meta = dict(polmodular_s=round(time.time() - t0, 1), deg_x=int(Pl.poldegree('x')), deg_y=int(Pl.poldegree('y')))
one_direct = pari.lift(pari.polmodular(LEVEL, 0, pari('Mod(1,2)'), 'y'))
phi_meta['Phi(1,Y) mod 2 equals polmodular(263,0,Mod(1,2))'] = bool(pari.lift(Pl.subst('x', 1) * pari('Mod(1,2)')) == one_direct)
g = pari("ffgen(Mod(1,2)*(z^131+z^13+z^2+z+1), 'z)")
# control: E0 (j = 1) should have 263 distinct F_q-roots (1 twice, plus the 262 floor j)
G0 = Pl.subst('x', g ** 0) * g ** 0
Y0q = pari.lift(pari.Mod(pari('y') * g ** 0, G0) ** (2**131))
phi_meta['control_E0_num_distinct_Fq_roots'] = int(pari.gcd(Y0q - pari('y'), G0).poldegree('y'))
print('phi', phi_meta, flush=True)


def to_ff(el):
    return sum((g ** i for i, c in enumerate(el.polynomial().list()) if c == 1), 0 * g)


for lab in labels:
    rec = {}
    b = K.from_integer(int(recs[lab]['b_int']))
    j = 1 / b
    assert j == K.from_integer(int(recs[lab]['j_int']))
    E = EllipticCurve(K, [1, 0, 0, 0, b])
    Et = EllipticCurve(K, [1, 1, 0, 0, b])
    while True:
        U = cof * Et.random_point()
        if 263 * U != 0:
            break
    T = 263 * U
    xs = [(i * T)[0] for i in range(1, 132)]
    h = R.one()
    for x in xs:
        h *= (X - x)
    t0 = time.time()
    phi = E.isogeny(h)
    rec['sage_kohel_build_s'] = round(time.time() - t0, 1)
    cod = phi.codomain()
    E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
    E0t = EllipticCurve(K, [1, 1, 0, 0, 1])
    rec['sage_degree'] = int(phi.degree())
    rec['sage_codomain_j_is_1'] = bool(cod.j_invariant() == 1)
    rec['sage_codomain_Fq_isomorphic_to_E0'] = bool(cod.is_isomorphic(E0))
    rec['sage_codomain_Fq_isomorphic_to_E0_twist'] = bool(cod.is_isomorphic(E0t))
    iso = cod.isomorphism_to(E0)
    v, bnew = velu_codomain_b(b, xs)
    ok = 0
    same = 0
    for _ in range(3):
        Pp = 4 * E.random_point()
        k = randint(1, int(N) - 1)
        Q = k * Pp
        a = iso(phi(Pp))
        c = iso(phi(Q))
        mine = velu_eval((Pp[0], Pp[1]), xs, v)
        ok += bool(a != 0 and N * a == 0 and k * a == c)
        same += bool(a == E0(mine[0], mine[1]) or a == -E0(mine[0], mine[1]))
    rec['sage_kohel_planted_ok'] = f'{ok}/3'
    rec['sage_image_equals_hand_velu_image_up_to_automorphism'] = f'{same}/3'
    # Phi_263(j_E, Y) over F_q
    t0 = time.time()
    jf = to_ff(j)
    G = Pl.subst('x', jf) * g ** 0      # poly in y over F_{2^131}
    rec['Phi(j,Y)_degree'] = int(G.poldegree('y'))
    yv = pari('y')
    Yq = pari.lift(pari.Mod(yv * g ** 0, G) ** (2**131))
    d = pari.gcd(Yq - yv, G)
    rec['num_distinct_Fq_roots_of_Phi(j,Y)'] = int(d.poldegree('y'))
    rec['that_root_is_1'] = bool(d.subst('y', g ** 0) == 0) if int(d.poldegree('y')) == 1 else None
    dG = pari.deriv(G, 'y')
    rec['Y=1_is_simple_root'] = bool(G.subst('y', g ** 0) == 0 and dG.subst('y', g ** 0) != 0)
    rec['phi_eval_s'] = round(time.time() - t0, 1)
    out[lab] = rec
    print(lab, rec, flush=True)
json.dump(dict(level=LEVEL, phi_meta=phi_meta, per_curve=out), open(os.path.join(HERE, 'kohel_and_phi_L%d.json' % LEVEL), 'w'), indent=1)
