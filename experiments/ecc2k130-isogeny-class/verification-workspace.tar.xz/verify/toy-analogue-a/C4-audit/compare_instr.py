#!/usr/bin/env python3
"""Compare the sweep's merge_steps with GFIRST, the exact global index of the first genuine repeated
class (hash set of every generated point, instrumentation in rho_instr.c)."""
import glob, os, json, re
D = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C4-audit/rerun'
SW = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/raw/T59/out'
gcnt_bad = set()
for e in glob.glob(os.path.join(D, '*.ierr')):
    for l in open(e):
        m = re.match(r'(\S+): GCNT', l)
        if m: gcnt_bad.add(m.group(1))
res = {}; tot = eq = 0; diffs = []
for fn in sorted(glob.glob(os.path.join(SW, '*.tsv'))):
    cfg = os.path.basename(fn)[:-4]
    sw = {}
    hdr = None
    for i, l in enumerate(open(fn).read().splitlines()):
        if not l: continue
        f = l.split('\t')
        if i == 0: hdr = f; continue
        sw[f[0]] = dict(zip(hdr, f))
    g = {}
    for c in sorted(glob.glob(os.path.join(D, cfg + '.chunk.??.instr'))):
        for l in open(c).read().splitlines():
            if l.startswith('id\t') or not l: continue
            f = l.split('\t'); g[f[0]] = int(f[-1])
    n = same = 0
    for k, r in sw.items():
        n += 1
        if g.get(k) == int(r['merge_steps']): same += 1
        else: diffs.append((k, r['merge_steps'], g.get(k), r['selfsolve']))
    bad_nonself = [k for k in gcnt_bad if k in sw and sw[k]['selfsolve'] != '1']
    res[cfg] = dict(rows=n, merge_steps_equals_exact_first_repeat=same, gcnt_mismatch_rows=len([k for k in gcnt_bad if k in sw]), gcnt_mismatch_not_selfsolve=len(bad_nonself))
    tot += n; eq += same
    print(cfg, res[cfg])
res['total'] = dict(rows=tot, equal=eq, diffs=diffs[:50])
print('TOTAL', tot, 'equal', eq, 'first diffs', diffs[:10])
json.dump(res, open(os.path.join(os.path.dirname(D), 'compare_instr.json'), 'w'), indent=1)
