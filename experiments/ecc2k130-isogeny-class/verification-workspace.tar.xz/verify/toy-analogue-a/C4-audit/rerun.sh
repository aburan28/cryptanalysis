#!/bin/bash
c=$1; cfg=$(basename $c | sed 's/\.chunk\..*//'); d=$(dirname $c)
cat $d/$cfg.hdr $c | timeout 2400 /Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C4-audit/sub/rho_T59 > $c.out 2> $c.err
