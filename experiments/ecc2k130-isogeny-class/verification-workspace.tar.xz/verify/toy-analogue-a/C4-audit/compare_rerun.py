#!/usr/bin/env python3
"""Compare the re-run of every T59 sweep input (fresh build of the current rho.c, byte-identical to
bin/rho_T59) with the sweep's raw/T59/out/*.tsv, column by column except the two CPU-time columns."""
import glob, os, json
D = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C4-audit/rerun'
SW = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/raw/T59/out'
res = {}
tot = mism = 0
for fn in sorted(glob.glob(os.path.join(SW, '*.tsv'))):
    cfg = os.path.basename(fn)[:-4]
    sw = {}
    for i, l in enumerate(open(fn).read().splitlines()):
        if i == 0 or not l: continue
        f = l.split('\t'); sw[f[0]] = f[:-2]
    mine = {}
    for c in sorted(glob.glob(os.path.join(D, cfg + '.chunk.*.out'))):
        for l in open(c).read().splitlines():
            if l.startswith('id\t') or not l: continue
            f = l.split('\t'); mine[f[0]] = f[:-2]
    same = sum(1 for k in sw if mine.get(k) == sw[k])
    res[cfg] = dict(sweep_rows=len(sw), rerun_rows=len(mine), identical_rows=same)
    tot += len(sw); mism += len(sw) - same
    print(cfg, res[cfg])
res['total'] = dict(rows=tot, mismatching=mism)
print('TOTAL rows', tot, 'mismatching', mism)
json.dump(res, open(os.path.join(os.path.dirname(D), 'compare_rerun.json'), 'w'), indent=1)
