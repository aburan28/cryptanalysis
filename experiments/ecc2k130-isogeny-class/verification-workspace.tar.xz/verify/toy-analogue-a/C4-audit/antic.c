/* C4 audit: anti-collision return probability for an r-adding walk (positive control r = 4).
   Two independent step-index sequences a_i, b_i uniform in [0,r); D_k = sum_{i<=k} (e_{a_i} - e_{b_i}).
   A would-be collision whose last k steps have equal multisets is not a new collision; the fraction of
   ineligible pairs is p = P(D_k = 0 for some k >= 1). Predicted rho factor 1/sqrt(1 - p). */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
static uint64_t s = 88172645463325252ULL;
static inline uint64_t xr(void) { s ^= s << 13; s ^= s >> 7; s ^= s << 17; return s; }
int main(int argc, char **argv) {
    int r = atoi(argv[1]); long trials = atol(argv[2]); long K = atol(argv[3]);
    long ret = 0;
    int *D = calloc(r, sizeof(int));
    for (long t = 0; t < trials; t++) {
        for (int i = 0; i < r; i++) D[i] = 0;
        int nz = 0;
        for (long k = 0; k < K; k++) {
            uint64_t z = xr(); int a = z % r, b = (z >> 32) % r;
            if (a == b) { if (nz == 0) { ret++; goto done; } continue; }
            nz -= (D[a] != 0) + (D[b] != 0);
            D[a]++; D[b]--;
            nz += (D[a] != 0) + (D[b] != 0);
            if (nz == 0) { ret++; goto done; }
        }
        done:;
    }
    double p = (double)ret / trials, se = sqrt(p * (1 - p) / trials);
    printf("r=%d trials=%ld K=%ld return_prob=%.4f +- %.4f  factor 1/sqrt(1-p)=%.4f  first-order 1/sqrt(1-1/r)=%.4f\n", r, trials, K, p, se, 1 / sqrt(1 - p), 1 / sqrt(1 - 1.0 / r));
    return 0;
}
