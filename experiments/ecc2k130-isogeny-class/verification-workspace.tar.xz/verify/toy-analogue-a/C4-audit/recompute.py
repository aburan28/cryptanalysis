#!/usr/bin/env python3
"""C4 audit: recompute T59 birthday-time ratios straight from the raw TSVs (independent of
the sweep's analyze.py), plus internal-consistency checks on every row.

Theory: M = N/c classes; E[T] ~ sqrt(pi M / 2) for T = number of generated points up to and
including the first repeat.  Exact finite-M value E[T] = sum_{k>=0} prod_{i<k}(1 - i/M)
= 1 + Q(M) ~ sqrt(pi M/2) + 2/3.
"""
import csv, glob, json, math, os, sys
import numpy as np
from scipy import stats

RAW = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/raw/T59'
OUT = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C4-audit'
N = 10063074221
n = 59
CS = {'neg': 2, 'negtau': 2 * n, 'transport_negtau': 2 * n, 'none': 1}


def hdr(cfg):
    h = {}
    for line in open(os.path.join(RAW, 'inputs', cfg + '.txt')):
        if line.startswith('inst'):
            continue
        k, v = line.split()
        h[k] = v
    return h


def insts(cfg):
    r = []
    for line in open(os.path.join(RAW, 'inputs', cfg + '.txt')):
        if line.startswith('inst'):
            r.append(line.split()[1])
    return r


res = {'configs': {}, 'groups': {}}
allrows = {}
for fn in sorted(glob.glob(os.path.join(RAW, 'out', '*.tsv'))):
    cfg = os.path.basename(fn)[:-4]
    curve, mode = cfg.split('__')
    h = hdr(cfg)
    assert int(h['N']) == N and int(h['n']) == n
    rows = list(csv.DictReader(open(fn), delimiter='\t'))
    ids_in = insts(cfg)
    ids_out = [r['id'] for r in rows]
    c = CS[mode]
    M = N / c
    th = math.sqrt(math.pi * M / 2)
    T = np.array([int(r['merge_steps']) for r in rows], dtype=float)
    steps = np.array([int(r['steps']) for r in rows], dtype=float)
    chk = dict(
        n_rows=len(rows), n_inputs=len(ids_in), ids_match_inputs=sorted(ids_in) == sorted(ids_out),
        ids_unique=len(set(ids_out)) == len(ids_out),
        all_verified=all(r['verified'] == '1' for r in rows), all_match=all(r['match'] == '1' for r in rows),
        all_merge_ok=all(r['merge_ok'] == '1' for r in rows),
        merge_le_steps=bool(np.all(T <= steps)), merge_pos=bool(np.all(T > 0)),
        abandoned=sum(int(r['abandoned']) for r in rows), fruitless=sum(int(r['fruitless']) for r in rows),
        inf=sum(int(r['inf']) for r in rows), selfsolve=sum(int(r['selfsolve']) for r in rows),
        degenerate=sum(int(r['degenerate']) for r in rows),
        k_true_distinct=len(set(r['k_true'] for r in rows)),
    )
    mean, sd = T.mean(), T.std(ddof=1)
    se = sd / math.sqrt(len(T))
    z = T ** 2 / (2 * M)
    ks = stats.kstest(z, 'expon')
    # post-merge overhead for DP-collision instances (non-selfsolve): expect ~ 2^dpbits
    dpb = int(h['dpbits'])
    nonself = [i for i, r in enumerate(rows) if r['selfsolve'] == '0']
    over = steps[nonself] - T[nonself]
    # exact E[T] (Ramanujan Q asymptotic; M >= 8e7 here)
    Mx = (N - 1) / c + 1
    ex = math.sqrt(math.pi * Mx / 2) + 2 / 3 - (1 / 12) * math.sqrt(math.pi / (2 * Mx))
    res['configs'][cfg] = dict(
        curve=curve, mode=mode, c=c, M=M, rbits=int(h['rbits']), dpbits=dpb, a2=h['a2'], b=h['b'],
        mean=mean, sd=sd, sd_over_mean=sd / mean, theory=th, ratio=mean / th,
        ci95=[(mean - 1.96 * se) / th, (mean + 1.96 * se) / th], ratio_exact=mean / ex,
        mean_T2_over_2M=float(z.mean()), ks_D=float(ks.statistic), ks_p=float(ks.pvalue),
        post_merge_overhead_mean=float(over.mean()), post_merge_overhead_se=float(over.std(ddof=1) / math.sqrt(len(over))),
        two_pow_dpbits=2 ** dpb, checks=chk)
    allrows[cfg] = T

groups = {
    'i_floor_neg': [k for k in allrows if k.endswith('__neg') and not k.startswith('E0')],
    'ii_E0_negtau': ['E0__negtau'],
    'iii_transport_negtau': [k for k in allrows if k.endswith('__transport_negtau')],
    'iv_E0_neg': ['E0__neg'],
    'v_E0_none': ['E0__none'],
}
for g, keys in groups.items():
    T = np.concatenate([allrows[k] for k in keys])
    c = CS[keys[0].split('__')[1]]
    M = N / c
    th = math.sqrt(math.pi * M / 2)
    se = T.std(ddof=1) / math.sqrt(len(T))
    ks = stats.kstest(T ** 2 / (2 * M), 'expon')
    res['groups'][g] = dict(configs=keys, n=len(T), mean=float(T.mean()), se=float(se), theory=th, ratio=float(T.mean() / th),
                            half95=float(1.96 * se / th), ks_p_pooled=float(ks.pvalue))

json.dump(res, open(os.path.join(OUT, 'recompute.json'), 'w'), indent=1)
print('group                     n     mean        theory      ratio  +-95%   KS p (pooled)')
for g, v in res['groups'].items():
    print(f"{g:24s} {v['n']:5d} {v['mean']:11.1f} {v['theory']:11.1f}  {v['ratio']:.4f} {v['half95']:.4f}  {v['ks_p_pooled']:.3f}")
print()
print('config                          c  rbits dp  rows  ratio   KS p   sd/mean  E[T2/2M]  overhead(2^dp) abandoned fruitless selfsolve checks')
for k, v in res['configs'].items():
    ch = v['checks']
    okall = all([ch['ids_match_inputs'], ch['ids_unique'], ch['all_verified'], ch['all_match'], ch['all_merge_ok'], ch['merge_le_steps'], ch['merge_pos']])
    print(f"{k:30s} {v['c']:4d} {v['rbits']:3d} {v['dpbits']:3d} {ch['n_rows']:5d} {v['ratio']:.4f} {v['ks_p']:.3f} {v['sd_over_mean']:.3f}  {v['mean_T2_over_2M']:.3f}   "
          f"{v['post_merge_overhead_mean']:7.1f}+-{v['post_merge_overhead_se']:.1f} ({v['two_pow_dpbits']}) {ch['abandoned']} {ch['fruitless']} {ch['selfsolve']} {okall} kdistinct={ch['k_true_distinct']} inf={ch['inf']} degen={ch['degenerate']}")
print('min KS p over configs:', min(v['ks_p'] for v in res['configs'].values()))
