/*
 * irho.c -- C4 audit: an INDEPENDENT Pollard-rho implementation for the T59 toy family
 * (y^2 + x y = x^3 + a2 x^2 + b over F_{2^59}, modulus z^59 + z^6 + z^5 + z^4 + z^3 + z + 1),
 * written from scratch (no code shared with toy-analogue-a/scripts/rho.c).
 *
 * Differences from the sweep's rho.c, on purpose:
 *   - portable field arithmetic (4-bit window schoolbook multiply, binary-EEA inversion;
 *     no PMULL, no Itoh-Tsujii);
 *   - own instances: random P of order N (random x, half-trace solve, cofactor multiply),
 *     Q = kP with k from our own RNG;
 *   - single-walk rho (no distinguished points), r = 2^RB-adding walk with our own index hash,
 *     NO look-ahead;
 *   - canonical representative: neg -> the sign with the LARGER y; negtau -> the conjugate with
 *     the LARGEST x, then larger y (the sweep uses minimal x / smaller y);
 *   - collision detection by an exact hash set of EVERY visited class (not DP + re-walk), so the
 *     first repeated class is found directly;
 *   - fruitless cycles (repeat with identical coefficients) are left via canon(2 * max-x point of
 *     the cycle).
 * Output per instance: id, T_all (points generated incl. the repeated one, incl. fruitless repeats),
 * T_distinct (distinct classes + 1), fruitless cycles, k_found == k_true, verified.
 *
 * usage: irho <mode none|neg|negtau> <a2> <b_hex> <count> <seed> <rbits>
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

typedef uint64_t u64;
typedef unsigned __int128 u128;

#define DEG 59
#define FMASK ((1ULL << DEG) - 1)
#define FTAIL 0x7BULL              /* z^6+z^5+z^4+z^3+z+1 */
#define FPOLY ((1ULL << DEG) | FTAIL)

static const u64 NORD = 10063074221ULL;
static const u64 COF = 57284756ULL;          /* #E / N = 4 * 14321189 */
static const u64 SEIG = 7715620412ULL;       /* tau acts as s on <P> (checked at run time) */

/* ---------- F_{2^59} ---------- */
static u128 clmul_port(u64 a, u64 b) {
    u64 T[16];
    T[0] = 0; T[1] = a;
    for (int i = 2; i < 16; i += 2) { T[i] = T[i / 2] << 1; T[i + 1] = T[i] ^ a; }
    /* a < 2^59, so T[i] < 2^63: fits */
    u128 r = 0;
    for (int i = 0; i < 16; i++) {
        u64 nib = (b >> (4 * i)) & 15;
        r ^= ((u128)T[nib]) << (4 * i);
    }
    return r;
}
static u64 fred(u128 r) {
    while (r >> DEG) {
        u64 h = (u64)(r >> DEG);
        r &= FMASK;
        /* h * FTAIL by shifts, FTAIL = 1 + z + z^3 + z^4 + z^5 + z^6 */
        u128 hh = h;
        r ^= hh ^ (hh << 1) ^ (hh << 3) ^ (hh << 4) ^ (hh << 5) ^ (hh << 6);
    }
    return (u64)r;
}
static inline u64 fmul(u64 a, u64 b) { return fred(clmul_port(a, b)); }
static inline u64 fsq(u64 a) { return fred(clmul_port(a, a)); }
static int deg64(u64 a) { return a ? 63 - __builtin_clzll(a) : -1; }
static u64 finv(u64 a) {
    /* binary extended Euclid (Hankerson-Menezes-Vanstone Alg. 2.49 style) */
    if (!a) { fprintf(stderr, "inverse of 0\n"); exit(9); }
    u64 u = a, v = FPOLY, g1 = 1, g2 = 0;
    while (u != 1 && v != 1) {
        while (!(u & 1)) { u >>= 1; g1 = (g1 & 1) ? (g1 ^ FPOLY) >> 1 : g1 >> 1; }
        while (!(v & 1)) { v >>= 1; g2 = (g2 & 1) ? (g2 ^ FPOLY) >> 1 : g2 >> 1; }
        if (deg64(u) > deg64(v)) { u ^= v; g1 ^= g2; } else { v ^= u; g2 ^= g1; }
    }
    return u == 1 ? g1 : g2;
}
static u64 ftrace(u64 a) { u64 t = a, s = a; for (int i = 1; i < DEG; i++) { t = fsq(t); s ^= t; } return s; }
static u64 fhalftrace(u64 c) { u64 s = c, t = c; for (int i = 1; i <= (DEG - 1) / 2; i++) { t = fsq(fsq(t)); s ^= t; } return s; }

/* ---------- curve ---------- */
static u64 A2, BB;
typedef struct { u64 x, y; int inf; } Pt;
static Pt O_ = {0, 0, 1};
static int oncurve(Pt P) { if (P.inf) return 1; u64 x2 = fsq(P.x); return (fsq(P.y) ^ fmul(P.x, P.y)) == (fmul(x2, P.x) ^ (A2 ? x2 : 0) ^ BB); }
static Pt pneg(Pt P) { if (P.inf) return P; Pt R = {P.x, P.x ^ P.y, 0}; return R; }
static Pt pdbl(Pt P) {
    if (P.inf || P.x == 0) return O_;
    u64 l = P.x ^ fmul(P.y, finv(P.x));
    Pt R; R.inf = 0;
    R.x = fsq(l) ^ l ^ A2;
    R.y = fsq(P.x) ^ fmul(l ^ 1, R.x);
    return R;
}
static Pt padd(Pt P, Pt Q) {
    if (P.inf) return Q; if (Q.inf) return P;
    if (P.x == Q.x) return (P.y == Q.y) ? pdbl(P) : O_;
    u64 l = fmul(P.y ^ Q.y, finv(P.x ^ Q.x));
    Pt R; R.inf = 0;
    R.x = fsq(l) ^ l ^ P.x ^ Q.x ^ A2;
    R.y = fmul(l, P.x ^ R.x) ^ R.x ^ P.y;
    return R;
}
static Pt pmul(Pt P, u64 k) { Pt R = O_; for (int i = 63; i >= 0; i--) { R = pdbl(R); if ((k >> i) & 1) R = padd(R, P); } return R; }
static int peq(Pt a, Pt b) { return (a.inf && b.inf) || (!a.inf && !b.inf && a.x == b.x && a.y == b.y); }

/* ---------- Z/N ---------- */
static inline u64 addN(u64 a, u64 b) { u64 c = a + b; return c >= NORD ? c - NORD : c; }
static inline u64 subN(u64 a, u64 b) { return a >= b ? a - b : a + NORD - b; }
static inline u64 mulN(u64 a, u64 b) { return (u64)(((u128)a * b) % NORD); }
static u64 powN(u64 a, u64 e) { u64 r = 1; while (e) { if (e & 1) r = mulN(r, a); a = mulN(a, a); e >>= 1; } return r; }
static u64 invN(u64 a) { return powN(a, NORD - 2); }

/* ---------- RNG (xoshiro256**) ---------- */
static u64 st4[4];
static inline u64 rotl(u64 x, int k) { return (x << k) | (x >> (64 - k)); }
static u64 rnd(void) { u64 r = rotl(st4[1] * 5, 7) * 9, t = st4[1] << 17; st4[2] ^= st4[0]; st4[3] ^= st4[1]; st4[1] ^= st4[2]; st4[0] ^= st4[3]; st4[2] ^= t; st4[3] = rotl(st4[3], 45); return r; }
static void seedrng(u64 s) { for (int i = 0; i < 4; i++) { s += 0x9E3779B97F4A7C15ULL; u64 z = s; z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL; st4[i] = z ^ (z >> 31); } }
static u64 rndN(void) { u64 r; do r = rnd() >> 30; while (r >= NORD * 1ULL); return r; } /* 34-bit rejection */

static Pt randpoint(void) {
    for (;;) {
        u64 x = rnd() & FMASK;
        if (!x) continue;
        u64 c = x ^ A2 ^ fmul(BB, fsq(finv(x)));    /* w^2 + w = x + a2 + b/x^2, y = x w */
        if (ftrace(c)) continue;
        u64 w = fhalftrace(c);
        Pt P = {x, fmul(x, w), 0};
        if (rnd() & 1) P = pneg(P);
        if (!oncurve(P)) { fprintf(stderr, "randpoint not on curve\n"); exit(8); }
        P = pmul(P, COF);
        if (!P.inf) return P;
    }
}

/* ---------- classes ---------- */
static int MODE; /* 0 none 1 neg 2 negtau */
static u64 SP[DEG];
static inline u64 canon(Pt *P) {
    u64 m = 1;
    if (MODE == 2) {
        u64 x = P->x, y = P->y, bx = x, by = y; int bi = 0;
        for (int i = 1; i < DEG; i++) { x = fsq(x); y = fsq(y); if (x > bx) { bx = x; by = y; bi = i; } }
        P->x = bx; P->y = by; m = SP[bi];
    }
    if (MODE >= 1) {
        u64 yn = P->x ^ P->y;
        if (yn > P->y) { P->y = yn; m = NORD - m; }
    }
    return m;
}

/* ---------- hash set of visited classes ---------- */
typedef struct { u64 x, y; u64 idx; u64 epoch; } Hent;
#define HBITS 23
static Hent *HT;
static u64 EPOCH;
static inline u64 hkey(u64 x, u64 y) { u64 h = (x * 0xD1B54A32D192ED03ULL) ^ (y * 0x8CB92BA72F3D8DD7ULL); h ^= h >> 29; h *= 0xBF58476D1CE4E5B9ULL; return h >> (64 - HBITS); }
/* returns pointer to entry for (x,y) (found or empty slot); *found set */
static Hent *hlook(u64 x, u64 y, int *found) {
    u64 i = hkey(x, y);
    for (;;) {
        Hent *e = &HT[i];
        if (e->epoch != EPOCH) { *found = 0; return e; }
        if (e->x == x && e->y == y) { *found = 1; return e; }
        i = (i + 1) & ((1ULL << HBITS) - 1);
    }
}

typedef struct { Pt P; u64 a, b; } Node;
#define MAXPATH (1ULL << 22)
static Node *PATH;

static int RB;
static Pt *RT; static u64 *RC, *RD;
static inline int idxj(u64 x) { return (int)((x * 0x9FB21C651E98DF25ULL) >> (64 - RB)); }

int main(int argc, char **argv) {
    if (argc != 7) { fprintf(stderr, "usage: irho mode a2 b_hex count seed rbits\n"); return 2; }
    MODE = !strcmp(argv[1], "none") ? 0 : !strcmp(argv[1], "neg") ? 1 : !strcmp(argv[1], "negtau") ? 2 : -1;
    if (MODE < 0) return 2;
    A2 = strtoull(argv[2], 0, 10); BB = strtoull(argv[3], 0, 16);
    long count = atol(argv[4]); u64 seed = strtoull(argv[5], 0, 10); RB = atoi(argv[6]);
    if (MODE == 2 && (BB != 1 || A2 > 1)) { fprintf(stderr, "negtau needs Koblitz\n"); return 2; }
    /* field self-tests */
    seedrng(12345);
    for (int t = 0; t < 1000; t++) { u64 a = rnd() & FMASK, b = rnd() & FMASK, c = rnd() & FMASK; if (!a) continue;
        if (fmul(a, finv(a)) != 1) { fprintf(stderr, "inv fail\n"); return 3; }
        if (fmul(a, b ^ c) != (fmul(a, b) ^ fmul(a, c))) { fprintf(stderr, "distrib fail\n"); return 3; }
        if (fmul(fmul(a, b), c) != fmul(a, fmul(b, c))) { fprintf(stderr, "assoc fail\n"); return 3; } }
    { u64 z = 2, t = z; for (int i = 0; i < DEG; i++) t = fsq(t); if (t != z) { fprintf(stderr, "z^(2^59) != z: modulus not irreducible?\n"); return 3; } }
    SP[0] = 1; for (int i = 1; i < DEG; i++) SP[i] = mulN(SP[i - 1], SEIG);
    HT = calloc(1ULL << HBITS, sizeof(Hent)); PATH = malloc(sizeof(Node) * MAXPATH);
    RT = malloc(sizeof(Pt) << RB); RC = malloc(8ULL << RB); RD = malloc(8ULL << RB);
    printf("id\tmode\tT_all\tT_distinct\tfruitless\tk_ok\tverified\trestarts\n");
    for (long inst = 0; inst < count; inst++) {
        seedrng(seed * 1000003ULL + (u64)inst);
        Pt P0 = randpoint();
        if (!pmul(P0, NORD).inf) { fprintf(stderr, "P0 order != N\n"); return 4; }
        if (MODE == 2) { Pt T = {fsq(P0.x), fsq(P0.y), 0}; if (!peq(T, pmul(P0, SEIG))) { fprintf(stderr, "tau(P) != sP\n"); return 4; } }
        u64 k = 1 + rndN() % (NORD - 1);
        Pt Q0 = pmul(P0, k);
        for (int j = 0; j < (1 << RB); j++) {
            do { RC[j] = rndN(); RD[j] = rndN(); RT[j] = padd(pmul(P0, RC[j]), pmul(Q0, RD[j])); } while (RT[j].inf);
        }
        EPOCH++;
        u64 a, b; Pt P;
        do { a = rndN(); b = rndN(); P = padd(pmul(P0, a), pmul(Q0, b)); } while (P.inf);
        u64 m = canon(&P); a = mulN(m, a); b = mulN(m, b);
        u64 cnt = 0, distinct = 0, fruitless = 0, restarts = 0;
        int found; Hent *e;
        u64 kf = 0; int solved = 0;
        /* insert start */
        e = hlook(P.x, P.y, &found); e->x = P.x; e->y = P.y; e->epoch = EPOCH; e->idx = 0;
        PATH[0].P = P; PATH[0].a = a; PATH[0].b = b; cnt = 1; distinct = 1;
        while (!solved) {
            if (cnt >= MAXPATH - 2) { fprintf(stderr, "path overflow\n"); return 6; }
            int j = idxj(P.x);
            Pt Nw = padd(P, RT[j]);
            u64 na = addN(a, RC[j]), nb = addN(b, RD[j]);
            if (Nw.inf) { /* P = -R_j: restart from a fresh random point (counted) */
                restarts++;
                do { na = rndN(); nb = rndN(); Nw = padd(pmul(P0, na), pmul(Q0, nb)); } while (Nw.inf);
            }
            m = canon(&Nw); na = mulN(m, na); nb = mulN(m, nb);
            for (;;) {
                cnt++;
                e = hlook(Nw.x, Nw.y, &found);
                if (!found) {
                    e->x = Nw.x; e->y = Nw.y; e->epoch = EPOCH; e->idx = cnt - 1;
                    PATH[cnt - 1].P = Nw; PATH[cnt - 1].a = na; PATH[cnt - 1].b = nb;
                    distinct++;
                    P = Nw; a = na; b = nb;
                    break;
                }
                Node *old = &PATH[e->idx];
                if (old->b != nb) { /* genuine collision: a + b k = na + nb k */
                    kf = mulN(subN(old->a, na), invN(subN(nb, old->b)));
                    solved = 1;
                    break;
                }
                /* fruitless cycle: points PATH[e->idx .. cnt-2]; leave via canon(2 * max-x point) */
                fruitless++;
                u64 bi = e->idx;
                for (u64 t = e->idx + 1; t <= cnt - 2; t++) if (PATH[t].P.x > PATH[bi].P.x) bi = t;
                Nw = pdbl(PATH[bi].P);
                na = addN(PATH[bi].a, PATH[bi].a); nb = addN(PATH[bi].b, PATH[bi].b);
                if (Nw.inf) { fprintf(stderr, "dbl inf\n"); return 7; }
                m = canon(&Nw); na = mulN(m, na); nb = mulN(m, nb);
                /* the escape point is a newly generated point: loop to look it up */
            }
        }
        int kok = (kf == k);
        int ver = peq(pmul(P0, kf), Q0);
        printf("%ld\t%s\t%llu\t%llu\t%llu\t%d\t%d\t%llu\n", inst, argv[1], (unsigned long long)cnt, (unsigned long long)(distinct + 1),
               (unsigned long long)fruitless, kok, ver, (unsigned long long)restarts);
        fflush(stdout);
    }
    return 0;
}
