# C4 audit: independent Sage checks of the T59 constants that the theory sqrt(pi N/(2c)) relies on.
# usage: sage -python sage_checks.py
import json, os, random, glob
from sage.all import GF, PolynomialRing, EllipticCurve, ZZ, is_prime, factor, Mod, Integer

RAW = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/raw/T59'
OUT = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C4-audit'
N = Integer(10063074221)
n = 59
res = {}
R = PolynomialRing(GF(2), 'z')
z = R.gen()
modpoly = z**59 + z**6 + z**5 + z**4 + z**3 + z + 1
res['modulus_irreducible'] = bool(modpoly.is_irreducible())
res['modulus_tail_hex'] = hex(sum(1 << i for i, c in enumerate(modpoly.list()[:59]) if c))
K = GF(2**59, 'z', modulus=modpoly)
g = K.gen()


def fe(h):
    v = int(h, 16)
    return K.from_integer(v)


res['N_prime'] = bool(is_prime(N))
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
card = E0.cardinality(algorithm="pari")
res['E0_card'] = str(card)
res['E0_card_factor'] = str(factor(card))
res['E0_card_div_N'] = bool(card % N == 0)
res['N2_not_div_card'] = bool(card % (N * N) != 0)
# tau eigenvalue
s = Integer(7715620412)
cof = card // N
while True:
    P = cof * E0.random_point()
    if not P.is_zero():
        break
assert (N * P).is_zero()
T = E0(P[0] ** 2, P[1] ** 2)
res['tau_is_s'] = bool(T == s * P)
ords = Mod(s, N).multiplicative_order()
res['ord_s_mod_N'] = int(ords)
res['minus1_in_<s>'] = bool(any(Mod(s, N) ** i == -1 for i in range(ords)))
res['class_size_negtau'] = int(2 * ords) if not res['minus1_in_<s>'] else int(ords)
# floor curves used in (i): their orders
fl = {}
for fn in sorted(glob.glob(os.path.join(RAW, 'inputs', '*__neg.txt'))):
    cfg = os.path.basename(fn)[:-4]
    h = {}
    first = None
    for line in open(fn):
        if line.startswith('inst'):
            if first is None:
                first = line.split()
            continue
        k, v = line.split()
        h[k] = v
    b = fe(h['b'])
    E = EllipticCurve(K, [1, int(h['a2']), 0, 0, b])
    c = E.cardinality(algorithm="pari")
    # check a few instances: P order N, Q = kP
    lines = [l.split() for l in open(fn) if l.startswith('inst')]
    random.seed(7)
    samp = random.sample(lines, 5)
    okinst = True
    for L in samp:
        Pp = E(fe(L[2]), fe(L[3]))
        Qp = E(fe(L[4]), fe(L[5]))
        k = Integer(L[6])
        okinst &= bool((N * Pp).is_zero() and not Pp.is_zero() and k * Pp == Qp)
    fl[cfg] = dict(b=h['b'], a2=h['a2'], j=str(E.j_invariant()), card=str(c), card_equals_E0=bool(c == card),
                   j_not_1=bool(E.j_invariant() != 1), sample_instances_ok=okinst)
res['neg_configs'] = fl
# transported/negtau/none instances live on E0: spot-check
for cfg in ['E0__negtau', 'E0__none', 'O00-000__transport_negtau', 'O01-029__transport_negtau']:
    lines = [l.split() for l in open(os.path.join(RAW, 'inputs', cfg + '.txt')) if l.startswith('inst')]
    random.seed(11)
    ok = True
    for L in random.sample(lines, 5):
        Pp = E0(fe(L[2]), fe(L[3])); Qp = E0(fe(L[4]), fe(L[5])); k = Integer(L[6])
        ok &= bool((N * Pp).is_zero() and not Pp.is_zero() and k * Pp == Qp)
    res['spot_' + cfg] = ok
import math
res['theory'] = {c: math.sqrt(math.pi * float(N) / (2 * c)) for c in (1, 2, 118)}
json.dump(res, open(os.path.join(OUT, 'sage_checks.json'), 'w'), indent=1)
print(json.dumps(res, indent=1))
