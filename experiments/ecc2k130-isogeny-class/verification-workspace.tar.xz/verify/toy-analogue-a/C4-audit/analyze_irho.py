#!/usr/bin/env python3
"""C4 audit: analyse the independent single-walk rho runs (irho.c) and compare them with the
sweep's raw T59 merge_steps (two-sample tests) and with the random-mapping theory."""
import csv, glob, json, math, os
import numpy as np
from scipy import stats

D = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C4-audit'
SW = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-a/raw/T59/out'
N = 10063074221
n = 59


def load(pattern):
    rows = []
    for fn in sorted(glob.glob(os.path.join(D, 'runs', pattern))):
        rows += list(csv.DictReader(open(fn), delimiter='\t'))
    return rows


def sweep(keys):
    v = []
    for k in keys:
        v += [int(r['merge_steps']) for r in csv.DictReader(open(os.path.join(SW, k + '.tsv')), delimiter='\t')]
    return np.array(v, float)


groups = {
    'i_floor_neg': ('O0*__neg__*.tsv', 2, ['O00-000__neg', 'O00-001__neg', 'O00-029__neg', 'O01-000__neg', 'O01-001__neg', 'O01-029__neg']),
    'ii_E0_negtau': ('E0__negtau__*.tsv', 2 * n, ['E0__negtau']),
    'iii_transport_negtau(sweep only; compare with my E0 negtau)': ('E0__negtau__*.tsv', 2 * n,
        ['O00-000__transport_negtau', 'O00-001__transport_negtau', 'O00-029__transport_negtau', 'O01-000__transport_negtau', 'O01-001__transport_negtau', 'O01-029__transport_negtau']),
    'iv_E0_neg': ('E0__neg__*.tsv', 2, ['E0__neg']),
    'v_E0_none': ('E0__none__*.tsv', 1, ['E0__none']),
    'control_E0_none_r4': ('E0__none_r4__*.tsv', 1, None),
}
out = {}
for g, (pat, c, swkeys) in groups.items():
    rows = load(pat)
    M = N / c
    th = math.sqrt(math.pi * M / 2)
    Ta = np.array([int(r['T_all']) for r in rows], float)
    Td = np.array([int(r['T_distinct']) for r in rows], float)
    ok = all(r['k_ok'] == '1' and r['verified'] == '1' for r in rows)
    fr = sum(int(r['fruitless']) for r in rows)
    rs = sum(int(r['restarts']) for r in rows)
    se = Td.std(ddof=1) / math.sqrt(len(Td))
    ks = stats.kstest(Td ** 2 / (2 * M), 'expon')
    o = dict(n=len(rows), all_logs_correct=ok, fruitless_total=fr, restarts=rs, theory=th,
             mean_T_distinct=float(Td.mean()), ratio_distinct=float(Td.mean() / th), half95=float(1.96 * se / th),
             mean_T_all=float(Ta.mean()), ratio_all=float(Ta.mean() / th), sd_over_mean=float(Td.std(ddof=1) / Td.mean()),
             ks_p_vs_Exp1=float(ks.pvalue))
    if swkeys:
        S = sweep(swkeys)
        o['sweep_n'] = len(S)
        o['sweep_ratio'] = float(S.mean() / th)
        o['ks2_sweep_vs_mine_p'] = float(stats.ks_2samp(S, Td).pvalue)
        o['mannwhitney_sweep_vs_mine_p'] = float(stats.mannwhitneyu(S, Td).pvalue)
        o['ratio_sweep_over_mine'] = float(S.mean() / Td.mean())
        o['ratio_sweep_over_mine_half95'] = float(1.96 * math.sqrt((S.std(ddof=1) / S.mean()) ** 2 / len(S) + (Td.std(ddof=1) / Td.mean()) ** 2 / len(Td)) * S.mean() / Td.mean())
    out[g] = o
    print(g)
    for k, v in o.items():
        print('   ', k, round(v, 4) if isinstance(v, float) else v)

# per floor curve (mine)
per = {}
for lab in ['O00-000', 'O00-001', 'O00-029', 'O01-000', 'O01-001', 'O01-029']:
    rows = load(f'{lab}__neg__*.tsv')
    Td = np.array([int(r['T_distinct']) for r in rows], float)
    th = math.sqrt(math.pi * N / 4)
    per[lab] = dict(n=len(Td), ratio=float(Td.mean() / th), ks_p=float(stats.kstest(Td ** 2 / (N / 2 * 2), 'expon').pvalue))
out['per_floor_curve_mine'] = per
print('per floor curve (mine):', json.dumps(per))

# Monte-Carlo: how often would 15 configs of the sweep's sizes all have KS p >= 0.148 and how spread are
# ratios under the exact random-mapping law (sampled via T = ceil(sqrt(2 M E)), E ~ Exp(1))
rng = np.random.default_rng(20260924)
sizes = [2000, 2000, 2000] + [500, 300] * 6
cs = [2, 118, 1] + [2, 118] * 6
minp, allpass = [], 0
R = 400
for _ in range(R):
    ps = []
    for sz, c in zip(sizes, cs):
        M = N / c
        T = np.ceil(np.sqrt(2 * M * rng.exponential(size=sz)))
        ps.append(stats.kstest(T ** 2 / (2 * M), 'expon').pvalue)
    minp.append(min(ps))
    allpass += min(ps) >= 0.148
out['mc_null_min_ks_p_over_15'] = dict(reps=R, frac_min_p_ge_0148=allpass / R, median_min_p=float(np.median(minp)))
print('MC under exact null: P(min KS p over 15 configs >= 0.148) =', allpass / R, ' median min p =', np.median(minp))
json.dump(out, open(os.path.join(D, 'analyze_irho.json'), 'w'), indent=1)
