import time
from sage.all import GF, PolynomialRing, EllipticCurve, Integer, pari
t0=time.time()
R = PolynomialRing(GF(2), 'z'); z = R.gen()
K = GF(2**59, 'z', modulus=z**59 + z**6 + z**5 + z**4 + z**3 + z + 1)
print('field', time.time()-t0, flush=True)
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
c = E0.cardinality(); print('E0 card', c, time.time()-t0, flush=True)
g=K.gen(); v=int('7c2b3204ad20544',16)
b = K.from_integer(v) if hasattr(K,'from_integer') else sum((g**i for i in range(59) if (v>>i)&1), K(0))
print('b', b == sum((g**i for i in range(59) if (v>>i)&1), K(0)), time.time()-t0, flush=True)
E = EllipticCurve(K, [1,0,0,0,b])
c2 = pari(E).ellcard() if False else None
t1=time.time(); c2 = E.cardinality(algorithm='pari'); print('floor card pari', c2, time.time()-t1, flush=True)
