#!/bin/bash
cd /Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C4-audit
out=$7
timeout 2400 ./irho $1 $2 $3 $4 $5 $6 > $out.part 2> $out.err && mv $out.part $out
