\\ C5 method 2b (PARI code path, cheap): psi_263 reduced mod my kernel polynomial h (via the
\\ char-2 division-polynomial recurrence computed mod h, validated against PARI elldivpol for
\\ n = 5..23), then PARI's own Velu (ellisogeny from h), codomain j, F_q-iso to E0, and
\\ planted pairs generated and checked with PARI ellmul.
\\ run with: gp -q -s 2000000000 divmod_check.gp
setrand(20260925);
read("kernels.gp");
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
fromint(n) = subst(Pol(binary(n)), 'x, z);
q = 2^131; N = 680564733841876926932320129493409985129;
E0 = ellinit([1,0,0,0,1], z);
DPF = Map(); DPM = 0; DPX = 0; DPA6 = 0;
{
dpv(k) =
  my(v, nn);
  if (mapisdefined(DPF, k, &v), return(v));
  if (k == 0, v = Mod(0, DPM),
  k == 1, v = Mod(1, DPM),
  k == 2, v = DPX,
  k == 3, v = DPX^4 + DPX^3 + DPA6,
  k == 4, v = DPX^6 + DPA6*DPX^2,
  k % 2 == 1, nn = (k-1)/2; v = dpv(nn+2)*dpv(nn)^3 + dpv(nn-1)*dpv(nn+1)^3,
  nn = k/2; v = dpv(nn)*(dpv(nn+2)*dpv(nn-1)^2 + dpv(nn-2)*dpv(nn+1)^2)/DPX);
  mapput(DPF, k, v);
  v;
}
{
divmod(n, a6, m) =
  DPF = Map(); DPM = m; DPX = Mod('x, m); DPA6 = a6;
  dpv(n);
}
{
check(lab, B, S) =
  my(b = fromint(B), E, h, KP, Ec, iso, Pp, Qp, Pk, Qk, k, ok = 0, res = Map(), smallok = 1, big);
  E = ellinit([1,0,0,0,b], z);
  if (E.j != 1/b, error("j"));
  big = 'x^40 + sum(i = 0, 39, random(z) * 'x^i);
  for (n = 1, 23, if (divmod(n, b, big) * if (n % 2, 1, Mod('x, big)) != Mod(elldivpol(E, n, 'x), big), smallok = 0));  \\ PARI elldivpol = psi_n (n odd), psi_n*psi_2 = psi_n*x (n even, char 2; checked exactly for n<=5 in dbg.gp)
  mapput(res, "recurrence_matches_elldivpol_n1_23", smallok);
  h = prod(i = 1, #S, 'x - fromint(S[i]));
  mapput(res, "h_deg", poldegree(h));
  mapput(res, "h_squarefree", poldegree(gcd(h, deriv(h))) == 0);
  mapput(res, "psi263_mod_h_is_0", divmod(263, b, h) == 0);
  mapput(res, "ctrl_psi131_mod_h_coprime", poldegree(gcd(lift(divmod(131, b, h)), h)) == 0);
  mapput(res, "ctrl_psi265_mod_h_coprime", poldegree(gcd(lift(divmod(265, b, h)), h)) == 0);
  KP = ellisogeny(E, h);
  Ec = ellinit(KP[1], z);
  mapput(res, "codomain_j_is_1", Ec.j == 1);
  if (Ec.a1 != 1 || Ec.a3 != 0 || Ec.a2 != 0, error("unexpected codomain shape"));
  iso = [1, 0, 0, Ec.a4];
  mapput(res, "iso_to_E0_ainv_ok", ellchangecurve(Ec, iso)[1..5] == E0[1..5]);
  for (i = 1, 5,
    Pp = [0];
    while (Pp == [0], Pp = ellmul(E, random(E), 4));
    k = random(N - 1) + 1;
    Qp = ellmul(E, Pp, k);
    Pk = ellchangepoint(ellisogenyapply(KP[2], Pp), iso);
    Qk = ellchangepoint(ellisogenyapply(KP[2], Qp), iso);
    ok += (ellisoncurve(E0, Pk) && ellisoncurve(E0, Qk) && Pk != [0] && ellmul(E0, Pk, N) == [0] && ellmul(E0, Pk, k) == Qk));
  mapput(res, "planted_ok_of_5", ok);
  print(lab, " ", Mat(res));
}
check("B077", B_B077, S_B077);
check("A000", B_A000, S_A000);
check("A065", B_A065, S_A065);
check("B130", B_B130, S_B130);
