read("divpol_check.gp");
check("B130", B_B130, S_B130);
