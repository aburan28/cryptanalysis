"""Dump b and my own kernel x-set (method 1 code path) for chosen labels as a gp file."""
import json, random, sys
from gf2m import Curve
d = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json'))
q = 2**131; t = int(d['meta']['t']); TW = q + 1 + t; H1 = TW // 263
rng = random.Random(777)
out = open('kernels.gp', 'w')
recs = {r['label']: r for r in d['curves']}
for lab in sys.argv[1:]:
    b = int(recs[lab]['b_int']); Et = Curve(1, 0, b)
    while True:
        K = Et.smul(H1, Et.random_point(rng))
        if K is not None: break
    xs, T = [], None
    for i in range(131):
        T = Et.add(T, K); xs.append(T[0])
    out.write('B_%s = %d;\nS_%s = [%s];\n' % (lab, b, lab, ','.join(map(str, xs))))
out.close()
