default(parisize, 2*10^9);
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
a = z^5+z+1;
iferr(P = polmodular(11, 0, a, 'y); print("ffelt ok deg ", poldegree(P)), E, print("ERR ", E));
