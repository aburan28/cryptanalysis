read("divpol_check.gp");
check("A000", B_A000, S_A000);
