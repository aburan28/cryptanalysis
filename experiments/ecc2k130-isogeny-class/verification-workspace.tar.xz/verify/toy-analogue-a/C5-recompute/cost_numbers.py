"""Cost numbers and the mod-263 Frobenius characteristic polynomial (own computation)."""
from mpmath import mp, mpf, pi, sqrt, log
mp.dps = 50
q = 2**131; t = -22283658519494248867; N = 680564733841876926932320129493409985129
f = 38531015900842053623; p = 146505763881528721
assert t*t - 4*q == -7*f*f and f == 263*p and q + 1 - t == 4*N
print('log2 N =', mp.nstr(log(N, 2), 10))
for name, m in [('negation only (class 2)', 2), ('negation+tau (class 262)', 262)]:
    it = sqrt(pi*N/(2*m))
    print(name, 'log2 sqrt(pi N/(2m)) =', mp.nstr(log(it, 2), 8))
print('gap log2 =', mp.nstr(log(sqrt(mpf(131)), 2), 8))
l = 263
print('t mod 263 =', t % l, ' q mod 263 =', q % l, ' disc t^2-4q mod 263 =', (t*t - 4*q) % l)
# char poly x^2 - t x + q mod 263 == (x - lam)^2 ?
lam = (t * pow(2, -1, l)) % l
print('double root lam = t/2 mod 263 =', lam, ' check lam^2 == q:', lam*lam % l == q % l)
print('v263(q+1-t) =', next(i for i in range(10) if (q+1-t) % l**(i+1)), ' v263(q+1+t) =', next(i for i in range(10) if (q+1+t) % l**(i+1)))
print('N mod 263 =', N % 263)
