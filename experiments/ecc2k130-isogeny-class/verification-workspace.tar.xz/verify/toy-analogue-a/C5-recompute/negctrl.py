"""Negative controls: my Velu check must FAIL for a wrong kernel (other curve's kernel / one x perturbed)."""
import json, random, sys
sys.argv = ['x', '0', 'NONE']   # load helpers from c5_sweep without running any curve
import c5_sweep as C
from gf2m import Curve, sqr
d = json.load(open(C.GT)); recs = {r['label']: r for r in d['curves']}
rng = random.Random(5)
bA = int(recs['B077']['b_int']); bB = int(recs['A000']['b_int'])
E = Curve(0, 0, bA)
S_good = C.kernel_xset(Curve(1, 0, bA))
S_other = C.kernel_xset(Curve(1, 0, bB))
S_pert = list(S_good); S_pert[7] ^= 1
for name, S in [('good', S_good), ('other-curve kernel', S_other), ('one x perturbed', S_pert)]:
    v = 0
    for x in S: v ^= x
    Cc = Curve(0, v, bA ^ v)
    A = E.random_point(rng); B = E.random_point(rng)
    PA = C.velu_eval(S, A)
    on = Cc.on(PA)
    hom = C.velu_eval(S, E.add(A, B)) == Cc.add(PA, C.velu_eval(S, B))
    print(name, ' j(C)==1:', (bA ^ v ^ sqr(v)) == 1, ' image on C:', on, ' hom:', hom)
