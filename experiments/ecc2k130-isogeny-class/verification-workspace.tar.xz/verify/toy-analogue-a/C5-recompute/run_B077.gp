read("divpol_check.gp");
check("B077", B_B077, S_B077);
