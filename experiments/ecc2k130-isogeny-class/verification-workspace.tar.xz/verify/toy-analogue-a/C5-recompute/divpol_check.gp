\\ C5 method 2 (PARI code path): kernel of the F_q-rational 263-isogeny of a floor curve from
\\ gcd(psi_263(x), x^q - x), PARI ellisogeny (its own Velu) from that kernel polynomial,
\\ codomain j, F_q-isomorphism to E0, planted relations generated and checked with PARI ellmul.
\\ run with: gp -s 4000000000
setrand(20260924);
read("kernels.gp");
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
fromint(n) = subst(Pol(binary(n)), 'x, z);
toint(e) = subst(lift(e.pol), variable(e.pol), 2);
q = 2^131; N = 680564733841876926932320129493409985129; t = -22283658519494248867;
E0 = ellinit([1,0,0,0,1], z);
{
check(lab, B, S) =
  my(b = fromint(B), E, f, T0, T1, g, h, xq, KP, iso, Ec, s, tt, Pp, Qp, Pk, Qk, k, ok = 0, res = Map());
  E = ellinit([1,0,0,0,b], z);
  if (E.j != 1/b, error("j"));
  T0 = getabstime();
  f = elldivpol(E, 263, 'x);
  mapput(res, "divpol_deg", poldegree(f));
  mapput(res, "divpol_s", (getabstime()-T0)/1000.);
  T1 = getabstime();
  xq = lift(Mod('x, f)^q);
  g = gcd(f, xq - 'x);
  g = g / pollead(g);
  mapput(res, "frob_gcd_s", (getabstime()-T1)/1000.);
  mapput(res, "gcd_deg", poldegree(g));
  h = prod(i = 1, #S, 'x - fromint(S[i]));
  mapput(res, "gcd_equals_my_kernel_poly", g == h); print(lab, " stage1 ", Mat(res)); writebin(Str("gcd_", lab, ".bin"), g);
  \\ isogeny from kernel polynomial (PARI's Velu)
  KP = ellisogeny(E, g);
  Ec = ellinit(KP[1], z);
  mapput(res, "codomain_ainv", apply(toint, Vec(Ec[1..5])));
  mapput(res, "codomain_j_is_1", Ec.j == 1);
  \\ iso to E0: need a1 = 1, a3 = 0 form; then s^2+s = a2, t = a4 (derived by hand)
  if (Ec.a1 != 1 || Ec.a3 != 0, error("unexpected codomain shape"));
  s = 0;
  if (Ec.a2 != 0, error("a2 != 0"));
  tt = Ec.a4;
  iso = [1, 0, s, tt];
  mapput(res, "iso_to_E0_ainv_ok", ellchangecurve(Ec, iso)[1..5] == E0[1..5]);
  for (i = 1, 3,
    Pp = ellmul(E, random(E), 4);
    if (Pp == [0], next);
    k = random(N - 1) + 1;
    Qp = ellmul(E, Pp, k);
    Pk = ellchangepoint(ellisogenyapply(KP[2], Pp), iso);
    Qk = ellchangepoint(ellisogenyapply(KP[2], Qp), iso);
    ok += (ellisoncurve(E0, Pk) && ellisoncurve(E0, Qk) && Pk != [0] && ellmul(E0, Pk, N) == [0] && ellmul(E0, Pk, k) == Qk));
  mapput(res, "planted_ok_of_3", ok);
  print(lab, " ", Mat(res));
}
