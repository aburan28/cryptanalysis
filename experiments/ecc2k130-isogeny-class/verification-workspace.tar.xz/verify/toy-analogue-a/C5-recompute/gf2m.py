"""Independent pure-Python arithmetic for C5 re-verification (no Sage, no sweep code).

F_q = F_2[z]/(z^131 + z^13 + z^2 + z + 1), elements = int bitmasks (bit i = z^i).
Curves: y^2 + x*y = x^3 + a2*x^2 + a4*x + a6 (a1 = 1, a3 = 0), affine points, None = O.
"""
import random

M = 131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << M) - 1


def reduce(r):
    while r >> M:
        hi = r >> M
        r = (r & MASK) ^ hi ^ (hi << 1) ^ (hi << 2) ^ (hi << 13)
    return r


def clmul(a, b):
    # 4-bit windowed carry-less multiply
    T = [0] * 16
    T[1] = b
    for i in range(2, 16):
        T[i] = (T[i >> 1] << 1) if not (i & 1) else (T[i - 1] ^ b)
    r = 0
    nb = (a.bit_length() + 3) // 4
    for k in range(nb - 1, -1, -1):
        r = (r << 4) ^ T[(a >> (4 * k)) & 15]
    return r


def mul(a, b):
    return reduce(clmul(a, b))


def sqr(a):
    return reduce(clmul(a, a))


def inv(a):
    assert a != 0
    u, v, g1, g2 = a, MOD, 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v, g1, g2, j = v, u, g2, g1, -j
        u ^= v << j
        g1 ^= g2 << j
    return reduce(g1)


def pow2k(a, k):
    for _ in range(k):
        a = sqr(a)
    return a


def power(a, e):
    r = 1
    while e:
        if e & 1:
            r = mul(r, a)
        a = sqr(a)
        e >>= 1
    return r


def trace(a):
    s, x = a, a
    for _ in range(M - 1):
        x = sqr(x)
        s ^= x
    assert s in (0, 1)
    return s


def halftrace(a):
    s, x = a, a
    for _ in range((M - 1) // 2):
        x = sqr(sqr(x))
        s ^= x
    return s


class Curve:
    def __init__(self, a2, a4, a6):
        self.a2, self.a4, self.a6 = a2, a4, a6

    def on(self, P):
        if P is None:
            return True
        x, y = P
        lhs = sqr(y) ^ mul(x, y)
        x2 = sqr(x)
        rhs = mul(x2, x) ^ mul(self.a2, x2) ^ mul(self.a4, x) ^ self.a6
        return lhs == rhs

    def neg(self, P):
        if P is None:
            return None
        return (P[0], P[0] ^ P[1])

    def add(self, P, Q):
        if P is None:
            return Q
        if Q is None:
            return P
        x1, y1 = P
        x2, y2 = Q
        if x1 == x2:
            if y1 ^ y2 == x1:  # Q = -P (covers 2-torsion x=0 too)
                return None
            return self.dbl(P)
        lam = mul(y1 ^ y2, inv(x1 ^ x2))
        x3 = sqr(lam) ^ lam ^ x1 ^ x2 ^ self.a2
        y3 = mul(lam, x1 ^ x3) ^ x3 ^ y1
        return (x3, y3)

    def dbl(self, P):
        if P is None:
            return None
        x1, y1 = P
        if x1 == 0:
            return None
        lam = x1 ^ mul(y1 ^ self.a4, inv(x1))
        x3 = sqr(lam) ^ lam ^ self.a2
        y3 = mul(lam ^ 1, x3) ^ y1 ^ mul(lam, x1)
        return (x3, y3)

    def smul(self, k, P):
        if k < 0:
            return self.smul(-k, self.neg(P))
        R = None
        for bit in bin(k)[2:] if k else '':
            R = self.dbl(R)
            if bit == '1':
                R = self.add(R, P)
        return R

    def random_point(self, rng):
        while True:
            x = rng.getrandbits(M)
            if x == 0:
                continue
            x2 = sqr(x)
            c = mul(x2, x) ^ mul(self.a2, x2) ^ mul(self.a4, x) ^ self.a6
            w = mul(c, inv(x2))
            if trace(w):
                continue
            z = halftrace(w)
            y = mul(x, z)
            if rng.getrandbits(1):
                y ^= x
            P = (x, y)
            assert self.on(P)
            return P
