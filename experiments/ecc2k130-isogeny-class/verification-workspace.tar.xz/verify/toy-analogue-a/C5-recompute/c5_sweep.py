"""C5 re-verification, method 1: own pure-Python code path (no Sage, no sweep code, no ecc2k.py).

For every floor curve E: y^2+xy = x^3 + b (a2 = 0, b from ground_truth.json):
 1. check b*j = 1, and #E(F_q) = 4N by random points ([4N]P = O, [4]P != O => N | ord).
 2. twist E': y^2+xy = x^3 + x^2 + b. Check #E' = q+1+t on random points, and find a point of
    order 263^2 (=> E'(F_q)[263^inf] cyclic => E(F_{q^2})[263] = ker(pi+1) is ONE line, as
    E(F_q)[263] = 0 because 263 does not divide 4N).
 3. kernel: K = [(q+1+t)/263] R', 131 x-coords x(iK), i=1..131 (these are the x-coords of
    E(F_{q^2})[263]\\{O} up to sign; pi = -1 on them since they come from the twist).
 4. own char-2 Velu (derived by hand from Velu's general formulas, a1=1,a3=0,a4=0):
       v = sum x_Q ; codomain C = [1, 0, 0, v, b+v], j(C) = 1/(b + v + v^2)
       X = x + sum( x_Q/(x+x_Q) + x_Q^2/(x+x_Q)^2 )
       Y = y + sum( x_Q^2 x/(x+x_Q)^3 + x_Q (x + y + x_Q^2)/(x+x_Q)^2 )
    and the F_q-isomorphism C -> E0 = [1,0,0,0,1]: (X, Y) -> (X, Y + v)   (valid iff b+v+v^2 = 1).
 5. per curve: NREL planted relations Q = kP (P = [4]R, order N), check phi(Q) = k phi(P) on E0,
    phi(P) on E0, [N]phi(P) = O, phi(P) != O; plus a homomorphism test phi(P+R) = phi(P)+phi(R)
    and a kernel-independence test (a second random kernel generator gives the same x-set).
"""
import json, random, sys, time, math, hashlib
from gf2m import Curve, mul, sqr, inv, MOD

GT = '/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json'
OUT = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-a/C5-recompute/c5_sweep_results.json'
NREL = int(sys.argv[1]) if len(sys.argv) > 1 else 3
ONLY = sys.argv[2:]

d = json.load(open(GT))
meta = d['meta']
assert int(meta['modulus_int']) == MOD
q = 2 ** 131
t = int(meta['t'])
N = int(meta['N'])
assert q + 1 - t == 4 * N == int(meta['card'])
TW = q + 1 + t
assert TW == int(meta['twist_card'])
assert TW % 263 ** 2 == 0 and (TW // 263 ** 2) % 263 != 0 and N % 263 != 0
H1 = TW // 263
H2 = TW // 263 ** 2

rng = random.Random(20260924)
E0 = Curve(0, 0, 1)


def batch_inv(vals):
    pref = [1] * (len(vals) + 1)
    for i, a in enumerate(vals):
        pref[i + 1] = mul(pref[i], a)
    ia = inv(pref[-1])
    out = [0] * len(vals)
    for i in range(len(vals) - 1, -1, -1):
        out[i] = mul(ia, pref[i])
        ia = mul(ia, vals[i])
    return out


def velu_eval(S, P):
    if P is None:
        return None
    x, y = P
    ds = [x ^ xq for xq in S]
    if 0 in ds:
        return None  # P in kernel
    ids = batch_inv(ds)
    X, Y = x, y
    for xq, i1 in zip(S, ids):
        i2 = sqr(i1)
        i3 = mul(i2, i1)
        xq2 = sqr(xq)
        X ^= mul(xq, i1) ^ mul(xq2, i2)
        Y ^= mul(mul(xq2, x), i3) ^ mul(mul(xq, x ^ y ^ xq2), i2)
    return (X, Y)


def kernel_xset(Et):
    while True:
        R = Et.random_point(rng)
        K = Et.smul(H1, R)
        if K is not None:
            break
    assert Et.smul(263, K) is None
    xs, T = [], None
    for i in range(1, 132):
        T = Et.add(T, K)
        assert T is not None
        xs.append(T[0])
    assert len(set(xs)) == 131 and 0 not in xs
    return xs


res = {}
t_all = time.time()
labels_done = 0
for rec in d['curves']:
    lab = rec['label']
    if lab == 'E0' or (ONLY and lab not in ONLY):
        continue
    t0 = time.time()
    b = int(rec['b_int'])
    j = int(rec['j_int'])
    assert int(rec['a2']) == 0 and mul(b, j) == 1 and j not in (0, 1)
    E = Curve(0, 0, b)
    Et = Curve(1, 0, b)
    r = {}
    # 1. order of E
    R = E.random_point(rng)
    P4 = E.smul(4, R)
    r['E_order_4N_randpoint'] = P4 is not None and E.smul(N, P4) is None
    # 2. twist order and cyclic 263-part
    Rt = Et.random_point(rng)
    r['twist_order_randpoint'] = Et.smul(TW, Rt) is None
    cyc = False
    for _ in range(20):
        U = Et.smul(H2, Et.random_point(rng))
        if U is not None and Et.smul(263, U) is not None:
            cyc = Et.smul(263 * 263, U) is None
            break
    r['twist_263part_cyclic_order_263sq_point'] = cyc
    # 3. kernel
    S = kernel_xset(Et)
    S2 = kernel_xset(Et)
    r['kernel_xset_independent_of_generator'] = set(S) == set(S2)
    # 4. codomain
    v = 0
    for xq in S:
        v ^= xq
    delta = b ^ v ^ sqr(v)
    r['codomain_j_is_1'] = (delta == 1)
    C = Curve(0, v, b ^ v)
    # 5. transport
    ok = 0
    hom_ok = True
    for _ in range(NREL):
        while True:
            P = E.smul(4, E.random_point(rng))
            if P is not None:
                break
        k = rng.randrange(1, N)
        Q = E.smul(k, P)
        PC = velu_eval(S, P)
        QC = velu_eval(S, Q)
        good = C.on(PC) and C.on(QC)
        Pe = (PC[0], PC[1] ^ v)
        Qe = (QC[0], QC[1] ^ v)
        good = good and E0.on(Pe) and E0.on(Qe)
        good = good and Pe is not None and E0.smul(N, Pe) is None and E0.smul(k, Pe) == Qe
        ok += bool(good)
    # homomorphism test with a random pair
    A = E.random_point(rng)
    B = E.random_point(rng)
    lhs = velu_eval(S, E.add(A, B))
    rhs = C.add(velu_eval(S, A), velu_eval(S, B))
    hom_ok = (lhs == rhs)
    # doubling-compatibility (phi([2]A) = [2]phi(A)) also checks the a4 = v in C
    hom_ok = hom_ok and velu_eval(S, E.dbl(A)) == C.dbl(velu_eval(S, A))
    r['homomorphism_test'] = hom_ok
    r['planted_ok'] = ok
    r['of'] = NREL
    r['v_int'] = str(v)
    r['kernel_poly_sha256'] = hashlib.sha256(','.join(map(str, sorted(S))).encode()).hexdigest()
    r['seconds'] = round(time.time() - t0, 2)
    res[lab] = r
    labels_done += 1
    allok = all(val for kk, val in r.items() if isinstance(val, bool)) and ok == NREL
    print(lab, 'ALLOK' if allok else 'FAIL', r['seconds'], flush=True)
    if not allok:
        print(json.dumps(r), flush=True)

summ = {
    'n_curves': labels_done,
    'all_flags_true': all(all(val for kk, val in r.items() if isinstance(val, bool)) for r in res.values()),
    'planted_total_ok': sum(r['planted_ok'] for r in res.values()),
    'planted_total': sum(r['of'] for r in res.values()),
    'distinct_v': len(set(r['v_int'] for r in res.values())),
    'wall_s': round(time.time() - t_all, 1),
}
print(json.dumps(summ))
if labels_done:  # negctrl.py imports this module with no labels; never overwrite results then
    json.dump({'summary': summ, 'per_curve': res}, open(OUT, 'w'), indent=1)
