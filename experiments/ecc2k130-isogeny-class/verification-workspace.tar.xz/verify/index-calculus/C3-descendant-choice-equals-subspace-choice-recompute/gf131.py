"""Independent pure-Python GF(2^131) arithmetic (no Sage, no ecc2k.py).

Field: F_2[z]/(z^131 + z^13 + z^2 + z + 1); an element is a Python int whose bit i is the
coefficient of z^i (the encoding documented in ground_truth/README.md).
Written from scratch for the C3 recompute check; used for reference values and for
validating the C counter (count131.c).
"""
M = 131
POLY = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << M) - 1


def clmul(a, b):
    r = 0
    while b:
        low = b & -b
        r ^= a << (low.bit_length() - 1)
        b ^= low
    return r


def red(r):
    # polynomial remainder mod POLY, bit by bit from the top
    while r.bit_length() > M:
        s = r.bit_length() - 1 - M
        r ^= POLY << s
    return r


def mul(a, b):
    return red(clmul(a, b))


def sqr(a):
    # spread bits then reduce (independent of clmul)
    r = 0
    i = 0
    while a:
        if a & 1:
            r |= 1 << (2 * i)
        a >>= 1
        i += 1
    return red(r)


def pw(a, e):
    r = 1
    while e:
        if e & 1:
            r = mul(r, a)
        a = mul(a, a)
        e >>= 1
    return r


def inv(a):
    assert a != 0
    # extended Euclid over F_2[z]
    u, v = a, POLY
    g1, g2 = 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v = v, u
            g1, g2 = g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return red(g1)


def sqrt(a):
    # a^(2^130)
    for _ in range(M - 1):
        a = sqr(a)
    return a


def trace(a):
    t = a
    s = a
    for _ in range(M - 1):
        t = sqr(t)
        s ^= t
    assert s in (0, 1)
    return s


def halftrace(c):
    h = c
    t = c
    for _ in range((M - 1) // 2):
        t = sqr(sqr(t))
        h ^= t
    return h


def on_curve(x, y, a2, b):
    lhs = sqr(y) ^ mul(x, y)
    x2 = sqr(x)
    rhs = mul(x2, x) ^ mul(a2, x2) ^ b
    return lhs == rhs


def liftable(x, b, a2=0):
    """return a y with (x,y) on y^2+xy = x^3+a2 x^2+b, or None; verified on the curve"""
    if x == 0:
        y = sqrt(b)
        assert on_curve(0, y, a2, b)
        return y
    c = x ^ a2 ^ mul(b, inv(sqr(x)))
    w = halftrace(c)
    y = mul(x, w)
    if on_curve(x, y, a2, b):
        return y
    assert trace(c) == 1
    return None


def gf2_rank(vs):
    rows = [v for v in vs]
    rank = 0
    basis = {}
    for v in rows:
        while v:
            hb = v.bit_length() - 1
            if hb in basis:
                v ^= basis[hb]
            else:
                basis[hb] = v
                rank += 1
                break
    return rank
