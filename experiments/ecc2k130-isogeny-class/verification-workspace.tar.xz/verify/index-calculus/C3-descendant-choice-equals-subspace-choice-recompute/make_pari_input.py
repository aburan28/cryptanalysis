"""Write pari_input.gp: BINT = Map(label -> b as integer) from ground_truth.json."""
import json, os
HERE = os.path.dirname(os.path.abspath(__file__))
gt = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
with open(os.path.join(HERE, "pari_input.gp"), "w") as fh:
    fh.write("BINT = Map();\n")
    for c in gt["curves"]:
        fh.write('mapput(BINT, "%s", %s);\n' % (c["label"], c["b_int"]))
    fh.write('TWISTCARD = %s;\nCARD = %s;\n' % (gt["meta"]["twist_card"], gt["meta"]["card"]))
print("wrote", len(gt["curves"]))
