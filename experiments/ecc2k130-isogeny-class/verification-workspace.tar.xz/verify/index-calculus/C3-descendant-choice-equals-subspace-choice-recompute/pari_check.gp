\\ C3 recompute, PARI/GP (standalone gp, not Sage) cross-check.
\\ Inputs come from pari_input.gp (b values copied from ground_truth.json by make_pari_input.py).
\\ 1. sqrt(z^i) = (z^i)^(2^130) for i < 16 in PARI's own F_{2^131}.
\\ 2. C(A057, sqrt V_k) via ellordinate over span{sqrt(z^i)}, and C(A058, V_k) via ellordinate,
\\    also E0 and the wrap-around A130 -> A000, B130 -> B000, k = 1..16.
\\ 3. sigma(x,y) = (x^2,y^2) is a homomorphism E_b(F_q) -> E_{b^2}(F_q) on random points.
default(parisize, 400000000);
read("pari_input.gp");
f = Mod(1,2)*(x^131+x^13+x^2+x+1);
if(!polisirreducible(f), error("modulus"));
z = ffgen(f, 'z);
fromint(n) = my(v=binary(n), r=0*z); for(i=1,#v, r = r*z + v[i]); r;
toint(e) = my(p=lift(e.pol), s=0); for(i=0,poldegree(p), s += polcoef(p,i)*2^i); s;
\\ ---- 1
sq = vector(16, i, (z^(i-1))^(2^130));
for(i=1,16, if(sq[i]^2 != z^(i-1), error("sqrt")));
print("SQRTHEX ", apply(e->Str(toint(e)), sq));
\\ ---- 2: counts over span(basis[1..k]) with ellordinate
countspan(E, basis) = {
  my(n=#basis, xs=vector(2^n), cnt=0, out=vector(n));
  xs[1] = 0*z;
  for(c=1, 2^n-1, my(low=valuation(c,2)); xs[c+1] = xs[bitand(c,c-1)+1] + basis[low+1]);
  for(c=0, 2^n-1,
    if(#ellordinate(E, xs[c+1]) > 0, cnt++);
    for(k=1,n, if(c == 2^k-1, out[k] = cnt)));
  out;
}
canon = vector(16, i, z^(i-1));
curve(bint) = ellinit([1,0,0,0,fromint(bint)], z);
pairs = [["A057","A058"], ["A130","A000"], ["B130","B000"], ["B021","B022"], ["E0","E0"]];
{for(i=1,#pairs,
  my(a=pairs[i][1], b=pairs[i][2], Ea=curve(mapget(BINT,a)), Eb=curve(mapget(BINT,b)), cs, cv);
  cs = countspan(Ea, sq);
  cv = countspan(Eb, canon);
  print("PAIR ", a, " ", b, " C(", a, ",sqrtV)=", cs, " C(", b, ",V)=", cv, " equal=", cs==cv));}
\\ ---- 3: homomorphism on random points
setrand(20260923);
homok = 0; homtot = 0;
sig(P) = if(P==[0], [0], [P[1]^2, P[2]^2]);
{for(i=1,#pairs,
  my(Ea=curve(mapget(BINT,pairs[i][1])), Eb=curve(mapget(BINT,pairs[i][2])));
  for(r=1,20,
    my(P=random(Ea), Q=random(Ea), m=random(2^130));
    homtot++;
    if(ellisoncurve(Eb, sig(P)) && sig(elladd(Ea,P,Q)) == elladd(Eb,sig(P),sig(Q)) && sig(ellmul(Ea,P,m)) == ellmul(Eb,sig(P),m), homok++)));}
print("HOM ", homok, "/", homtot);
