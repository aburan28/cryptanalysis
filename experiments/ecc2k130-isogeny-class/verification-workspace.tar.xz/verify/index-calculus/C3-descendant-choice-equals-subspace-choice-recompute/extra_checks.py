"""C3 recompute, extra checks (own code; uses count131 and gf131.py).

(a) PARI sqrt basis (pari_check.log) == my sqrt basis; PARI counts == my C counts == per_curve.json.
(b) Iterated identity: C(X_j, V_k) = C(X_0, V_k^(1/2^j)) for every j = 0..130, both orbits, k <= 14
    (the orbit is one curve seen through 131 subspaces).
(c) E0 with 262 random 16-dim subspaces vs the 262 floor curves on the canonical V:
    is the best descendant's count inside the spread E0 gets by choosing subspaces?
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; python3 extra_checks.py
"""
import os, sys, json, time, subprocess, random, math, ast
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf131 as F

t0 = time.time()
res = {}
rc = json.load(open(os.path.join(HERE, "recompute_chart.json")))
CV = rc["counts_canonV"]
gt = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
B = {c["label"]: int(c["b_int"]) for c in gt["curves"]}
pc = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/index-calculus/per_curve.json"))


def run_counts(bvals, basis):
    inp = "%d\n" % len(bvals) + "".join("%x\n" % b for b in bvals) + "%d\n" % len(basis) + \
          "".join("%x\n" % v for v in basis)
    out = subprocess.run([os.path.join(HERE, "count131")], input=inp, capture_output=True, text=True,
                         check=True, timeout=2400).stdout.strip().split("\n")
    return [list(map(int, ln.split()))[1:] for ln in out]


# (a)
log = open(os.path.join(HERE, "pari_check.log")).read().split("\n")
sqline = [l for l in log if l.startswith("SQRTHEX ")][0]
pari_sq = [int(s) for s in ast.literal_eval(sqline[len("SQRTHEX "):])]
my_sq = [int(h, 16) for h in rc["sqrt_basis_hex"]]
res["pari_sqrt_basis_equals_mine"] = pari_sq == my_sq
pairs = {}
for l in log:
    if l.startswith("PAIR "):
        parts = l.split()
        a, b = parts[1], parts[2]
        cs = ast.literal_eval(l.split("sqrtV)=")[1].split(" C(")[0])
        cv = ast.literal_eval(l.split(",V)=")[1].split(" equal")[0])
        pairs[a + "->" + b] = {
            "pari_C_a_sqrtV_eq_pari_C_b_V": cs == cv,
            "pari_C_b_V_eq_my_C_b_V": cv == CV[b],
            "pari_C_a_sqrtV_eq_my_C_a_sqrtV": cs == rc["counts_sqrtV"][a],
            "pari_C_b_V_eq_per_curve_k8_16": all(cv[k - 1] == pc[b]["count_incl_x0"]["canon"]["k%d" % k]
                                                   for k in range(8, 17)),
            "C_b_V_k8_k10_k12_k16": [cv[7], cv[9], cv[11], cv[15]],
        }
res["pari_pairs"] = pairs
print("(a)", res["pari_sqrt_basis_equals_mine"], json.dumps(pairs), flush=True)

# (b)
KB = 14
iter_ok = 0
iter_tot = 0
iter_fail = []
for orb in "AB":
    basis = [1 << i for i in range(KB)]
    for j in range(131):
        if j > 0:
            basis = [F.sqrt(v) for v in basis]          # V^(1/2^j)
        c0 = run_counts([B["%s000" % orb]], basis)[0]
        target = CV["%s%03d" % (orb, j)][:KB]
        iter_tot += 1
        if c0 == target:
            iter_ok += 1
        else:
            iter_fail.append((orb, j, c0, target))
    # closing the orbit: V^(1/2^131) = V
    res["V_pow_2^-131_equals_V_%s" % orb] = [F.sqrt(v) for v in basis] == [1 << i for i in range(KB)]
res["iterated_identity"] = {"k_max": KB, "orbit_members_checked": iter_tot, "all_k_match": iter_ok,
                            "fails": iter_fail[:5]}
print("(b)", res["iterated_identity"], res.get("V_pow_2^-131_equals_V_A"), flush=True)

# (c) E0 on random subspaces
rng = random.Random(31337)
e0c = []
for r in range(262):
    while True:
        bas = [rng.getrandbits(131) for _ in range(16)]
        if F.gf2_rank(bas) == 16:
            break
    e0c.append(run_counts([B["E0"]], bas)[0])
floor = [l for l in CV if l != "E0"]
spread = {}
for k in range(8, 17):
    fl = [CV[l][k - 1] for l in floor]
    e0 = [row[k - 1] for row in e0c]
    mu = 2 ** (k - 1)
    sd = math.sqrt(2 ** k) / 2
    best = max(floor, key=lambda l: CV[l][k - 1])
    spread[k] = {"floor_canonV_min_max": [min(fl), max(fl)], "best_descendant": best,
                 "E0_randomW_min_max": [min(e0), max(e0)],
                 "floor_sd": round(math.sqrt(sum((x - sum(fl) / len(fl)) ** 2 for x in fl) / (len(fl) - 1)), 2),
                 "E0_randomW_sd": round(math.sqrt(sum((x - sum(e0) / len(e0)) ** 2 for x in e0) / (len(e0) - 1)), 2),
                 "binomial_sd": round(sd, 2),
                 "z_best_descendant": round((max(fl) - mu) / sd, 2),
                 "z_best_E0_subspace": round((max(e0) - mu) / sd, 2),
                 "frac_E0_subspaces_ge_best_descendant": round(sum(1 for x in e0 if x >= max(fl)) / len(e0), 4)}
res["E0_random_subspaces_vs_floor"] = spread
for k, v in spread.items():
    print("(c) k=%d" % k, v, flush=True)
res["E0_random_counts"] = e0c
res["elapsed_s"] = time.time() - t0
json.dump(res, open(os.path.join(HERE, "extra_checks.json"), "w"), indent=0)
print("done %.1fs" % (time.time() - t0))
