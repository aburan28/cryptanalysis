/* Independent liftable-x counter for y^2 + x y = x^3 + b over F_2[z]/(z^131+z^13+z^2+z+1).
 *
 * Written from scratch for the C3 recompute check (does not reuse the sweep's BLAS/Hankel
 * trace method).  Criterion per x != 0: c = x + b/x^2, w = HalfTrace(c), y = x*w, and x is
 * counted iff (x, y) satisfies the curve equation EXACTLY (explicit point).  For x not
 * counted we also assert Tr(c) = 1 (so no y exists).  x = 0 is counted after checking
 * y = sqrt(b) satisfies y^2 = b.  Every inversion is checked (x * x^-1 == 1).
 *
 * Input (stdin, hex without 0x, one per line):
 *   ncurves  then ncurves lines b
 *   nbasis   then nbasis lines basis vectors
 * Output: for each curve one line "idx C_1 C_2 ... C_nbasis" where C_k = #{liftable x in
 *   span(basis[0..k-1])} (including x = 0), enumerating x[c] = XOR_{bit i of c} basis[i].
 * Self-test mode: ./count131 selftest   prints products for Python cross-validation.
 */
#include <arm_neon.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { uint64_t w[3]; } fe;

static inline void clmul64(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    poly128_t r = vmull_p64((poly64_t)a, (poly64_t)b);
    uint64x2_t v = vreinterpretq_u64_p128(r);
    *lo = vgetq_lane_u64(v, 0);
    *hi = vgetq_lane_u64(v, 1);
}

/* reduce a 6-word polynomial (degree <= 260) mod z^131+z^13+z^2+z+1 */
static inline fe reduce6(uint64_t r[6]) {
    for (int pass = 0; pass < 2; pass++) {
        /* H = r >> 131 (up to 3 words, r has at most 5 significant words) */
        uint64_t h0 = (r[2] >> 3) | (r[3] << 61);
        uint64_t h1 = (r[3] >> 3) | (r[4] << 61);
        uint64_t h2 = (r[4] >> 3) | (r[5] << 61);
        uint64_t h3 = (r[5] >> 3);
        /* L = r mod 2^131 */
        r[2] &= 7ULL; r[3] = 0; r[4] = 0; r[5] = 0;
        /* r ^= H * (1 + z + z^2 + z^13) */
        uint64_t H[4] = {h0, h1, h2, h3};
        int sh[4] = {0, 1, 2, 13};
        for (int s = 0; s < 4; s++) {
            int k = sh[s];
            for (int i = 0; i < 4; i++) {
                if (k == 0) { r[i] ^= H[i]; }
                else {
                    r[i] ^= H[i] << k;
                    r[i + 1] ^= H[i] >> (64 - k);
                }
            }
        }
    }
    fe o;
    o.w[0] = r[0]; o.w[1] = r[1]; o.w[2] = r[2];
    if (r[2] >> 3 || r[3] || r[4] || r[5]) { fprintf(stderr, "reduce failed\n"); exit(3); }
    return o;
}

static inline fe fmul(fe a, fe b) {
    uint64_t r[6] = {0, 0, 0, 0, 0, 0};
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            uint64_t lo, hi;
            clmul64(a.w[i], b.w[j], &lo, &hi);
            r[i + j] ^= lo;
            r[i + j + 1] ^= hi;
        }
    return reduce6(r);
}

static inline fe fsqr(fe a) {
    uint64_t r[6] = {0, 0, 0, 0, 0, 0};
    for (int i = 0; i < 3; i++) {
        uint64_t lo, hi;
        clmul64(a.w[i], a.w[i], &lo, &hi);
        r[2 * i] ^= lo;
        r[2 * i + 1] ^= hi;
    }
    return reduce6(r);
}

static inline fe fadd(fe a, fe b) { fe o; for (int i = 0; i < 3; i++) o.w[i] = a.w[i] ^ b.w[i]; return o; }
static inline int feq(fe a, fe b) { return a.w[0] == b.w[0] && a.w[1] == b.w[1] && a.w[2] == b.w[2]; }
static inline int fzero(fe a) { return !(a.w[0] | a.w[1] | a.w[2]); }
static fe fone(void) { fe o = {{1, 0, 0}}; return o; }

static fe fsqrn(fe a, int n) { for (int i = 0; i < n; i++) a = fsqr(a); return a; }

/* Itoh-Tsujii: beta_k = a^(2^k - 1); beta_{m+n} = beta_m^(2^n) * beta_n; a^-1 = beta_130^2 */
static fe finv(fe a) {
    fe b1 = a;
    fe b2 = fmul(fsqrn(b1, 1), b1);
    fe b4 = fmul(fsqrn(b2, 2), b2);
    fe b8 = fmul(fsqrn(b4, 4), b4);
    fe b16 = fmul(fsqrn(b8, 8), b8);
    fe b32 = fmul(fsqrn(b16, 16), b16);
    fe b64 = fmul(fsqrn(b32, 32), b32);
    fe b128 = fmul(fsqrn(b64, 64), b64);
    fe b130 = fmul(fsqrn(b128, 2), b2);
    return fsqr(b130);
}

static fe halftrace(fe c) {
    fe h = c, t = c;
    for (int i = 0; i < 65; i++) { t = fsqr(fsqr(t)); h = fadd(h, t); }
    return h;
}

static int ftrace(fe c) {
    fe s = c, t = c;
    for (int i = 0; i < 130; i++) { t = fsqr(t); s = fadd(s, t); }
    if (s.w[1] || s.w[2] || s.w[0] > 1) { fprintf(stderr, "trace not in F2\n"); exit(4); }
    return (int)s.w[0];
}

static fe parsehex(const char *s) {
    fe o = {{0, 0, 0}};
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r' || s[n - 1] == ' ')) n--;
    int bit = 0;
    for (size_t i = n; i-- > 0;) {
        char ch = s[i];
        int v = (ch >= '0' && ch <= '9') ? ch - '0' : (ch >= 'a' && ch <= 'f') ? ch - 'a' + 10 : (ch >= 'A' && ch <= 'F') ? ch - 'A' + 10 : -1;
        if (v < 0) { fprintf(stderr, "bad hex %s\n", s); exit(2); }
        for (int k = 0; k < 4; k++, bit++)
            if ((v >> k) & 1) {
                if (bit >= 131) { fprintf(stderr, "value too large\n"); exit(2); }
                o.w[bit / 64] |= 1ULL << (bit % 64);
            }
    }
    return o;
}

static void printhex(fe a) { printf("%016llx%016llx%016llx", (unsigned long long)a.w[2], (unsigned long long)a.w[1], (unsigned long long)a.w[0]); }

int main(int argc, char **argv) {
    char line[256];
    if (argc > 1 && strcmp(argv[1], "selftest") == 0) {
        /* read pairs a b, print a*b, a^2, a^-1, sqrt? no: halftrace(a), trace(a) */
        while (fgets(line, sizeof line, stdin)) {
            char *sp = strchr(line, ' ');
            if (!sp) break;
            *sp = 0;
            fe a = parsehex(line), b = parsehex(sp + 1);
            printhex(fmul(a, b)); printf(" ");
            printhex(fsqr(a)); printf(" ");
            if (fzero(a)) printf("0"); else printhex(finv(a));
            printf(" ");
            printhex(halftrace(a)); printf(" %d\n", ftrace(a));
        }
        return 0;
    }
    int nc, nb;
    if (!fgets(line, sizeof line, stdin)) return 1;
    nc = atoi(line);
    fe *bs = malloc(sizeof(fe) * nc);
    for (int i = 0; i < nc; i++) { if (!fgets(line, sizeof line, stdin)) return 1; bs[i] = parsehex(line); }
    if (!fgets(line, sizeof line, stdin)) return 1;
    nb = atoi(line);
    fe basis[32];
    for (int i = 0; i < nb; i++) { if (!fgets(line, sizeof line, stdin)) return 1; basis[i] = parsehex(line); }
    long nx = 1L << nb;
    fe *xs = malloc(sizeof(fe) * nx);
    fe *ix2 = malloc(sizeof(fe) * nx);
    xs[0].w[0] = xs[0].w[1] = xs[0].w[2] = 0;
    for (long c = 1; c < nx; c++) {
        int low = __builtin_ctzl(c);
        xs[c] = fadd(xs[c & (c - 1)], basis[low]);
    }
    for (long c = 1; c < nx; c++) {
        if (fzero(xs[c])) { fprintf(stderr, "basis dependent\n"); return 5; }
        fe x2 = fsqr(xs[c]);
        ix2[c] = finv(x2);
        if (!feq(fmul(x2, ix2[c]), fone())) { fprintf(stderr, "inversion failed\n"); return 6; }
    }
    for (int ci = 0; ci < nc; ci++) {
        fe b = bs[ci];
        long cnt = 0;
        long *cum = calloc(nb + 1, sizeof(long));
        /* x = 0: y = sqrt(b) = b^(2^130) */
        fe y0 = fsqrn(b, 130);
        if (!feq(fsqr(y0), b)) { fprintf(stderr, "sqrt failed\n"); return 7; }
        cnt = 1;
        int kk = 0;
        for (long c = 0; c < nx; c++) {
            if (c > 0) {
                fe x = xs[c];
                fe cc = fadd(x, fmul(b, ix2[c]));
                fe w = halftrace(cc);
                fe y = fmul(x, w);
                fe lhs = fadd(fsqr(y), fmul(x, y));
                fe x2 = fsqr(x);
                fe rhs = fadd(fmul(x2, x), b);
                if (feq(lhs, rhs)) cnt++;
                else if (ftrace(cc) != 1) { fprintf(stderr, "halftrace inconsistency\n"); return 8; }
            }
            /* after processing c = 2^k - 1 record C_k */
            while (kk < nb && c == (1L << (kk + 1)) - 1) { cum[kk + 1] = cnt; kk++; }
        }
        printf("%d", ci);
        for (int k = 1; k <= nb; k++) printf(" %ld", cum[k]);
        printf("\n");
        fflush(stdout);
        free(cum);
    }
    return 0;
}
