\\ negative control for isogeny_check.gp: wrong kernels must fail the same tests
default(parisize, 400000000);
read("pari_input.gp");
f = Mod(1,2)*(x^131+x^13+x^2+x+1);
z = ffgen(f, 'z);
fromint(n) = my(v=binary(n), r=0*z); for(i=1,#v, r = r*z + v[i]); r;
N = CARD/4;
setrand(99);
{foreach(["A057","B113","A000"], lab,
  my(b=fromint(mapget(BINT,lab)), Xt=ellinit([1,1,0,0,b], z), X=ellinit([1,0,0,0,b], z), R, Q, xs, v, v2, xs3, v3, cnt=0);
  until(Q != [0], R = random(Xt); Q = ellmul(Xt, R, TWISTCARD/263));
  xs = vector(131, i, ellmul(Xt, Q, i)[1]);
  v = vecsum(xs);
  v2 = v - xs[131];                               \\ drop one kernel point
  R = random(Xt); xs3 = vector(131, i, ellmul(Xt, R, i)[1]); v3 = vecsum(xs3);   \\ non-kernel "subgroup"
  print(lab, ": true kernel j=1? ", ellinit([1,0,0,v,b+v],z).j == 1,
        "  dropped-point j=1? ", ellinit([1,0,0,v2,b+v2],z).j == 1,
        "  random-point j=1? ", ellinit([1,0,0,v3,b+v3],z).j == 1));}
