"""Cross-validate count131 (C/NEON) field ops against gf131.py (pure Python), and
gf131.py against first principles (a * inv(a) == 1, sqr == mul(a,a), halftrace identity).
Run: python3 validate_c.py
"""
import os, random, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf131 as F

rng = random.Random(4242)
vals = [0, 1, 2, (1 << 130), F.MASK] + [rng.getrandbits(131) for _ in range(400)]
pairs = [(a, rng.getrandbits(131)) for a in vals]
inp = "".join("%x %x\n" % (a, b) for a, b in pairs)
out = subprocess.run([os.path.join(HERE, "count131"), "selftest"], input=inp, capture_output=True,
                     text=True, check=True).stdout.strip().split("\n")
bad = 0
for (a, b), line in zip(pairs, out):
    p, s, iv, ht, tr = line.split()
    ok = int(p, 16) == F.mul(a, b) and int(s, 16) == F.sqr(a) and F.sqr(a) == F.mul(a, a)
    if a:
        ok &= int(iv, 16) == F.inv(a) and F.mul(a, F.inv(a)) == 1
    h = F.halftrace(a)
    ok &= int(ht, 16) == h and int(tr) == F.trace(a)
    ok &= (F.sqr(h) ^ h) == (a ^ F.trace(a))       # H(c)^2 + H(c) = c + Tr(c)
    if not ok:
        bad += 1
print("selftest rows:", len(pairs), "mismatches:", bad)
# modulus irreducibility sanity: z^(2^131) == z and z^(2^k) != z for k | 131, k < 131 (only k=1)
z = 2
t = z
for _ in range(131):
    t = F.sqr(t)
print("z^(2^131) == z:", t == z, " z^2 != z:", F.sqr(z) != z)
assert bad == 0
