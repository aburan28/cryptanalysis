"""C3 recompute: C(X_{j+1}, V) = C(X_j, sqrt V) for the canonical V_k, all 262 floor curves + E0.

Independent code path: own GF(2^131) arithmetic (gf131.py, count131.c); liftability decided
by an explicit point (half-trace solve + curve-equation check), not by the sweep's
Hankel/BLAS trace test.  Only ground_truth.json (b_int, labels) is read as input; the sweep's
per_curve.json / raw_counts.json are read only at the end for comparison.

Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; python3 recompute_chart.py
"""
import os, sys, json, time, subprocess, random, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf131 as F

GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
IC = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"
KMAX = 16
t0 = time.time()
res = {}

gt = json.load(open(GT))
assert int(gt["meta"]["modulus_int"]) == F.POLY
curves = gt["curves"]
labels = [c["label"] for c in curves]
B = {c["label"]: int(c["b_int"]) for c in curves}
J = {c["label"]: int(c["j_int"]) for c in curves}
assert all(int(c["a2"]) == 0 for c in curves)

# ---- 1. label structure: b(X_{k+1}) = b(X_k)^2, orbit closes, j*b = 1 -------------------
lab_ok = {"b_next_is_b_squared": 0, "wraparound_ok": 0, "jb_eq_1": 0, "orbit_sizes": {}}
for orb in "AB":
    xs = ["%s%03d" % (orb, i) for i in range(131)]
    lab_ok["orbit_sizes"][orb] = len(set(B[l] for l in xs))
    for i in range(131):
        nxt = xs[(i + 1) % 131]
        if F.sqr(B[xs[i]]) == B[nxt]:
            lab_ok["b_next_is_b_squared"] += 1
            if i == 130:
                lab_ok["wraparound_ok"] += 1
for l in labels:
    if F.mul(B[l], J[l]) == 1:
        lab_ok["jb_eq_1"] += 1
lab_ok["E0_b"] = B["E0"]
lab_ok["E0_fixed_by_squaring"] = F.sqr(B["E0"]) == B["E0"]
res["label_structure"] = lab_ok
print("labels:", lab_ok, flush=True)
assert lab_ok["b_next_is_b_squared"] == 262 and lab_ok["jb_eq_1"] == 263

# ---- 2. sqrt basis by 130 squarings (own arithmetic) ------------------------------------
canon = [1 << i for i in range(KMAX)]
sq = [F.sqrt(v) for v in canon]
assert all(F.sqr(s) == v for s, v in zip(sq, canon))
res["sqrt_basis_hex"] = ["%x" % s for s in sq]
res["sqrt_basis_popcount"] = [bin(s).count("1") for s in sq]


def run_counts(bvals, basis):
    inp = "%d\n" % len(bvals) + "".join("%x\n" % b for b in bvals) + "%d\n" % len(basis) + \
          "".join("%x\n" % v for v in basis)
    out = subprocess.run([os.path.join(HERE, "count131")], input=inp, capture_output=True, text=True,
                         check=True, timeout=2400).stdout.strip().split("\n")
    rows = [list(map(int, ln.split())) for ln in out]
    assert [r[0] for r in rows] == list(range(len(bvals)))
    return [r[1:] for r in rows]


bl = [B[l] for l in labels]
tc = time.time()
Cv = run_counts(bl, canon)
print("canonical V counts done %.1fs" % (time.time() - tc), flush=True)
tc = time.time()
Cs = run_counts(bl, sq)
print("sqrt V counts done %.1fs" % (time.time() - tc), flush=True)
CV = {l: Cv[i] for i, l in enumerate(labels)}      # CV[l][k-1] = C(l, V_k)
CS = {l: Cs[i] for i, l in enumerate(labels)}      # CS[l][k-1] = C(l, sqrt V_k)


def nxt(l):
    if l == "E0":
        return "E0"
    return "%s%03d" % (l[0], (int(l[1:]) + 1) % 131)


# ---- 3. the identity, all 263 x 16 cells -------------------------------------------------
cells = 0
fails = []
for l in labels:
    for k in range(1, KMAX + 1):
        cells += 1
        if CS[l][k - 1] != CV[nxt(l)][k - 1]:
            fails.append((l, k, CS[l][k - 1], CV[nxt(l)][k - 1]))
res["identity_own_counts"] = {"cells": cells, "failures": fails[:20], "n_fail": len(fails)}
print("identity (own counts, both sides):", cells, "cells,", len(fails), "failures", flush=True)

# ---- 4. compare with the sweep's files ------------------------------------------------------
pc = json.load(open(IC + "per_curve.json"))
rc = json.load(open(IC + "raw_counts.json"))["counts"]
m_pc = m_rc = n_pc = n_rc = 0
mis = []
for l in labels:
    for k in range(1, KMAX + 1):
        mine = CV[l][k - 1]
        rv = rc[l]["canon"][str(k)]
        n_rc += 1
        if rv == mine:
            m_rc += 1
        else:
            mis.append(("raw_counts", l, k, mine, rv))
        kk = "k%d" % k
        if kk in pc[l]["count_incl_x0"]["canon"]:
            n_pc += 1
            if pc[l]["count_incl_x0"]["canon"][kk] == mine:
                m_pc += 1
            else:
                mis.append(("per_curve", l, k, mine, pc[l]["count_incl_x0"]["canon"][kk]))
# the chart check against the sweep's values: my C(X_j, sqrt V) vs sweep's C(X_{j+1}, V)
m_ch = n_ch = 0
for l in labels:
    for k in range(1, KMAX + 1):
        n_ch += 1
        if CS[l][k - 1] == rc[nxt(l)]["canon"][str(k)]:
            m_ch += 1
res["vs_sweep"] = {"raw_counts_cells": n_rc, "raw_counts_match": m_rc, "per_curve_cells": n_pc,
                   "per_curve_match": m_pc, "my_sqrtV_vs_sweep_nextV_cells": n_ch,
                   "my_sqrtV_vs_sweep_nextV_match": m_ch, "mismatches": mis[:20]}
print("vs sweep:", {k: v for k, v in res["vs_sweep"].items() if k != "mismatches"}, flush=True)

# the 33 cells of structure_checks.json, re-read and compared with my numbers
sc = json.load(open(IC + "structure_checks.json"))["frobenius_chart_identity"]
m33 = sum(1 for r in sc if CS[r["curve"]][r["k"] - 1] == r["C_curve_on_sqrtV"] == CV[r["next"]][r["k"] - 1])
res["structure_checks_33_cells_reproduced"] = {"rows": len(sc), "match": m33}
print("structure_checks rows reproduced:", m33, "/", len(sc), flush=True)

# ---- 5. overlap dim(V_k cap sqrt V_k) for k = 1..32 ----------------------------------------
canon32 = [1 << i for i in range(32)]
sq32 = [F.sqrt(v) for v in canon32]
ov = {}
for k in range(1, 33):
    r = F.gf2_rank(canon32[:k] + sq32[:k])
    ov[k] = 2 * k - r
res["dim_V_cap_sqrtV"] = ov
print("dim(V_k cap sqrt V_k):", ov, flush=True)
# how does the next conjugate see V? C(X_{j+1},V) = C(X_j, sqrt V); also V^(1/2^i) overlaps
ov_iter = {}
for k in (8, 12, 16):
    cur = canon32[:k]
    row = []
    for i in range(1, 6):
        cur = [F.sqrt(v) for v in cur]
        row.append(2 * k - F.gf2_rank(canon32[:k] + cur))
    ov_iter[k] = row
res["dim_V_cap_V_pow_2^-i_i1to5"] = ov_iter
print("dim(V_k cap V_k^(1/2^i)), i=1..5:", ov_iter, flush=True)

# ---- 6. correlation of adjacent conjugates (own counts) --------------------------------------
def pearson(a, b):
    n = len(a)
    ma, mb = sum(a) / n, sum(b) / n
    sa = math.sqrt(sum((x - ma) ** 2 for x in a))
    sb = math.sqrt(sum((y - mb) ** 2 for y in b))
    return sum((x - ma) * (y - mb) for x, y in zip(a, b)) / (sa * sb)


floor = [l for l in labels if l != "E0"]
cor = {}
for k in range(6, KMAX + 1):
    a = [CV[l][k - 1] for l in floor]
    b = [CV[nxt(l)][k - 1] for l in floor]
    cor[k] = {"pearson_adjacent": round(pearson(a, b), 4),
              "independence_model_2^(-dim_overlap_share)": round(2.0 ** (ov[k] - k), 4)}
res["adjacent_conjugate_correlation"] = cor
print("adjacent correlation:", cor, flush=True)
res["counts_canonV"] = CV
res["counts_sqrtV"] = CS
res["elapsed_s"] = time.time() - t0
json.dump(res, open(os.path.join(HERE, "recompute_chart.json"), "w"), indent=0)
print("done %.1fs" % (time.time() - t0))
assert not fails and m_rc == n_rc and m_pc == n_pc and m_ch == n_ch and m33 == len(sc)
