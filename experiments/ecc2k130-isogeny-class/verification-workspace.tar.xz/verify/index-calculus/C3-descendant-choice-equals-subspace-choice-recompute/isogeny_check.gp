\\ C3 recompute: every floor curve X: y^2+xy = x^3+b has an F_q-rational 263-isogeny to E0.
\\ Own Velu in standalone gp (not Sage's E.isogeny, not polmodular, not H_D):
\\ - twist X' = [1,1,0,0,b] has #X' = q+1+t (TWISTCARD, divisible by 263^2);
\\   Q = (TWISTCARD/263) R, R random on X', is a point of order 263 over F_q;
\\ - kernel x-coordinates x(iQ), i=1..131, are in F_q; the char-2 twist isomorphism
\\   (x,y)->(x, y+s x), s^2+s=1, keeps x, so the SAME kernel polynomial is an F_q-rational
\\   kernel on X itself;
\\ - Velu (a1=1,a3=0,a4=0): v = sum x_Q, codomain [1,a2,0,v,b+v], j = 1/(b+v+v^2);
\\ - check: j(codomain) = 1, codomain order is CARD = 4N (so it is E0, not its twist),
\\   the Velu x-map X(P) = x + sum (x_Q/(x+x_Q) + x_Q^2/(x+x_Q)^2) sends 8 random order-N
\\   points of X to x-coordinates that lift on the codomain to points of order N.
default(parisize, 400000000);
read("pari_input.gp");
f = Mod(1,2)*(x^131+x^13+x^2+x+1);
z = ffgen(f, 'z);
fromint(n) = my(v=binary(n), r=0*z); for(i=1,#v, r = r*z + v[i]); r;
N = CARD/4;
setrand(263263);
labs = List();
{for(o=1,2, for(i=0,130, listput(labs, Str(["A","B"][o], if(i<10,"00",if(i<100,"0","")), i))));}
ok = 0; tot = 0; bad = List();
{for(li=1,#labs,
  my(lab=labs[li], b=fromint(mapget(BINT,lab)), Xt=ellinit([1,1,0,0,b], z), X=ellinit([1,0,0,0,b], z),
     R, Q, xs, v, C, Ct, good=1, P, Pi, xm, ys);
  tot++;
  until(Q != [0], R = random(Xt); Q = ellmul(Xt, R, TWISTCARD/263));
  if(ellmul(Xt, Q, 263) != [0], good = 0);
  xs = vector(131, i, ellmul(Xt, Q, i)[1]);
  if(#Set(xs) != 131, good = 0);
  v = vecsum(xs);
  C = ellinit([1,0,0,v,b+v], z);
  Ct = ellinit([1,1,0,v,b+v], z);
  if(C.j != 1 || Ct.j != 1, good = 0);
  if(b + v + v^2 != 1, good = 0);
  for(r=1,4, if(ellmul(C, random(C), CARD) != [0], good = 0); if(ellmul(Ct, random(Ct), TWISTCARD) != [0], good = 0));
  \\ codomain of the untwisted X is E0 up to F_q-isomorphism: same j, same order CARD
  for(r=1,8,
    P = ellmul(X, random(X), 4);
    if(P == [0] || ellmul(X, P, N) != [0], good = 0; next);
    xm = P[1] + sum(i=1,131, xs[i]/(P[1]+xs[i]) + xs[i]^2/(P[1]+xs[i])^2);
    ys = ellordinate(C, xm);
    if(#ys == 0, good = 0; next);
    Pi = [xm, ys[1]];
    if(Pi == [0] || ellmul(C, Pi, N) != [0], good = 0));
  if(good, ok++, listput(bad, lab)));}
print("ISOG ", ok, "/", tot, " bad=", bad);
\\ E0 itself: j(E0)=1, #E0 = CARD
E0 = ellinit([1,0,0,0,1], z);
print("E0 j=", E0.j, " CARD*random=0: ", ellmul(E0, random(E0), CARD) == [0]);
