"""Audit of the 'only class-wide linear bias' and z-shift parts of C4, plus consistency of the
sweep's stored counts / z-scores with the Tr(b)=1 bookkeeping.
Own GF(2^131) arithmetic (carry-less multiply + reduction by z^131+z^13+z^2+z+1) for traces,
computed as the sum of the 131 Frobenius conjugates (no trace mask, no Sage, no ecc2k.py).
Run: python3 linear_bias.py
"""
import json, math
NB = 131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
IC = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"


def mul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        b >>= 1
        a <<= 1
        if a >> 131:
            a ^= MOD
    return r


def trace(v):
    s, u = 0, v
    for _ in range(NB):
        s ^= u
        u = mul(u, u)
    assert s in (0, 1), s
    return s


def rank(vs):
    basis = {}   # pivot bit -> vector
    for v in vs:
        while v:
            p = v.bit_length() - 1
            if p in basis:
                v ^= basis[p]
            else:
                basis[p] = v
                break
    return len(basis)


out = {}
# trace mask by the Frobenius sum
out["trace_mask_bits_frobenius_sum"] = [i for i in range(NB) if trace(1 << i)]
g = json.load(open(GT))
lab = [r["label"] for r in g["curves"]]
B = {r["label"]: int(r["b_int"]) for r in g["curves"]}
tr = {l: trace(B[l]) for l in lab}
out["class_Tr_b_counts"] = {str(v): sum(1 for l in lab if tr[l] == v) for v in (0, 1)}
A = [l for l in lab if l.startswith("A")]
Bo = [l for l in lab if l.startswith("B")]
b0 = B["E0"]
out["rank_linear_span_all_263_b"] = rank([B[l] for l in lab])
out["rank_affine_differences_all_263 (b_i + b_E0)"] = rank([B[l] ^ b0 for l in lab])
out["rank_affine_differences_orbitA_131"] = rank([B[l] ^ B["A000"] for l in A])
out["rank_affine_differences_orbitB_131"] = rank([B[l] ^ B["B000"] for l in Bo])
out["rank_linear_span_orbitA"] = rank([B[l] for l in A])
out["rank_linear_span_orbitB"] = rank([B[l] for l in Bo])
# orbit closure under squaring (Frobenius), which is what forces the ranks
out["orbitA_closed_under_squaring"] = set(mul(B[l], B[l]) for l in A) == set(B[l] for l in A)
out["orbitB_closed_under_squaring"] = set(mul(B[l], B[l]) for l in Bo) == set(B[l] for l in Bo)
# nondegenerate trace form => #{w : Tr(w b) constant on class} = 2^(131 - affine rank)
out["dim_of_w_with_Tr(w*b)_constant_on_class"] = NB - out["rank_affine_differences_all_263 (b_i + b_E0)"]
out["w=1_is_such_a_functional (Tr(b_i + b_E0) = 0 for all i)"] = all(trace(B[l] ^ b0) == 0 for l in lab)

# ---- sweep's stored counts vs Tr(b) bookkeeping ----
raw = json.load(open(IC + "raw_counts.json"))
raw2 = json.load(open(IC + "raw_counts_null2.json"))
C = dict(raw["counts"]); C.update(raw2["counts"])
trn = {}
for d in (raw, raw2):
    for l, r in d["null_curves"].items():
        trn[l] = trace(int(r["b_int"]))
# V_1 = {0, 1} for the canonical basis: C(V_1) = 1 (x=0) + [x=1 lifts] = 1 + Tr(b)
out["canon_k1_count_eq_1+Tr(b)"] = {
    "class": sum(1 for l in lab if C[l]["canon"]["1"] == 1 + tr[l]),
    "null1": sum(1 for l in raw["null_curves"] if C[l]["canon"]["1"] == 1 + trn[l]),
    "null2": sum(1 for l in raw2["null_curves"] if C[l]["canon"]["1"] == 1 + trn[l])}
out["null1_Tr_b_counts_own_trace"] = {str(v): sum(1 for l in raw["null_curves"] if trn[l] == v) for v in (0, 1)}
out["null2_Tr_b_counts_own_trace"] = {str(v): sum(1 for l in raw2["null_curves"] if trn[l] == v) for v in (0, 1)}
tab = {}
for l, r in raw["null_curves"].items():
    key = "%d,%d" % (trn[l], int(r["order_pari"]) % 8)
    tab[key] = tab.get(key, 0) + 1
out["null1_(Tr_b,stored_order_mod8)_table"] = tab
tab2 = {}
for l, r in raw2["null_curves"].items():
    key = "%d,%d" % (trn[l], int(r["order_pari"]) % 8)
    tab2[key] = tab2.get(key, 0) + 1
out["null2_(Tr_b,stored_order_mod8)_table"] = tab2

# z-shift: under b uniform on F_q, x=1 is a fair coin; with Tr(b)=1 it is certain: mean +1/2,
# sd of Binomial(2^k-1,1/2) = sqrt(2^k-1)/2 => shift 1/sqrt(2^k-1)
out["zshift_1_over_sqrt(2^k-1)"] = {k: 1 / math.sqrt(2 ** k - 1) for k in range(8, 17)}
# recompute the sweep's z (matched and uniform-reference) from raw counts and compare with per_curve.json
per = json.load(open(IC + "per_curve.json"))
maxdiff_m = maxdiff_u = 0.0
diffs = {k: [] for k in (8, 10, 12, 14, 16)}
for l in lab:
    for k in (8, 10, 12, 14, 16):
        c = C[l]["canon"][str(k)]
        coins = 2 ** k - 2                      # x = 0 and x = 1 deterministic (1 in V_k)
        zm = ((c - 1 - tr[l]) - coins / 2) / math.sqrt(coins / 4)
        n = 2 ** k - 1
        zu = ((c - 1) - n / 2) / math.sqrt(n / 4)
        maxdiff_m = max(maxdiff_m, abs(zm - per[l]["zscores"]["canon"]["k%d" % k]))
        maxdiff_u = max(maxdiff_u, abs(zu - per[l]["zscores_uniform_b_reference"]["canon"]["k%d" % k]))
        diffs[k].append(zu - zm)
out["per_curve_json_canon_z_recompute_maxabsdiff"] = {"matched": maxdiff_m, "uniform_ref": maxdiff_u}
out["mean_(z_uniform - z_matched)_canon_class"] = {k: sum(v) / len(v) for k, v in diffs.items()}
out["range_(z_uniform - z_matched)_canon_class"] = {k: [min(v), max(v)] for k, v in diffs.items()}
json.dump(out, open("linear_bias.json", "w"), indent=1)
for k, v in out.items():
    print(k, ":", v)
