"""Export b values (and stored orders) from ground_truth.json and the sweep's raw count files
to plain text for an independent standalone-GP check.  Plain python3, no Sage, no ecc2k.py.
Lines: label b_int a2 stored_order"""
import json
GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
IC = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"
g = json.load(open(GT))
with open("class_b.txt", "w") as f:
    for r in g["curves"]:
        f.write("%s %s %s %s\n" % (r["label"], r["b_int"], r["a2"], r["order_pari"]))
for name, fn in (("null1", "raw_counts.json"), ("null2", "raw_counts_null2.json")):
    d = json.load(open(IC + fn))
    with open(name + "_b.txt", "w") as f:
        for l, r in d["null_curves"].items():
            f.write("%s %s 0 %s\n" % (l, r["b_int"], r["order_pari"]))
print("class", len(g["curves"]), "N", g["meta"]["N"], "card", g["meta"]["card"])
