\\ Independent standalone-GP audit of claim C4 (all class curves have Tr(b)=1, x=1 lifts,
\\ Tr(b)=0 <=> 8 | #E for a2=0). Uses only PARI finite-field arithmetic; field built here from
\\ the polynomial z^131+z^13+z^2+z+1 (no Sage, no ecc2k.py).
\\ Run: export TMPDIR=...; gp -q -f c4_class.gp
default(parisize, 10^9);
N = 680564733841876926932320129493409985129;
q = 2^131;
t = -22283658519494248867;
CARD = q + 1 - t;
if (CARD != 4*N, error("4N mismatch"));
T = Mod(1,2)*(x^131+x^13+x^2+x+1);
if (!polisirreducible(T), error("modulus not irreducible"));
z = ffgen(T, 'z);
toff(n) = subst(Pol(binary(n)), 'x, z) + 0*z;   \\ bit i -> z^i  (binary() is MSB first)
tofint(e) = subst(lift(e.pol), 'z, 2);           \\ back to integer bitmask
\\ round-trip check of the encoding
{ setrand(1); for (i = 1, 200, my(n = random(q)); if (tofint(toff(n)) != n, error("encoding"))); }

\\ ---- 1. trace mask
mask = [i | i <- [0..130], trace(z^i) == 1];
print("trace_mask_bits ", mask);
bitsof(n) = my(v = binary(n)); vector(#v, i, v[#v+1-i]);   \\ LSB first
trm(n) = my(s = 0); for (i = 1, #mask, s += bittest(n, mask[i])); s % 2;

\\ ---- 2. class curves
readcurves(fn) = { my(L = readstr(fn), out = vector(#L)); for (i = 1, #L, my(w = strsplit(L[i], " ")); out[i] = [w[1], eval(w[2]), eval(w[3]), eval(w[4])]); out; }
C = readcurves("class_b.txt");
{
  my(ntr1 = 0, ntrm = 0, ncard = 0, nstored = 0, nord1 = 0, nord1pts = 0, nx4 = 0, nhalf = 0, ngrp = 0, nb1 = 0, t0 = getabstime());
  my(tr0list = List());
  for (i = 1, #C,
    my(lab = C[i][1], bi = C[i][2], a2 = C[i][3], b = toff(bi));
    if (a2 != 0, error("a2 != 0 for ", lab));
    my(tr = trace(b));
    if (tr == 1, ntr1++, listput(tr0list, lab));
    if (trm(bi) == tr, ntrm++);
    my(E = ellinit([1, 0, 0, 0, b]));
    my(c = ellcard(E));
    if (c == CARD, ncard++);
    if (c == C[i][4], nstored++);
    \\ x = 1 lifts: ellordinate returns the y's with (1,y) on E
    my(ys = ellordinate(E, 1 + 0*z));
    if (#ys > 0, nord1++);
    if (#ys == 2, nord1pts++);
    \\ the order-4 points have x4 = b^(1/4); check they exist and are NOT halvable
    my(x4 = sqrt(sqrt(b)), y4s = ellordinate(E, x4));
    if (#y4s == 2 && ellorder(E, [x4, y4s[1]]) == 4, nx4++);
    \\ halvability of an order-4 point: some Q in E(F_q) with 2Q = P4 <=> lambda^2+lambda = x4 solvable
    \\ (a2 = 0) <=> trace(x4) = 0; record the trace (expect 1 => not halvable)
    if (trace(x4) == 1, nhalf++);
    \\ group structure: 2-part must be Z/4 (cyclic of order exactly 4)
    my(G = ellgroup(E));
    if (#G == 1 && valuation(G[1], 2) == 2, ngrp++);
  );
  print("class_curves ", #C);
  print("class_Tr_b_eq_1 ", ntr1, "  Tr_b_eq_0_labels ", Vec(tr0list));
  print("class_trace_mask_parity_agrees_with_pari_trace ", ntrm);
  print("class_ellcard_eq_4N ", ncard, "  equal_to_stored_order_pari ", nstored);
  print("class_x1_lifts(ellordinate nonempty) ", nord1, "  with_2_ys ", nord1pts);
  print("class_order4_point_at_x=b^(1/4) ", nx4, "  with_Tr(x4)=1 (not halvable) ", nhalf);
  print("class_ellgroup_cyclic_with_2part_4 ", ngrp);
  print("class_seconds ", (getabstime() - t0)/1000.);
}

\\ ---- 3. the sweep's nulls: recount with PARI, compare Tr(b) vs #E mod 8
tally(fn) = {
  my(Lc = readcurves(fn), tab = Map(), nstored = 0, n4N = 0);
  for (i = 1, #Lc,
    my(bi = Lc[i][2], b = toff(bi), tr = trace(b), c = ellcard(ellinit([1,0,0,0,b])));
    if (c == Lc[i][4], nstored++);
    if (c == CARD, n4N++);
    my(key = [lift(tr), c % 8], v = 0);
    if (mapisdefined(tab, key, &v), mapput(tab, key, v + 1), mapput(tab, key, 1));
  );
  print(fn, " n=", #Lc, " ellcard_equal_stored=", nstored, " card_eq_4N=", n4N, "  (Tr(b), #E mod 8) -> count: ", Mat(tab));
}
tally("null1_b.txt");
tally("null2_b.txt");

\\ ---- 4. fresh random b, a2 = 0 and a2 = 1
{
  setrand(20260930);
  my(M = 3000, tab0 = Map(), tab1 = Map(), t0 = getabstime(), bad0 = 0, bad1 = 0);
  for (i = 1, M,
    my(b = random(z));
    if (b == 0, next);
    my(tr = lift(trace(b)));
    my(c0 = ellcard(ellinit([1,0,0,0,b])), c1 = ellcard(ellinit([1,1,0,0,b])));
    my(k0 = [tr, c0 % 8], k1 = [tr, c1 % 8], v = 0);
    if (mapisdefined(tab0, k0, &v), mapput(tab0, k0, v+1), mapput(tab0, k0, 1));
    if (mapisdefined(tab1, k1, &v), mapput(tab1, k1, v+1), mapput(tab1, k1, 1));
    if ((tr == 0) != (c0 % 8 == 0), bad0++);
    if (c1 % 4 != 2, bad1++);
  );
  print("fresh_random M=", M, " a2=0: (Tr(b), #E mod 8) -> count ", Mat(tab0), "  exceptions_to_[Tr(b)=0 <=> 8|#E]: ", bad0);
  print("fresh_random a2=1: (Tr(b), #E mod 8) -> count ", Mat(tab1), "  a2=1 curves with #E != 2 mod 4: ", bad1);
  print("fresh_seconds ", (getabstime() - t0)/1000.);
}
quit;
