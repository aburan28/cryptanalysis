\\ Tr(b) = Tr(1/j) for the floor curves straight from the class polynomial, without any root or
\\ ground-truth b: for an F_2-irreducible m(Y) = Y^131 + ... + c1*Y + c0 (c0 = 1) with root j,
\\ 1/j has minimal polynomial c0*Y^131 + c1*Y^130 + ..., so Tr(1/j) = c1/c0 = c1; also Tr(j) = c130.
default(parisize, 2*10^9);
t0 = getabstime();
H = polclass(-484183);
print("polclass degree ", poldegree(H), "  seconds ", (getabstime()-t0)/1000.);
H2 = H * Mod(1,2);
par = eval(Str("[", readstr("HD_mod2_lowfirst.txt")[1], "]"));
print("H_D mod 2 equals parities of ground-truth hex file: ", Vecrev(lift(H2)) == par);
F = factor(H2);
print("factor degrees ", apply(poldegree, F[,1]~), " exponents ", F[,2]~);
for (i = 1, #F~, my(m = F[i,1], c = Vecrev(lift(m))); \
  print("factor ", i, ": c0=", c[1], " c1 (=Tr(1/j)=Tr(b))=", c[2], " c130 (=Tr(j))=", c[131]));
quit;
