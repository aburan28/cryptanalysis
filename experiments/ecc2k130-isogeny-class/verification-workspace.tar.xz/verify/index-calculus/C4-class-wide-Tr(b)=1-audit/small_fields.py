"""Exhaustive small-field check of the theory behind C4.
For E_{a,b}: y^2 + xy = x^3 + a x^2 + b over F_{2^m}, b != 0:
 (H) halving criterion: P in 2E(F_q)  <=>  P = O or Tr(x_P) = Tr(a)   [checked on ALL points, m <= 8]
 (O8) a = 0:  E(F_q) has a point of order 8  <=>  Tr(b) = 0             [direct point orders, m <= 8]
 (M8) a = 0:  8 | #E  <=>  Tr(b) = 0                                    [PARI counts, m <= 14]
 (L1) x = 1 is an abscissa on E_{0,b}  <=>  Tr(1 + b) = 0 (so <=> Tr(b)=1 when m is odd)   [m <= 8]
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python small_fields.py
"""
import json, time
from sage.all import GF, EllipticCurve
res = {}
t0 = time.time()
for m in range(2, 9):
    K = GF(2**m, "g")
    stat = {"curves": 0, "points": 0, "H_fail": 0, "O8_fail": 0, "L1_fail": 0, "a0_tr0": 0, "a0_tr1": 0}
    for b in K:
        if b == 0:
            continue
        for a in (K(0), K(1)):
            E = EllipticCurve(K, [1, a, 0, 0, b])
            pts = E.points()
            stat["curves"] += 1
            stat["points"] += len(pts)
            twoE = set(2 * P for P in pts)
            crit = set(P for P in pts if P.is_zero() or P[0].trace() == a.trace())
            if twoE != crit:
                stat["H_fail"] += 1
            if a == 0:
                has8 = any(P.order() % 8 == 0 for P in pts)
                if has8 != (b.trace() == 0):
                    stat["O8_fail"] += 1
                stat["a0_tr%d" % int(b.trace())] += 1
                lifts1 = any((not P.is_zero()) and P[0] == 1 for P in pts)
                if lifts1 != ((1 + b).trace() == 0):
                    stat["L1_fail"] += 1
    res["m%d" % m] = stat
    print(m, stat, "%.1fs" % (time.time() - t0), flush=True)
m8 = {}
for m in range(2, 15):
    K = GF(2**m, "g")
    fail = 0
    tab = {}
    for b in K:
        if b == 0:
            continue
        n = int(EllipticCurve(K, [1, 0, 0, 0, b]).cardinality(algorithm="pari"))
        key = "%d,%d" % (int(b.trace()), n % 8)
        tab[key] = tab.get(key, 0) + 1
        if (n % 8 == 0) != (b.trace() == 0):
            fail += 1
    m8["m%d" % m] = {"table_Trb_cardmod8": tab, "fail": fail}
    print("M8", m, tab, "fail", fail, flush=True)
res["M8"] = m8
res["elapsed_s"] = time.time() - t0
json.dump(res, open("small_fields.json", "w"), indent=1)
