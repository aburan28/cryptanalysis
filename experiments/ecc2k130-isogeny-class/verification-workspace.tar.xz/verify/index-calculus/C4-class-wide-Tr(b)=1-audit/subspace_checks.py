"""(1) Is 1 in V_k for the sweep's four subspaces (k = 1..16)?  The Tr(b) correction must apply
exactly where 1 in V_k.  (2) Exceptions to the conditional pairwise independence used by the
C1 model: x1, x2 in V_k \\ {0,1} with 1/x1 + 1/x2 = 1 (i.e. x2 = x1/(x1+1)) make the two lift
indicators deterministic functions of each other once Tr(b) is fixed.  Count such pairs in V_16.
Field built here from the modulus (Sage GF with explicit modulus), not from ecc2k.py.
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python subspace_checks.py"""
import json
from sage.all import GF, PolynomialRing
R = PolynomialRing(GF(2), "t"); tt = R.gen()
K = GF(2**131, "z", modulus=tt**131 + tt**13 + tt**2 + tt + 1)
raw = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/index-calculus/raw_counts.json"))
bases = {s: [int(v) for v in raw["log"]["subspace_bases"][s]] for s in raw["meta"]["subspaces"]}


def rank(vs):
    basis = {}
    for v in vs:
        while v:
            p = v.bit_length() - 1
            if p in basis:
                v ^= basis[p]
            else:
                basis[p] = v
                break
    return len(basis)


out = {"canon_basis_is_z^i": bases["canon"] == [1 << i for i in range(16)]}
out["one_in_V_k"] = {s: [k for k in range(1, 17) if rank(b[:k] + [1]) == rank(b[:k])] for s, b in bases.items()}
out["rank_V16"] = {s: rank(b) for s, b in bases.items()}
pairs = {}
for s, b in bases.items():
    xs = [0] * (1 << 16)
    for c in range(1, 1 << 16):
        low = (c & -c).bit_length() - 1
        xs[c] = xs[c & (c - 1)] ^ b[low]
    pos = {v: c for c, v in enumerate(xs)}
    found = []
    for c in range(1, 1 << 16):
        if xs[c] == 1:
            continue
        xv = K.from_integer(xs[c])
        y = (xv / (xv + 1)).to_integer()
        if y in pos and y not in (0, 1):
            found.append((c, pos[y]))
    pairs[s] = {"n_ordered_pairs_in_V16": len(found), "examples": found[:5]}
    print(s, pairs[s], flush=True)
out["pairs_x_and_x_over_x_plus_1_in_V16"] = pairs
json.dump(out, open("subspace_checks.json", "w"), indent=1)
print(json.dumps({k: v for k, v in out.items() if k != "pairs_x_and_x_over_x_plus_1_in_V16"}))
