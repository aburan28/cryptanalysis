"""Explicit F_q-rational 263-isogeny E0 -> A058 via Velu with hand formulas (no Sage isogeny class).
Char-2 Velu for y^2+xy = x^3+a2 x^2+a6 and odd kernel G: with S = 131 representatives of (G\{O})/+-,
g^x_Q = x_Q^2 + y_Q, g^y_Q = x_Q, v_Q = x_Q, u_Q = x_Q^2, w = sum(u_Q + x_Q v_Q) = 0, so the codomain is
y^2 + xy = x^3 + a2 x^2 + v x + (a6 + v), v = sum_S x_Q, j' = 1/(a6 + v + v^2).
Kernels found on the twist E0' = [1,1,0,0,1] (263-part (Z/263)^2 over F_q); the x-sets are the kernels of E0 too.
Progress printed; run with timeout."""
import sys, json, time
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import EllipticCurve, set_random_seed
set_random_seed(20260923)
t0 = time.time()
def log(*a): print("[%.1fs]" % (time.time() - t0), *a, flush=True)
K = ecc2k.field()
q, t, N = ecc2k.q, ecc2k.t, ecc2k.N
Et = EllipticCurve(K, [1, 1, 0, 0, 1])
target = "A058"
bT = ecc2k.dec(ecc2k.RECORDS[target]["b_int"]); jT = 1 / bT
floorj = {ecc2k.dec(ecc2k.RECORDS[l]["j_int"]): l for l in ecc2k.LABELS if l != "E0"}
cof = (q + 1 + t) // 263**2   # 263-part of the twist is (Z/263)^2 (exponent 263)
def pt263():
    while True:
        P = cof * Et.random_point()
        if not P.is_zero():
            assert (263 * P).is_zero(); return P
P1 = pt263(); log("P1")
while True:
    P2 = pt263()
    if P1.weil_pairing(P2, 263) != 1: break
log("P2, Weil pairing nontrivial")
res = {"target": target}
hits = {}
found = None
gens = [P1] + [P2 + i * P1 for i in range(263)]
for idx, G in enumerate(gens):
    xs, Q = [], G
    for i in range(131):
        xs.append(Q[0]); Q = Q + G
    v = sum(xs)
    jv = 1 / (1 + v + v * v)
    lab = "E0" if jv == 1 else floorj.get(jv, "NOT_IN_FLOOR")
    hits[lab] = hits.get(lab, 0) + 1
    if lab == target and found is None:
        found = (idx, v)
log("scanned all 264 subgroups")
res["codomain_label_histogram_over_264_subgroups"] = {"E0": hits.get("E0", 0), "NOT_IN_FLOOR": hits.get("NOT_IN_FLOOR", 0),
                                                     "distinct_floor_labels": len([k for k in hits if k not in ("E0", "NOT_IN_FLOOR")]),
                                                     "max_multiplicity": max(hits.values())}
assert found is not None
idx, v = found
Ec = EllipticCurve(K, [1, 0, 0, v, 1 + v])   # Velu codomain of E0 (a2 = 0, a6 = 1) by kernel with x-sum v
res["velu_codomain_j_eq_A058"] = bool(Ec.j_invariant() == jT)
EA = ecc2k.curve(target)
res["codomain_Fq_isomorphic_to_A058_model"] = bool(Ec.is_isomorphic(EA))
res["codomain_Fq_isomorphic_to_A058_twist"] = bool(Ec.is_isomorphic(EllipticCurve(K, [1, 1, 0, 0, bT])))
log("isomorphism checks done")
# order of the codomain: a point of order N*4 test ([4]P != O, [N][4]P = O => #Ec = 4N by Hasse)
while True:
    P = 4 * Ec.random_point()
    if not P.is_zero(): break
res["codomain_has_point_of_order_N"] = bool((N * P).is_zero())
res["elapsed_s"] = round(time.time() - t0, 1)
json.dump(res, open("iso_A058_velu.json", "w"), indent=1)
print(json.dumps(res, indent=1))
