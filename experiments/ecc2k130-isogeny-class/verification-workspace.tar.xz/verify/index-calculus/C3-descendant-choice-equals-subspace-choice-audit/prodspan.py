"""dim span{v1*v2 : v1, v2 in W} (HPST 'V^(2)' size; GG16 Sec. 8) for W = V_k, sqrt(V_k), and random bases of density.py.
Frobenius is a ring automorphism, so dim span(sqrtV)^(2) must equal dim span(V)^(2)."""
import json
MOD = (1 << 131) | (1 << 13) | 7
def mul(a, b):
    r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1; a <<= 1
        if a >> 131: a ^= MOD
    return r
def rank(vs):
    basis = {}
    for v in vs:
        while v:
            p = v.bit_length() - 1
            if p in basis: v ^= basis[p]
            else: basis[p] = v; break
    return len(basis)
def sqrt(a):
    for _ in range(130): a = mul(a, a)
    return a
raw = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/index-calculus/raw_counts.json"))
bases = {s: [int(v) for v in raw["log"]["subspace_bases"][s]] for s in ["canon", "rand1", "rand2", "rand3"]}
bases["sqrt_canon"] = [sqrt(v) for v in bases["canon"]]
out = {}
for k in (8, 12, 16):
    row = {}
    for s, B in bases.items():
        Bk = B[:k]
        row[s] = rank([mul(a, b) for i, a in enumerate(Bk) for b in Bk[i:]])
    out[str(k)] = row
json.dump(out, open("prodspan.json", "w"), indent=1)
print(json.dumps(out))
