"""Is pi ≡ -1 mod 263*O_K on E0 (so every cyclic 263-subgroup of E0 is Gal-stable => all 264 263-isogenies F_q-rational)?
Independent of the ground-truth file: t from the Lucas recurrence of tau^2 + tau + 2 = 0 (#E0(F_2) = 4, t1 = -1)."""
import json
q = 2**131
# brute-force #E0(F_2): y^2 + xy = x^3 + 1 over F_2
pts = 1 + sum(1 for x in (0, 1) for y in (0, 1) if (y*y + x*y - x**3 - 1) % 2 == 0)
t1 = 2 + 1 - pts
# t_n = t1 t_{n-1} - 2 t_{n-2}, t0 = 2
a, b = 2, t1
for _ in range(130): a, b = b, t1 * b - 2 * a
t = b
N = (q + 1 - t) // 4
D = t * t - 4 * q
f2 = D // -7
import math
f = math.isqrt(f2)
res = {"#E0(F_2)": pts, "t": str(t), "t_mod_263": t % 263, "t2_minus_4q_is_minus7f2": f * f == f2 and D == -7 * f2,
       "f": str(f), "f_mod_263": f % 263, "f_over_263": str(f // 263)}
u = (t + 2)
res["263_divides_t_plus_2"] = u % 263 == 0
res["(t+2)/263_parity"] = (u // 263) % 2
res["(f/263)_parity"] = (f // 263) % 2
res["(pi+1)/263_in_O_K"] = u % 263 == 0 and f % 263 == 0 and ((u // 263) - (f // 263)) % 2 == 0
res["gcd(263,N)"] = math.gcd(263, N)
res["4N == q+1-t"] = 4 * N == q + 1 - t
res["N"] = str(N)
json.dump(res, open("scalar_frob.json", "w"), indent=1)
print(json.dumps(res, indent=1))
