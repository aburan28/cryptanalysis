"""dim(V_k ∩ V_k^(1/2^j)) for V_k = span(1, z, ..., z^(k-1)) in F_2[z]/(z^131+z^13+z^2+z+1), pure python3."""
import json
MOD = (1 << 131) | (1 << 13) | 7
def mul(a, b):
    r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1; a <<= 1
        if a >> 131: a ^= MOD
    return r
def sqr(a): return mul(a, a)
def rank(vs):
    basis = {}  # pivot -> vector
    for v in vs:
        while v:
            p = v.bit_length() - 1
            if p in basis: v ^= basis[p]
            else: basis[p] = v; break
    return len(basis)
def root(a, j):  # a^(2^(131-j)) = a^(2^-j)
    for _ in range((131 - j) % 131): a = sqr(a)
    return a
zi = [1 << i for i in range(16)]
# sqrt(z^i) for i<16 via 130 squarings
sq = [root(v, 1) for v in zi]
assert all(sqr(s) == v for s, v in zip(sq, zi))
out = {"adjacent": {}, "all_j": {}}
for k in range(1, 17):
    r = rank(zi[:k] + sq[:k])
    out["adjacent"][str(k)] = 2 * k - r
# all conjugates j = 1..130 for k = 8, 12, 16: iterate sqrt
for k in (8, 12, 16):
    cur = zi[:k]
    dims = []
    for j in range(1, 131):
        cur = [root(v, 1) for v in cur]
        dims.append(2 * k - rank(zi[:k] + cur))
    out["all_j"][str(k)] = {"dims_j1_to_j130": dims, "max": max(dims),
                            "argmax_j": [j + 1 for j, d in enumerate(dims) if d == max(dims)],
                            "count_dim_ge_2": sum(1 for d in dims if d >= 2)}
json.dump(out, open("intersect.json", "w"), indent=1)
print("adjacent dim(V_k ∩ sqrtV_k), k=1..16:", out["adjacent"])
for k in (8, 12, 16):
    a = out["all_j"][str(k)]
    print(k, "max", a["max"], "at j", a["argmax_j"], "#j with dim>=2:", a["count_dim_ge_2"], "dims[:8]", a["dims_j1_to_j130"][:8], "dims[-8:]", a["dims_j1_to_j130"][-8:])
