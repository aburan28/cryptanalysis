\\ PARI/GP: sqrt(z^i) = (z^i)^(2^130); count x in span(sqrt(z^i), i<k) liftable on A057; also A058 on span(z^i)
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
fromint(n) = my(v = binary(n)); sum(i=1, #v, v[i]*z^(#v-i)) + 0*z;
toint(a) = my(P = a.pol); subst(lift(P), variable(P), 2);
b57 = fromint(0x3dba68d2d1db144f20fe0652052ae0350);
b58 = fromint(0x2439e5e8ce836a3b3b4c69b74af0a2938);
print("b58 == b57^2: ", b58 == b57^2);
print("z^131 == z^13+z^2+z+1: ", z^131 == z^13+z^2+z+1);
sq = vector(16, i, (z^(i-1))^(2^130));
print("sqrt check: ", vector(16, i, sq[i]^2 == z^(i-1)) == vector(16,i,1));
print("sqrt(z) int hex: ", Strprintf("%x", toint(sq[2])));
lift_ok(b, xx) = if(xx == 0, 1, trace(xx + b/xx^2) == 0);
cnt(b, bas, k) = my(c = 0, xx); for(m = 0, 2^k - 1, xx = 0*z; for(i = 1, k, if(bittest(m, i-1), xx += bas[i])); c += lift_ok(b, xx)); c;
can = vector(16, i, z^(i-1));
for(k = 8, 14, print("k=", k, " C(A057,sqrtV)=", cnt(b57, sq, k), " C(A058,V)=", cnt(b58, can, k), " C(A057,V)=", cnt(b57, can, k)));
