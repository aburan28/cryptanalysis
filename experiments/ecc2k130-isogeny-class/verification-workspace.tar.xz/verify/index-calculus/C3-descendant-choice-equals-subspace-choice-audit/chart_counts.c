/* Independent re-implementation (no Sage, no BLAS/Hankel trick) of the rational-x counts
 *   C(E_b, W_k) = #{x in W_k : x = 0 or Tr(x + b/x^2) = 0},   E_b : y^2 + xy = x^3 + b over F_2^131
 * for W in {V, sqrt(V)} with V = canon (1, z, ..., z^15) and the three random bases of density.py.
 * Field: F_2[z]/(z^131 + z^13 + z^2 + z + 1), elements = 131-bit masks (bit i = z^i).
 * Multiplication: ARM PMULL, cross-checked against a bit-serial reference multiply.
 * sqrt(a) = a^(2^130) by 130 squarings (checked: sqrt(a)^2 = a).
 * Trace: Tr(z^i) computed as sum_{j<131} (z^i)^(2^j) (checked to lie in F_2).
 * The trace criterion is also cross-checked by explicitly solving w^2 + w = x + b/x^2 with the
 * half-trace and testing (x, x*w) on the curve.
 * Build: clang -O2 -march=armv8-a+crypto chart_counts.c -o chart_counts
 * Run  : ./chart_counts curves.txt bases.txt > counts_mine.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <arm_neon.h>

typedef struct { uint64_t w[3]; } fe;
#define TOPMASK ((1ULL << 3) - 1) /* bits 128..130 */

static int fe_eq(fe a, fe b) { return a.w[0] == b.w[0] && a.w[1] == b.w[1] && a.w[2] == b.w[2]; }
static int fe_zero(fe a) { return (a.w[0] | a.w[1] | a.w[2]) == 0; }
static fe fe_add(fe a, fe b) { fe r = {{a.w[0] ^ b.w[0], a.w[1] ^ b.w[1], a.w[2] ^ b.w[2]}}; return r; }
static fe fe_one(void) { fe r = {{1, 0, 0}}; return r; }

/* reduce a 6-word (<= 384-bit) polynomial modulo z^131 + z^13 + z^2 + z + 1 */
static fe reduce6(uint64_t r[6]) {
    for (int pass = 0; pass < 4; pass++) {
        /* h = r >> 131 */
        uint64_t h[4];
        for (int i = 0; i < 4; i++) {
            /* bit 131 = word 2, bit 3 */
            uint64_t lo = r[i + 2] >> 3;
            uint64_t hi = (i + 3 < 6) ? (r[i + 3] << 61) : 0;
            h[i] = lo | hi;
        }
        if ((h[0] | h[1] | h[2] | h[3]) == 0) break;
        r[2] &= TOPMASK; r[3] = r[4] = r[5] = 0;
        /* r ^= h * (1 + z + z^2 + z^13) */
        uint64_t acc[6] = {0};
        int sh[4] = {0, 1, 2, 13};
        for (int s = 0; s < 4; s++) {
            int k = sh[s];
            for (int i = 0; i < 4; i++) {
                acc[i] ^= h[i] << k;
                if (k) acc[i + 1] ^= h[i] >> (64 - k);
            }
        }
        for (int i = 0; i < 6; i++) r[i] ^= acc[i];
    }
    fe o = {{r[0], r[1], r[2]}};
    if (r[2] >> 3 || r[3] || r[4] || r[5]) { fprintf(stderr, "reduce failed\n"); exit(2); }
    return o;
}

static fe mul_ref(fe a, fe b) {
    uint64_t r[6] = {0};
    for (int i = 0; i < 131; i++) {
        if ((b.w[i >> 6] >> (i & 63)) & 1) {
            int ws = i >> 6, bs = i & 63;
            for (int j = 0; j < 3; j++) {
                r[j + ws] ^= a.w[j] << bs;
                if (bs) r[j + ws + 1] ^= a.w[j] >> (64 - bs);
            }
        }
    }
    return reduce6(r);
}

static inline void clmul64(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    poly128_t p = vmull_p64((poly64_t)a, (poly64_t)b);
    uint64x2_t v = vreinterpretq_u64_p128(p);
    *lo = vgetq_lane_u64(v, 0);
    *hi = vgetq_lane_u64(v, 1);
}

static fe mul(fe a, fe b) {
    uint64_t r[6] = {0};
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            uint64_t lo, hi;
            clmul64(a.w[i], b.w[j], &lo, &hi);
            r[i + j] ^= lo;
            r[i + j + 1] ^= hi;
        }
    return reduce6(r);
}

static fe sqr(fe a) { return mul(a, a); }

static fe inv(fe a) { /* a^(2^131 - 2) = prod_{i=1}^{130} a^(2^i) */
    fe r = fe_one(), s = a;
    for (int i = 1; i <= 130; i++) { s = sqr(s); r = mul(r, s); }
    return r;
}

static fe fsqrt(fe a) { for (int i = 0; i < 130; i++) a = sqr(a); return a; }

static fe halftrace(fe a) { /* sum_{i=0}^{65} a^(4^i) ; solves w^2 + w = a when Tr(a) = 0 (n odd) */
    fe r = a, s = a;
    for (int i = 1; i <= 65; i++) { s = sqr(sqr(s)); r = fe_add(r, s); }
    return r;
}

static fe TRMASK;
static int tr(fe a) {
    uint64_t v = (a.w[0] & TRMASK.w[0]) ^ (a.w[1] & TRMASK.w[1]) ^ (a.w[2] & TRMASK.w[2]);
    return __builtin_parityll(v);
}

static fe from_hex(const char *s) {
    fe r = {{0, 0, 0}};
    size_t n = strlen(s);
    int bit = 0;
    for (long i = (long)n - 1; i >= 0; i--, bit += 4) {
        char c = s[i];
        int v = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : (c >= 'A' && c <= 'F') ? c - 'A' + 10 : -1;
        if (v < 0) { fprintf(stderr, "bad hex %s\n", s); exit(2); }
        for (int k = 0; k < 4; k++)
            if ((v >> k) & 1) {
                int b = bit + k;
                if (b >= 131) { fprintf(stderr, "value too large\n"); exit(2); }
                r.w[b >> 6] |= 1ULL << (b & 63);
            }
    }
    return r;
}

static void print_hex(FILE *f, fe a) { fprintf(f, "%01llx%016llx%016llx", (unsigned long long)a.w[2], (unsigned long long)a.w[1], (unsigned long long)a.w[0]); }

static uint64_t rng_state = 0x9E3779B97F4A7C15ULL;
static uint64_t rnd64(void) { rng_state ^= rng_state << 13; rng_state ^= rng_state >> 7; rng_state ^= rng_state << 17; return rng_state; }
static fe rnd_fe(void) { fe r = {{rnd64(), rnd64(), rnd64() & TOPMASK}}; return r; }

#define MAXC 300
#define KMAX 16
static char labels[MAXC][16];
static fe bs[MAXC];
static int ncurves = 0;

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: %s curves.txt bases.txt\n", argv[0]); return 1; }
    /* --- field self tests --- */
    for (int t = 0; t < 200000; t++) {
        fe a = rnd_fe(), b = rnd_fe();
        if (!fe_eq(mul(a, b), mul_ref(a, b))) { fprintf(stderr, "PMULL vs reference mismatch\n"); return 2; }
    }
    fe z = {{2, 0, 0}};
    /* z^131 must equal z^13 + z^2 + z + 1 */
    fe zp = fe_one();
    for (int i = 0; i < 131; i++) zp = mul_ref(zp, z);
    fe expect = {{(1ULL << 13) | 7, 0, 0}};
    if (!fe_eq(zp, expect)) { fprintf(stderr, "modulus check failed\n"); return 2; }
    for (int t = 0; t < 200; t++) {
        fe a = rnd_fe();
        if (fe_zero(a)) continue;
        if (!fe_eq(mul(a, inv(a)), fe_one())) { fprintf(stderr, "inverse failed\n"); return 2; }
        if (!fe_eq(sqr(fsqrt(a)), a)) { fprintf(stderr, "sqrt failed\n"); return 2; }
    }
    /* trace mask from the definition Tr(u) = sum_j u^(2^j) */
    memset(&TRMASK, 0, sizeof TRMASK);
    fe zi = fe_one();
    for (int i = 0; i < 131; i++) {
        fe s = zi, acc = {{0, 0, 0}};
        for (int j = 0; j < 131; j++) { acc = fe_add(acc, s); s = sqr(s); }
        if (!(fe_zero(acc) || fe_eq(acc, fe_one()))) { fprintf(stderr, "trace not in F2\n"); return 2; }
        if (fe_eq(acc, fe_one())) TRMASK.w[i >> 6] |= 1ULL << (i & 63);
        zi = mul(zi, z);
    }
    fprintf(stderr, "trace mask bits:");
    for (int i = 0; i < 131; i++) if ((TRMASK.w[i >> 6] >> (i & 63)) & 1) fprintf(stderr, " %d", i);
    fprintf(stderr, "\n");

    /* --- curves --- */
    FILE *fc = fopen(argv[1], "r");
    char lab[64], hex[128];
    while (fscanf(fc, "%63s %127s", lab, hex) == 2) {
        strncpy(labels[ncurves], lab, 15);
        bs[ncurves] = from_hex(hex);
        ncurves++;
    }
    fclose(fc);
    /* Frobenius orbit structure, independent of ecc2k.frobenius_next: b(X_{k+1 mod 131}) == b(X_k)^2 */
    int orbit_ok = 1, nchk = 0;
    for (int i = 0; i < ncurves; i++) {
        char nxt[16];
        if (!strcmp(labels[i], "E0")) strcpy(nxt, "E0");
        else snprintf(nxt, sizeof nxt, "%c%03d", labels[i][0], (atoi(labels[i] + 1) + 1) % 131);
        int jn = -1;
        for (int j = 0; j < ncurves; j++) if (!strcmp(labels[j], nxt)) jn = j;
        if (jn < 0 || !fe_eq(sqr(bs[i]), bs[jn])) orbit_ok = 0;
        nchk++;
    }
    printf("ORBIT_CHECK b(next)==b^2 for %d curves: %s\n", nchk, orbit_ok ? "ok" : "FAIL");
    /* all b distinct */
    int distinct = 1;
    for (int i = 0; i < ncurves; i++) for (int j = i + 1; j < ncurves; j++) if (fe_eq(bs[i], bs[j])) distinct = 0;
    printf("B_DISTINCT %d\n", distinct);

    /* --- subspaces --- */
    FILE *fb = fopen(argv[2], "r");
    char line[8192];
    int *lift = malloc(sizeof(int) * (1 << KMAX));
    fe *xs = malloc(sizeof(fe) * (1 << KMAX));
    fe *ws = malloc(sizeof(fe) * (1 << KMAX));
    int *trx = malloc(sizeof(int) * (1 << KMAX));
    long hcheck_ok = 0, hcheck_bad = 0;
    while (fgets(line, sizeof line, fb)) {
        char *tok = strtok(line, " \n");
        if (!tok) continue;
        char sname[32];
        strncpy(sname, tok, 31);
        fe basis[KMAX];
        int nb = 0;
        while ((tok = strtok(NULL, " \n")) && nb < KMAX) basis[nb++] = from_hex(tok);
        if (nb != KMAX) { fprintf(stderr, "basis size %d\n", nb); return 2; }
        for (int variant = 0; variant < 3; variant++) {
            /* 0: V, 1: sqrt(V) = span(sqrt(v_i)), 2: V^2 = span(v_i^2) */
            fe bb[KMAX];
            char vname[48];
            for (int i = 0; i < KMAX; i++) bb[i] = variant == 0 ? basis[i] : variant == 1 ? fsqrt(basis[i]) : sqr(basis[i]);
            snprintf(vname, sizeof vname, "%s%s", variant == 0 ? "" : variant == 1 ? "sqrt_" : "sq_", sname);
            if (variant == 1) for (int i = 0; i < KMAX; i++) if (!fe_eq(sqr(bb[i]), basis[i])) { fprintf(stderr, "sqrt basis\n"); return 2; }
            if (variant == 1 && !strcmp(sname, "canon")) {
                for (int i = 0; i < KMAX; i++) { printf("SQRT_BASIS canon %d ", i); print_hex(stdout, bb[i]); printf("\n"); }
            }
            xs[0] = (fe){{0, 0, 0}};
            for (int c = 1; c < (1 << KMAX); c++) {
                int low = __builtin_ctz(c);
                xs[c] = fe_add(xs[c & (c - 1)], bb[low]);
            }
            for (int c = 0; c < (1 << KMAX); c++) {
                trx[c] = tr(xs[c]);
                ws[c] = c ? sqr(inv(xs[c])) : (fe){{0, 0, 0}};
                if (c && fe_zero(xs[c])) { fprintf(stderr, "dependent basis\n"); return 2; }
            }
            for (int ci = 0; ci < ncurves; ci++) {
                long cnt[KMAX + 1];
                memset(cnt, 0, sizeof cnt);
                for (int c = 0; c < (1 << KMAX); c++) {
                    int l = (c == 0) || ((trx[c] ^ tr(mul(bs[ci], ws[c]))) == 0);
                    if (l) cnt[c ? 64 - __builtin_clzll((unsigned long long)c) : 0]++;
                    /* half-trace cross-check on a deterministic sparse sample */
                    if (c && ((c * 2654435761u + ci * 40503u) % 997u) == 0) {
                        fe a = fe_add(xs[c], mul(bs[ci], ws[c]));
                        fe w = halftrace(a);
                        int solved = fe_eq(fe_add(sqr(w), w), a);
                        fe x = xs[c], y = mul(x, w);
                        fe lhs = fe_add(sqr(y), mul(x, y));
                        fe rhs = fe_add(mul(sqr(x), x), bs[ci]);
                        int oncurve = fe_eq(lhs, rhs);
                        if ((solved && oncurve) == l) hcheck_ok++; else hcheck_bad++;
                    }
                }
                long cum = 0;
                printf("COUNT %s %s", labels[ci], vname);
                for (int k = 0; k <= KMAX; k++) { cum += cnt[k]; if (k >= 1) printf(" %ld", cum); }
                printf("\n");
            }
            fprintf(stderr, "subspace %s done\n", vname);
        }
    }
    printf("HALFTRACE_CROSSCHECK ok=%ld bad=%ld\n", hcheck_ok, hcheck_bad);
    return 0;
}
