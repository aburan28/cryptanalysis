"""Compare independent C counts (counts_mine.txt) with the sweep's raw_counts.json and test
C(X_{j+1}, V) == C(X_j, sqrt V) and C(X_{j-1}, V^2) == C(X_j, V) for ALL 263 curves, k = 1..16,
V in {canon, rand1, rand2, rand3}. Plain python3."""
import json, math
D = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C3-descendant-choice-equals-subspace-choice-audit:/"
raw = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/index-calculus/raw_counts.json"))
per = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/index-calculus/per_curve.json"))
RC = raw["counts"]
labels = raw["meta"]["class_labels"]
mine = {}
for line in open(D + "counts_mine.txt"):
    if line.startswith("COUNT"):
        f = line.split()
        mine.setdefault(f[1], {})[f[2]] = [int(v) for v in f[3:]]
def nxt(l, d=1):
    if l == "E0": return "E0"
    return "%s%03d" % (l[0], (int(l[1:]) + d) % 131)
out = {}
# 1. reproduce raw_counts on V (all 263 x 4 x 16)
rep_tot = rep_bad = 0
for l in labels:
    for s in ["canon", "rand1", "rand2", "rand3"]:
        for k in range(1, 17):
            rep_tot += 1
            if mine[l][s][k - 1] != RC[l][s][str(k)]: rep_bad += 1
out["reproduce_raw_counts"] = {"cells": rep_tot, "mismatch": rep_bad}
# 2. chart identity with sqrt, vs raw_counts (their numbers) and vs mine
id_tot = id_bad_raw = id_bad_mine = 0; id_bad_sq = 0
nontrivial = 0
for l in labels:
    for s in ["canon", "rand1", "rand2", "rand3"]:
        for k in range(1, 17):
            id_tot += 1
            a = mine[l]["sqrt_" + s][k - 1]
            if a != RC[nxt(l)][s][str(k)]: id_bad_raw += 1
            if a != mine[nxt(l)][s][k - 1]: id_bad_mine += 1
            if mine[l]["sq_" + s][k - 1] != mine[nxt(l, -1)][s][k - 1]: id_bad_sq += 1
            if mine[l]["sqrt_" + s][k - 1] != mine[l][s][k - 1]: nontrivial += 1
out["chart_identity_sqrt"] = {"cells": id_tot, "mismatch_vs_raw_counts": id_bad_raw, "mismatch_vs_mine": id_bad_mine,
                              "cells_where_C(X,sqrtV)!=C(X,V)": nontrivial}
out["chart_identity_square"] = {"cells": id_tot, "mismatch": id_bad_sq}
# E0 invariance
out["E0_C_V_eq_C_sqrtV_all"] = all(mine["E0"]["sqrt_" + s] == mine["E0"][s] for s in ["canon", "rand1", "rand2", "rand3"])
# per_curve.json count_incl_x0 (derived file) vs mine
pc_bad = pc_tot = 0
for l in labels:
    for s in ["canon", "rand1", "rand2", "rand3"]:
        for k in range(8, 17):
            pc_tot += 1
            if per[l]["count_incl_x0"][s]["k%d" % k] != mine[l][s][k - 1]: pc_bad += 1
out["per_curve_json_count_incl_x0"] = {"cells": pc_tot, "mismatch": pc_bad}
# 3. suggested check row: A057 on sqrt(V) vs A058 canon in per_curve.json
out["A057_sqrtV_vs_A058_V"] = {str(k): [mine["A057"]["sqrt_canon"][k - 1], per["A058"]["count_incl_x0"]["canon"]["k%d" % k]] for k in range(8, 17)}
# 4. adjacent-conjugate correlation over the 262 floor curves: corr(C(X_j,V), C(X_{j+1},V)), canon, per k
floor = [l for l in labels if l != "E0"]
corr = {}
for s in ["canon", "rand1", "rand2", "rand3"]:
    for k in (8, 10, 12, 14, 16):
        a = [mine[l][s][k - 1] for l in floor]; b = [mine[nxt(l)][s][k - 1] for l in floor]
        ma, mb = sum(a) / len(a), sum(b) / len(b)
        cov = sum((x - ma) * (y - mb) for x, y in zip(a, b)) / (len(a) - 1)
        va = sum((x - ma) ** 2 for x in a) / (len(a) - 1); vb = sum((y - mb) ** 2 for y in b) / (len(b) - 1)
        corr["%s_k%d" % (s, k)] = round(cov / math.sqrt(va * vb), 4)
out["adjacent_corr_empirical_262"] = corr
out["adjacent_corr_model_canon"] = {"k%d" % k: round((2 ** (k // 2) - 2) / (2 ** k - 2), 4) for k in (8, 10, 12, 14, 16)}
json.dump(out, open(D + "compare.json", "w"), indent=1)
print(json.dumps(out, indent=1))
