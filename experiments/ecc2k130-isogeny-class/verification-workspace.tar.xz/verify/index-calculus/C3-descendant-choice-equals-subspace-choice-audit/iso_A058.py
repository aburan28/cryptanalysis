"""Explicit F_q-rational 263-isogeny E0 -> A058 (a curve outside the ground-truth check's 12-curve sample).
Kernel found on the quadratic twist E0' = [1,1,0,0,1] (whose 263-part is (Z/263)^2 over F_q; x-coordinates of
kernels are shared with E0), then the isogeny is built on E0 itself from the kernel polynomial (F_q coefficients).
Run: export TMPDIR=...; sage -python iso_A058.py"""
import sys, json, time, random
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import EllipticCurve, PolynomialRing, set_random_seed
set_random_seed(20260923)
t0 = time.time()
K = ecc2k.field(); z = K.gen()
q, t, N = ecc2k.q, ecc2k.t, ecc2k.N
E0 = EllipticCurve(K, [1, 0, 0, 0, 1]); Et = EllipticCurve(K, [1, 1, 0, 0, 1])
target = "A058"
bT = ecc2k.dec(ecc2k.RECORDS[target]["b_int"]); jT = 1 / bT
cof = (q + 1 + t) // 263**2   # 263-part of the twist is (Z/263)^2 (exponent 263)
def pt263():
    while True:
        P = cof * Et.random_point()
        if not P.is_zero():
            assert (263 * P).is_zero(); return P
P1 = pt263()
while True:
    P2 = pt263()
    if P1.weil_pairing(P2, 263) != 1: break
res = {"target": target}
def xs_of(G):
    xs, Q = [], G
    for i in range(131):
        xs.append(Q[0]); Q = Q + G
    return xs
found = None
gens = [P1] + [P2 + i * P1 for i in range(263)]
jvals = {}
R = PolynomialRing(K, "X"); X = R.gen()
for idx, G in enumerate(gens):
    xs = xs_of(G)
    v = sum(xs)
    jv = 1 / (1 + v + v * v)   # hand Velu codomain j for b = 1 (from the ground-truth check); verified below with Sage
    jvals[idx] = jv
    if jv == jT:
        found = (idx, G, xs); break
res["subgroups_scanned"] = len(jvals)
assert found is not None, "A058 not reached"
idx, G, xs = found
kp = R(1)
for xv in xs: kp *= (X - xv)
res["kernel_poly_degree"] = int(kp.degree())
# isogeny on E0 itself from the F_q kernel polynomial
t1 = time.time()
phi = E0.isogeny(kp)
res["isogeny_build_s"] = round(time.time() - t1, 1)
Ec = phi.codomain()
res["degree"] = int(phi.degree())
res["codomain_j_eq_A058"] = bool(Ec.j_invariant() == jT)
EA = ecc2k.curve(target)
res["codomain_Fq_isomorphic_to_A058_model"] = bool(Ec.is_isomorphic(EA))
res["codomain_Fq_isomorphic_to_A058_twist"] = bool(Ec.is_isomorphic(EllipticCurve(K, [1, 1, 0, 0, bT])))
# push a point of order N from E0 through phi
while True:
    P = 4 * E0.random_point()
    if not P.is_zero(): break
assert (N * P).is_zero()
Q = phi(P)
res["image_nonzero"] = not Q.is_zero(); res["N_times_image_zero"] = bool((N * Q).is_zero())
# DLP transport on the image: a random a, phi([a]P) == [a]phi(P)
a = random.Random(5).randrange(1, N)
res["phi_linear_on_random_multiple"] = bool(phi(a * P) == a * Q)
res["elapsed_s"] = round(time.time() - t0, 1)
json.dump(res, open("iso_A058.json", "w"), indent=1)
print(json.dumps(res, indent=1))
