"""Independent audit of claim C5 (tau factor base is E0-only and GGMP-type Frobenius-invariant
factor bases are unrealisable at (q, n) = (2, 131)).

Does NOT use ecc2k.py or the sweep's structure_checks.py; reads ground_truth.json directly and
builds its own field.

Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python audit_c5.py
"""
import json, math, time, random
from sage.all import (GF, PolynomialRing, ZZ, Integer, matrix, vector, pari, Mod, EllipticCurve,
                      identity_matrix, kronecker, is_prime, factor)

OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C5-tau-factor-base-E0-only-and-unrealisable-at-131-audit:/"
GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
t0 = time.time()
res = {}

# ---------------------------------------------------------------- 1. x^131 + 1 over F_2
F2 = GF(2)
P2 = PolynomialRing(F2, "x"); x = P2.gen()
fac_sage = (x ** 131 + 1).factor()
res["x131p1_factor_degrees_sage"] = sorted(int(f.degree()) for f, e in fac_sage)
res["x131p1_factor_mults_sage"] = sorted(int(e) for f, e in fac_sage)
fm = pari("factormod(x^131+1, 2)")
res["x131p1_factor_degrees_pari"] = sorted(int(pari("poldegree")(g)) for g in fm[0])
Phi = sum(x ** i for i in range(131))
res["Phi131_irreducible_sage"] = bool(Phi.is_irreducible())
res["Phi131_irreducible_pari"] = bool(pari("polisirreducible(Mod(1,2)*sum(i=0,130,x^i))"))
res["ord_131_2"] = int(Mod(2, 131).multiplicative_order())
# GGMP Lemma 4.1 (Menezes-Qu Lemma 7): n = s*l + 1 with l = ord_n(2); s = number of degree-l factors
res["GGMP_lemma41_s"] = (131 - 1) // res["ord_131_2"]

# ---------------------------------------------------------------- 2. squaring operator on F_q
meta = json.load(open(GT))["meta"]
MODI = int(meta["modulus_int"])
Rz = PolynomialRing(F2, "z")
modpoly = Rz([(MODI >> i) & 1 for i in range(MODI.bit_length())])
assert modpoly.degree() == 131 and modpoly.is_irreducible()
K = GF(2 ** 131, "z", modulus=modpoly)
z = K.gen()
def vec(u):
    return vector(F2, u.polynomial().padded_list(131))
S = matrix(F2, [vec((z ** i) ** 2) for i in range(131)]).transpose()   # column i = (z^i)^2
assert S * vec(z ** 5 + z) == vec((z ** 5 + z) ** 2)
mp = S.minpoly()
cp = S.charpoly()
res["squaring_minpoly_is_x131p1"] = bool(mp.list() == (x ** 131 + 1).list())
res["squaring_charpoly_is_x131p1"] = bool(cp.list() == (x ** 131 + 1).list())
I = identity_matrix(F2, 131)
ker1 = (S + I).right_kernel()
PhiS = sum((S ** i for i in range(131)), matrix(F2, 131, 131))
kerPhi = PhiS.right_kernel()
res["dim_ker_S_plus_1"] = int(ker1.dimension())
res["dim_ker_Phi131_S"] = int(kerPhi.dimension())
res["ker_S_plus_1_is_F2"] = bool(ker1.dimension() == 1 and vec(K(1)) in ker1)
# ker Phi(S) = ker Tr: check that a basis of kerPhi consists of trace-0 elements
res["ker_Phi_is_ker_trace"] = bool(all(K(list(b)).trace() == 0 for b in kerPhi.basis()))
# cyclic operator with squarefree min poly having 2 irreducible factors -> exactly 4 invariant subspaces
res["invariant_subspace_dims"] = sorted({0, int(ker1.dimension()), int(kerPhi.dimension()), 131})
# Frobenius-span dimension of random elements (must lie in {0,1,130,131})
rng = random.Random(20260923)
spans = {}
for _ in range(300):
    u = K.from_integer(rng.getrandbits(131))
    M = matrix(F2, [vec(u ** (2 ** i)) for i in range(131)])
    d = int(M.rank()); spans[d] = spans.get(d, 0) + 1
for u in (K(0), K(1), z + z ** 2):            # z + z^2 has trace 0 -> span dim <= 130
    M = matrix(F2, [vec(u ** (2 ** i)) for i in range(131)])
    d = int(M.rank()); spans[d] = spans.get(d, 0) + 1
res["frobenius_span_dims_histogram"] = {str(k): v for k, v in sorted(spans.items())}
# smallest Frobenius-invariant subspace containing the canonical V_k = span(1..z^(k-1)), k=2..20
inv_hull = {}
for k in (2, 5, 10, 20, 40):
    rows = [vec((z ** i) ** (2 ** j)) for i in range(k) for j in range(131)]
    inv_hull[str(k)] = int(matrix(F2, rows).rank())
res["invariant_hull_dim_of_canonical_V_k"] = inv_hull

# ---------------------------------------------------------------- 3. GGMP Sec 4.2 preconditions at q = 2
q0 = 2
lo, hi = q0 + 1 - 2 * math.sqrt(q0), q0 + 1 + 2 * math.sqrt(q0)
res["F2_hasse_interval"] = [lo, hi]
res["F2_curve_orders_possible"] = [m for m in range(0, 10) if lo < m < hi]
res["multiples_of_131_in_F2_hasse"] = [m for m in res["F2_curve_orders_possible"] if m % 131 == 0]
res["torus_131_divides_q0_plus_1"] = (q0 + 1) % 131 == 0
res["kummer_131_divides_q0_minus_1"] = (q0 - 1) % 131 == 0 and q0 - 1 > 0
res["artin_schreier_131_equals_char"] = (131 == 2)
res["Gal_Fq_F2_order_prime"] = bool(is_prime(131))

# ---------------------------------------------------------------- 4. endomorphism rings
p = int(meta["p"]); f = int(meta["f"]); t = int(meta["t"]); q = 2 ** 131
assert f == 263 * p and t * t - 4 * q == -7 * f * f
# O_K = Z[w], w = (1+sqrt(-7))/2, w^2 = w - 2; N(a + b w) = a^2 + a b + 2 b^2
def norm(a, b):
    return a * a + a * b + 2 * b * b
norm2 = [(a, b) for a in range(-3, 4) for b in range(-3, 4) if norm(a, b) == 2]
res["norm2_elements_OK_(a,b)_in_a+bw"] = norm2
# tau: tau^2 + tau + 2 = 0; w - 1 satisfies (w-1)^2 + (w-1) + 2 = w^2 - w + 2 = 0 -> tau = w - 1 (or -w)
res["norm2_in_Z+cOK"] = {str(c): [ab for ab in norm2 if ab[1] % c == 0] for c in (263, p, 263 * p)}
# minimal non-scalar norm in Z + 263 O_K: exact bound 7 c^2 / 4 and brute force
c = 263
brute = min(norm(a, c * b) for b in range(1, 4) for a in range(-3 * c, 3 * c))
res["min_nonscalar_degree_Z+263OK"] = int(brute)
res["min_nonscalar_degree_lower_bound_7c2/4"] = 7 * c * c / 4
res["factor_121046"] = str(factor(brute))
res["min_nonscalar_degree_Z+pOK_lower_bound_log2"] = math.log2(7 * p * p / 4)
# powers of tau in Z + 263 O_K: tau = w - 1 = (-1, 1); multiply (a + b w)(c + d w) = ac - 2bd + (ad + bc - bd... )
def mul(u, v):
    a, b = u; c2, d = v
    # w^2 = w - 2
    return (a * c2 - 2 * b * d, a * d + b * c2 + b * d)
tau = (-1, 1)
assert mul(tau, tau)[0] + tau[0] + 2 == 0 and mul(tau, tau)[1] + tau[1] == 0
e_in = []
pw = (1, 0)
for e in range(1, 263 * 2 + 1):
    pw = mul(pw, tau)
    if pw[1] % 263 == 0:
        e_in.append(e)
res["exponents_e<=526_with_tau^e_in_Z+263OK"] = e_in
# tau^131 = pi ?  (pi = (t + sqrt(-7) f)/2 up to sign conventions; check norm and trace)
pw = (1, 0)
for e in range(131):
    pw = mul(pw, tau)
a, b = pw
tr = 2 * a + b          # Tr(a + b w) = 2a + b
res["tau^131_trace_equals_t"] = bool(tr == t)
res["tau^131_norm_equals_q"] = bool(norm(a, b) == q)
res["tau^131_w_coeff_equals_f"] = bool(abs(b) == f)
# eigenvalues of tau mod 263
ev = sorted(r for r in range(263) if (r * r + r + 2) % 263 == 0)
res["tau_eigenvalues_mod_263"] = ev
res["order_of_eigen_ratio_mod_263"] = int((Mod(ev[0], 263) / Mod(ev[1], 263)).multiplicative_order())

# ---------------------------------------------------------------- 5. the 263 curves (read JSON directly)
curves = json.load(open(GT))["curves"]
assert len(curves) == 263
degs, fixed, sep2, sep2_E0, autsz = {}, [], [], None, {}
for rec in curves:
    lab = rec["label"]
    j = K.from_integer(int(rec["j_int"]))
    b = K.from_integer(int(rec["b_int"]))
    assert b * j == 1
    d = int(j.minpoly().degree())
    degs[d] = degs.get(d, 0) + 1
    if j ** 2 == j:
        fixed.append(lab)
    # separable 2-isogeny: kernel = the unique point of order 2, (0, sqrt(b))
    E = EllipticCurve(K, [1, int(rec["a2"]), 0, 0, b])
    T = E(0, b.sqrt())
    assert (2 * T).is_zero() and not T.is_zero()
    phi = E.isogeny(T)
    jc = phi.codomain().j_invariant()
    ok = (jc == j.sqrt())
    if lab == "E0":
        sep2_E0 = {"codomain_j_is_1": bool(jc == 1), "codomain_j_eq_j_sqrt": bool(ok)}
    else:
        sep2.append((lab, bool(ok), bool(jc == j), bool(j ** 2 == j)))
    if lab in ("E0", "A000", "B000", "A077", "B130"):
        autsz[lab] = len(E.automorphisms())
res["j_degree_over_F2_histogram"] = {str(k): v for k, v in degs.items()}
res["labels_with_j_in_F2"] = fixed
res["E0_separable_2isogeny"] = sep2_E0
res["floor_sep2_codomain_j_equals_sqrt_j_all"] = all(r[1] for r in sep2)
res["floor_sep2_codomain_j_equals_j_any"] = any(r[2] for r in sep2)
res["floor_j_squared_equals_j_any"] = any(r[3] for r in sep2)
res["floor_count_checked"] = len(sep2)
res["automorphism_group_sizes_sample"] = autsz

res["elapsed_s"] = time.time() - t0
json.dump(res, open(OUT + "audit_c5.json", "w"), indent=1, default=str)
for k, v in res.items():
    print(k, ":", v)
