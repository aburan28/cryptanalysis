"""Scope check for the 'unrealisable at (2,131)' part of claim C5.

Couveignes-Lercier (as recalled in GGMP Sec 4.2) need a commutative algebraic group G over F_2 with a
subgroup T of G(F_2) of order 131 (T is identified with Gal(F_{2^131}/F_2)).  GGMP only treat
1-dimensional G (G_a, G_m / Kummer, the norm torus, elliptic curves).  Here we list, for small
dimension g, whether some abelian variety over F_2 has 131 | #A(F_2) (via Weil polynomials,
P(1) = #A(F_2)), and the smallest dimension of an algebraic torus over F_2 with 131 | #T(F_2).
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python cl_groups_c5.py
"""
import json, math, time
from sage.all import ZZ, Mod, cyclotomic_polynomial, euler_phi, PolynomialRing, QQ
from sage.rings.polynomial.weil.weil_polynomials import WeilPolynomials

OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C5-tau-factor-base-E0-only-and-unrealisable-at-131-audit:/"
t0 = time.time()
res = {}
for g in (1, 2, 3, 4, 5):
    lo, hi = (math.sqrt(2) - 1) ** (2 * g), (math.sqrt(2) + 1) ** (2 * g)
    polys = list(WeilPolynomials(2 * g, 2))
    orders = sorted({int(P(1)) for P in polys})
    hits = [str(P) for P in polys if P(1) % 131 == 0 and P(1) != 0]
    res["g%d" % g] = {"weil_bound_interval": [lo, hi], "num_weil_polys": len(polys),
                      "max_order": max(orders), "orders_divisible_by_131": sorted({int(P(1)) for P in polys if P(1) % 131 == 0}),
                      "example_polys_with_131": hits[:5],
                      "irreducible_examples_with_131": [s for s in hits if PolynomialRing(QQ, 'x')(s).is_irreducible()][:5]}
    print(g, res["g%d" % g], flush=True)
# tori: #T(F_2) for T = norm-type torus attached to Phi_k is Phi_k(2); 131 | Phi_k(2) iff k = ord_131(2) * 131^j
ks = [k for k in range(1, 400) if cyclotomic_polynomial(k)(2) % 131 == 0]
res["tori_k_with_131_divides_Phi_k(2)"] = ks
res["tori_min_dimension_euler_phi"] = int(min(euler_phi(k) for k in ks))
res["elapsed_s"] = time.time() - t0
json.dump(res, open(OUT + "cl_groups_c5.json", "w"), indent=1)
print(json.dumps(res, indent=1))
