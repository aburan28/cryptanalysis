"""Check the 'transfer' part of claim C5 on one floor curve (A000): an explicit F_q-rational
263-isogeny phi: E0 -> A000 and its dual, both injective on the order-N subgroups, so a DLP on
A000[N] maps to a DLP on E0[N] (and back) in polynomial time.
Kernel x-coordinates are taken from the twist E0' = [1,1,0,0,1] whose 263-part is (Z/263)^2 over F_q
(in char 2 the quadratic twist keeps x-coordinates, so the kernel polynomial is the same).
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python transfer_c5.py
"""
import json, time, random
from sage.all import GF, PolynomialRing, EllipticCurve, ZZ, set_random_seed

OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C5-tau-factor-base-E0-only-and-unrealisable-at-131-audit:/"
GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
set_random_seed(20260923)
t0 = time.time()
d = json.load(open(GT)); meta = d["meta"]
MODI = int(meta["modulus_int"])
R = PolynomialRing(GF(2), "z")
K = GF(2 ** 131, "z", modulus=R([(MODI >> i) & 1 for i in range(MODI.bit_length())]))
N = int(meta["N"]); CARD = int(meta["card"]); TW = int(meta["twist_card"])
rec = {c["label"]: c for c in d["curves"]}
bA = K.from_integer(int(rec["A000"]["b_int"])); jA = 1 / bA
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
E0t = EllipticCurve(K, [1, 1, 0, 0, 1])
assert TW % 263 ** 2 == 0 and (TW // 263 ** 2) % 263 != 0
cof = TW // 263 ** 2
def pt263():
    while True:
        P = cof * E0t.random_point()
        if not P.is_zero():
            return P
P1 = pt263()
while True:
    P2 = pt263()
    if P1.weil_pairing(P2, 263) != 1:
        break
res = {"E0t_263_basis_weil_pairing_nontrivial": True}
gens = [P1] + [P2 + i * P1 for i in range(263)]
target = None
for G in gens:
    xs, Q = [], G
    for k in range(131):
        xs.append(Q[0]); Q = Q + G
    v = sum(xs, K(0))
    jc = 1 / (1 + v + v * v)
    if jc == jA:
        target = (G, xs)
        break
assert target is not None
G, xs = target
Px = PolynomialRing(K, "X"); X = Px.gen()
ker = Px(1)
for u in xs:
    ker *= (X - u)
res["kernel_poly_degree"] = int(ker.degree())
res["kernel_poly_Fq_rational"] = True       # all x in F_q by construction
tp = time.time()
phi = E0.isogeny(ker)
res["isogeny_seconds"] = time.time() - tp
Ec = phi.codomain()
res["phi_degree"] = int(phi.degree())
res["codomain_j_equals_A000"] = bool(Ec.j_invariant() == jA)
EA = EllipticCurve(K, [1, int(rec["A000"]["a2"]), 0, 0, bA])
res["codomain_isomorphic_to_A000_model"] = bool(Ec.is_isomorphic(EA))
iso = Ec.isomorphism_to(EA)
# a point of order 4N on E0 and its image
while True:
    P = E0.random_point()
    if not (CARD // 2 * P).is_zero() and not (4 * P).is_zero():
        break
assert (CARD * P).is_zero()
PA = iso(phi(P))
res["phi(P)_order_4N"] = bool((CARD * PA).is_zero() and not ((CARD // 2) * PA).is_zero()
                              and not (4 * PA).is_zero())
PN = 4 * P
res["phi_on_N_subgroup_injective_sample"] = bool(not iso(phi(PN)).is_zero() and (N * iso(phi(PN))).is_zero())
res["gcd_263_N"] = int(ZZ(263).gcd(N))
# dual isogeny: Sage has no dual() in char 2, so build psi: A000 -> (j=1) from the unique
# F_q-rational 263-subgroup (computed on the twist EAt, whose 263-part is cyclic of order 263^2;
# x-coordinates are twist-invariant in char 2), then test psi o phi = +-[263] on E0.
EAt = EllipticCurve(K, [1, 1 - int(rec["A000"]["a2"]), 0, 0, bA])
TWA = int(EAt.cardinality(extension_degree=1)) if False else TW
assert TWA % 263 ** 2 == 0
cofA = TWA // 263 ** 2
while True:
    Q = cofA * EAt.random_point()
    if not (263 * Q).is_zero():
        break
H = 263 * Q
assert not H.is_zero() and (263 * H).is_zero()
res["EAt_has_point_of_order_263^2"] = True
xs2, Q2 = [], H
for k in range(131):
    xs2.append(Q2[0]); Q2 = Q2 + H
ker2 = Px(1)
for u in xs2:
    ker2 *= (X - u)
tp = time.time()
psi = EA.isogeny(ker2)
res["psi_seconds"] = time.time() - tp
res["psi_codomain_j"] = str(psi.codomain().j_invariant())
to_E0 = psi.codomain().isomorphism_to(E0)
back = to_E0(psi(iso(phi(P))))
res["psi_o_phi_equals_pm263_on_P"] = bool(back == 263 * P or back == -263 * P)
k = random.Random(1).randrange(1, N)
QA = iso(phi(PN)); RA = k * QA
Q0 = to_E0(psi(QA)); R0 = to_E0(psi(RA))
res["psi_image_order_N"] = bool(not Q0.is_zero() and (N * Q0).is_zero())
res["relation_preserved_R0_eq_kQ0"] = bool(R0 == k * Q0)
# an independent random point of A000[N] also maps to order N
while True:
    S0 = (CARD // N) * EA.random_point()
    if not S0.is_zero():
        break
res["psi_random_A000_N_point_to_order_N"] = bool(not to_E0(psi(S0)).is_zero() and (N * to_E0(psi(S0))).is_zero())
res["elapsed_s"] = time.time() - t0
json.dump(res, open(OUT + "transfer_c5.json", "w"), indent=1)
for k2, v2 in res.items():
    print(k2, ":", v2)
