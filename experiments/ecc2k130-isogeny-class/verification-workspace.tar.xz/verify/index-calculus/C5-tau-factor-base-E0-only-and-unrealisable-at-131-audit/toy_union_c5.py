"""Independent recomputation of the n = 19 'tau_union_demo' numbers cited by claim C5
(61 unknowns on E0 vs 973 on floor curve F000 at l = 7), plus:
  - check that F000 (b_int 515802 from relprob_toy.json) really is a 457-floor curve:
    #E = 4N and Phi_457(1, j) = 0 in F_{2^19} (PARI polmodular), j not in F_2;
  - the Frobenius-invariant subspaces of F_{2^19} (x^19+1 = (x+1)*deg-18 irreducible, ord_19(2)=18);
  - context: E0 plain (non-union) factor base size at l = 7 and at l = 7 + log2(19).
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python toy_union_c5.py
"""
import json, time
from sage.all import GF, PolynomialRing, EllipticCurve, pari, Mod, is_prime

OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C5-tau-factor-base-E0-only-and-unrealisable-at-131-audit:/"
t0 = time.time()
n = 19
R = PolynomialRing(GF(2), "z"); zz = R.gen()
mod = zz ** 19 + zz ** 5 + zz ** 2 + zz + 1
assert mod.is_irreducible()
K = GF(2 ** n, "z", modulus=mod); z = K.gen()
q = 2 ** n
tt = [2, -1]
for i in range(2, n + 1):
    tt.append(-tt[-1] - 2 * tt[-2])
t = tt[n]; CARD = q + 1 - t; N = CARD // 4
res = {"t": t, "CARD": CARD, "N": N, "N_prime": bool(is_prime(N)),
       "disc_check": (t * t - 4 * q) == -7 * 457 ** 2}
xs = PolynomialRing(GF(2), "x").gen()
res["x19p1_factor_degrees"] = sorted(int(f.degree()) for f, e in (xs ** 19 + 1).factor())
res["ord_19_2"] = int(Mod(2, 19).multiplicative_order())

bF = K.from_integer(515802)          # F000 from relprob_toy.json 'curves'
jF = 1 / bF
EF = EllipticCurve(K, [1, 0, 0, 0, bF])
res["F000_card_is_4N"] = bool(EF.cardinality() == CARD)
res["F000_j_minpoly_degree"] = int(jF.minpoly().degree())
tp = time.time()
Phi1 = pari("polmodular(457, 0, Mod(1,2), 'Y)")          # Phi_457(1, Y) mod 2 (Y = the variable)
coeffs = [int(pari("lift")(c)) for c in pari("Vecrev")(Phi1)]
val = sum((jF ** i for i, c in enumerate(coeffs) if c), K(0))
res["Phi457(1,j_F000)==0"] = bool(val == 0)
res["polmodular_seconds"] = time.time() - tp
res["Phi457(1,Y)_degree"] = len(coeffs) - 1


def liftable(b, u):
    return u == 0 or (u + b / (u * u)).trace() == 0


demo = {}
for l in (5, 6, 7):
    V = [K(sum(((c >> i) & 1) * z ** i for i in range(l))) for c in range(1 << l)]
    U = set()
    for u in V:
        y = u
        for _ in range(n):
            U.add(y)
            y = y * y
    for lab, b in (("E0", K(1)), ("F000", bF)):
        L = [u for u in U if liftable(b, u)]
        pts = sum(1 if u == 0 else 2 for u in L)
        if lab == "E0":
            orbs = {min((u ** (2 ** k)).to_integer() for k in range(n)) for u in L}
            unk = len(orbs)
        else:
            unk = len(L)                                  # points up to negation
        plainV = sum(1 if u == 0 else 2 for u in V if liftable(b, u))
        demo["l%d_%s" % (l, lab)] = {"union_x": len(U), "union_points": pts,
                                    "unknowns_mod_neg(+tau on E0)": unk,
                                    "plain_V_points": plainV,
                                    "plain_V_unknowns_mod_neg": sum(1 for u in V if liftable(b, u))}
res["tau_union_demo"] = demo
res["elapsed_s"] = time.time() - t0
json.dump(res, open(OUT + "toy_union_c5.json", "w"), indent=1)
for k, v in res.items():
    print(k, ":", v)
