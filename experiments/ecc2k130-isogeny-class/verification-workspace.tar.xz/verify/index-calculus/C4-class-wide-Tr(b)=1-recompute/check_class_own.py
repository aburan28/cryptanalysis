"""C4 recompute, part 1: pure python3 with own GF(2^131) arithmetic (gf2m_own.py).

Checks, all on the 263 class curves read from ground_truth.json:
  1. trace mask of the polynomial basis, derived two ways (Newton identities on
     the modulus; direct Frobenius sums of z^i) -> set of i with Tr(z^i) = 1.
  2. a2 = 0 and Tr(b) for every class curve, by full Frobenius sum and by mask.
  3. x = 1 lifts on every class curve (explicit point, checked on the curve).
  4. #E = 4N by own scalar multiplication: a point of exact order 4N, plus
     Hasse-interval uniqueness; 2-Sylow cyclic of order 4 (T4 = [N]P has order
     4, x(T4) = b^(1/4), 2*T4 = (0, sqrt b)); explicit failure of halving T4.
  5. F_2-rank of {b_i - b_E0} and of one Frobenius orbit's differences, and the
     full space of lambda with Tr(lambda*b) constant on the class.
  6. which x in the canonical subspace V_12 have a class-wide constant
     lift status (direct evaluation over all 263 curves).
"""
import json, math, random, sys, time, os

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf2m_own as G

t0 = time.time()
out = {}
GT = '/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json'
gt = json.load(open(GT))
meta = gt['meta']
assert int(meta['modulus_int']) == G.F, 'modulus mismatch'
N = int(meta['N'])
q = 1 << 131
card = int(meta['card'])
assert card == 4 * N

# ---- 1. trace mask ---------------------------------------------------------
# Newton: for f = z^131 + sum c_j z^j, e_i = c_{131-i}; s_k = sum_{i<k} e_i s_{k-i} + k e_k (mod 2)
coeffs = {13: 1, 2: 1, 1: 1, 0: 1}
e = [0] * 132
for j, c in coeffs.items():
    e[131 - j] = c
s = [131 % 2] + [0] * 131  # s_0 = Tr(1) = 131 mod 2
for k in range(1, 131):
    v = (k * e[k]) & 1
    for i in range(1, k):
        v ^= e[i] & s[k - i]
    s[k] = v
mask_newton = [i for i in range(131) if s[i]]
mask_frob = [i for i in range(131) if G.trace_frob(1 << i)]
out['trace_mask_bits_newton'] = mask_newton
out['trace_mask_bits_frobenius'] = mask_frob
assert mask_newton == mask_frob
TRMASK = sum(1 << i for i in mask_frob)


def tr_mask(a):
    return bin(a & TRMASK).count('1') & 1


# ---- 2/3/4. per-curve checks ----------------------------------------------
rng = random.Random(0xC4C4)
hasse_lo = q + 1 - 2 * math.isqrt(q) - 2
hasse_hi = q + 1 + 2 * math.isqrt(q) + 2
mults = [m * N for m in range(hasse_lo // N, hasse_hi // N + 2) if hasse_lo <= m * N <= hasse_hi]
out['multiples_of_N_in_hasse_interval'] = [str(m) for m in mults]
assert mults == [4 * N]

per = []
tr_counts = {0: 0, 1: 0}
for c in gt['curves']:
    lab = c['label']
    b = int(c['b_int'])
    a2 = int(c['a2'])
    rec = {'label': lab, 'a2': a2}
    tf = G.trace_frob(b)
    tm = tr_mask(b)
    assert tf == tm
    rec['Tr_b'] = tf
    tr_counts[tf] += 1
    # x = 1 lifts?
    P1 = G.lift_x(1, a2, b)
    rec['x1_lifts'] = P1 is not None
    if P1 is not None:
        assert G.on_curve(P1, a2, b)
    # a point of exact order 4N
    ok = False
    for attempt in range(20):
        P = G.random_point(a2, b, rng)
        assert G.on_curve(P, a2, b)
        if G.smul(4 * N, P, a2, b) is not None:
            rec['order_4N_fails'] = True
            break
        if G.smul(2 * N, P, a2, b) is not None and G.smul(4, P, a2, b) is not None:
            ok = True
            break
    rec['point_of_order_4N'] = ok
    # 2-Sylow: T4 = [N]P has exact order 4
    T4 = G.smul(N, P, a2, b)
    T2 = G.dbl(T4, a2, b)
    rec['T4_order4'] = (T4 is not None and T2 is not None and G.dbl(T2, a2, b) is None)
    rec['T2_is_(0,sqrt b)'] = (T2 == (0, G.sqrt_(b)))
    c4 = G.sqrt_(G.sqrt_(b))
    rec['x(T4)=b^(1/4)'] = (T4[0] == c4)
    # try to halve T4: x^2 + b/x^2 = c4  <=>  u^2 + c4*u + c4^4 = 0 with u = x^2
    # substitute u = c4*v: v^2 + v = c4^2 ; solvable iff Tr(c4^2) = 0
    rec['Tr(c4^2)'] = G.trace_frob(G.sqr(c4))
    rec['T4_halvable'] = (rec['Tr(c4^2)'] == 0)
    per.append(rec)

out['n_curves'] = len(per)
out['Tr_b_counts'] = tr_counts
out['all_a2_zero'] = all(r['a2'] == 0 for r in per)
out['all_x1_lift'] = all(r['x1_lifts'] for r in per)
out['all_point_order_4N'] = all(r['point_of_order_4N'] for r in per)
out['all_T4_order4'] = all(r['T4_order4'] for r in per)
out['all_T2_is_(0,sqrt b)'] = all(r['T2_is_(0,sqrt b)'] for r in per)
out['all_x(T4)=b^(1/4)'] = all(r['x(T4)=b^(1/4)'] for r in per)
out['n_T4_halvable'] = sum(r['T4_halvable'] for r in per)
out['any_order_4N_fail'] = any(r.get('order_4N_fails') for r in per)
print('per-curve done', time.time() - t0, flush=True)

# ---- 5. linear algebra over F_2 ------------------------------------------
def rank_f2(vecs):
    basis = {}  # pivot bit -> vector
    for v in vecs:
        while v:
            p = v.bit_length() - 1
            if p in basis:
                v ^= basis[p]
            else:
                basis[p] = v
                break
    return len(basis), basis

bs = {c['label']: int(c['b_int']) for c in gt['curves']}
b0 = bs['E0']
diffs = [bs[l] ^ b0 for l in bs if l != 'E0']
out['rank_all_b'] = rank_f2(list(bs.values()))[0]
out['rank_diffs_from_E0'] = rank_f2(diffs)[0]
for orb in 'AB':
    lab = [l for l in bs if l.startswith(orb)]
    d = [bs[l] ^ bs[orb + '000'] for l in lab]
    out['rank_diffs_orbit_' + orb] = rank_f2(d)[0]
    out['rank_orbit_' + orb] = rank_f2([bs[l] for l in lab])[0]
    out['Tr_b_values_orbit_' + orb] = sorted(set(tr_mask(bs[l]) for l in lab))
# all trace-zero vectors lie in the span of the differences?
rk, basis = rank_f2(diffs)
def in_span(v):
    while v:
        p = v.bit_length() - 1
        if p not in basis:
            return False
        v ^= basis[p]
    return True
out['diffs_all_trace_zero'] = all(tr_mask(d) == 0 for d in diffs)
# lambda-space: Tr(lambda * d) = 0 for all d.  Build the 131x131 matrix of the
# bilinear form restricted to a basis of the differences span and find kernel.
dbasis = list(basis.values())
# linear map lambda -> (Tr(lambda*d_j))_j ; compute images of z^i
rows = []
for i in range(131):
    lam = 1 << i
    img = 0
    for jj, d in enumerate(dbasis):
        img |= G.trace_frob(G.mul(lam, d)) << jj
    rows.append(img)
# kernel of the map  (F_2^131 -> F_2^rk): gaussian elimination with tracking
aug = [(rows[i], 1 << i) for i in range(131)]
kernel = []
piv = {}
for img, comb in aug:
    while img:
        p = img.bit_length() - 1
        if p in piv:
            img ^= piv[p][0]
            comb ^= piv[p][1]
        else:
            piv[p] = (img, comb)
            break
    if img == 0:
        kernel.append(comb)
kr, kb = rank_f2(kernel)
out['dim_lambda_space_constant_on_class'] = kr
out['lambda_space_basis'] = [str(v) for v in kb.values()]
print('linear algebra done', time.time() - t0, flush=True)

# ---- 6. class-wide constant lift status in canonical V_k ------------------
K = 12
const_x = []
blist = list(bs.values())
for x in range(1, 1 << K):
    lam = G.inv(G.sqr(x))
    trx = tr_mask(x)
    vals = set()
    for b in blist:
        vals.add(trx ^ tr_mask(G.mul(b, lam)))
        if len(vals) > 1:
            break
    if len(vals) == 1:
        const_x.append((x, 'lifts' if vals.pop() == 0 else 'never'))
out['canon_V12_x_with_classwide_constant_lift'] = const_x

# z-shift arithmetic
out['one_over_sqrt_2k_minus_1'] = {k: 1 / math.sqrt(2 ** k - 1) for k in range(1, 17)}
out['elapsed_s'] = time.time() - t0
json.dump({'summary': out, 'per_curve': per},
          open(os.path.join(HERE, 'check_class_own.json'), 'w'), indent=1)
print(json.dumps(out, indent=1, default=str)[:6000])
