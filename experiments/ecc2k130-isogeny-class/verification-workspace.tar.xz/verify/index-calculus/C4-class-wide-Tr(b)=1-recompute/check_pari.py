"""C4 recompute, part 2: PARI (via cypari2 inside Sage) cross-checks.

  A. class curves: PARI trace() of b as t_FFELT, ellordinate(E,1), ellcard,
     ellgroup (2-Sylow structure) for all 263.
  B. fresh random null (own seed): 600 random b with a2 = 0, 200 with a random
     nonzero a2 of trace 0, 200 with a2 of trace 1: PARI ellcard mod 8 vs trace(b).
  C. the sweep's own null samples (R*** in raw_counts.json, S*** in
     raw_counts_null2.json): recompute Tr(b) (PARI trace and own mask) and
     ellcard from scratch; compare with their order_pari and their observations.
Run: sage -python check_pari.py
"""
import json, os, sys, time, random
from cypari2 import Pari

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf2m_own as G

pari = Pari()
pari.allocatemem(2 * 10**9, silent=True)
t0 = time.time()
MOD = (1 << 131) | (1 << 13) | 7
N = 680564733841876926932320129493409985129
out = {}

pari('Tmod = Mod(1,2)*(z^131 + z^13 + z^2 + z + 1)')
pari('g = ffgen(Tmod, \'z)')
# int bitmask -> FFELT: sum of bits * g^i
pari('I2F(n) = my(v = Vecrev(binary(n)), s = 0*g); for(i=1, #v, if(v[i], s += g^(i-1))); s')

def ff(n):
    return pari('I2F(%d)' % n)

def pari_trace(n):
    return int(pari('trace(I2F(%d))' % n))

TRMASK = (1 << 0) | (1 << 129)
def own_tr(n):
    return bin(n & TRMASK).count('1') & 1

# sanity: I2F consistent with own arithmetic for random products
rng = random.Random(20260923)
for _ in range(50):
    a, b = rng.getrandbits(131), rng.getrandbits(131)
    c = G.mul(a, b)
    assert pari('I2F(%d)*I2F(%d) == I2F(%d)' % (a, b, c)) == 1
out['pari_vs_own_field_mul_checks'] = 50

# ---------- A. class curves ----------
gt = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json'))
A = []
for c in gt['curves']:
    b = int(c['b_int']); a2 = int(c['a2'])
    pari('E = ellinit([1, I2F(%d), 0, 0, I2F(%d)])' % (a2, b))
    trb = pari_trace(b)
    ords = pari('ellordinate(E, 1 + 0*g)')
    card = int(pari('ellcard(E)'))
    grp = [int(v) for v in pari('ellgroup(E)')]
    rec = dict(label=c['label'], Tr_b_pari=trb, Tr_b_own=own_tr(b),
               n_ordinates_x1=len(ords), card=str(card), card_mod8=card % 8,
               card_eq_4N=(card == 4 * N), group=[str(g) for g in grp])
    # verify each returned ordinate really is on the curve (PARI side)
    oc = pari('my(v = ellordinate(E, 1 + 0*g)); vector(#v, i, ellisoncurve(E, [1 + 0*g, v[i]]))')
    assert len(oc) == len(ords) and all(int(u) == 1 for u in oc)
    A.append(rec)
out['class_n'] = len(A)
out['class_Tr_b_pari_values'] = sorted(set(r['Tr_b_pari'] for r in A))
out['class_Tr_b_own_values'] = sorted(set(r['Tr_b_own'] for r in A))
out['class_x1_ordinates_counts'] = sorted(set(r['n_ordinates_x1'] for r in A))
out['class_card_mod8_values'] = sorted(set(r['card_mod8'] for r in A))
out['class_all_card_4N'] = all(r['card_eq_4N'] for r in A)
out['class_group_structures'] = sorted(set(tuple(r['group']) for r in A))
print('A done', time.time() - t0, flush=True)

# ---------- B. fresh random null ----------
def sample(nb, a2mode, seed):
    r = random.Random(seed)
    rows = []
    while len(rows) < nb:
        b = r.getrandbits(131)
        if b == 0:
            continue
        if a2mode == 'zero':
            a2 = 0
        else:
            want = 0 if a2mode == 'tr0' else 1
            while True:
                a2 = r.getrandbits(131)
                if a2 not in (0, 1) and own_tr(a2) == want:
                    break
        pari('E = ellinit([1, I2F(%d), 0, 0, I2F(%d)])' % (a2, b))
        card = int(pari('ellcard(E)'))
        rows.append((own_tr(b), pari_trace(b), card % 8, pari_trace(a2)))
    return rows

B = {}
for mode, nb, seed in [('zero', 600, 11), ('tr0', 200, 12), ('tr1', 200, 13)]:
    rows = sample(nb, mode, seed)
    assert all(r[0] == r[1] for r in rows)
    tab = {}
    for trb, _, m8, tra2 in rows:
        key = 'Tr(a2)=%d,Tr(b)=%d' % (tra2, trb)
        tab.setdefault(key, {})
        tab[key][str(m8)] = tab[key].get(str(m8), 0) + 1
    B[mode] = {'n': nb, 'seed': seed, 'table_card_mod8': tab}
out['fresh_null'] = B
print('B done', time.time() - t0, flush=True)

# ---------- C. the sweep's own null samples ----------
IC = '/Volumes/SSD990/ecdlp-hardness-work/index-calculus/'
rc = json.load(open(IC + 'raw_counts.json'))
rn2 = json.load(open(IC + 'raw_counts_null2.json'))
C = {}
for name, nc in [('null1_R', rc['null_curves']), ('null2_S', rn2['null_curves'])]:
    trc = {0: 0, 1: 0}
    pairs = set()
    mism_order = 0
    mism_tr = 0
    own_order_checks = 0
    own_order_fail = 0
    n = 0
    for lab, v in nc.items():
        b = int(v['b_int'])
        theirs = int(v['order_pari'])
        pari('E = ellinit([1, 0, 0, 0, I2F(%d)])' % b)
        mine = int(pari('ellcard(E)'))
        if mine != theirs:
            mism_order += 1
        tp, to = pari_trace(b), own_tr(b)
        if tp != to:
            mism_tr += 1
        trc[to] += 1
        pairs.add((to, mine % 8))
        # own-arithmetic check of the PARI order on a few curves: [#E]P = O
        if n < 40:
            P = G.random_point(0, b, rng)
            own_order_checks += 1
            if G.smul(mine, P, 0, b) is not None:
                own_order_fail += 1
        n += 1
    C[name] = dict(n=n, Tr_b_counts=trc, pairs_Tr_b_card_mod8=sorted(pairs),
                   order_mismatch_vs_their_order_pari=mism_order,
                   trace_mismatch_pari_vs_own=mism_tr,
                   own_arith_order_checks=own_order_checks,
                   own_arith_order_failures=own_order_fail,
                   n_order_eq_4N=sum(1 for v in nc.values() if int(v['order_pari']) == 4 * N))
C['their_observations_null2_file'] = rn2['observations']
out['sweep_nulls_recomputed'] = C
out['elapsed_s'] = time.time() - t0
json.dump({'summary': out, 'class_per_curve': A}, open(os.path.join(HERE, 'check_pari.json'), 'w'), indent=1)
print(json.dumps(out, indent=1, default=str))
