"""Own, from-scratch GF(2^131) and binary-curve arithmetic in pure python3.

Independent of the sweep's scripts, of Sage and of PARI.  Field elements are
ints (bit i = coefficient of z^i), modulus z^131 + z^13 + z^2 + z + 1.
Curve: y^2 + x*y = x^3 + a2*x^2 + b, affine points (x, y), None = O.
"""
import random

M = 131
F = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << M) - 1


def reduce(r):
    # fold with the sparse pentanomial: z^131 = z^13 + z^2 + z + 1
    while r >> M:
        hi = r >> M
        r = (r & MASK) ^ hi ^ (hi << 1) ^ (hi << 2) ^ (hi << 13)
    return r


def mul(a, b):
    if a.bit_length() < b.bit_length():
        a, b = b, a
    r = 0
    while b:
        low = b & -b
        r ^= a << (low.bit_length() - 1)
        b ^= low
    return reduce(r)


# bit-spreading table for squaring
_SQ = [0] * 256
for _i in range(256):
    _v = 0
    for _j in range(8):
        if (_i >> _j) & 1:
            _v |= 1 << (2 * _j)
    _SQ[_i] = _v


def sqr(a):
    r = 0
    s = 0
    while a:
        r |= _SQ[a & 0xFF] << s
        a >>= 8
        s += 16
    return reduce(r)


def inv(a):
    # extended Euclid over F_2[z]
    if a == 0:
        raise ZeroDivisionError
    u, v = a, F
    g1, g2 = 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v = v, u
            g1, g2 = g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return reduce(g1)


def trace_frob(a):
    """Tr(a) = sum_{i<131} a^(2^i), computed by repeated squaring (no mask)."""
    s = a
    t = a
    for _ in range(M - 1):
        t = sqr(t)
        s ^= t
    assert s in (0, 1), s
    return s


def half_trace(c):
    """H(c) = sum_{i=0}^{65} c^(2^(2i)); H^2 + H = c + Tr(c) for odd M."""
    h = c
    t = c
    for _ in range((M - 1) // 2):
        t = sqr(sqr(t))
        h ^= t
    return h


def sqrt_(a):
    # a^(2^130)
    for _ in range(M - 1):
        a = sqr(a)
    return a


def on_curve(P, a2, b):
    if P is None:
        return True
    x, y = P
    lhs = sqr(y) ^ mul(x, y)
    rhs = mul(sqr(x), x) ^ mul(a2, sqr(x)) ^ b
    return lhs == rhs


def neg(P):
    if P is None:
        return None
    x, y = P
    return (x, x ^ y)


def add(P, Q, a2, b):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y1 ^ y2 == x2:  # Q = -P
            return None
        return dbl(P, a2, b)
    lam = mul(y1 ^ y2, inv(x1 ^ x2))
    x3 = sqr(lam) ^ lam ^ x1 ^ x2 ^ a2
    y3 = mul(lam, x1 ^ x3) ^ x3 ^ y1
    return (x3, y3)


def dbl(P, a2, b):
    if P is None:
        return None
    x1, y1 = P
    if x1 == 0:
        return None  # (0, sqrt b) has order 2
    lam = x1 ^ mul(y1, inv(x1))
    x3 = sqr(lam) ^ lam ^ a2
    y3 = sqr(x1) ^ mul(lam ^ 1, x3)
    return (x3, y3)


def smul(k, P, a2, b):
    if k < 0:
        return smul(-k, neg(P), a2, b)
    R = None
    for bit in bin(k)[2:]:
        R = dbl(R, a2, b)
        if bit == '1':
            R = add(R, P, a2, b)
    return R


def lift_x(x, a2, b):
    """Return a point with abscissa x, or None if x does not lift (x != 0)."""
    if x == 0:
        return (0, sqrt_(b))
    # y = x*w,  w^2 + w = x + a2 + b/x^2
    c = x ^ a2 ^ mul(b, inv(sqr(x)))
    if trace_frob(c) != 0:
        return None
    w = half_trace(c)
    assert sqr(w) ^ w == c
    return (x, mul(x, w))


def random_point(a2, b, rng):
    while True:
        x = rng.getrandbits(M)
        if x == 0:
            continue
        P = lift_x(x, a2, b)
        if P is not None:
            if rng.getrandbits(1):
                P = neg(P)
            return P
