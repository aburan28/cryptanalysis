/* C4 recompute, part 3: brute-force point counts over small F_{2^m}.
 *
 * For every m in 3..14, every a2 and every b != 0 in F_{2^m}, count
 *   #E(F_{2^m}) = 1 + #{(x,y) in F^2 : y^2 + x y = x^3 + a2 x^2 + b}
 * by enumerating ALL (x,y) pairs (via per-x histograms of y^2+xy), with no use
 * of any trace criterion.  Then compare with Tr(b), Tr(a2) computed by
 * Frobenius sums.  Checks:
 *   (i)   Tr(a2)=0 : 4 | #E always
 *   (ii)  Tr(a2)=0 : 8 | #E  <=>  Tr(b)=0
 *   (iii) Tr(a2)=1 : #E = 2 mod 4
 *   (iv)  Tr(a2)=0, a2 = 0, m odd: x=1 has a point  <=>  Tr(b)=1   (by brute force)
 * Output: one line per m with counts and number of violations.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

static const uint32_t POLY[] = {
  0, 0, 0,
  0xB,      /* 3: x^3+x+1 */
  0x13,     /* 4: x^4+x+1 */
  0x25,     /* 5: x^5+x^2+1 */
  0x43,     /* 6: x^6+x+1 */
  0x83,     /* 7: x^7+x+1 */
  0x11B,    /* 8: x^8+x^4+x^3+x+1 */
  0x211,    /* 9: x^9+x^4+1 */
  0x409,    /* 10: x^10+x^3+1 */
  0x805,    /* 11: x^11+x^2+1 */
  0x1053,   /* 12: x^12+x^6+x^4+x+1 */
  0x201B,   /* 13: x^13+x^4+x^3+x+1 */
  0x4443,   /* 14: x^14+x^10+x^6+x+1 */
};

static int m;
static uint32_t fpoly, qsz;

static uint32_t gmul(uint32_t a, uint32_t b) {
  uint32_t r = 0;
  while (b) {
    if (b & 1) r ^= a;
    b >>= 1;
    a <<= 1;
    if (a >> m) a ^= fpoly;
  }
  return r;
}

static int is_field(void) {
  /* x^(2^m) == x and x^(2^(m/p)) != x for primes p | m  (Rabin test for fpoly) */
  uint32_t x = 2, t = x;
  for (int i = 0; i < m; i++) t = gmul(t, t);
  if (t != x) return 0;
  for (int p = 2; p <= m; p++) {
    int prime = 1;
    for (int d = 2; d * d <= p; d++) if (p % d == 0) prime = 0;
    if (!prime || m % p) continue;
    /* gcd(x^(2^(m/p)) - x, f) must be 1: here check via brute force that no
       element of a proper subfield-degree root exists: easier, check f has no
       root-set collapse by verifying order of multiplicative closure below */
    uint32_t u = x;
    for (int i = 0; i < m / p; i++) u = gmul(u, u);
    if (u == x) return 0;
  }
  /* full check: every nonzero element has an inverse (brute force) */
  for (uint32_t a = 1; a < qsz; a++) {
    int ok = 0;
    for (uint32_t c = 1; c < qsz; c++) if (gmul(a, c) == 1) { ok = 1; break; }
    if (!ok) return 0;
  }
  return 1;
}

static int tr(uint32_t a) {
  uint32_t s = a, t = a;
  for (int i = 1; i < m; i++) { t = gmul(t, t); s ^= t; }
  if (s > 1) { fprintf(stderr, "trace not in F2\n"); exit(1); }
  return (int)s;
}

int main(int argc, char **argv) {
  int mmax = argc > 1 ? atoi(argv[1]) : 13;
  for (m = 3; m <= mmax; m++) {
    fpoly = POLY[m];
    qsz = 1u << m;
    if (!is_field()) { printf("m=%d polynomial not irreducible!\n", m); return 1; }
    uint32_t *sqx = malloc(sizeof(uint32_t) * qsz); /* x^2 */
    uint32_t *cub = malloc(sizeof(uint32_t) * qsz); /* x^3 */
    int *trv = malloc(sizeof(int) * qsz);
    for (uint32_t a = 0; a < qsz; a++) { sqx[a] = gmul(a, a); cub[a] = gmul(sqx[a], a); trv[a] = tr(a); }
    /* hist[x][v] = #{y : y^2 + x y = v} */
    uint8_t *hist = calloc((size_t)qsz * qsz, 1);
    for (uint32_t x = 0; x < qsz; x++)
      for (uint32_t y = 0; y < qsz; y++)
        hist[(size_t)x * qsz + (sqx[y] ^ gmul(x, y))]++;
    long n_tr0 = 0, n_tr1 = 0;
    long v_i = 0, v_ii = 0, v_iii = 0, v_iv = 0, n_iv = 0;
    long c8_tr0 = 0, c8_tr1 = 0, n_a2tr0 = 0;
    /* all a2 for m <= 10; for larger m: a2 = 0, 1, and the first nonzero a2 of each trace class */
    uint32_t a2list[4096]; int na2 = 0;
    if (m <= 10) { for (uint32_t a = 0; a < qsz; a++) a2list[na2++] = a; }
    else {
      a2list[na2++] = 0; a2list[na2++] = 1;
      int got0 = 0, got1 = 0;
      for (uint32_t a = 2; a < qsz && !(got0 && got1); a++) {
        if (trv[a] == 0 && !got0) { a2list[na2++] = a; got0 = 1; }
        if (trv[a] == 1 && !got1) { a2list[na2++] = a; got1 = 1; }
      }
    }
    for (int ia = 0; ia < na2; ia++) {
      uint32_t a2 = a2list[ia];
      int ta2 = trv[a2];
      uint32_t *h = malloc(sizeof(uint32_t) * qsz);
      for (uint32_t x = 0; x < qsz; x++) h[x] = cub[x] ^ gmul(a2, sqx[x]);
      for (uint32_t b = 1; b < qsz; b++) {
        long cnt = 1;
        for (uint32_t x = 0; x < qsz; x++) cnt += hist[(size_t)x * qsz + (h[x] ^ b)];
        int tb = trv[b];
        if (ta2 == 0) {
          n_a2tr0++;
          if (cnt % 4) v_i++;
          int div8 = (cnt % 8 == 0);
          if (div8 != (tb == 0)) v_ii++;
          if (tb == 0) { n_tr0++; c8_tr0 += div8; } else { n_tr1++; c8_tr1 += div8; }
          if (a2 == 0 && (m & 1)) {
            n_iv++;
            int x1 = hist[(size_t)1 * qsz + (h[1] ^ b)] > 0;
            if (x1 != (tb == 1)) v_iv++;
          }
        } else {
          if (cnt % 4 != 2) v_iii++;
        }
      }
      free(h);
    }
    printf("m=%2d  a2 values=%d  curves(Tr a2=0)=%ld  Tr(b)=0:%ld (8|#E:%ld)  Tr(b)=1:%ld (8|#E:%ld)  "
           "viol(i)=%ld viol(ii)=%ld viol(iii)=%ld  x=1-lift checks=%ld viol(iv)=%ld\n",
           m, na2, n_a2tr0, n_tr0, c8_tr0, n_tr1, c8_tr1, v_i, v_ii, v_iii, n_iv, v_iv);
    fflush(stdout);
    free(sqx); free(cub); free(trv); free(hist);
  }
  return 0;
}
