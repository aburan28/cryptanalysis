"""C4 recompute, part 4: the z-shift from the deterministic x = 1 lift.

Own recount (gf2m_own arithmetic, own trace) of C_k = #{x in V_k canon : x = 0 or
Tr(x + b/x^2) = 0} for all 263 class curves at k = 8, 10, 12; compare with the
sweep's per_curve.json count_incl_x0; recompute z_uniform (Binomial(2^k-1,1/2)
reference, det = 1) and z_TrB1 (det = 2, coins = 2^k - 2) and their difference,
versus 1/sqrt(2^k - 1).  Also counts, in the canonical V_k, pairs x1 != x2 with
x1^-2 + x2^-2 = 1 (which would make two coins perfectly anti-correlated given
Tr(b) = 1).
"""
import json, math, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf2m_own as G

TRMASK = 1 | (1 << 129)
tr = lambda a: bin(a & TRMASK).count('1') & 1
gt = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json'))
pc = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/index-calculus/per_curve.json'))
out = {}
for k in (8, 10, 12):
    lams = [(x, tr(x), G.inv(G.sqr(x))) for x in range(1, 1 << k)]
    mism = 0
    shifts = []
    zdiff_theirs = []
    for c in gt['curves']:
        b = int(c['b_int'])
        C = 1 + sum(1 for x, tx, lam in lams if tx ^ tr(G.mul(b, lam)) == 0)
        theirs = pc[c['label']]['count_incl_x0']['canon']['k%d' % k]
        if C != theirs:
            mism += 1
        zu = (C - 1 - (2 ** k - 1) / 2) / math.sqrt((2 ** k - 1) / 4)
        zc = (C - 2 - (2 ** k - 2) / 2) / math.sqrt((2 ** k - 2) / 4)
        shifts.append(zu - zc)
        if k in (8, 10, 12):
            t_u = pc[c['label']]['zscores_uniform_b_reference']['canon']['k%d' % k]
            t_c = pc[c['label']]['zscores']['canon']['k%d' % k]
            zdiff_theirs.append(t_u - t_c)
            assert abs(t_u - zu) < 1e-3 and abs(t_c - zc) < 1e-3, (c['label'], k, t_u, zu, t_c, zc)
    out['k%d' % k] = dict(count_mismatches_vs_sweep=mism,
                          one_over_sqrt=1 / math.sqrt(2 ** k - 1),
                          own_zu_minus_zc_min=min(shifts), own_zu_minus_zc_max=max(shifts),
                          sweep_zu_minus_zc_min=min(zdiff_theirs), sweep_zu_minus_zc_max=max(zdiff_theirs))
# anti-correlated pairs x^-2 + y^-2 = 1 inside canonical V_16:
# equivalent to 1/x + 1/y = 1, i.e. y = x/(x+1); check whether y lies in V_16.
K = 16
pairs = 0
for x in range(2, 1 << K):
    y = G.mul(x, G.inv(x ^ 1))
    if y < (1 << K):
        pairs += 1
out['canon_V16_pairs_with_lam_sum_1'] = pairs
json.dump(out, open(os.path.join(HERE, 'check_zshift.json'), 'w'), indent=1)
print(json.dumps(out, indent=1))
