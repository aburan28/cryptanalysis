"""Re-run the floor-vs-null KS2 permutation p-values with 50000 permutations (two seeds) to pin down
MC error, using scipy's ks_2samp statistic on a subsample of permutations as a cross-check of my
tie-aware KS2 implementation."""
import json, math, numpy as np
from scipy import stats
exec(open("stats_mine.py").read().split("per_k = {}")[0].replace("rng = np.random.default_rng(424242)", "rng = np.random.default_rng(777)"))
res = {}
for k in KS:
    zf, _, _ = cells(FLOOR, k)
    for g in "RS":
        zg, _, _ = cells(GROUPS[g], k)
        D, p1, pa = ks2_perm(zf, zg, nperm=50000, batch=1000)
        # cross-check statistic definition against scipy on 300 random permutations
        allv = np.concatenate([zf, zg]); mism = 0
        for _ in range(300):
            pv = rng.permutation(allv)
            a, b = pv[:len(zf)], pv[len(zf):]
            d_sc = stats.ks_2samp(a, b).statistic
            d_me = ks2_perm(a, b, nperm=0)[0]
            mism += abs(d_sc - d_me) > 1e-12
        res["k%d_%s" % (k, g)] = {"D": D, "p_perm50000": p1, "p_asymp": pa, "stat_mismatch_vs_scipy_300": int(mism)}
        print(k, g, res["k%d_%s" % (k, g)], flush=True)
json.dump(res, open("perm_recheck.json", "w"), indent=1)
