"""Compare my C recount (counts_mine.txt) with the sweep's raw_counts.json / raw_counts_null2.json
and per_curve.json count_incl_x0.  Writes counts_mine.json."""
import json
W = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"
C, TRB = {}, {}
for line in open("counts_mine.txt"):
    p = line.split()
    if p[0] == "TRB":
        TRB[p[1]] = int(p[2]); continue
    if p[0] == "SPOT":
        continue
    C.setdefault(p[0], {}).setdefault(p[1], {})[int(p[2])] = int(p[3])
json.dump({"counts": C, "Tr_b": TRB}, open("counts_mine.json", "w"))
r1 = json.load(open(W + "raw_counts.json"))["counts"]
r2 = json.load(open(W + "raw_counts_null2.json"))["counts"]
pc = json.load(open(W + "per_curve.json"))
theirs = dict(r1); theirs.update(r2)
cells = mism = 0
bad = []
for l, d in theirs.items():
    for s, dk in d.items():
        for k, v in dk.items():
            cells += 1
            if C[l][s][int(k)] != v:
                mism += 1; bad.append((l, s, k, v, C[l][s][int(k)]))
pcc = pcm = 0
for l, r in pc.items():
    for s, dk in r["count_incl_x0"].items():
        for kk, v in dk.items():
            pcc += 1
            if C[l][s][int(kk[1:])] != v:
                pcm += 1
cls = [l for l in C if l == "E0" or l[0] in "AB"]
print("cells compared vs raw_counts*.json:", cells, "mismatches:", mism, bad[:5])
print("cells compared vs per_curve.json count_incl_x0:", pcc, "mismatches:", pcm)
print("class curves:", len(cls), "Tr(b) values on class:", sorted(set(TRB[l] for l in cls)))
print("Tr(b) R-null counts:", {v: sum(1 for l in TRB if l[0] == 'R' and TRB[l] == v) for v in (0, 1)},
      "S-null:", {v: sum(1 for l in TRB if l[0] == 'S' and TRB[l] == v) for v in (0, 1)},
      "M:", {v: sum(1 for l in TRB if l[0] == 'M' and TRB[l] == v) for v in (0, 1)},
      "T:", {v: sum(1 for l in TRB if l[0] == 'T' and TRB[l] == v) for v in (0, 1)})
