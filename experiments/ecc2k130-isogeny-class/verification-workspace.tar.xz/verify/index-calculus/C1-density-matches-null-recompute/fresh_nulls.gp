\\ Fresh null curves y^2+xy=x^3+b (a2=0) over F_2^131, independent of the sweep's nulls.
\\ M000..M262: uniform random b;  T000..T262: uniform random b conditioned on trace(b)=1.
\\ Each point-counted with PARI ellcard; must differ from 4N and from the twist order q+1+t.
g=ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1),'z);
N=680564733841876926932320129493409985129; CARD=4*N; q=2^131; t=-22283658519494248867; TW=q+1+t;
setrand(8675309);
toint(e)=subst(e.pol,'z,2);
f=fileopen("fresh_nulls.txt","w");
cnt=0; while(cnt<263, b=random(g); if(b==0||b==1,next); n=ellcard(ellinit([1,0,0,0,b])); if(n==CARD||n==TW, print("ISOG ",toint(b)); next); filewrite(f,Str("M",if(cnt<10,"00",if(cnt<100,"0","")),cnt," ",toint(b)," ",n," ",lift(trace(b)))); cnt++);
cnt=0; while(cnt<263, b=random(g); if(b==0||b==1||trace(b)!=1,next); n=ellcard(ellinit([1,0,0,0,b])); if(n==CARD||n==TW, print("ISOG ",toint(b)); next); filewrite(f,Str("T",if(cnt<10,"00",if(cnt<100,"0","")),cnt," ",toint(b)," ",n," ",lift(trace(b)))); cnt++);
fileclose(f);
print("done");
