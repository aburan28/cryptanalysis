"""Odd k = 9, 11, 13, 15 (the claim says k = 8..16 but reports even k only): same floor tests."""
import json, numpy as np
from scipy import stats
exec(open("stats_mine.py").read().split("per_k = {}")[0].replace("rng = np.random.default_rng(424242)", "rng = np.random.default_rng(5150)"))
res = {}
for k in [9, 11, 13, 15]:
    zf, Xf, cf = cells(FLOOR, k)
    D, p = ks_mc_pvalue(zf, cf, nsim=10000)
    labs = [(l, s) for l in FLOOR for s in SUBS]
    r = {"mean": float(zf.mean()), "sd": float(zf.std(ddof=1)), "ks_D": D, "ks_p_mc": p,
         "chi2": chi2_exact_bins(Xf, cf),
         "max": [float(zf.max()), labs[int(zf.argmax())], p_max_ge(zf.max(), cf)],
         "min": [float(zf.min()), labs[int(zf.argmin())], p_min_le(zf.min(), cf)]}
    for g in "RS":
        zg, _, _ = cells(GROUPS[g], k)
        r["ks2_vs_" + g] = ks2_perm(zf, zg, nperm=5000)[1]
    zE, _, _ = cells(["E0"], k)
    r["E0_z"] = [round(float(v), 3) for v in zE]
    res[str(k)] = r
    print(k, json.dumps(r), flush=True)
json.dump(res, open("odd_k.json", "w"), indent=1)
