\\ Count x in V_k (k<=12 canon, k<=10 rand1..3) with ellordinate(E,x) nonempty, E=[1,0,0,0,b] over
\\ F_2[z]/(z^131+z^13+z^2+z+1).  Independent tool (PARI's own quadratic solver) and plain binary
\\ enumeration of coefficient vectors (no Gray code, no halftrace).
read("pari_input.gp");
g=ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1),'z);
toff(n)=subst(Pol(binary(n),'y),'y,g)+0*g;
countV(E,bas,k)={my(B=vector(k,i,toff(bas[i])),c=0,xx);for(m=0,2^k-1, xx=0*g; for(i=1,k, if(bittest(m,i-1), xx+=B[i])); if(#ellordinate(E,xx)>0,c++)); c};
cumV(E,bas,K)={my(B=vector(K,i,toff(bas[i])),cnt=vector(K+1),xx,hb);for(m=0,2^K-1, xx=0*g; for(i=1,K, if(bittest(m,i-1), xx+=B[i])); if(#ellordinate(E,xx)>0, hb=if(m==0,0,#binary(m)); cnt[hb+1]++)); vector(K,k,sum(j=1,k+1,cnt[j]))};
f=fileopen("pari_counts.txt","w");
{for(i=1,#LAB, E=ellinit([1,0,0,0,toff(BV[i])],g); if(type(E.disc)!="t_FFELT", error("not over Fq"));
  v=cumV(E,BAS_canon,12); for(k=1,12, filewrite(f,Str(LAB[i]," canon ",k," ",v[k])));
  v=cumV(E,BAS_rand1,10); for(k=1,10, filewrite(f,Str(LAB[i]," rand1 ",k," ",v[k])));
  v=cumV(E,BAS_rand2,10); for(k=1,10, filewrite(f,Str(LAB[i]," rand2 ",k," ",v[k])));
  v=cumV(E,BAS_rand3,10); for(k=1,10, filewrite(f,Str(LAB[i]," rand3 ",k," ",v[k])));
  print1(LAB[i]," "))};
fileclose(f);
E=ellinit([1,0,0,0,toff(BV[1])],g); print("\ndirect k=6 canon ",LAB[1]," ",countV(E,BAS_canon,6));
