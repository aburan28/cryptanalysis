/* Exactness check for the binomial model's second moment, conditional on Tr(b).
 * Coins for x, y (x,y not in {0,1}) are the linear forms b -> Tr(b w), w = 1/x^2.  Conditional on
 * Tr(b) (= form with w = 1), two coins are independent iff w_x, w_y, 1 are F2-independent, i.e.
 * x != y and 1/x + 1/y != 1 (i.e. y != x/(x+1)).  Coins in different subspaces are uncorrelated
 * under the same condition.  This program counts, over the union of the 4 subspaces V_16,
 * (a) pairwise intersections of the subspaces (shared x), (b) x with x/(x+1) in any V_16. */
#define main liftcount_main
#include "liftcount.c"
#undef main
static int ech_n[8]; static fe ech[8][16]; static int ech_piv[8][16];
static int topbit(fe a) { for (int w = 2; w >= 0; w--) if (a.w[w]) return 64 * w + 63 - __builtin_clzll(a.w[w]); return -1; }
static int inspace(int s, fe v) {
    for (int i = 0; i < ech_n[s]; i++) { int p = ech_piv[s][i]; if ((v.w[p >> 6] >> (p & 63)) & 1) v = fadd(v, ech[s][i]); }
    return fzero(v);
}
static void build_ech(int s) {
    ech_n[s] = 0;
    for (int i = 0; i < KMAX; i++) {
        fe v = basis[s][i];
        for (int j = 0; j < ech_n[s]; j++) { int p = ech_piv[s][j]; if ((v.w[p >> 6] >> (p & 63)) & 1) v = fadd(v, ech[s][j]); }
        if (fzero(v)) { fprintf(stderr, "dependent\n"); exit(1); }
        int p = topbit(v);
        for (int j = 0; j < ech_n[s]; j++) if ((ech[s][j].w[p >> 6] >> (p & 63)) & 1) ech[s][j] = fadd(ech[s][j], v);
        ech[s][ech_n[s]] = v; ech_piv[s][ech_n[s]] = p; ech_n[s]++;
    }
}
int main(void) {
    char buf[64];
    if (scanf("%d", &nsub) != 1) return 4;
    for (int s = 0; s < nsub; s++) { scanf("%31s", subname[s]); for (int i = 0; i < KMAX; i++) { scanf("%63s", buf); basis[s][i] = parse_hex(buf); } build_ech(s); }
    long long shared[8][8] = {{0}}, xrel[8][8] = {{0}}, total = 0;
    for (int s = 0; s < nsub; s++) {
        fe x = {{0, 0, 0}};
        for (int c = 1; c < NX; c++) {
            x = fadd(x, basis[s][__builtin_ctz(c)]);
            if (!inspace(s, x)) { fprintf(stderr, "enum bug\n"); return 1; }
            if (feq(x, fone())) continue;
            total++;
            fe y = fmul(x, finv(fadd(x, fone())));          /* x/(x+1) */
            if (!feq(fadd(finv(x), finv(y)), fone())) { fprintf(stderr, "relation bug\n"); return 1; }
            for (int t = 0; t < nsub; t++) {
                if (t != s && inspace(t, x)) shared[s][t]++;
                if (inspace(t, y)) xrel[s][t]++;
            }
        }
    }
    printf("x checked (nonzero, !=1, all 4 subspaces): %lld\n", total);
    for (int s = 0; s < nsub; s++) for (int t = 0; t < nsub; t++)
        printf("%s->%s shared_x %lld  x/(x+1)-in-target %lld\n", subname[s], subname[t], shared[s][t], xrel[s][t]);
    return 0;
}
