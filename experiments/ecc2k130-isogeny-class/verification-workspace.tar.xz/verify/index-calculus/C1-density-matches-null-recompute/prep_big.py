"""input_big.txt for liftcount from big_null.txt (same 4 subspace bases as input.txt)."""
lines = open("input.txt").read().split("\n")
nsub = int(lines[0])
head = lines[: 1 + nsub]
cur = [l.split() for l in open("big_null.txt") if l.strip()]
assert len(cur) == 26200 + 200 * 131, len(cur)
assert len(set(b for _, b in cur)) == len(cur), "duplicate b"
with open("input_big.txt", "w") as f:
    f.write("\n".join(head) + "\n%d\n" % len(cur))
    for l, b in cur:
        f.write("%s %x\n" % (l, int(b)))
print("curves", len(cur))
