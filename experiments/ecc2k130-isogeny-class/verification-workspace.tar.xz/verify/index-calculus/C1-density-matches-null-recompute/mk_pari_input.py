import json, random
W = "/Volumes/SSD990/ecdlp-hardness-work/"
gt = json.load(open(W + "ground_truth/ground_truth.json"))
r1 = json.load(open(W + "index-calculus/raw_counts.json"))
labs = [c["label"] for c in gt["curves"] if c["label"] != "E0"]
rng = random.Random(31337)
pick = ["E0"] + sorted(rng.sample(labs, 20)) + ["B019", "A001", "A114", "A052", "A060", "A126", "A017", "B011", "B014"]
seen = []
[seen.append(p) for p in pick if p not in seen]
b = {c["label"]: int(c["b_int"]) for c in gt["curves"]}
bases = {s: [int(v) for v in r1["log"]["subspace_bases"][s]] for s in ["canon", "rand1", "rand2", "rand3"]}
with open("pari_input.gp", "w") as f:
    f.write("LAB=[%s];\n" % ",".join('"%s"' % l for l in seen))
    f.write("BV=[%s];\n" % ",".join(str(b[l]) for l in seen))
    for s in bases:
        f.write("BAS_%s=[%s];\n" % (s, ",".join(str(v) for v in bases[s])))
print(seen, len(seen))
