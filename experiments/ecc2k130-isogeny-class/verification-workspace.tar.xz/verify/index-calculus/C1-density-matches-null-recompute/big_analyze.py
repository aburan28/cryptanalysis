"""Empirical calibration of the claim-C1 tests with REAL random curves (not binomial simulation).
Input: big_null.txt (PARI: U* = 26200 independent random b with Tr(b)=1, point-counted;
       O* = 200 random b with Tr(b)=1 and their full Frobenius orbits, 131 conjugates each),
       counts_big.txt (my C liftcount on them), counts_mine.json (floor), prep_out.json.
Groups of 262 curves: U-groups (independent curves), O-groups (2 full Frobenius orbits = the
floor's orbit structure).  For each group we compute exactly the floor's statistics.
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; python3 big_analyze.py
"""
import json, math
import numpy as np
from scipy import stats

rng = np.random.default_rng(99991)
KS = [8, 10, 12, 14, 16]
SUBS = ["canon", "rand1", "rand2", "rand3"]
ONE = {s: set(v) for s, v in json.load(open("prep_out.json"))["one_in_Vk"].items()}

# ---- parse big counts ----
idx, TR = {}, {}
rows = []
for line in open("counts_big.txt"):
    p = line.split()
    if p[0] == "TRB":
        TR[p[1]] = int(p[2]); continue
    if p[0] == "SPOT":
        print("spot", p[1:]); continue
    rows.append(p)
labels = list(TR)
li = {l: i for i, l in enumerate(labels)}
si = {s: i for i, s in enumerate(SUBS)}
A = np.zeros((len(labels), 4, 17), dtype=np.int64)
for l, s, k, v in rows:
    A[li[l], si[s], int(k)] = int(v)
assert all(v == 1 for v in TR.values()), "all big-null b must have Tr(b)=1"
print("curves", len(labels))

d = json.load(open("counts_mine.json"))
FLOOR = sorted(l for l in d["counts"] if l[0] in "AB" and len(l) == 4)
F = np.array([[[0] + [d["counts"][l][s][str(k)] for k in range(1, 17)] for s in SUBS] for l in FLOOR])
assert all(d["Tr_b"][l] == 1 for l in FLOOR)

DET = np.array([[1 + (1 if k in ONE[s] else 0) for k in range(17)] for s in SUBS])   # Tr(b)=1 everywhere
COINS = np.array([[(1 << k) - 1 - (1 if k in ONE[s] else 0) for k in range(17)] for s in SUBS])


def Z(cnt):  # cnt: (n, 4, 17)
    return ((cnt - DET) - COINS / 2) / np.sqrt(COINS / 4)


zF = Z(F)
zB = Z(A)
U = [[li["U%d" % (262 * g + j)] for j in range(262)] for g in range(100)]
O = [[li["O%d_%d" % (2 * g + h, i)] for h in (0, 1) for i in range(131)] for g in range(100)]


def ksphi(z):
    z = np.sort(z.ravel()); n = len(z)
    Fz = stats.norm.cdf(z); i = np.arange(1, n + 1)
    return max((i / n - Fz).max(), (Fz - (i - 1) / n).max())


# reference distribution of D under the binomial model for the floor's cell structure
REF = {}
for k in KS:
    co = np.repeat(COINS[:, k][None, :], 262, axis=0).ravel()
    Ds = []
    for _ in range(10):
        X = rng.binomial(co[None, :], 0.5, size=(2000, len(co)))
        Zs = np.sort((X - co / 2) / np.sqrt(co / 4), axis=1)
        Fz = stats.norm.cdf(Zs); n = Zs.shape[1]; i = np.arange(1, n + 1)
        Ds.append(np.maximum((i / n - Fz).max(axis=1), (Fz - (i - 1) / n).max(axis=1)))
    REF[k] = np.concatenate(Ds)


def gstats(z):  # z: (262, 4, 17)
    r = {}
    for k in KS:
        zk = z[:, :, k]
        D = ksphi(zk)
        r[k] = {"D": D, "p": float((1 + (REF[k] >= D - 1e-12).sum()) / (1 + len(REF[k]))),
                "mean": float(zk.mean()), "sd": float(zk.std(ddof=1)), "max": float(zk.max()), "min": float(zk.min())}
    r["grand"] = float(z[:, :, KS].mean())
    r["extreme_abs"] = float(np.abs(z[:, :, KS]).max())
    return r


fl = gstats(zF)
gu = [gstats(zB[g]) for g in U]
go = [gstats(zB[g]) for g in O]
out = {"floor": {str(k): v for k, v in fl.items()}}
for name, G in (("U_independent", gu), ("O_frobenius_orbits", go)):
    ent = {}
    gm = np.array([g["grand"] for g in G])
    ent["grand_mean_mean_sd"] = [float(gm.mean()), float(gm.std(ddof=1))]
    ent["frac_abs_grand_ge_floor"] = float((np.abs(gm) >= abs(fl["grand"])).mean())
    ent["frac_grand_ge_floor"] = float((gm >= fl["grand"]).mean())
    ex = np.array([g["extreme_abs"] for g in G])
    ent["extreme_abs_z_over_20cells_mean_q05_q95"] = [float(ex.mean()), float(np.quantile(ex, .05)), float(np.quantile(ex, .95))]
    ent["frac_extreme_abs_ge_floor"] = float((ex >= fl["extreme_abs"]).mean())
    for k in KS:
        ps = np.array([g[k]["p"] for g in G])
        Ds = np.array([g[k]["D"] for g in G])
        mx = np.array([g[k]["max"] for g in G]); mn = np.array([g[k]["min"] for g in G])
        sd = np.array([g[k]["sd"] for g in G])
        ent[str(k)] = {
            "binomialMC_p_uniformity_KS_p": float(stats.kstest(ps, "uniform").pvalue),
            "frac_p_lt_0.05": float((ps < 0.05).mean()), "median_p": float(np.median(ps)),
            "frac_D_ge_floor": float((Ds >= fl[k]["D"] - 1e-12).mean()),
            "frac_max_ge_floor": float((mx >= fl[k]["max"]).mean()),
            "frac_min_le_floor": float((mn <= fl[k]["min"]).mean()),
            "mean_of_max": float(mx.mean()),
            "sd_of_z_mean": float(sd.mean())}
    out[name] = ent

# ---- pooled test of the binomial shape with all 26200 independent curves (104800 cells per k) ----
allU = [i for g in U for i in g]
pool = {}
for k in KS:
    z = zB[allU][:, :, k].ravel()
    X = (A[allU][:, :, k] - DET[:, k]).ravel()
    co = np.repeat(COINS[:, k][None, :], len(allU), axis=0).ravel()
    # exact chi-square with binomial-quantile bins, separately per coins value
    chi = 0.0; df = 0
    for c in sorted(set(co.tolist())):
        x = X[co == c]
        edges = np.unique(stats.binom.ppf(np.linspace(0, 1, 21)[1:-1], c, 0.5))
        b = np.searchsorted(edges, x, side="right")
        pr = np.diff(np.concatenate([[0.0], stats.binom.cdf(edges - 1, c, 0.5), [1.0]]))
        ob = np.bincount(b, minlength=len(pr)); ex = pr * len(x)
        chi += float(((ob - ex) ** 2 / ex).sum()); df += len(pr) - 1
    u = stats.binom.cdf(X - 1, co, 0.5) + rng.random(len(X)) * stats.binom.pmf(X, co, 0.5)
    pool[str(k)] = {"n_cells": int(len(z)), "mean_z": float(z.mean()), "var_z": float(z.var(ddof=1)),
                    "se_mean": float(1 / math.sqrt(len(z))),
                    "skew": float(stats.skew(z)), "excess_kurtosis": float(stats.kurtosis(z)),
                    "chi2_20bins": [chi, df, float(stats.chi2.sf(chi, df))],
                    "randomized_PIT_KS_p": float(stats.kstest(u, "uniform").pvalue)}
out["pooled_26200_independent_curves"] = pool

# ---- Frobenius-neighbour correlation on canon: floor vs O-groups vs U-groups ----
def neigh_corr(z, orbit_pairs, k, s):
    a = np.array([z[i, si[s], k] for i, j in orbit_pairs]); b = np.array([z[j, si[s], k] for i, j in orbit_pairs])
    return float(np.corrcoef(a, b)[0, 1])


fl_pairs = []
fi = {l: i for i, l in enumerate(FLOOR)}
for orb in "AB":
    for i in range(131):
        fl_pairs.append((fi["%s%03d" % (orb, i)], fi["%s%03d" % (orb, (i + 1) % 131)]))
o_pairs = [(li["O%d_%d" % (h, i)], li["O%d_%d" % (h, (i + 1) % 131)]) for h in range(200) for i in range(131)]
u_pairs = [(allU[2 * i], allU[2 * i + 1]) for i in range(len(allU) // 2)]
nc = {}
for k in KS:
    nc[str(k)] = {s: {"floor": neigh_corr(zF, fl_pairs, k, s), "O_all_200_orbits": neigh_corr(zB, o_pairs, k, s),
                      "U_unrelated_pairs": neigh_corr(zB, u_pairs, k, s),
                      "predicted_canon": (2 ** math.ceil(k / 2) - 2) / (2 ** k - 2) if s == "canon" else 0.0}
                  for s in SUBS}
out["frobenius_neighbour_corr"] = nc
json.dump(out, open("big_analyze.json", "w"), indent=1)
print(json.dumps(out, indent=1))
