"""Independent statistics for claim C1 (density of liftable x matches the binomial model; floor
curves indistinguishable from random non-isogenous curves).  Own code; does not import or reuse
index-calculus/analyze.py.  Inputs: counts_mine.json (my C recount), prep_out.json, and optionally
big_counts.npz (empirical null of real random curves, made by big_null.py).

Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; python3 stats_mine.py
"""
import json, math, os, sys
import numpy as np
from scipy import stats

rng = np.random.default_rng(424242)          # seed unrelated to the sweep's 20260923
KS = [8, 10, 12, 14, 16]
SUBS = ["canon", "rand1", "rand2", "rand3"]
d = json.load(open("counts_mine.json"))
C, TRB = d["counts"], d["Tr_b"]
ONE = {s: set(v) for s, v in json.load(open("prep_out.json"))["one_in_Vk"].items()}
FLOOR = sorted(l for l in C if l[0] in "AB" and len(l) == 4)
assert len(FLOOR) == 262
GROUPS = {"floor": FLOOR}
for p in "RSMT":
    GROUPS[p] = sorted(l for l in C if l[0] == p)
    assert len(GROUPS[p]) == 263, p
out = {"groups": {g: len(v) for g, v in GROUPS.items()}}


def model(tr, s, k):
    one = k in ONE[s]
    return 1 + (tr if one else 0), (1 << k) - 1 - (1 if one else 0)


def zscore(cnt, tr, s, k):
    det, coins = model(tr, s, k)
    return ((cnt - det) - coins / 2) / math.sqrt(coins / 4)


def cells(labels, k):
    """z, X (=C-det), coins for all (label, subspace) at level k"""
    z, X, co = [], [], []
    for l in labels:
        for s in SUBS:
            det, coins = model(TRB[l], s, k)
            X.append(C[l][s][str(k)] - det); co.append(coins)
            z.append(zscore(C[l][s][str(k)], TRB[l], s, k))
    return np.array(z), np.array(X), np.array(co)


# ---------- KS distance of z to Phi, with correct handling of ties ----------
def ks_to_phi(z):
    z = np.sort(z)
    n = len(z)
    F = stats.norm.cdf(z)
    i = np.arange(1, n + 1)
    return float(max(np.max(i / n - F), np.max(F - (i - 1) / n)))


def ks_to_phi_batch(Z):
    Z = np.sort(Z, axis=1)
    n = Z.shape[1]
    F = stats.norm.cdf(Z)
    i = np.arange(1, n + 1)
    return np.maximum((i / n - F).max(axis=1), (F - (i - 1) / n).max(axis=1))


def ks_mc_pvalue(z, coins, nsim=20000, batch=2000):
    d0 = ks_to_phi(z)
    ge = 0
    for b0 in range(0, nsim, batch):
        Xs = rng.binomial(coins[None, :], 0.5, size=(batch, len(coins)))
        Zs = (Xs - coins / 2) / np.sqrt(coins / 4)
        ge += int((ks_to_phi_batch(Zs) >= d0 - 1e-12).sum())
    return d0, (1 + ge) / (1 + nsim)


# ---------- randomized PIT (exactly U(0,1) under Bin(coins,1/2)) ----------
def pit(X, coins, v):
    return stats.binom.cdf(X - 1, coins, 0.5) + v * stats.binom.pmf(X, coins, 0.5)


def ad_stat(u):
    u = np.clip(np.sort(u), 1e-15, 1 - 1e-15)
    n = len(u)
    i = np.arange(1, n + 1)
    return float(-n - np.mean((2 * i - 1) * (np.log(u) + np.log(1 - u[::-1]))))


AD_REF = {}


def ad_pvalue(u):
    n = len(u)
    if n not in AD_REF:
        AD_REF[n] = np.array([ad_stat(rng.random(n)) for _ in range(4000)])
    a = ad_stat(u)
    return a, float((1 + (AD_REF[n] >= a).sum()) / (1 + len(AD_REF[n])))


# ---------- exact chi-square on X for cells sharing the same coins ----------
def chi2_exact_bins(X, coins, nb=10):
    res = []
    for c in sorted(set(coins.tolist())):
        x = X[coins == c]
        # bin edges at binomial quantiles
        qs = stats.binom.ppf(np.linspace(0, 1, nb + 1)[1:-1], c, 0.5)
        edges = np.unique(qs)
        # bin j = #{edges <= x}, i.e. edges[j-1] <= x < edges[j]; P(bin) exactly from the cdf
        idx = np.searchsorted(edges, x, side="right")
        cdf_e = stats.binom.cdf(edges - 1, c, 0.5)          # P(X < edge)
        probs = np.diff(np.concatenate([[0.0], cdf_e, [1.0]]))
        obs = np.bincount(idx, minlength=len(probs))
        exp = probs * len(x)
        chi = float(((obs - exp) ** 2 / exp).sum())
        res.append((c, len(x), chi, len(probs) - 1))
    chi = sum(r[2] for r in res); df = sum(r[3] for r in res)
    return chi, df, float(stats.chi2.sf(chi, df))


# ---------- two-sample KS with ties, and permutation p ----------
def ks2_perm(a, b, nperm=10000, batch=1000):
    allv = np.concatenate([a, b])
    order = np.argsort(allv, kind="mergesort")
    sv = allv[order]
    ends = np.r_[np.nonzero(np.diff(sv))[0], len(sv) - 1]      # last index of each tie block
    na, nb = len(a), len(b)
    lab0 = np.r_[np.ones(na), np.zeros(nb)][order]

    def stat(lab):  # lab: (m, n) 1 for group a
        ca = np.cumsum(lab, axis=-1)[..., ends]
        cb = (ends + 1) - ca
        return np.abs(ca / na - cb / nb).max(axis=-1)
    d0 = float(stat(lab0[None, :])[0])
    ge = 0
    base = np.r_[np.ones(na), np.zeros(nb)]
    for _ in range(nperm // batch):
        L = np.array([rng.permutation(base) for _ in range(batch)])
        ge += int((stat(L) >= d0 - 1e-12).sum())
    return d0, (1 + ge) / (1 + nperm), float(stats.ks_2samp(a, b, method="asymp").pvalue)


# ---------- extremes ----------
def p_max_ge(zobs, coins):
    """P(max_i z_i >= zobs) for independent cells, exact binomial tails"""
    thr = np.ceil(coins / 2 + zobs * np.sqrt(coins / 4) - 1e-9)
    logq = np.log(np.clip(stats.binom.cdf(thr - 1, coins, 0.5), 1e-300, 1)).sum()
    return float(-np.expm1(logq))


def p_min_le(zobs, coins):
    thr = np.floor(coins / 2 + zobs * np.sqrt(coins / 4) + 1e-9)
    logq = np.log(np.clip(stats.binom.sf(thr, coins, 0.5), 1e-300, 1)).sum()
    return float(-np.expm1(logq))


per_k = {}
for k in KS:
    zf, Xf, cf = cells(FLOOR, k)
    ent = {"n_cells": len(zf), "mean_z": float(zf.mean()), "sd_z": float(zf.std(ddof=1))}
    D, p = ks_mc_pvalue(zf, cf)
    ent["ks_vs_binomial_D"] = D
    ent["ks_vs_binomial_p_mc20000"] = p
    ps_ks, ps_ad = [], []
    for rep in range(200):
        u = pit(Xf, cf, rng.random(len(Xf)))
        ps_ks.append(stats.kstest(u, "uniform").pvalue)
        if rep < 50:
            ps_ad.append(ad_pvalue(u)[1])
    ent["randomized_PIT_KS_p_median_q05_q95"] = [float(np.median(ps_ks)), float(np.quantile(ps_ks, .05)), float(np.quantile(ps_ks, .95))]
    ent["randomized_PIT_AD_p_median_q05_q95"] = [float(np.median(ps_ad)), float(np.quantile(ps_ad, .05)), float(np.quantile(ps_ad, .95))]
    ent["chi2_binomial_bins"] = chi2_exact_bins(Xf, cf)
    ent["sum_z2_chi2_two_sided_p"] = float(2 * min(stats.chi2.cdf((zf ** 2).sum(), len(zf)), stats.chi2.sf((zf ** 2).sum(), len(zf))))
    for g in "RSMT":
        zg, Xg, cg = cells(GROUPS[g], k)
        D2, pp, pa = ks2_perm(zf, zg)
        ent["ks2_floor_vs_" + g] = {"D": D2, "p_perm10000": pp, "p_asymp": pa}
        Dg, pg = ks_mc_pvalue(zg, cg, nsim=4000)
        ent["null_" + g + "_ks_vs_binomial_p_mc"] = pg
        ent["null_" + g + "_mean_sd"] = [float(zg.mean()), float(zg.std(ddof=1))]
    # extremes
    labs = [(l, s) for l in FLOOR for s in SUBS]
    imax, imin = int(zf.argmax()), int(zf.argmin())
    sim_max = np.array([((rng.binomial(cf, 0.5) - cf / 2) / np.sqrt(cf / 4)).max() for _ in range(5000)])
    ent["max_z"] = float(zf[imax]); ent["max_cell"] = labs[imax]
    ent["p_max_ge_obs_exact"] = p_max_ge(zf[imax], cf)
    ent["p_max_ge_obs_sim"] = float((sim_max >= zf[imax] - 1e-12).mean())
    ent["expected_max_sim"] = float(sim_max.mean())
    ent["min_z"] = float(zf[imin]); ent["min_cell"] = labs[imin]
    ent["p_min_le_obs_exact"] = p_min_le(zf[imin], cf)
    zE, _, _ = cells(["E0"], k)
    ent["E0_z"] = [float(v) for v in zE]
    per_k[str(k)] = ent
    print(k, json.dumps({kk: v for kk, v in ent.items()}), flush=True)
out["per_k"] = per_k

# ---------- grand mean over k in KS x 4 subspaces ----------
def grand(labels):
    v = [zscore(C[l][s][str(k)], TRB[l], s, k) for l in labels for s in SUBS for k in KS]
    return float(np.mean(v)), len(v)


def se_grand(nlab):
    # Cov(z_k, z_k') within one (curve, subspace), nested V_k: shared coins = coins_min -> corr sqrt(cmin/cmax)
    tot = 0.0
    for s in SUBS:
        cs = [model(1, s, k)[1] for k in KS]
        tot += sum(math.sqrt(min(a, b) / max(a, b)) for a in cs for b in cs)
    n = nlab * len(SUBS) * len(KS)
    return math.sqrt(nlab * tot) / n


gm = {}
for g, L in GROUPS.items():
    m, n = grand(L)
    se = se_grand(len(L))
    gm[g] = {"grand_mean_z": m, "n": n, "se_analytic": se, "z_of_mean": m / se}
# Frobenius-orbit correction for the floor: consecutive orbit members share V_k cap sqrt(V_k) on canon
out["grand_mean"] = gm
print("grand mean", json.dumps(gm), flush=True)

# ---------- E0 ----------
e0 = [zscore(C["E0"][s][str(k)], TRB["E0"], s, k) for k in KS for s in SUBS]
out["E0_max_abs_z_20cells"] = float(np.max(np.abs(e0)))
out["E0_z_20cells"] = e0
print("E0 max|z|", out["E0_max_abs_z_20cells"])

# ---------- per-curve Mahalanobis over its 20 cells ----------
def sigma20():
    S = np.zeros((20, 20))
    idx = [(s, k) for s in SUBS for k in KS]
    for a, (s1, k1) in enumerate(idx):
        for b, (s2, k2) in enumerate(idx):
            if s1 == s2:
                c1, c2 = model(1, s1, k1)[1], model(1, s2, k2)[1]
                S[a, b] = math.sqrt(min(c1, c2) / max(c1, c2))
    return idx, S


idx, S = sigma20()
Si = np.linalg.inv(S)
Q = {}
for l in FLOOR + ["E0"]:
    zv = np.array([zscore(C[l][s][str(k)], TRB[l], s, k) for s, k in idx])
    Q[l] = float(zv @ Si @ zv)
qf = np.array([Q[l] for l in FLOOR])
out["per_curve_mahalanobis"] = {
    "E0_Q": Q["E0"], "E0_p": float(stats.chi2.sf(Q["E0"], 20)),
    "floor_Q_mean": float(qf.mean()), "floor_Q_ks_vs_chi2_20_p": float(stats.kstest(qf, stats.chi2(20).cdf).pvalue),
    "floor_max_Q": float(qf.max()), "floor_max_Q_curve": FLOOR[int(qf.argmax())],
    "floor_max_Q_p_single": float(stats.chi2.sf(qf.max(), 20)),
    "floor_max_Q_p_bonferroni262": float(min(1, 262 * stats.chi2.sf(qf.max(), 20))),
    "floor_min_Q": float(qf.min()), "floor_min_Q_curve": FLOOR[int(qf.argmin())],
    "floor_min_Q_p_bonferroni262": float(min(1, 262 * stats.chi2.cdf(qf.min(), 20)))}
print("mahalanobis", json.dumps(out["per_curve_mahalanobis"]), flush=True)

# ---------- canonical-subspace correlation between Frobenius neighbours (structural) ----------
# C(b^2, V) = C(b, sqrt V); V_k cap sqrt(V_k) >= span{1, z, ..., z^(ceil(k/2)-1)}
out["frobenius_neighbour_overlap_note"] = {str(k): (2 ** math.ceil(k / 2) - 2) / (2 ** k - 2) for k in KS}
json.dump(out, open("stats_mine.json", "w"), indent=1)
print("wrote stats_mine.json")
