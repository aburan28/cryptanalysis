"""Build liftcount input: 4 subspace bases (read as data from the sweep's raw_counts.json log),
class curves (b from ground_truth.json), sweep nulls R*/S* (b from raw_counts*.json), fresh nulls M*/T*
(fresh_nulls.txt, PARI-generated).  Plain python3.  Also independently checks the bases are
F_2-independent and whether 1 lies in V_k (own GF(2) elimination)."""
import json
W = "/Volumes/SSD990/ecdlp-hardness-work/"
gt = json.load(open(W + "ground_truth/ground_truth.json"))
r1 = json.load(open(W + "index-calculus/raw_counts.json"))
r2 = json.load(open(W + "index-calculus/raw_counts_null2.json"))
N = 680564733841876926932320129493409985129
q = 2**131; t = -22283658519494248867
curves = [(c["label"], int(c["b_int"])) for c in gt["curves"]]
assert all(int(c["a2"]) == 0 for c in gt["curves"])
curves += [(l, int(r["b_int"])) for l, r in r1["null_curves"].items()]
curves += [(l, int(r["b_int"])) for l, r in r2["null_curves"].items()]
fresh = {}
for line in open("fresh_nulls.txt"):
    l, b, n, tr = line.split()
    b, n, tr = int(b), int(n), int(tr)
    assert n != 4 * N and n != q + 1 + t and abs(q + 1 - n) <= 2 * 2**65.5
    # #E = 4 mod 8 iff Tr(b) = 1 (no rational 8-torsion); #E = 0 mod 8 iff Tr(b) = 0
    assert n % 4 == 0 and (n % 8 == 4) == (tr == 1), (l, n % 8, tr)
    fresh[l] = {"b": b, "order": n, "tr": tr}
    curves.append((l, b))
assert len(set(b for _, b in curves)) == len(curves), "duplicate b"
bases = {s: [int(v) for v in r1["log"]["subspace_bases"][s]] for s in ["canon", "rand1", "rand2", "rand3"]}
assert bases["canon"] == [1 << i for i in range(16)]

def rank(vs):
    piv = {}
    r = 0
    for v in vs:
        while v:
            h = v.bit_length() - 1
            if h in piv:
                v ^= piv[h]
            else:
                piv[h] = v; r += 1; break
    return r
one_in = {s: [k for k in range(1, 17) if rank(bases[s][:k] + [1]) == rank(bases[s][:k])] for s in bases}
assert all(rank(bases[s]) == 16 for s in bases)
with open("input.txt", "w") as f:
    f.write("%d\n" % len(bases))
    for s, bs in bases.items():
        f.write(s + " " + " ".join("%x" % v for v in bs) + "\n")
    f.write("%d\n" % len(curves))
    for l, b in curves:
        f.write("%s %x\n" % (l, b))
json.dump({"one_in_Vk": one_in, "n_curves": len(curves),
           "fresh_tr_counts": {p: {str(v): sum(1 for l, r in fresh.items() if l[0] == p and r["tr"] == v) for v in (0, 1)} for p in "MT"}},
          open("prep_out.json", "w"), indent=1)
print(json.load(open("prep_out.json")))
