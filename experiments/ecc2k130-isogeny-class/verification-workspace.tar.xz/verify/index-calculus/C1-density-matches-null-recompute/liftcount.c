/*
 * Independent recount of liftable x on y^2 + x y = x^3 + b over F_2^131
 * (polynomial basis z^131 + z^13 + z^2 + z + 1), for x in nested subspaces V_1..V_16.
 *
 * Deliberately a different code path from index-calculus/density.py:
 *   - own GF(2^131) arithmetic (ARM PMULL carry-less multiply + own reduction),
 *     cross-checked at start-up against a bit-serial multiply;
 *   - inversion by Fermat (a^(2^131-2)), checked a * a^-1 = 1;
 *   - liftability decided by actually SOLVING the quadratic: for x != 0 put y = x w,
 *     then w^2 + w = c with c = x + b / x^2; take h = halftrace(c) (built from the
 *     definition sum_{i=0}^{65} c^(4^i)), and x is liftable iff h^2 + h == c.
 *     (No trace mask, no Hankel matrix, no BLAS.)  For a sample of lifts the full
 *     point (x, x h) is checked on the curve equation.
 *   - x = 0 is always liftable (point (0, sqrt b)).
 *   - subspace enumerated in Gray-code order (first 2^k Gray codes = V_k).
 *
 * Input  (stdin):  line 1: "NSUB"; then NSUB lines "name v0 v1 ... v15" (hex basis vectors);
 *                  then "NCURVE"; then NCURVE lines "label bhex".
 * Output (stdout): "label subspace k count" for k = 1..16, plus "TRB label tr" lines
 *                  (Tr(b) by definition sum b^(2^i)).
 * Build: clang -O3 -march=armv8.2-a+crypto -o liftcount liftcount.c -lpthread
 */
#include <arm_neon.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { uint64_t w[3]; } fe;
#define M131 ((uint64_t)7) /* bits 128..130 in w[2] */

static inline void clmul(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    poly128_t r = vmull_p64((poly64_t)a, (poly64_t)b);
    uint64x2_t v = vreinterpretq_u64_p128(r);
    *lo = vgetq_lane_u64(v, 0);
    *hi = vgetq_lane_u64(v, 1);
}
static void clmul_slow(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    uint64_t l = 0, h = 0;
    for (int i = 0; i < 64; i++)
        if ((b >> i) & 1) { l ^= a << i; if (i) h ^= a >> (64 - i); }
    *lo = l; *hi = h;
}

/* t[0..5] (degree <= 260) -> reduced fe */
static inline fe reduce6(uint64_t t[6]) {
    for (int pass = 0; pass < 2; pass++) {
        uint64_t h0 = (t[2] >> 3) | (t[3] << 61), h1 = (t[3] >> 3) | (t[4] << 61),
                 h2 = (t[4] >> 3) | (t[5] << 61), h3 = t[5] >> 3;
        t[2] &= M131; t[3] = t[4] = t[5] = 0;
        uint64_t h[4] = {h0, h1, h2, h3};
        /* t ^= h * (1 + z + z^2 + z^13) */
        const int sh[4] = {0, 1, 2, 13};
        for (int s = 0; s < 4; s++) {
            int k = sh[s];
            for (int i = 0; i < 4; i++) {
                uint64_t v = h[i];
                if (!v) continue;
                if (k == 0) { t[i] ^= v; }
                else { t[i] ^= v << k; t[i + 1] ^= v >> (64 - k); }
            }
        }
    }
    fe r = {{t[0], t[1], t[2]}};
    return r;
}
static inline fe fmul(fe a, fe b) {
    uint64_t t[6] = {0}, lo, hi;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            clmul(a.w[i], b.w[j], &lo, &hi);
            t[i + j] ^= lo; t[i + j + 1] ^= hi;
        }
    return reduce6(t);
}
static fe fmul_slow(fe a, fe b) {
    uint64_t t[6] = {0}, lo, hi;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            clmul_slow(a.w[i], b.w[j], &lo, &hi);
            t[i + j] ^= lo; t[i + j + 1] ^= hi;
        }
    return reduce6(t);
}
static inline fe fsqr(fe a) { return fmul(a, a); }
static inline fe fadd(fe a, fe b) { fe r = {{a.w[0] ^ b.w[0], a.w[1] ^ b.w[1], a.w[2] ^ b.w[2]}}; return r; }
static inline int feq(fe a, fe b) { return a.w[0] == b.w[0] && a.w[1] == b.w[1] && a.w[2] == b.w[2]; }
static inline int fzero(fe a) { return !(a.w[0] | a.w[1] | a.w[2]); }
static fe fone(void) { fe r = {{1, 0, 0}}; return r; }
static fe finv(fe a) { /* a^(2^131 - 2) = prod_{i=1}^{130} a^(2^i) */
    fe r = fone(), s = a;
    for (int i = 1; i <= 130; i++) { s = fsqr(s); r = fmul(r, s); }
    return r;
}
static int ftrace(fe a) { /* definition */
    fe s = a, acc = a;
    for (int i = 1; i < 131; i++) { s = fsqr(s); acc = fadd(acc, s); }
    /* result must be 0 or 1 */
    if (acc.w[1] || acc.w[2] || (acc.w[0] >> 1)) { fprintf(stderr, "trace not in F2!\n"); exit(2); }
    return (int)acc.w[0];
}
static fe halftrace_def(fe a) {
    fe s = a, acc = a;
    for (int i = 1; i <= 65; i++) { s = fsqr(fsqr(s)); acc = fadd(acc, s); }
    return acc;
}
static fe fe_bit(int j) { fe r = {{0, 0, 0}}; r.w[j >> 6] = (uint64_t)1 << (j & 63); return r; }

static fe HT[17][256];
static void build_ht(void) {
    fe base[136];
    for (int j = 0; j < 131; j++) base[j] = halftrace_def(fe_bit(j));
    for (int j = 131; j < 136; j++) memset(&base[j], 0, sizeof(fe));
    for (int k = 0; k < 17; k++)
        for (int v = 0; v < 256; v++) {
            fe acc = {{0, 0, 0}};
            for (int i = 0; i < 8; i++)
                if ((v >> i) & 1) acc = fadd(acc, base[8 * k + i]);
            HT[k][v] = acc;
        }
}
static inline fe halftrace(fe c) {
    fe acc = {{0, 0, 0}};
    for (int k = 0; k < 17; k++) {
        int wi = (8 * k) >> 6, sh = (8 * k) & 63;
        unsigned v = (unsigned)((c.w[wi] >> sh) & 0xff);
        acc = fadd(acc, HT[k][v]);
    }
    return acc;
}

static uint64_t hexnib(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    fprintf(stderr, "bad hex %c\n", c); exit(2);
}
static fe parse_hex(const char *s) {
    fe r = {{0, 0, 0}};
    int n = (int)strlen(s);
    for (int i = 0; i < n; i++) {
        uint64_t d = hexnib(s[n - 1 - i]);
        int bit = 4 * i;
        if (bit >= 192) { if (d) { fprintf(stderr, "too big\n"); exit(2); } continue; }
        r.w[bit >> 6] |= d << (bit & 63);
    }
    if (r.w[2] >> 3) { fprintf(stderr, "element >= 2^131\n"); exit(2); }
    return r;
}

static uint64_t rng_state = 0x243F6A8885A308D3ull;
static uint64_t rnd(void) { /* splitmix64 */
    uint64_t z = (rng_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull; z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}
static fe frand(void) { fe r = {{rnd(), rnd(), rnd() & M131}}; return r; }

#define KMAX 16
#define NX (1 << KMAX)
static int nsub, ncur;
static char subname[8][32];
static fe basis[8][KMAX];
static char label[60000][16];
static fe bcur[60000];
static fe xs[NX], ws[NX];
static int32_t (*cum)[KMAX + 1]; /* per curve: count on V_k */
static long long sample_checked = 0, sample_bad = 0;

typedef struct { int c0, c1; } job;
static void *work(void *arg) {
    job *jb = (job *)arg;
    for (int ci = jb->c0; ci < jb->c1; ci++) {
        fe b = bcur[ci];
        int32_t cnt = 1; /* x = 0 */
        cum[ci][0] = 1;  /* V_0 = {0} */
        int nextk = 1;
        for (int c = 1; c < NX; c++) {
            fe cc = fadd(xs[c], fmul(b, ws[c]));
            fe h = halftrace(cc);
            if (feq(fadd(fsqr(h), h), cc)) cnt++;
            if (c == (1 << nextk) - 1) { cum[ci][nextk] = cnt; nextk++; }
        }
    }
    return NULL;
}

int main(int argc, char **argv) {
    int nthreads = argc > 1 ? atoi(argv[1]) : 12;
    /* ---- self tests ---- */
    for (int it = 0; it < 20000; it++) {
        fe a = frand(), b = frand();
        if (!feq(fmul(a, b), fmul_slow(a, b))) { fprintf(stderr, "PMULL mismatch\n"); return 3; }
        if (!feq(fmul(a, b), fmul(b, a))) { fprintf(stderr, "noncommutative\n"); return 3; }
        fe c = frand();
        if (!feq(fmul(fmul(a, b), c), fmul(a, fmul(b, c)))) { fprintf(stderr, "nonassoc\n"); return 3; }
        if (!feq(fmul(a, fadd(b, c)), fadd(fmul(a, b), fmul(a, c)))) { fprintf(stderr, "nondistrib\n"); return 3; }
    }
    /* z^131 = z^13 + z^2 + z + 1 */
    { fe z = fe_bit(1), p = fone(); for (int i = 0; i < 131; i++) p = fmul(p, z);
      fe e = fadd(fadd(fe_bit(13), fe_bit(2)), fadd(fe_bit(1), fone()));
      if (!feq(p, e)) { fprintf(stderr, "z^131 wrong\n"); return 3; } }
    /* Frobenius has order 131: a^(2^131) = a */
    for (int it = 0; it < 50; it++) { fe a = frand(), s = a; for (int i = 0; i < 131; i++) s = fsqr(s);
      if (!feq(s, a)) { fprintf(stderr, "a^(2^131) != a\n"); return 3; } }
    for (int it = 0; it < 200; it++) { fe a = frand(); if (fzero(a)) continue;
      if (!feq(fmul(a, finv(a)), fone())) { fprintf(stderr, "inv wrong\n"); return 3; } }
    build_ht();
    int tr1 = ftrace(fone());
    fprintf(stderr, "selftest ok; Tr(1)=%d\n", tr1);
    /* halftrace identity h^2+h = c + Tr(c) on random c (table vs definition) */
    for (int it = 0; it < 2000; it++) { fe c = frand(); fe h = halftrace(c);
      if (!feq(h, halftrace_def(c))) { fprintf(stderr, "HT table mismatch\n"); return 3; }
      fe l = fadd(fsqr(h), h); int t = ftrace(c);
      fe rhs = t ? fadd(c, fone()) : c;
      if (!feq(l, rhs)) { fprintf(stderr, "HT identity fails\n"); return 3; } }

    /* ---- input ---- */
    char buf[64];
    if (scanf("%d", &nsub) != 1) return 4;
    for (int s = 0; s < nsub; s++) {
        if (scanf("%31s", subname[s]) != 1) return 4;
        for (int i = 0; i < KMAX; i++) { if (scanf("%63s", buf) != 1) return 4; basis[s][i] = parse_hex(buf); }
    }
    if (scanf("%d", &ncur) != 1) return 4;
    for (int c = 0; c < ncur; c++) {
        if (scanf("%15s %63s", label[c], buf) != 2) return 4;
        bcur[c] = parse_hex(buf);
    }
    for (int c = 0; c < ncur; c++) printf("TRB %s %d\n", label[c], ftrace(bcur[c]));
    cum = malloc(sizeof(*cum) * ncur);
    for (int s = 0; s < nsub; s++) {
        /* Gray-code walk: step c toggles basis[ctz(c)]; after steps 0..2^k-1 exactly V_k seen */
        xs[0] = (fe){{0, 0, 0}};
        for (int c = 1; c < NX; c++) xs[c] = fadd(xs[c - 1], basis[s][__builtin_ctz(c)]);
        /* sanity: all distinct nonzero (basis independent) -> checked via sort-free hash */
        for (int c = 1; c < NX; c++) {
            if (fzero(xs[c])) { fprintf(stderr, "dependent basis %s\n", subname[s]); return 5; }
            fe ix = finv(xs[c]);
            ws[c] = fsqr(ix);
            if (!feq(fmul(ws[c], fsqr(xs[c])), fone())) { fprintf(stderr, "w wrong\n"); return 5; }
        }
        pthread_t th[64]; job jb[64];
        int per = (ncur + nthreads - 1) / nthreads;
        for (int t = 0; t < nthreads; t++) {
            jb[t].c0 = t * per; jb[t].c1 = (t + 1) * per < ncur ? (t + 1) * per : ncur;
            if (jb[t].c0 > ncur) jb[t].c0 = ncur;
            pthread_create(&th[t], NULL, work, &jb[t]);
        }
        for (int t = 0; t < nthreads; t++) pthread_join(th[t], NULL);
        for (int c = 0; c < ncur; c++)
            for (int k = 1; k <= KMAX; k++) printf("%s %s %d %d\n", label[c], subname[s], k, cum[c][k]);
        /* full-point spot check: 20000 random (x, curve) pairs; if lift, (x, x h) on curve;
           if not, Tr(c) (definition) must be 1 */
        for (int it = 0; it < 20000; it++) {
            int c = 1 + (int)(rnd() % (NX - 1)), ci = (int)(rnd() % ncur);
            fe x = xs[c], b = bcur[ci];
            fe cc = fadd(x, fmul(b, ws[c]));
            fe h = halftrace(cc);
            int lift = feq(fadd(fsqr(h), h), cc);
            sample_checked++;
            if (lift) {
                fe y = fmul(x, h);
                fe lhs = fadd(fsqr(y), fmul(x, y));
                fe rhs = fadd(fmul(fsqr(x), x), b);
                if (!feq(lhs, rhs)) sample_bad++;
            } else {
                if (ftrace(cc) != 1) sample_bad++;
            }
        }
        fprintf(stderr, "subspace %s done\n", subname[s]);
    }
    fprintf(stderr, "spot checks %lld bad %lld\n", sample_checked, sample_bad);
    printf("SPOT %lld %lld\n", sample_checked, sample_bad);
    return sample_bad ? 6 : 0;
}
