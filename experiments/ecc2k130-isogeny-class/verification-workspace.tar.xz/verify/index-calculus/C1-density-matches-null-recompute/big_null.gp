\\ Large empirical null for calibrating the binomial model with REAL curves (a2=0, Tr(b)=1 like the class).
\\ U-set: 100 groups x 262 independent random b, each point-counted (order != 4N, != q+1+t, = 4 mod 8).
\\ O-set: 100 groups, each = the two full Frobenius orbits {b^(2^i)} of 2 random b (orbit structure of the floor);
\\        the base b of each orbit is point-counted (conjugates have the same order).
g=ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1),'z);
N=680564733841876926932320129493409985129; CARD=4*N; q=2^131; t=-22283658519494248867; TW=q+1+t;
toint(e)=subst(e.pol,'z,2);
setrand(1729);
f=fileopen("big_null.txt","w");
bad=0; cnt=0;
{while(cnt<26200, b=random(g); if(b==0||b==1||trace(b)!=1,next);
  n=ellcard(ellinit([1,0,0,0,b],g)); if(n==CARD||n==TW, bad++; next); if(n%8!=4, error("mod8"));
  filewrite(f,Str("U",cnt," ",toint(b))); cnt++)};
cnt=0;
{while(cnt<200, b=random(g); if(b==0||b==1||trace(b)!=1,next);
  n=ellcard(ellinit([1,0,0,0,b],g)); if(n==CARD||n==TW, bad++; next); if(n%8!=4, error("mod8"));
  if(poldegree(minpoly(b))!=131, error("deg"));
  for(i=0,130, filewrite(f,Str("O",cnt,"_",i," ",toint(b^(2^i))))); cnt++)};
fileclose(f);
print("excluded isogenous: ",bad);
