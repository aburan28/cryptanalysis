"""Grand-mean SE for the floor including the structural Frobenius-orbit covariance on the canonical
subspace: C(b^(2^m), V) = C(b, V^(1/2^m)), and V_k cap V_k'^(1/2^m) contains span{z^j : j < k, 2^m j < k'}
(x=0 and x=1 are deterministic and excluded from the coins).  Distances m and -m within an orbit of 131."""
import math
KS = [8, 10, 12, 14, 16]
SUBS = 4
def coins(k, canon): return 2 ** k - 2 if canon else 2 ** k - 1
nlab, n = 262, 262 * 4 * 5
base = 0.0
for canon in (True, False, False, False):
    base += sum(math.sqrt(min(coins(a, canon), coins(b, canon)) / max(coins(a, canon), coins(b, canon))) for a in KS for b in KS)
var0 = nlab * base / n ** 2
extra = 0.0
for m in range(1, 8):          # orbit distance m: A_i vs A_{i+m}; C(A_{i+m}, V_k') = C(A_i, V_k'^(1/2^m))
    for a in KS:
        for b in KS:
            dim = len([j for j in range(a) if (2 ** m) * j < b])      # shared basis monomials z^j
            shared = 2 ** dim - 2 if dim >= 1 else 0
            cov = max(shared, 0) / math.sqrt(coins(a, True) * coins(b, True))
            extra += 2 * nlab * cov     # ordered pairs (i, i+m) and (i, i-m) over both orbits
var1 = var0 + extra / n ** 2
print("SE analytic (independent curves): %.5f" % math.sqrt(var0))
print("SE with Frobenius-orbit covariance on canon: %.5f" % math.sqrt(var1))
print("floor grand mean 0.032053 -> z = %.3f (indep) / %.3f (orbit-corrected)" % (0.03205311711819977 / math.sqrt(var0), 0.03205311711819977 / math.sqrt(var1)))
