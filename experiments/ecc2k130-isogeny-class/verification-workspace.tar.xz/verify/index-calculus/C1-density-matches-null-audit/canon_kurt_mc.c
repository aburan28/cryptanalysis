/* Monte Carlo check of the exact canonical-subspace moments (canon_moments.c):
 * draw b uniform with Tr(b) = 1 (like every class curve), count liftable x in the canonical V_k and in
 * the sweep's rand1 V_k (control; predicted binomial), accumulate skewness / excess kurtosis of
 * X = C - det.  Tr(b w) evaluated as parity(w & M_b), M_b[j] = Tr(b z^j) (validated against direct
 * multiplication on the first 50 b). */
#include <math.h>
#include "gf131.h"
#define NB_DRAWS 4000000
#include <stdlib.h>
/* b drawn with arc4random_buf (ChaCha20): a GF(2)-linear generator such as xorshift would put all b
   in a <=64-dim F_2-subspace and bias every statistic of linear functionals Tr(b w). */
static fe crand(void) { fe r; arc4random_buf(r.w, sizeof r.w); r.w[2] &= 7ULL; return r; }
int main(int argc, char **argv) {
    fe one = {{1, 0, 0}}, zz = {{2, 0, 0}};
    fe zp = one; TMASK = (fe){{0, 0, 0}};
    for (int j = 0; j < 131; j++) { if (ftrace_slow(zp)) TMASK.w[j / 64] |= 1ULL << (j % 64); zp = fmul(zp, zz); }
    /* canonical basis z^0..z^15 and rand1 basis from argv[1] (16 hex numbers in a file) */
    fe bas[2][16];
    for (int i = 0; i < 16; i++) { bas[0][i] = (fe){{0,0,0}}; bas[0][i].w[i / 64] = 1ULL << (i % 64); }
    FILE *f = fopen(argv[1], "r"); char hex[64];
    for (int i = 0; i < 16; i++) { if (fscanf(f, "%63s", hex) != 1) return 2; bas[1][i] = from_hex(hex); }
    fclose(f);
    int KM = 12, NX = 1 << KM;
    static fe W[2][1 << 12]; static int trx[2][1 << 12]; static int isone[2][1 << 12];
    for (int s = 0; s < 2; s++)
        for (int c = 0; c < NX; c++) {
            fe x = {{0, 0, 0}};
            for (int i = 0; i < KM; i++) if ((c >> i) & 1) x = fadd(x, bas[s][i]);
            if (c) W[s][c] = fsqr(finv(x));
            trx[s][c] = ftrace(x);
            isone[s][c] = feq(x, one);
        }
    int ks[3] = {8, 10, 12};
    double m[2][3][5]; memset(m, 0, sizeof m);
    long tail3[2][3], tail35[2][3], tailmin416[2][3]; memset(tail3, 0, sizeof tail3); memset(tail35, 0, sizeof tail35); memset(tailmin416, 0, sizeof tailmin416);  /* sums of X^p, p = 0..4, of centred S = 2X - n */
    rng_state = 0x1234567899ULL;
    for (long it = 0; it < NB_DRAWS; it++) {
        fe b;
        do { b = crand(); } while (ftrace(b) != 1);
        fe Mb = {{0, 0, 0}}, zj = one;
        for (int j = 0; j < 131; j++) { if (ftrace(fmul(b, zj))) Mb.w[j / 64] |= 1ULL << (j % 64); zj = fmul(zj, zz); }
        for (int s = 0; s < 2; s++) {
            int X = 0, ki = 0, n = 0;
            for (int c = 1; c < NX; c++) {
                if (!isone[s][c]) {
                    int tb = (__builtin_popcountll(W[s][c].w[0] & Mb.w[0]) + __builtin_popcountll(W[s][c].w[1] & Mb.w[1]) +
                              __builtin_popcountll(W[s][c].w[2] & Mb.w[2])) & 1;
                    if (it < 50 && tb != ftrace(fmul(b, W[s][c]))) { fprintf(stderr, "bilinear mismatch\n"); return 3; }
                    X += ((trx[s][c] ^ tb) == 0);
                    n++;
                }
                if (c == (1 << ks[ki]) - 1) {
                    double S = 2.0 * X - n, p = 1;
                    for (int q = 0; q < 5; q++) { m[s][ki][q] += p; p *= S; }
                    double zz_ = S / sqrt((double)n);
                    tail3[s][ki] += fabs(zz_) > 3; tail35[s][ki] += fabs(zz_) > 3.5; tailmin416[s][ki] += zz_ <= -4.157;
                    ki++;
                    if (ki == 3) break;
                }
            }
        }
    }
    const char *nm[2] = {"canon", "rand1"};
    for (int s = 0; s < 2; s++)
        for (int ki = 0; ki < 3; ki++) {
            int n = (1 << ks[ki]) - 1 - (s == 0 ? 1 : 0);
            double N = m[s][ki][0], mu1 = m[s][ki][1] / N, mu2 = m[s][ki][2] / N, mu3 = m[s][ki][3] / N, mu4 = m[s][ki][4] / N;
            /* raw moments of S (model mean 0, var n) */
            printf("%s k=%d n=%d draws=%.0f  E[S]/sqrt(n)=%+.4f  Var/n=%.4f  E[S^3]/n^1.5=%+.4f  E[S^4]/n^2-3=%+.4f  (binomial: -2/n=%+.4f)\n",
                   nm[s], ks[ki], n, N, mu1 / sqrt(n), mu2 / n, mu3 / pow(n, 1.5), mu4 / ((double)n * n) - 3.0, -2.0 / n);
            printf("    P(|z|>3)=%.6f  P(|z|>3.5)=%.6f  P(z<=-4.157)=%.2e\n", tail3[s][ki] / N, tail35[s][ki] / N, tailmin416[s][ki] / N);
        }
    return 0;
}
