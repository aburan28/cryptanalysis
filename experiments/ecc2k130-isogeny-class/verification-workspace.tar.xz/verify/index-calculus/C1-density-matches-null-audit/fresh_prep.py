# Fresh-subspace replication inputs: 64 random 16-dim nested subspaces from a seed fixed before any
# fresh count was seen (string seed "C1-audit-fresh-2026-09-23"), same 789 curves as inputs.txt.
import random
OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C1-density-matches-null-audit:/"
NB, KMAX, NS = 131, 16, 64


def rank2(vs):
    piv, r = {}, 0
    for v in vs:
        while v:
            h = v.bit_length() - 1
            if h in piv:
                v ^= piv[h]
            else:
                piv[h] = v
                r += 1
                break
    return r


rng = random.Random("C1-audit-fresh-2026-09-23")
lines = open(OUT + "inputs.txt").read().splitlines()
nc = int(lines[0].split()[0])
curves = lines[1:1 + nc]
subs = []
for i in range(NS):
    while True:
        B = [rng.getrandbits(NB) for _ in range(KMAX)]
        if rank2(B) == KMAX and rank2(B + [1]) == KMAX + 1:   # full rank and 1 not in V_16
            break
    subs.append(("f%02d" % i) + " " + " ".join("%033x" % v for v in B))
with open(OUT + "inputs_fresh.txt", "w") as f:
    f.write("%d %d\n" % (nc, NS))
    f.write("\n".join(curves) + "\n")
    f.write("\n".join(subs) + "\n")
print("wrote", nc, "curves,", NS, "subspaces")
