# Third method: PARI ellordinate (actual root finding of the curve equation in y) on
# ellinit([1,0,0,0,b], ffgen(z^131+z^13+z^2+z+1)); plus PARI ellcard of every null curve.
# Run: sage -python pari_check.py
import json, random, time
from sage.all import pari
OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C1-density-matches-null-audit:/"
IC = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"
GT = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
raw = json.load(open(IC + "raw_counts.json"))
raw2 = json.load(open(IC + "raw_counts_null2.json"))
per = json.load(open(IC + "per_curve.json"))
t0 = time.time()
pari.allocatemem(2 * 10**9)
g = pari("ffgen(Mod(1,2)*(z^131+z^13+z^2+z+1), 'z)")
MOD = int(GT["meta"]["modulus_int"])
assert MOD == (1 << 131) | (1 << 13) | 7
N = int(GT["meta"]["N"]); CARD = int(GT["meta"]["card"]); TW = int(GT["meta"]["twist_card"])


# faster: build from bit list via polynomial in g
gp_elt = pari("(v, g) -> my(s = 0*g, p = 1 + 0*g); while(v, if(bitand(v, 1), s += p); p *= g; v >>= 1); s")
gp_cnt = pari("(E, xs) -> my(c = 0); for(i = 1, #xs, if(#ellordinate(E, xs[i]) > 0, c++)); c")
B = {c["label"]: int(c["b_int"]) for c in GT["curves"]}
B.update({l: int(r["b_int"]) for l, r in raw["null_curves"].items()})
B.update({l: int(r["b_int"]) for l, r in raw2["null_curves"].items()})
bases = {s: [int(v) for v in raw["log"]["subspace_bases"][s]] for s in raw["meta"]["subspaces"]}

rng = random.Random(424242)
floor = [c["label"] for c in GT["curves"] if c["label"] != "E0"]
labels = ["E0", "A000", "B000", "B019", "A001", "A114", "A052", "A060", "A126", "B011", "B014", "A017"]
labels += rng.sample([l for l in floor if l not in labels], 10)
labels += rng.sample(raw["meta"]["null_labels"], 3) + rng.sample(raw2["meta"]["labels"], 3)
res = {"labels": labels, "rows": []}
for s, kmax in (("canon", 12), ("rand1", 10), ("rand3", 10)):
    xs = [0] * (1 << kmax)
    for c in range(1, 1 << kmax):
        low = (c & -c).bit_length() - 1
        xs[c] = xs[c & (c - 1)] ^ bases[s][low]
    xe = [gp_elt(v, g) for v in xs]
    for l in labels:
        E = pari.ellinit([1, 0, 0, 0, gp_elt(B[l], g)], g)
        cnts = {}
        # nested counts k = 6..kmax
        for k in range(6, kmax + 1):
            cnts[k] = int(gp_cnt(E, pari(xe[: 1 << k])))
        ref = raw["counts"].get(l, raw2["counts"].get(l))[s]
        row = {"curve": l, "subspace": s, "pari_counts": cnts,
               "sweep_counts": {k: ref[str(k)] for k in cnts},
               "match": all(cnts[k] == ref[str(k)] for k in cnts)}
        if l in per and s == "canon":
            row["per_curve_json_match"] = all(per[l]["count_incl_x0"]["canon"]["k%d" % k] == cnts[k]
                                              for k in cnts if k >= 8)
        res["rows"].append(row)
    print(s, "done %.1fs" % (time.time() - t0), flush=True)
res["all_match"] = all(r["match"] for r in res["rows"])
res["n_rows"] = len(res["rows"])

# group orders of every null curve (non-isogeny to E0) and a few class curves
orders = {}
for l in raw["meta"]["null_labels"] + raw2["meta"]["labels"] + ["E0", "A000", "B000", "B019"]:
    E = pari.ellinit([1, 0, 0, 0, gp_elt(B[l], g)], g)
    orders[l] = int(pari.ellcard(E))
nulls = raw["meta"]["null_labels"] + raw2["meta"]["labels"]
res["null_orders"] = {"n": len(nulls), "eq_4N": sum(orders[l] == CARD for l in nulls),
                      "eq_twist": sum(orders[l] == TW for l in nulls),
                      "distinct": len(set(orders[l] for l in nulls)),
                      "null2_mod8_4": all(orders[l] % 8 == 4 for l in raw2["meta"]["labels"]),
                      "null1_mod8_hist": {str(m): sum(orders[l] % 8 == m for l in raw["meta"]["null_labels"]) for m in range(8)},
                      "match_sweep_recorded": all(orders[l] == int((raw["null_curves"].get(l) or raw2["null_curves"][l])["order_pari"]) for l in nulls)}
res["class_orders_eq_4N"] = {l: orders[l] == CARD for l in ["E0", "A000", "B000", "B019"]}
res["elapsed_s"] = time.time() - t0
json.dump(res, open(OUT + "pari_check.json", "w"), indent=1)
print(json.dumps({k: v for k, v in res.items() if k != "rows"}, indent=1))
print("rows:", res["n_rows"], "all_match:", res["all_match"])
