/* Independent recount of liftable x in nested subspaces for y^2 + xy = x^3 + b over
 * F_2[z]/(z^131 + z^13 + z^2 + z + 1).  Own field arithmetic (ARM PMULL), own inversion
 * (Fermat, x^(2^131-2)), own trace (sum of 131 Frobenius powers, used to build a trace mask
 * which is then cross-checked against direct Frobenius-sum traces on random elements).
 * For every (curve, x) pair the product b * (1/x)^2 is computed directly (no bilinear trick).
 * x in V is liftable iff x == 0 or Tr(x + b/x^2) == 0.
 * Output: label subspace C_1 ... C_16  (C_k = #liftable x among the first 2^k enumerated x).
 */
#include <arm_neon.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { uint64_t w[3]; } fe; /* bits 0..130 */

static inline void clmul64(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    poly128_t r = vmull_p64((poly64_t)a, (poly64_t)b);
    uint64x2_t v = vreinterpretq_u64_p128(r);
    *lo = vgetq_lane_u64(v, 0);
    *hi = vgetq_lane_u64(v, 1);
}

/* reduce 6-word product (bits 0..260) mod z^131+z^13+z^2+z+1 */
static inline fe reduce(uint64_t c[6]) {
    /* H = c >> 131 : bits 131..383 -> up to 3 words */
    for (int pass = 0; pass < 2; pass++) {
        uint64_t h[3];
        /* bit 131 = word 2 bit 3 */
        h[0] = (c[2] >> 3) | (c[3] << 61);
        h[1] = (c[3] >> 3) | (c[4] << 61);
        h[2] = (c[4] >> 3) | (c[5] << 61);
        uint64_t hh = c[5] >> 3; /* should be 0 */
        if (hh) { fprintf(stderr, "reduce overflow\n"); exit(2); }
        c[2] &= 7ULL; c[3] = c[4] = c[5] = 0;
        /* c ^= H * (1 + z + z^2 + z^13) ; H < 2^130 so result < 2^143 */
        uint64_t t[4] = {0, 0, 0, 0};
        int sh[4] = {0, 1, 2, 13};
        for (int s = 0; s < 4; s++) {
            int k = sh[s];
            if (k == 0) { t[0] ^= h[0]; t[1] ^= h[1]; t[2] ^= h[2]; }
            else {
                t[0] ^= h[0] << k;
                t[1] ^= (h[1] << k) | (h[0] >> (64 - k));
                t[2] ^= (h[2] << k) | (h[1] >> (64 - k));
                t[3] ^= (h[2] >> (64 - k));
            }
        }
        c[0] ^= t[0]; c[1] ^= t[1]; c[2] ^= t[2]; c[3] ^= t[3];
        if (!(c[2] >> 3) && !c[3]) break;
    }
    if ((c[2] >> 3) || c[3] || c[4] || c[5]) { fprintf(stderr, "reduce incomplete\n"); exit(3); }
    fe r = {{c[0], c[1], c[2]}};
    return r;
}

static inline fe fmul(fe a, fe b) {
    uint64_t c[6] = {0, 0, 0, 0, 0, 0};
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            uint64_t lo, hi;
            clmul64(a.w[i], b.w[j], &lo, &hi);
            c[i + j] ^= lo;
            c[i + j + 1] ^= hi;
        }
    return reduce(c);
}
static inline fe fsqr(fe a) { return fmul(a, a); }
static inline int fzero(fe a) { return !(a.w[0] | a.w[1] | a.w[2]); }
static inline int feq(fe a, fe b) { return a.w[0] == b.w[0] && a.w[1] == b.w[1] && a.w[2] == b.w[2]; }
static inline fe fadd(fe a, fe b) { fe r = {{a.w[0] ^ b.w[0], a.w[1] ^ b.w[1], a.w[2] ^ b.w[2]}}; return r; }

static fe finv(fe a) { /* a^(2^131 - 2) = (a^(2^130-1))^2 via square-and-multiply chain */
    fe r = a;               /* a^(2^1 - 1) */
    for (int i = 1; i < 130; i++) { r = fsqr(r); r = fmul(r, a); } /* a^(2^(i+1)-1) */
    return fsqr(r);         /* a^(2^131 - 2) */
}
static int ftrace_slow(fe a) {
    fe s = a, t = a;
    for (int i = 1; i < 131; i++) { t = fsqr(t); s = fadd(s, t); }
    /* s must be 0 or 1 */
    if (s.w[1] || s.w[2] || (s.w[0] >> 1)) { fprintf(stderr, "trace not in F2\n"); exit(4); }
    return (int)s.w[0];
}
static fe TMASK;
static inline int ftrace(fe a) {
    return (__builtin_popcountll(a.w[0] & TMASK.w[0]) + __builtin_popcountll(a.w[1] & TMASK.w[1]) +
            __builtin_popcountll(a.w[2] & TMASK.w[2])) & 1;
}

static fe from_hex(const char *s) {
    fe r = {{0, 0, 0}};
    size_t n = strlen(s);
    for (size_t i = 0; i < n; i++) {
        char ch = s[n - 1 - i];
        int v = (ch >= '0' && ch <= '9') ? ch - '0' : (ch >= 'a' && ch <= 'f') ? ch - 'a' + 10 : -1;
        if (v < 0) { fprintf(stderr, "bad hex\n"); exit(5); }
        size_t bit = 4 * i;
        for (int k = 0; k < 4; k++)
            if ((v >> k) & 1) {
                size_t bb = bit + k;
                if (bb >= 131) { fprintf(stderr, "hex too large\n"); exit(6); }
                r.w[bb / 64] |= 1ULL << (bb % 64);
            }
    }
    return r;
}
static uint64_t rng_state = 88172645463325252ULL;
static uint64_t xs64(void) { rng_state ^= rng_state << 13; rng_state ^= rng_state >> 7; rng_state ^= rng_state << 17; return rng_state; }
static fe frand(void) { fe r = {{xs64(), xs64(), xs64() & 7ULL}}; return r; }

#define KMAX 16
#define NX (1 << KMAX)

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: recount inputs.txt out.txt\n"); return 1; }
    /* ---- self tests ---- */
    fe one = {{1, 0, 0}}, zz = {{2, 0, 0}};
    fe fr = zz;
    for (int i = 0; i < 131; i++) fr = fsqr(fr);
    if (!feq(fr, zz)) { fprintf(stderr, "z^(2^131) != z\n"); return 7; }
    for (int i = 0; i < 200; i++) {
        fe a = frand(), b = frand(), c = frand();
        if (fzero(a)) continue;
        if (!feq(fmul(a, finv(a)), one)) { fprintf(stderr, "inverse fail\n"); return 8; }
        if (!feq(fmul(a, fadd(b, c)), fadd(fmul(a, b), fmul(a, c)))) { fprintf(stderr, "distrib fail\n"); return 9; }
        if (!feq(fmul(fmul(a, b), c), fmul(a, fmul(b, c)))) { fprintf(stderr, "assoc fail\n"); return 10; }
    }
    /* trace mask from slow traces of z^j */
    fe zp = one;
    TMASK = (fe){{0, 0, 0}};
    int ntm = 0;
    for (int j = 0; j < 131; j++) {
        if (ftrace_slow(zp)) { TMASK.w[j / 64] |= 1ULL << (j % 64); ntm++; }
        zp = fmul(zp, zz);
    }
    for (int i = 0; i < 2000; i++) {
        fe a = frand();
        if (ftrace(a) != ftrace_slow(a)) { fprintf(stderr, "trace mask fail\n"); return 11; }
    }
    fprintf(stderr, "self-tests ok; trace mask popcount %d; bits:", ntm);
    for (int j = 0; j < 131; j++) if ((TMASK.w[j / 64] >> (j % 64)) & 1) fprintf(stderr, " %d", j);
    fprintf(stderr, "\n");

    FILE *f = fopen(argv[1], "r");
    int nc, ns;
    if (fscanf(f, "%d %d", &nc, &ns) != 2) return 12;
    char (*lab)[16] = malloc(nc * 16);
    fe *B = malloc(nc * sizeof(fe));
    char hex[64];
    for (int i = 0; i < nc; i++) { if (fscanf(f, "%15s %63s", lab[i], hex) != 2) return 13; B[i] = from_hex(hex); }
    char (*sname)[16] = malloc(ns * 16);
    fe (*basis)[KMAX] = malloc(ns * sizeof(fe[KMAX]));
    for (int s = 0; s < ns; s++) {
        if (fscanf(f, "%15s", sname[s]) != 1) return 14;
        for (int i = 0; i < KMAX; i++) { if (fscanf(f, "%63s", hex) != 1) return 15; basis[s][i] = from_hex(hex); }
    }
    fclose(f);
    FILE *o = fopen(argv[2], "w");
    /* trace of b for every curve (slow trace, independent of the mask) */
    for (int i = 0; i < nc; i++) fprintf(o, "TRB %s %d\n", lab[i], ftrace_slow(B[i]));
    fe *X = malloc(NX * sizeof(fe)), *W = malloc(NX * sizeof(fe));
    int *trx = malloc(NX * sizeof(int));
    for (int s = 0; s < ns; s++) {
        for (int c = 0; c < NX; c++) {
            fe x = {{0, 0, 0}};
            for (int i = 0; i < KMAX; i++) if ((c >> i) & 1) x = fadd(x, basis[s][i]);
            X[c] = x;
            if (c && fzero(x)) { fprintf(stderr, "basis dependent\n"); return 16; }
            if (c) { fe ix = finv(x); W[c] = fsqr(ix); }
            trx[c] = ftrace(x);
        }
        for (int i = 0; i < nc; i++) {
            int cum = 0;
            int C[KMAX + 1];
            for (int c = 0; c < NX; c++) {
                int lift = (c == 0) ? 1 : ((trx[c] ^ ftrace(fmul(B[i], W[c]))) == 0);
                cum += lift;
                for (int k = 1; k <= KMAX; k++) if (c == (1 << k) - 1) C[k] = cum;
            }
            fprintf(o, "CNT %s %s", lab[i], sname[s]);
            for (int k = 1; k <= KMAX; k++) fprintf(o, " %d", C[k]);
            fprintf(o, "\n");
        }
        fprintf(stderr, "subspace %s done\n", sname[s]);
    }
    fclose(o);
    return 0;
}
