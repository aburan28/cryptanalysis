"""Independent statistics for claim C1 from the independently recounted counts (counts_c.json,
produced by recount.c, which reproduced every sweep count exactly).

Model (re-derived): x in V liftable on y^2+xy=x^3+b  <=>  x = 0 or Tr(x + b/x^2) = 0.
x = 0 always counts; x = 1 (if in V) counts iff Tr(b) = 1 (Tr(1) = 1, n odd).  Other x: coin
c_x = [Tr(x) + Tr(b w_x) = 0], w_x = x^-2, fair and pairwise independent over uniform b
(given Tr(b)) as long as no w_x + w_y = 1 with x,y in V (checked in theory_checks).
Tests (all written from scratch here):
  T1 pooled KS vs Phi, p by Monte Carlo of independent exact binomials (as the sweep did)
  T2 randomized-PIT u = F(X-1) + V f(X) (exactly U(0,1) under the binomial); KS + Anderson-Darling
     vs U(0,1); median p over 101 randomisations
  T3 floor vs null1 / null2: two-sample KS and AD, permutation at the CURVE level (a curve's
     4 subspace cells stay together)
  T4 grand mean of z over floor x 4 subspaces x k in {8,..,16 even}, SE analytic (nested cov)
     and by simulation
  T5 per-k floor max z and min z with exact binomial tail product
  T6 |z| > 3 exceedance count, MC of the nested exact binomial model
"""
import json, math
import numpy as np
from scipy import stats

OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C1-density-matches-null-audit:/"
IC = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"
d = json.load(open(OUT + "counts_c.json"))
CNT, TRB = d["counts"], d["trb"]
raw = json.load(open(IC + "raw_counts.json"))
raw2 = json.load(open(IC + "raw_counts_null2.json"))
GT = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
CLASS = [c["label"] for c in GT["curves"]]
FLOOR = [l for l in CLASS if l != "E0"]
NULL1 = raw["meta"]["null_labels"]
NULL2 = raw2["meta"]["labels"]
SUBS = ["canon", "rand1", "rand2", "rand3"]
BASES = {s: [int(v) for v in raw["log"]["subspace_bases"][s]] for s in SUBS}
KS = [8, 10, 12, 14, 16]
rng = np.random.default_rng(777001)


def rank2(vs):
    piv = {}
    r = 0
    for v in vs:
        while v:
            h = v.bit_length() - 1
            if h in piv:
                v ^= piv[h]
            else:
                piv[h] = v
                r += 1
                break
    return r


ONE = {s: [rank2(BASES[s][:k] + [1]) == rank2(BASES[s][:k]) for k in range(17)] for s in SUBS}


def model(l, s, k):
    one = ONE[s][k]
    det = 1 + (TRB[l] if one else 0)
    coins = (1 << k) - 1 - (1 if one else 0)
    return det, coins


def zval(l, s, k):
    det, coins = model(l, s, k)
    return ((CNT[l][s][k - 1] - det) - coins / 2) / math.sqrt(coins / 4)


def xval(l, s, k):
    det, coins = model(l, s, k)
    return CNT[l][s][k - 1] - det, coins


G = {"floor": FLOOR, "null1": NULL1, "null2": NULL2}
Z = {g: np.array([[[zval(l, s, k) for k in KS] for s in SUBS] for l in L]) for g, L in G.items()}  # (curves,4,5)
XC = {g: np.array([[[xval(l, s, k) for k in KS] for s in SUBS] for l in L]) for g, L in G.items()}  # (curves,4,5,2)
res = {"one_in_V": {s: [k for k in range(1, 17) if ONE[s][k]] for s in SUBS}}


def ks_phi(z):
    z = np.sort(z)
    F = stats.norm.cdf(z)
    n = len(z)
    i = np.arange(1, n + 1)
    return max((i / n - F).max(), (F - (i - 1) / n).max())


def pit(X, n):
    V = rng.random(X.shape)
    return stats.binom.cdf(X - 1, n, 0.5) + V * stats.binom.pmf(X, n, 0.5)


def ad_unif(u):
    u = np.sort(np.clip(u, 1e-15, 1 - 1e-15))
    n = len(u)
    i = np.arange(1, n + 1)
    return -n - np.mean((2 * i - 1) * (np.log(u) + np.log(1 - u[::-1])))


AD_NULL = {}


def ad_p(a, n):
    if n not in AD_NULL:
        AD_NULL[n] = np.array([ad_unif(rng.random(n)) for _ in range(20000)])
    return float((1 + (AD_NULL[n] >= a).sum()) / (1 + len(AD_NULL[n])))


per_k = {}
for ki, k in enumerate(KS):
    ent = {}
    for g in G:
        z = Z[g][:, :, ki].ravel()
        X = XC[g][:, :, ki, 0].ravel().astype(int)
        n = XC[g][:, :, ki, 1].ravel().astype(int)
        D = ks_phi(z)
        sims = np.array([ks_phi((rng.binomial(n, 0.5) - n / 2) / np.sqrt(n / 4)) for _ in range(4000)])
        p_ks_mc = float((1 + (sims >= D - 1e-12).sum()) / 4001)
        pks, pad = [], []
        for _ in range(101):
            u = pit(X, n)
            pks.append(stats.kstest(u, "uniform").pvalue)
            pad.append(ad_p(ad_unif(u), len(u)))
        ent[g] = {"n_cells": int(len(z)), "mean_z": float(z.mean()), "sd_z": float(z.std(ddof=1)),
                  "KS_D": float(D), "KS_mc_p": p_ks_mc,
                  "PIT_KS_p_median": float(np.median(pks)), "PIT_AD_p_median": float(np.median(pad)),
                  "chi2_sumz2_p_two_sided": float(2 * min(stats.chi2.cdf((z ** 2).sum(), len(z)),
                                                          stats.chi2.sf((z ** 2).sum(), len(z))))}
    # curve-level permutation, floor vs nulls
    for gn in ("null1", "null2"):
        A, B = Z["floor"][:, :, ki], Z[gn][:, :, ki]
        allc = np.concatenate([A, B])
        nA = len(A)
        d0 = stats.ks_2samp(A.ravel(), B.ravel()).statistic
        m0 = abs(A.mean() - B.mean())
        cnt = cntm = 0
        NP = 4000
        for _ in range(NP):
            perm = rng.permutation(len(allc))
            a, b = allc[perm[:nA]].ravel(), allc[perm[nA:]].ravel()
            cnt += stats.ks_2samp(a, b).statistic >= d0 - 1e-12
            cntm += abs(a.mean() - b.mean()) >= m0 - 1e-12
        ad = stats.anderson_ksamp([A.ravel(), B.ravel()], method=stats.PermutationMethod(n_resamples=999, random_state=int(rng.integers(1 << 31))))
        ent["floor_vs_" + gn] = {"KS_D": float(d0), "KS_perm_curve_level_p": float((cnt + 1) / (NP + 1)),
                                 "meandiff_perm_p": float((cntm + 1) / (NP + 1)),
                                 "AD_ksamp_perm_p": float(ad.pvalue)}
    # extremes (floor)
    zf = Z["floor"][:, :, ki]
    nf = XC["floor"][:, :, ki, 1].ravel().astype(int)
    zmax, zmin = float(zf.max()), float(zf.min())
    imax = np.unravel_index(zf.argmax(), zf.shape)
    imin = np.unravel_index(zf.argmin(), zf.shape)

    def tail_max(zo):
        lp = 0.0
        for n in nf:
            c = math.ceil(n / 2 + zo * math.sqrt(n / 4) - 1e-9)
            lp += stats.binom.logcdf(c - 1, n, 0.5)
        return 1 - math.exp(lp)

    def tail_min(zo):
        lp = 0.0
        for n in nf:
            c = math.floor(n / 2 + zo * math.sqrt(n / 4) + 1e-9)
            lp += stats.binom.logsf(c, n, 0.5)
        return 1 - math.exp(lp)

    mx = np.array([((rng.binomial(nf, 0.5) - nf / 2) / np.sqrt(nf / 4)).max() for _ in range(3000)])
    ent["floor_extremes"] = {"max_z": zmax, "max_cell": [FLOOR[imax[0]], SUBS[imax[1]]], "P_max_ge": tail_max(zmax),
                             "E_max_mc": float(mx.mean()), "min_z": zmin, "min_cell": [FLOOR[imin[0]], SUBS[imin[1]]],
                             "P_min_le": tail_min(zmin)}
    ent["E0"] = {"z": [zval("E0", s, k) for s in SUBS]}
    per_k[str(k)] = ent
res["per_k"] = per_k

# grand mean, analytic SE (nested covariance within a (curve, subspace) cell; independent otherwise)
gm = {}
for g, L in G.items():
    m = float(Z[g].mean())
    tot = 0.0
    for s in SUBS:
        cs = [model(L[0], s, k)[1] for k in KS]
        tot += sum(math.sqrt(min(a, b) / max(a, b)) for a in cs for b in cs)
    ncell = Z[g].size
    se = math.sqrt(tot * len(L)) / ncell
    gm[g] = {"grand_mean_z": m, "se_analytic": se, "z_of_mean": m / se, "p_two_sided": float(2 * stats.norm.sf(abs(m / se)))}
# simulated SE of the grand mean for the floor layout (nested binomials)
sims = []
for _ in range(2000):
    tot = 0.0
    for si, s in enumerate(SUBS):
        coins = [model(FLOOR[0], s, k)[1] for k in range(1, 17)]
        X = np.zeros(len(FLOOR))
        prev = 0
        acc = 0.0
        for k in range(1, 17):
            X = X + rng.binomial(coins[k - 1] - prev, 0.5, size=len(FLOOR))
            prev = coins[k - 1]
            if k in KS:
                acc += ((X - coins[k - 1] / 2) / math.sqrt(coins[k - 1] / 4)).sum()
        tot += acc
    sims.append(tot / Z["floor"].size)
gm["floor"]["se_simulated"] = float(np.std(sims))
res["grand_mean"] = gm

# exceedance |z| > 3 (and > 3.5), nested exact-binomial MC with the floor cell layout
def exceed_mc(thr, reps=4000):
    out = []
    for _ in range(reps):
        c = 0
        for s in SUBS:
            coins = [model(FLOOR[0], s, k)[1] for k in range(1, 17)]
            X = np.zeros(len(FLOOR))
            prev = 0
            for k in range(1, 17):
                X = X + rng.binomial(coins[k - 1] - prev, 0.5, size=len(FLOOR))
                prev = coins[k - 1]
                if k in KS:
                    c += int((np.abs((X - coins[k - 1] / 2) / math.sqrt(coins[k - 1] / 4)) > thr).sum())
        out.append(c)
    return np.array(out)


ex = {}
for thr in (3.0, 3.5):
    sim = exceed_mc(thr)
    ex[str(thr)] = {"mc_mean": float(sim.mean()), "mc_sd": float(sim.std())}
    for g in G:
        obs = int((np.abs(Z[g]) > thr).sum())
        ex[str(thr)][g] = {"obs": obs, "p_ge": float((1 + (sim >= obs).sum()) / (1 + len(sim))),
                           "by_subspace": {s: int((np.abs(Z[g][:, si, :]) > thr).sum()) for si, s in enumerate(SUBS)}}
res["exceedance"] = ex
res["E0_max_abs_z"] = float(max(abs(zval("E0", s, k)) for s in SUBS for k in KS))
json.dump(res, open(OUT + "stats_indep.json", "w"), indent=1)

print("1 in V:", res["one_in_V"])
for k in KS:
    e = per_k[str(k)]
    f = e["floor"]
    print("k=%2d floor mean %+.3f sd %.3f KSmc %.3f PIT-KS %.3f PIT-AD %.3f chi2 %.3f | null1 KSmc %.3f null2 KSmc %.3f"
          % (k, f["mean_z"], f["sd_z"], f["KS_mc_p"], f["PIT_KS_p_median"], f["PIT_AD_p_median"], f["chi2_sumz2_p_two_sided"],
             e["null1"]["KS_mc_p"], e["null2"]["KS_mc_p"]))
    print("      f-vs-n1 KS(curve perm) %.3f meandiff %.3f AD %.3f | f-vs-n2 KS %.3f meandiff %.3f AD %.3f"
          % (tuple(e["floor_vs_null1"][x] for x in ("KS_perm_curve_level_p", "meandiff_perm_p", "AD_ksamp_perm_p")) +
             tuple(e["floor_vs_null2"][x] for x in ("KS_perm_curve_level_p", "meandiff_perm_p", "AD_ksamp_perm_p"))))
    x = e["floor_extremes"]
    print("      max %+.3f %s P>=%.3f E[max]=%.2f | min %+.3f %s P<=%.4f | E0 z %s"
          % (x["max_z"], x["max_cell"], x["P_max_ge"], x["E_max_mc"], x["min_z"], x["min_cell"], x["P_min_le"],
             ["%+.2f" % v for v in e["E0"]["z"]]))
print("grand mean:", json.dumps(gm))
print("exceedance:", json.dumps(ex))
print("E0 max |z|:", res["E0_max_abs_z"])
