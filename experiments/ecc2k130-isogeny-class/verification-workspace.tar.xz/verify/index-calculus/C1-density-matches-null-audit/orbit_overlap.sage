# Frobenius-orbit dependence among floor curves.
# (1) count(b^2, V) = count(b, sqrt V): checked by running recount.c on sqrt(canon) for A000 vs A001 canon.
# (2) for each subspace V (canon, rand1..3) and d = 1..130: dim(V_k' cap Frob^{-d}(V_k)) for k, k' in
#     {8,..,16 even}; z(A_{i+d}, V_k) and z(A_i, V_k') share exactly the coins x in that intersection
#     (minus 0 and 1), giving Cov = shared / sqrt(coins_k coins_k').  Then the grand-mean SE is
#     recomputed including these cross-curve covariances.
import json, math, subprocess
OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C1-density-matches-null-audit:/"
IC = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"
R.<Z> = GF(2)[]
K.<z> = GF(2^131, modulus=Z^131 + Z^13 + Z^2 + Z + 1)
raw = json.load(open(IC + "raw_counts.json"))
SUBS = ["canon", "rand1", "rand2", "rand3"]
B = {s: [K.from_integer(int(v)) for v in raw["log"]["subspace_bases"][s]] for s in SUBS}
KS = [8, 10, 12, 14, 16]
V = VectorSpace(GF(2), 131)
def vec(x): return V([int(c) for c in x.polynomial().padded_list(131)])

# (1) sqrt(canon) subspace for A000 vs A001 on canon
sq = [x.sqrt() for x in B["canon"]]
lines = open(OUT + "inputs.txt").read().splitlines()
cur = [l for l in lines[1:790] if l.split()[0] in ("A000", "A001", "B000", "B001", "E0")]
with open(OUT + "inputs_sqrt.txt", "w") as f:
    f.write("%d 2\n" % len(cur))
    f.write("\n".join(cur) + "\n")
    f.write("canon " + " ".join("%033x" % x.to_integer() for x in B["canon"]) + "\n")
    f.write("sqrtcanon " + " ".join("%033x" % x.to_integer() for x in sq) + "\n")
subprocess.run([OUT + "recount", OUT + "inputs_sqrt.txt", OUT + "counts_sqrt.txt"], check=True, stderr=subprocess.DEVNULL)
C = {}
for line in open(OUT + "counts_sqrt.txt"):
    p = line.split()
    if p[0] == "CNT":
        C[(p[1], p[2])] = [int(v) for v in p[3:]]
frob_ok = {"A001_canon_eq_A000_sqrtcanon": C[("A001", "canon")] == C[("A000", "sqrtcanon")],
           "B001_canon_eq_B000_sqrtcanon": C[("B001", "canon")] == C[("B000", "sqrtcanon")],
           "E0_canon_eq_E0_sqrtcanon": C[("E0", "canon")] == C[("E0", "sqrtcanon")],
           "A000_canon_ne_A001_canon_k16": C[("A000", "canon")][15] != C[("A001", "canon")][15]}
print(frob_ok)

# (2) overlaps
ov = {}
for s in SUBS:
    Vk = {k: V.subspace([vec(x) for x in B[s][:k]]) for k in KS}
    ov[s] = {}
    for d in range(1, 131):
        e = 2^(131 - d)              # x -> x^(2^-d) = x^(2^(131-d))
        img = {k: V.subspace([vec(x^e) for x in B[s][:k]]) for k in KS}
        row = {}
        for k in KS:
            for kp in KS:
                dim = Vk[kp].intersection(img[k]).dimension()
                if dim > 0:
                    row["%d,%d" % (k, kp)] = int(dim)
        if row:
            ov[s][d] = row
    print(s, {d: ov[s][d].get("16,16") for d in sorted(ov[s])[:6]}, "n_d_with_overlap", len(ov[s]))

one_in = {"canon": True, "rand1": False, "rand2": False, "rand3": False}
def coins(s, k): return (1 << k) - 1 - (1 if one_in[s] else 0)
def shared(s, dim):
    n = (1 << dim) - 1           # nonzero x in intersection
    if one_in[s]:
        n -= 1                   # x = 1 is deterministic (1 lies in every canonical intersection)
    return max(n, 0)

# variance of the floor grand mean: 262 curves x 4 subspaces x 5 k
ncurve, ncell = 262, 262 * 4 * 5
var_within = 0.0
for s in SUBS:
    cs = [coins(s, k) for k in KS]
    var_within += sum(math.sqrt(min(a, b) / max(a, b)) for a in cs for b in cs)
var_within *= ncurve
var_cross = 0.0
for s in SUBS:
    for d, row in ov[s].items():
        for key, dim in row.items():
            k, kp = map(int, key.split(","))
            # each ordered (i, i+d) pair within an orbit: 131 per orbit, 2 orbits
            var_cross += 2 * 131 * shared(s, dim) / math.sqrt(coins(s, k) * coins(s, kp))
se0 = math.sqrt(var_within) / ncell
se1 = math.sqrt(var_within + var_cross) / ncell
res = {"frobenius_identity": frob_ok, "overlap_dims": {s: {str(d): r for d, r in ov[s].items()} for s in SUBS},
       "grand_mean_se_no_orbit_cov": se0, "grand_mean_se_with_orbit_cov": se1,
       "z_of_mean_with_orbit_cov": 0.03205311711819977 / se1}
json.dump(res, open(OUT + "orbit_overlap.json", "w"), indent=1)
print("SE without / with orbit covariance: %.5f %.5f  -> z of floor grand mean %.3f" % (se0, se1, res["z_of_mean_with_orbit_cov"]))
