"""Analysis of the fresh-subspace replication (64 random subspaces, 1 not in V_16, seed fixed in
fresh_prep.py before any count was seen).  Pre-declared questions:
 Q1 floor |z|>3 and |z|>3.5 exceedances vs the nested exact-binomial MC (does the 26-vs-14.3 excess
    on the original 4 subspaces replicate?), and vs the two nulls.
 Q2 the 24 floor curves that carried the original exceedances: is their mean z^2 on fresh subspaces
    higher than the other 238 floor curves'?  (curve-specific heavy tails)
 Q3 per-curve dispersion: variance across curves of per-curve mean z^2 vs the null MC (curve-level
    heterogeneity), and pooled KS / sd / mean per k; floor vs null curve-level permutation tests.
"""
import json, math
import numpy as np
from scipy import stats

OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C1-density-matches-null-audit:/"
IC = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"
raw = json.load(open(IC + "raw_counts.json"))
raw2 = json.load(open(IC + "raw_counts_null2.json"))
GT = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
exc = json.load(open(IC + "exceedance_mc.json"))
CLASS = [c["label"] for c in GT["curves"]]
FLOOR = [l for l in CLASS if l != "E0"]
G = {"floor": FLOOR, "null1": raw["meta"]["null_labels"], "null2": raw2["meta"]["labels"]}
KS = [8, 10, 12, 14, 16]
cnt = {}
for line in open(OUT + "counts_fresh.txt"):
    p = line.split()
    if p[0] == "CNT":
        cnt.setdefault(p[1], {})[p[2]] = [int(v) for v in p[3:]]
SUBS = sorted(next(iter(cnt.values())).keys())
NS = len(SUBS)
coins = {k: (1 << k) - 1 for k in KS}          # 1 not in V_16 for every fresh subspace -> det = 1
Z = {g: np.array([[[((cnt[l][s][k - 1] - 1) - coins[k] / 2) / math.sqrt(coins[k] / 4) for k in KS] for s in SUBS]
                  for l in L]) for g, L in G.items()}    # (curves, NS, 5)
rng = np.random.default_rng(31337)


def sim_nested(ncurves, reps):
    """nested exact binomials for random subspaces (coins 2^k - 1), returns (reps, ncurves, NS, 5) z"""
    out = np.empty((reps, ncurves, NS, len(KS)))
    for r in range(reps):
        X = np.zeros((ncurves, NS))
        prev = 0
        ki = 0
        for k in range(1, 17):
            c = (1 << k) - 1
            X = X + rng.binomial(c - prev, 0.5, size=(ncurves, NS))
            prev = c
            if k in KS:
                out[r, :, :, ki] = (X - c / 2) / math.sqrt(c / 4)
                ki += 1
    return out


REPS = 400
sim = sim_nested(262, REPS)
res = {"n_subspaces": NS, "reps": REPS}
ex = {}
for thr in (3.0, 3.5):
    s = (np.abs(sim) > thr).sum(axis=(1, 2, 3))
    ex[str(thr)] = {"mc_mean": float(s.mean()), "mc_sd": float(s.std())}
    for g in G:
        obs = int((np.abs(Z[g][:262]) > thr).sum()) if g != "floor" else int((np.abs(Z[g]) > thr).sum())
        ex[str(thr)][g] = {"obs_first262": obs, "p_ge": float((1 + (s >= obs).sum()) / (1 + REPS)),
                           "p_le": float((1 + (s <= obs).sum()) / (1 + REPS))}
res["Q1_exceedance"] = ex

# Q2: original exceedance curves
orig = sorted({c[0] for c in exc["floor"]["cells"]})
idx = [FLOOR.index(l) for l in orig]
rest = [i for i in range(len(FLOOR)) if i not in idx]
mz2 = (Z["floor"] ** 2).mean(axis=(1, 2))
d0 = mz2[idx].mean() - mz2[rest].mean()
perm = []
for _ in range(20000):
    pp = rng.permutation(len(FLOOR))
    perm.append(mz2[pp[:len(idx)]].mean() - mz2[pp[len(idx):]].mean())
perm = np.array(perm)
res["Q2_orig_exceedance_curves"] = {"curves": orig, "n": len(orig), "mean_z2_those": float(mz2[idx].mean()),
                                    "mean_z2_others": float(mz2[rest].mean()), "diff": float(d0),
                                    "perm_p_one_sided": float((1 + (perm >= d0).sum()) / (1 + len(perm))),
                                    "n_fresh_exceed_those": int((np.abs(Z["floor"][idx]) > 3).sum()),
                                    "n_fresh_exceed_others": int((np.abs(Z["floor"][rest]) > 3).sum())}

# Q3: curve-level heterogeneity: variance across curves of per-curve mean z^2
simv = np.array([((sim[r] ** 2).mean(axis=(1, 2))).var() for r in range(REPS)])
simm = np.array([((sim[r] ** 2).mean(axis=(1, 2))).max() for r in range(REPS)])
q3 = {}
for g in G:
    m = (Z[g][:262] ** 2).mean(axis=(1, 2))
    q3[g] = {"var_percurve_mean_z2": float(m.var()), "p_ge": float((1 + (simv >= m.var()).sum()) / (1 + REPS)),
             "max_percurve_mean_z2": float(m.max()), "p_max_ge": float((1 + (simm >= m.max()).sum()) / (1 + REPS))}
q3["mc_var_mean"] = float(simv.mean())
res["Q3_curve_heterogeneity"] = q3

perk = {}
for ki, k in enumerate(KS):
    e = {}
    for g in G:
        z = Z[g][:, :, ki].ravel()
        s2 = float((z ** 2).sum())
        e[g] = {"n": int(z.size), "mean": float(z.mean()), "mean_p": float(2 * stats.norm.sf(abs(z.mean()) * math.sqrt(z.size))),
                "sd": float(z.std(ddof=1)),
                "chi2_p_two_sided": float(2 * min(stats.chi2.cdf(s2, z.size), stats.chi2.sf(s2, z.size))),
                "skew": float(stats.skew(z)), "exkurt": float(stats.kurtosis(z))}
    for gn in ("null1", "null2"):
        A, B = Z["floor"][:, :, ki].mean(axis=1), Z[gn][:, :, ki].mean(axis=1)
        e["floor_vs_" + gn + "_curve_mean_welch_p"] = float(stats.ttest_ind(A, B, equal_var=False).pvalue)
        A2, B2 = (Z["floor"][:, :, ki] ** 2).mean(axis=1), (Z[gn][:, :, ki] ** 2).mean(axis=1)
        e["floor_vs_" + gn + "_curve_meanz2_welch_p"] = float(stats.ttest_ind(A2, B2, equal_var=False).pvalue)
    perk[str(k)] = e
res["per_k"] = perk
# simulated reference for skew / kurtosis sampling spread of a pooled k=16 group
sk = [stats.kurtosis(sim[r, :, :, -1].ravel()) for r in range(REPS)]
res["mc_exkurt_k16_5_95"] = [float(np.quantile(sk, .05)), float(np.quantile(sk, .95))]
json.dump(res, open(OUT + "fresh_analyze.json", "w"), indent=1)
print(json.dumps(res["Q1_exceedance"], indent=0))
print(json.dumps(res["Q2_orig_exceedance_curves"]))
print(json.dumps(res["Q3_curve_heterogeneity"]))
for k in KS:
    e = perk[str(k)]
    print(k, {g: (round(e[g]["mean"], 4), round(e[g]["mean_p"], 3), round(e[g]["sd"], 4), round(e[g]["chi2_p_two_sided"], 3),
                  round(e[g]["exkurt"], 3)) for g in G},
          "f-n1 mean p %.3f z2 p %.3f | f-n2 mean p %.3f z2 p %.3f" % (
              e["floor_vs_null1_curve_mean_welch_p"], e["floor_vs_null1_curve_meanz2_welch_p"],
              e["floor_vs_null2_curve_mean_welch_p"], e["floor_vs_null2_curve_meanz2_welch_p"]))
print("MC exkurt k16 5-95%:", res["mc_exkurt_k16_5_95"])
