/* Exact 3rd/4th moments of the canonical-subspace count over uniform b (Tr(b) = 1), to test how
 * far the "exact binomial model" is from exact beyond the 2nd moment.
 * Canonical V_k = polynomials of degree < k in F_2[z], k <= 16, field modulus degree 131.
 * Coins: x in V_k \ {0,1}, s_x = (-1)^(Tr(x) + Tr(b w_x)), w_x = x^-2.  Tr(x) = x_0 for deg x < 118
 * (trace mask bits {0,129}, from recount.c).  E_b[prod s] != 0 only if sum of 1/x over the set is 0
 * (or 1, impossible here by a degree argument), and then equals (-1)^Tr(sum x).  Since all
 * degrees stay < 131 the relations are identities in F_2[z].
 *   3-sets: u = xy/(x+y) must be a polynomial of degree < k, u != 0,1.
 *   4-sets: 1/x+1/y = 1/u+1/v, i.e. equal reduced fractions (x+y)/(xy).
 * S = sum s_x, n = #coins = 2^k - 2:  E S^3 = 6 R3,  E S^4 = 3n^2 - 2n + 24 R4  (signed counts).
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static inline uint64_t pmul(uint64_t a, uint64_t b) { uint64_t r = 0; while (b) { if (b & 1) r ^= a; a <<= 1; b >>= 1; } return r; }
static inline int deg(uint64_t a) { return a ? 63 - __builtin_clzll(a) : -1; }
static inline uint64_t pdivmod(uint64_t a, uint64_t b, uint64_t *rem) {
    uint64_t q = 0; int db = deg(b);
    while (a && deg(a) >= db) { int s = deg(a) - db; q ^= 1ULL << s; a ^= b << s; }
    *rem = a; return q;
}
static inline uint64_t pgcd(uint64_t a, uint64_t b) { while (b) { uint64_t r; pdivmod(a, b, &r); a = b; b = r; } return a; }
static int cmpu64(const void *a, const void *b) { uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b; return x < y ? -1 : x > y; }

int main(int argc, char **argv) {
    int kmax4 = argc > 1 ? atoi(argv[1]) : 14;
    for (int k = 4; k <= 16; k++) {
        uint64_t lim = 1ULL << k;
        double n = (double)(lim - 2);
        long long r3pos = 0, r3neg = 0, r3raw = 0;
        for (uint64_t x = 2; x < lim; x++)
            for (uint64_t y = x + 1; y < lim; y++) {
                uint64_t p = pmul(x, y), g = x ^ y, rem;
                uint64_t u = pdivmod(p, g, &rem);
                if (rem || u < 2 || u >= lim) continue;
                r3raw++;
                if (((x ^ y ^ u) & 1) == 0) r3pos++; else r3neg++;
            }
        /* each triple found once per pair it contains (3 times) */
        double R3 = (double)(r3pos - r3neg) / 3.0;
        double skew = 6.0 * R3 / (n * sqrt(n));
        printf("k=%2d n=%.0f triples=%lld (pos %lld neg %lld) R3_signed=%.1f skew_of_count=%.5f", k, n, r3raw / 3,
               r3pos / 3, r3neg / 3, R3, skew);
        if (k <= kmax4) {
            uint64_t npairs = (uint64_t)(lim - 2) * (lim - 3) / 2, i = 0;
            uint64_t *key = malloc(npairs * sizeof(uint64_t));
            for (uint64_t x = 2; x < lim; x++)
                for (uint64_t y = x + 1; y < lim; y++) {
                    uint64_t num = x ^ y, den = pmul(x, y), g = pgcd(den, num), r;
                    num = pdivmod(num, g, &r); den = pdivmod(den, g, &r);
                    int sgn = (int)((x ^ y) & 1);
                    /* den < 2^(2k-1) <= 2^31, num < 2^k; pack (den, num, sign) */
                    key[i++] = (den << 33) | (num << 1) | (uint64_t)sgn;
                }
            qsort(key, npairs, sizeof(uint64_t), cmpu64);
            double R4x3 = 0; long long groups_multi = 0, r4raw_x3 = 0;
            uint64_t a = 0;
            while (a < npairs) {
                uint64_t b = a; long long m = 0, ssum = 0;
                while (b < npairs && (key[b] >> 1) == (key[a] >> 1)) { m++; ssum += (key[b] & 1) ? -1 : 1; b++; }
                if (m > 1) { groups_multi++; R4x3 += ((double)ssum * ssum - m) / 2.0; r4raw_x3 += m * (m - 1) / 2; }
                a = b;
            }
            free(key);
            double R4 = R4x3 / 3.0;
            double exkurt = 24.0 * R4 / (n * n);
            printf(" | 4-sets=%lld R4_signed=%.1f excess_kurtosis=%.6f", r4raw_x3 / 3, R4, exkurt);
        }
        printf("\n");
        fflush(stdout);
    }
    return 0;
}
