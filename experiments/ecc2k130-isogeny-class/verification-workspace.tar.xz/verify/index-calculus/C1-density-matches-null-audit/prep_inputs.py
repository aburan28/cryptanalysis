# Writes inputs.txt for recount.c: curve labels + b (hex), subspace bases (hex).
# Class b values read straight from ground_truth.json (not via ecc2k.py);
# null b values and subspace bases from the sweep's raw_counts*.json.
import json
GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
IC = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"
OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C1-density-matches-null-audit:/"
g = json.load(open(GT))
raw = json.load(open(IC + "raw_counts.json"))
raw2 = json.load(open(IC + "raw_counts_null2.json"))
curves = [(c["label"], int(c["b_int"])) for c in g["curves"]]
assert all(int(c["a2"]) == 0 for c in g["curves"])
curves += [(l, int(raw["null_curves"][l]["b_int"])) for l in raw["meta"]["null_labels"]]
curves += [(l, int(raw2["null_curves"][l]["b_int"])) for l in raw2["meta"]["labels"]]
subs = raw["meta"]["subspaces"]
bases = {s: [int(v) for v in raw["log"]["subspace_bases"][s]] for s in subs}
with open(OUT + "inputs.txt", "w") as f:
    f.write("%d %d\n" % (len(curves), len(subs)))
    for l, b in curves:
        f.write("%s %033x\n" % (l, b))
    for s in subs:
        f.write(s + " " + " ".join("%033x" % v for v in bases[s]) + "\n")
print(len(curves), subs)
