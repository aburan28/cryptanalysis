import json
IC = "/Volumes/SSD990/ecdlp-hardness-work/index-calculus/"
OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C1-density-matches-null-audit:/"
raw = json.load(open(IC + "raw_counts.json"))
raw2 = json.load(open(IC + "raw_counts_null2.json"))
per = json.load(open(IC + "per_curve.json"))
Craw = dict(raw["counts"]); Craw.update(raw2["counts"])
mine, trb = {}, {}
for line in open(OUT + "counts_c.txt"):
    p = line.split()
    if p[0] == "TRB":
        trb[p[1]] = int(p[2])
    else:
        mine.setdefault(p[1], {})[p[2]] = [int(v) for v in p[3:]]
n_cells = n_mis = 0
mis = []
for l, d in mine.items():
    for s, arr in d.items():
        for k in range(1, 17):
            n_cells += 1
            if Craw[l][s][str(k)] != arr[k - 1]:
                n_mis += 1
                mis.append((l, s, k, Craw[l][s][str(k)], arr[k - 1]))
print("curves", len(mine), "cells compared (curve x subspace x k=1..16):", n_cells, "mismatches:", n_mis, mis[:10])
# per_curve.json count_incl_x0 (k = 8..16)
pm = 0; pc = 0
for l, r in per.items():
    for s, dd in r["count_incl_x0"].items():
        for kk, v in dd.items():
            pc += 1
            pm += (v != mine[l][s][int(kk[1:]) - 1])
print("per_curve.json count_incl_x0 cells:", pc, "mismatches:", pm)
cls = [c["label"] for c in json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))["curves"]]
print("Tr(b) class:", sorted(set(trb[l] for l in cls)), " null1 Tr(b)=0/1:",
      sum(trb[l] == 0 for l in raw["meta"]["null_labels"]), sum(trb[l] == 1 for l in raw["meta"]["null_labels"]),
      " null2:", sorted(set(trb[l] for l in raw2["meta"]["labels"])))
json.dump({"counts": mine, "trb": trb}, open(OUT + "counts_c.json", "w"))
