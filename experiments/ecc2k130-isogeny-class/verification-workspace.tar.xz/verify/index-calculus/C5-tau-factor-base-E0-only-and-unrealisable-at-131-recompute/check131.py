"""Independent re-derivation (pure python3, no Sage/PARI) of the structural numbers in claim C5.

Everything is done with hand-written GF(2) polynomial / linear-algebra code on integer bitmasks.
1. ord_131(2) by brute force.
2. factorisation pattern of x^131+1 over GF(2) by distinct-degree factorisation (own code),
   plus a Rabin irreducibility test of Phi_131.
3. The squaring map sigma on F_{2^131} = F_2[z]/(z^131+z^13+z^2+z+1) as a 131x131 F_2 matrix:
   minimal polynomial via Krylov sequence of a vector, dims of ker(sigma+1), ker(Phi(sigma)) = ker Tr.
   Cyclic module with squarefree min poly (x^131+1) => invariant subspaces <-> monic divisors.
   Empirical corroboration: dimension of the sigma-span of random elements.
4. Norm-form minimum on Z + c*O_K for c = 263, p, 263p (O_K = Z[w], w = (1+sqrt(-7))/2),
   and all norm-2 elements of O_K.
5. All elliptic curves over F_2 (all 32 Weierstrass (a1,a2,a3,a4,a6)), their point counts.
6. Degree over F_2 of each floor j from ground_truth.json (orbit length under squaring, own arithmetic).
7. log2 numbers.
"""
import json, math, random, time

t0 = time.time()
out = {}
n = 131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1

# ---------- 1. ord_131(2)
o, v = 1, 2 % n
while v != 1:
    v = (v * 2) % n
    o += 1
out["ord_131_2_bruteforce"] = o

# ---------- GF(2)[x] polynomial helpers (bitmask)
def pdeg(a):
    return a.bit_length() - 1

def pmod(a, m):
    dm = pdeg(m)
    while a and pdeg(a) >= dm:
        a ^= m << (pdeg(a) - dm)
    return a

def pmul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a <<= 1
        b >>= 1
    return r

def pmulmod(a, b, m):
    return pmod(pmul(a, b), m)

def pgcd(a, b):
    while b:
        a, b = b, pmod(a, b)
    return a

def pdiv(a, b):
    q = 0
    db = pdeg(b)
    while a and pdeg(a) >= db:
        s = pdeg(a) - db
        q |= 1 << s
        a ^= b << s
    return q, a

X = 0b10
F = (1 << 131) | 1          # x^131 + 1
# ---------- 2. distinct-degree factorisation of x^131+1 (squarefree since 131 odd)
# derivative of x^131+1 is 131 x^130 = x^130; gcd(F, x^130) = 1 -> squarefree
out["x131p1_squarefree"] = (pgcd(F, 1 << 130) == 1)
f = F
h = X
ddf = {}
d = 0
while f != 1 and pdeg(f) >= 2 * (d + 1):
    d += 1
    h = pmulmod(h, h, f) if pdeg(f) > 0 else h        # h = x^(2^d) mod f
    g = pgcd(f, h ^ X)
    if g != 1:
        ddf[d] = pdeg(g)
        f, r = pdiv(f, g)
        assert r == 0
        h = pmod(h, f)
if f != 1:
    ddf[pdeg(f)] = ddf.get(pdeg(f), 0) + pdeg(f)
out["x131p1_distinct_degree_factorisation"] = {str(k): {"total_degree": v_, "num_factors": v_ // k} for k, v_ in ddf.items()}
# explicit: (x+1) divides, quotient Phi = 1 + x + ... + x^130; Rabin test for Phi irreducible
PHI = (1 << 131) - 1
qq, r = pdiv(F, 0b11)
assert r == 0 and qq == PHI
def x_pow_2k_mod(k, m):
    h = X
    for _ in range(k):
        h = pmulmod(h, h, m)
    return h
rabin = {"x^(2^130) = x mod Phi": x_pow_2k_mod(130, PHI) == pmod(X, PHI)}
for r_ in (2, 5, 13):
    rabin["gcd(x^(2^%d)-x, Phi) = 1" % (130 // r_)] = pgcd(PHI, x_pow_2k_mod(130 // r_, PHI) ^ X) == 1
out["Phi131_rabin_irreducible"] = rabin
out["Phi131_irreducible"] = all(rabin.values())

# ---------- 3. squaring matrix on F_{2^131}
def fmul(a, b):
    return pmod(pmul(a, b), MOD)
def fsq(a):
    return fmul(a, a)
# check modulus irreducible by Rabin (131 prime): x^(2^131)=x mod m and gcd(x^2 - x, m) = 1
irr = (x_pow_2k_mod(131, MOD) == X) and (pgcd(MOD, x_pow_2k_mod(1, MOD) ^ X) == 1)
out["modulus_irreducible_rabin"] = irr
cols = [fsq(1 << i) for i in range(n)]   # sigma(z^i), column i
def apply_sigma(v):
    r = 0
    i = 0
    while v:
        if v & 1:
            r ^= cols[i]
        v >>= 1
        i += 1
    return r
# rank over F_2 of a list of row bitmasks
def rank(rows):
    rows = list(rows)
    rk = 0
    piv = {}
    for r in rows:
        while r:
            hb = r.bit_length() - 1
            if hb in piv:
                r ^= piv[hb]
            else:
                piv[hb] = r
                rk += 1
                break
    return rk
# ker(sigma + 1): image of sigma+1 has rank n - dim ker
img_s1 = [apply_sigma(1 << i) ^ (1 << i) for i in range(n)]
out["dim_ker_sigma_plus_1"] = n - rank(img_s1)
# Phi(sigma) = sum_{i<131} sigma^i = Trace map (image in F_2)
def trace_map(v):
    acc, w = 0, v
    for _ in range(n):
        acc ^= w
        w = apply_sigma(w)
    return acc
img_tr = [trace_map(1 << i) for i in range(n)]
out["trace_values_in_F2"] = all(x in (0, 1) for x in img_tr)
out["dim_ker_Phi_sigma"] = n - rank(img_tr)
# sigma^131 = identity, sigma != identity
w = 0x123456789abcdef0123456789abcdef1 % (1 << 131)
ww = w
for _ in range(n):
    ww = apply_sigma(ww)
out["sigma^131_is_identity_on_sample"] = (ww == w)
# minimal polynomial: Krylov dims of random vectors; min poly of the operator = lcm over vectors
rng = random.Random(20260923)
def krylov_dim(v):
    rows = []
    w = v
    for _ in range(n + 1):
        rows.append(w)
        w = apply_sigma(w)
    return rank(rows)
kd = {}
for _ in range(200):
    v = rng.getrandbits(n)
    d_ = krylov_dim(v)
    kd[d_] = kd.get(d_, 0) + 1
# plus structured vectors: elements of F_2, trace-zero elements
kd_struct = {"1": krylov_dim(1), "z": krylov_dim(2)}
tz = 2 if trace_map(2) == 0 else 2 ^ 1   # a trace-zero element
kd_struct["trace_zero_elem"] = krylov_dim(tz)
out["krylov_dims_random_200"] = {str(k): v_ for k, v_ in sorted(kd.items())}
out["krylov_dims_structured"] = kd_struct
# conclusion: if some v has Krylov dim 131, min poly = char poly = x^131+1 (cyclic module).
# Invariant subspaces of a cyclic module F_2[x]/(g) <-> monic divisors of g; with
# g = (x+1)*Phi, Phi irreducible: divisors {1, x+1, Phi, g} -> subspaces of dim 131,130,1,0
cyclic = 131 in kd
divs = [1, 0b11, PHI, F] if (out["Phi131_irreducible"] and cyclic) else None
out["invariant_subspace_dims"] = sorted(n - pdeg(dv) for dv in divs) if divs else None
# count divisors explicitly from the factor list
# ---------- 4. norm forms
def min_norm_order(c, bmax=3):
    """min over a in Z, b != 0 of N(a + c*b*w) = a^2 + a*c*b + 2*(c*b)^2 (exact by completing square)"""
    best = None
    for b in range(1, bmax + 1):
        C = c * b
        for a in (-(C // 2) - 1, -(C // 2), -(C // 2) + 1, -((C + 1) // 2)):
            val = a * a + a * C + 2 * C * C
            if best is None or val < best[0]:
                best = (val, a, C)
    return best
p = 146505763881528721
res4 = {}
for name, c in (("263", 263), ("p", p), ("263p", 263 * p), ("1", 1)):
    val, a, C = min_norm_order(c)
    res4[name] = {"min_norm_nonscalar": val, "element_a_plus_c_w": [a, C],
                  "equals_(1+7c^2)/4": val == (1 + 7 * c * c) // 4}
out["norm_form_min"] = res4
# brute-force cross-check for c = 263 over a window
bf = min(a * a + a * (263 * b) + 2 * (263 * b) ** 2 for b in range(-5, 6) if b != 0 for a in range(-2000, 2001))
out["norm_form_min_263_bruteforce_window"] = bf
# all elements of O_K of norm 2: a^2 + ab + 2b^2 = 2  (|b| <= 1.07, |a| <= 2)
n2 = [(a, b) for a in range(-5, 6) for b in range(-5, 6) if a * a + a * b + 2 * b * b == 2]
out["O_K_norm2_elements_(a,b)_for_a+b*w"] = n2
out["norm2_in_Z+263O_K"] = [e for e in n2 if e[1] % 263 == 0]
out["units_O_K_norm1"] = [(a, b) for a in range(-5, 6) for b in range(-5, 6) if a * a + a * b + 2 * b * b == 1]
out["60523_factor"] = [d_ for d_ in range(2, 247) if 121046 % d_ == 0]

# ---------- 5. elliptic curves over F_2
def count_F2(a1, a2, a3, a4, a6):
    cnt = 1
    for x in (0, 1):
        for y in (0, 1):
            if (y * y + a1 * x * y + a3 * y - (x ** 3 + a2 * x * x + a4 * x + a6)) % 2 == 0:
                cnt += 1
    return cnt
def nonsingular(a1, a2, a3, a4, a6):
    # discriminant over Z reduced mod 2
    b2 = a1 * a1 + 4 * a2
    b4 = 2 * a4 + a1 * a3
    b6 = a3 * a3 + 4 * a6
    b8 = a1 * a1 * a6 + 4 * a2 * a6 - a1 * a3 * a4 + a2 * a3 * a3 - a4 * a4
    D = -b2 * b2 * b8 - 8 * b4 ** 3 - 27 * b6 * b6 + 9 * b2 * b4 * b6
    return D % 2 != 0
orders = set()
for mask in range(32):
    a = [(mask >> i) & 1 for i in range(5)]
    if nonsingular(*a):
        orders.add(count_F2(*a))
out["F2_curve_orders"] = sorted(orders)
lo, hi = 3 - 2 * math.sqrt(2), 3 + 2 * math.sqrt(2)
out["F2_hasse_interval"] = [lo, hi]
out["multiples_of_131_in_F2_hasse"] = [m for m in range(1, 6) if lo < m < hi and m % 131 == 0]
out["F2_orders_divisible_by_131"] = [m for m in orders if m % 131 == 0]
out["131_divides_q+1=3"] = (3 % 131 == 0)
out["131_divides_q-1=1"] = (1 % 131 == 0)
out["E0_F2_count"] = count_F2(1, 0, 0, 0, 1)

# ---------- 6. degrees of floor j over F_2 from ground truth (own squaring)
gt = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
assert int(gt["meta"]["modulus_int"]) == MOD
degs = {}
orbit_ok = True
jset = {}
for c in gt["curves"]:
    j = int(c["j_int"])
    b = int(c["b_int"])
    assert fmul(j, b) == 1                      # j = 1/b
    jset[c["label"]] = j
    # orbit length under squaring
    L, w = 1, fsq(j)
    while w != j:
        w = fsq(w)
        L += 1
        assert L <= 131
    degs[c["label"]] = L
out["j_degree_E0"] = degs["E0"]
floor_degs = sorted(set(v_ for k, v_ in degs.items() if k != "E0"))
out["floor_j_degrees_over_F2"] = floor_degs
out["num_floor_curves"] = sum(1 for k in degs if k != "E0")
out["floor_a2_values"] = sorted(set(int(c["a2"]) for c in gt["curves"] if c["label"] != "E0"))
# label consistency j(X_{k+1}) = j(X_k)^2
lab_ok = all(fsq(jset["%s%03d" % (o_, k)]) == jset["%s%03d" % (o_, (k + 1) % 131)] for o_ in "AB" for k in range(131))
out["frobenius_label_chain_ok"] = lab_ok

# ---------- 7. log2
out["log2_131"] = math.log2(131)
out["2log2_131"] = 2 * math.log2(131)
out["elapsed_s"] = time.time() - t0
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C5-tau-factor-base-E0-only-and-unrealisable-at-131-recompute:/check131.json", "w"), indent=1)
print(json.dumps(out, indent=1))
