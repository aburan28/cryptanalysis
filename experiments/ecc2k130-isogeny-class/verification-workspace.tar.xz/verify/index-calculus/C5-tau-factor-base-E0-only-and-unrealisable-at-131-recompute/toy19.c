/* Independent recompute of the n = 19 tau-union toy (claim C5), with NO class polynomial:
 *   F_{2^19} = F_2[z]/(z^19+z^5+z^2+z+1) via exp/log tables (2^19-1 is prime, so z generates).
 *   For every b in F_q^* and a2 in {0,1}: decide whether #E_{a2,b} = CARD = 4N by scalar
 *   multiplication ([4]P != O and [N][4]P = O  =>  N | #E  =>  #E = 4N, the only multiple of N in
 *   the Hasse interval).  This lists the whole F_q-isogeny class {E0} u floor, independently of polclass.
 *   Then, for V_l = span(1, z, ..., z^(l-1)), U_l = union_{k<19} V_l^(2^k):
 *     E0 unknowns  = #squaring-orbits of liftable x in U_l   (classes under <-1, tau>)
 *     floor unknowns = #liftable x in U_l                     (classes under -1 only)
 *   for E0, F000 (floor curve with the smallest integer j) and ALL floor curves (distribution),
 *   plus the plain (non-union) V_l factor base for comparison.
 * Build: clang -O2 -o toy19 toy19.c ; Run: ./toy19 > toy19.json
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define NB 19
#define Q (1u << NB)
#define QM1 (Q - 1)
#define MODP ((1u << 19) | (1u << 5) | (1u << 2) | (1u << 1) | 1u)

static uint32_t EXP[2 * QM1 + 2], LOG[Q];
static uint32_t TRMASK;

static inline uint32_t mul(uint32_t a, uint32_t b) { return (a && b) ? EXP[LOG[a] + LOG[b]] : 0; }
static inline uint32_t inv(uint32_t a) { return EXP[(QM1 - LOG[a]) % QM1]; }
static inline uint32_t sq(uint32_t a) { return mul(a, a); }
static inline int tr(uint32_t a) { return __builtin_parity(a & TRMASK); }
static uint32_t htrace(uint32_t c) { /* sum_{i=0}^{9} c^(4^i) */
    uint32_t h = c, u = c;
    for (int i = 0; i < (NB - 1) / 2; i++) { u = sq(sq(u)); h ^= u; }
    return h;
}

typedef struct { uint32_t x, y; int inf; } Pt;
static uint32_t A2, B;
static Pt padd(Pt P, Pt R) {
    if (P.inf) return R;
    if (R.inf) return P;
    Pt o = {0, 0, 0};
    if (P.x == R.x) {
        if ((P.y ^ R.y) == P.x) { o.inf = 1; return o; }   /* R = -P (covers x = 0 2-torsion) */
        /* doubling */
        if (P.x == 0) { o.inf = 1; return o; }
        uint32_t l = P.x ^ mul(P.y, inv(P.x));
        uint32_t x3 = sq(l) ^ l ^ A2;
        uint32_t y3 = sq(P.x) ^ mul(l, x3) ^ x3;
        o.x = x3; o.y = y3; return o;
    }
    uint32_t l = mul(P.y ^ R.y, inv(P.x ^ R.x));
    uint32_t x3 = sq(l) ^ l ^ P.x ^ R.x ^ A2;
    uint32_t y3 = mul(l, P.x ^ x3) ^ x3 ^ P.y;
    o.x = x3; o.y = y3; return o;
}
static Pt pmulk(Pt P, uint64_t k) {
    Pt Rr = {0, 0, 1};
    while (k) { if (k & 1) Rr = padd(Rr, P); P = padd(P, P); k >>= 1; }
    return Rr;
}
static int oncurve(Pt P) {
    uint32_t x = P.x, y = P.y;
    return (sq(y) ^ mul(x, y)) == (mul(sq(x), x) ^ mul(A2, sq(x)) ^ B);
}
static uint64_t rng_state = 0x9e3779b97f4a7c15ull;
static uint32_t rnd(void) {
    rng_state ^= rng_state << 13; rng_state ^= rng_state >> 7; rng_state ^= rng_state << 17;
    return (uint32_t)(rng_state % QM1) + 1;
}

static int64_t TT[NB + 1];
static int64_t CARD, NN;

/* returns 1 if #E_{A2,B} = CARD (proved by a point of order divisible by N), 0 otherwise */
static int has_card(void) {
    for (int tries = 0; tries < 40; tries++) {
        uint32_t x = rnd();
        uint32_t c = x ^ A2 ^ mul(B, inv(sq(x)));
        if (tr(c)) continue;
        Pt P = {x, mul(x, htrace(c)), 0};
        if (!oncurve(P)) { fprintf(stderr, "lift failed\n"); exit(1); }
        Pt P4 = pmulk(P, 4);
        if (P4.inf) continue;
        Pt R = pmulk(P4, (uint64_t)NN);
        return R.inf ? 1 : 0;
    }
    return 0;
}

static uint8_t lifts(uint32_t x) { /* number of affine points with abscissa x */
    if (x == 0) return 1;
    uint32_t c = x ^ A2 ^ mul(B, inv(sq(x)));
    return tr(c) ? 0 : 2;
}

int main(void) {
    /* tables */
    uint32_t v = 1;
    for (uint32_t i = 0; i < QM1; i++) {
        EXP[i] = v; LOG[v] = i;
        v <<= 1; if (v & Q) v ^= MODP;
    }
    if (v != 1) { fprintf(stderr, "z not of order q-1\n"); return 1; }
    for (uint32_t i = QM1; i < 2 * QM1 + 2; i++) EXP[i] = EXP[i - QM1];
    /* trace mask: Tr(z^i) */
    TRMASK = 0;
    for (int i = 0; i < NB; i++) {
        uint32_t a = 1u << i, s = a, acc = 0;
        for (int k = 0; k < NB; k++) { acc ^= s; s = sq(s); }
        if (acc != 0 && acc != 1) { fprintf(stderr, "trace not in F2\n"); return 1; }
        if (acc) TRMASK |= 1u << i;
    }
    /* trace of E0 via Lucas: t1 = -1 (#E0(F2) = 4), t_{k+1} = t1 t_k - 2 t_{k-1} */
    TT[0] = 2; TT[1] = -1;
    for (int k = 2; k <= NB; k++) TT[k] = TT[1] * TT[k - 1] - 2 * TT[k - 2];
    int64_t t = TT[NB];
    CARD = (int64_t)Q + 1 - t; NN = CARD / 4;
    int nprime = 1;
    for (int64_t d = 2; d * d <= NN; d++) if (NN % d == 0) { nprime = 0; break; }
    int64_t disc = t * t - 4 * (int64_t)Q;
    printf("{\n \"n\": %d, \"t\": %lld, \"card\": %lld, \"N\": %lld, \"N_prime\": %d, \"disc\": %lld,", NB, (long long)t, (long long)CARD, (long long)NN, nprime, (long long)disc);
    /* disc = -7 f^2 ? */
    int64_t f2 = -disc / 7, f = 0;
    for (int64_t s = 1; s * s <= f2; s++) if (s * s == f2) f = s;
    printf(" \"f\": %lld, \"minus7f2_ok\": %d,\n", (long long)f, (int)(-7 * f * f == disc));

    /* scan the whole isogeny class */
    static uint8_t cls[Q];   /* bit0: a2=0 has CARD, bit1: a2=1 has CARD */
    int count0 = 0, count1 = 0, both = 0;
    for (uint32_t b = 1; b < Q; b++) {
        B = b; A2 = 0; int c0 = has_card();
        A2 = 1; int c1 = has_card();
        cls[b] = (uint8_t)(c0 | (c1 << 1));
        count0 += c0; count1 += c1; both += (c0 && c1);
    }
    int e0 = cls[1];
    printf(" \"class_curves_a2_0\": %d, \"class_curves_a2_1\": %d, \"both\": %d, \"E0_b1_flag\": %d,\n", count0, count1, both, e0);
    /* floor = class minus j = 1 (b = 1); index by j = 1/b */
    static uint32_t floorj[Q]; int nf = 0;
    for (uint32_t j = 2; j < Q; j++) { uint32_t b = inv(j); if (cls[b]) floorj[nf++] = j; }
    /* floorj is already sorted by integer j. squaring orbits of floor j */
    int orbit_len_hist[NB + 1]; memset(orbit_len_hist, 0, sizeof orbit_len_hist);
    for (int i = 0; i < nf; i++) {
        uint32_t j = floorj[i], w = sq(j); int L = 1;
        while (w != j) { w = sq(w); L++; }
        orbit_len_hist[L]++;
    }
    printf(" \"num_floor\": %d, \"floor_j_orbit_len_19_count\": %d, \"F000_j_int\": %u, \"F000_b_int\": %u, \"F000_a2\": %d,\n",
           nf, orbit_len_hist[NB], floorj[0], inv(floorj[0]), (cls[inv(floorj[0])] & 1) ? 0 : 1);

    printf(" \"tau_union\": {\n");
    for (int l = 5; l <= 7; l++) {
        static uint8_t inU[Q];
        memset(inU, 0, sizeof inU);
        for (uint32_t c = 0; c < (1u << l); c++) {
            uint32_t y = c;
            for (int k = 0; k < NB; k++) { inU[y] = 1; y = sq(y); }
        }
        int ucount = 0; for (uint32_t x = 0; x < Q; x++) ucount += inU[x];
        /* E0 */
        A2 = 0; B = 1;
        int e0pts = 0, e0lift = 0, e0orb = 0, e0plainpts = 0, e0plainx = 0;
        for (uint32_t x = 0; x < Q; x++) if (inU[x]) {
            uint8_t L = lifts(x); if (!L) continue;
            e0pts += L; e0lift++;
            /* orbit representative: x is the minimum of its squaring orbit */
            uint32_t w = sq(x), mn = x; while (w != x) { if (w < mn) mn = w; w = sq(w); }
            if (mn == x) e0orb++;
        }
        for (uint32_t x = 0; x < (1u << l); x++) { uint8_t L = lifts(x); e0plainpts += L; e0plainx += (L > 0); }
        /* all floor curves (a2 chosen so #E = CARD) */
        int f000pts = -1, f000lift = -1, mn_l = 1 << 30, mx_l = 0; double sum_l = 0;
        int f000plainpts = -1, f000plainx = -1;
        for (int i = 0; i < nf; i++) {
            B = inv(floorj[i]); A2 = (cls[B] & 1) ? 0 : 1;
            int pts = 0, lift = 0;
            for (uint32_t x = 0; x < Q; x++) if (inU[x]) { uint8_t L = lifts(x); pts += L; lift += (L > 0); }
            if (i == 0) {
                f000pts = pts; f000lift = lift;
                f000plainpts = 0; f000plainx = 0;
                for (uint32_t x = 0; x < (1u << l); x++) { uint8_t L = lifts(x); f000plainpts += L; f000plainx += (L > 0); }
            }
            if (lift < mn_l) mn_l = lift; if (lift > mx_l) mx_l = lift; sum_l += lift;
        }
        printf("  \"l%d\": {\"union_x_count\": %d, \"E0_union_points\": %d, \"E0_union_liftable_x\": %d, \"E0_unknowns_mod_neg_tau\": %d,"
               " \"E0_plainV_points\": %d, \"E0_plainV_unknowns_mod_neg\": %d,"
               " \"F000_union_points\": %d, \"F000_unknowns_mod_neg\": %d, \"F000_plainV_points\": %d, \"F000_plainV_unknowns_mod_neg\": %d,"
               " \"all_floor_union_unknowns_min\": %d, \"max\": %d, \"mean\": %.3f}%s\n",
               l, ucount, e0pts, e0lift, e0orb, e0plainpts, e0plainx, f000pts, f000lift, f000plainpts, f000plainx,
               mn_l, mx_l, sum_l / nf, l < 7 ? "," : "");
    }
    printf(" }\n}\n");
    return 0;
}
