# third code path: PARI factormod / znorder / qfbred via Sage's pari interface, plus the
# F_q-rationality of every 263-isogeny out of E0 (pi acts on E0[263] as a scalar).
import json
from sage.all import pari
out = {}
out["pari_factormod_x131p1_degrees"] = [int(pari("poldegree")(g)) for g in pari("factormod(x^131+1, 2)")[0]]
out["pari_znorder_2_mod_131"] = int(pari("znorder(Mod(2,131))"))
out["pari_factormod_x19p1_degrees"] = [int(pari("poldegree")(g)) for g in pari("factormod(x^19+1, 2)")[0]]
# reduced principal form of disc -7*263^2: minimum nonzero value off the scalar line
out["pari_qfbred_principal_D-484183"] = str(pari("qfbred(Qfb(1,263,2*263^2))"))
out["pari_qfbclassno_D-484183"] = int(pari("qfbclassno(-7*263^2)"))
# Lucas trace, and pi - a in 263*O_K
q = 2**131
t = [2, -1]
for k in range(2, 132):
    t.append(-t[-1] - 2 * t[-2])
t = t[131]
f = 38531015900842053623
p = 146505763881528721
assert t * t - 4 * q == -7 * f * f and f == 263 * p
a = (t * pow(2, -1, 263)) % 263
out["t"] = t
out["t_mod_263"] = t % 263
out["a=t/2_mod_263"] = a
# pi - a = ((t-2a) + f*sqrt(-7))/2 ; /263 -> ((t-2a)/263 + p*sqrt(-7))/2 in O_K iff integral & same parity
out["263_divides_t-2a"] = (t - 2 * a) % 263 == 0
out["parity_match"] = ((t - 2 * a) // 263 - p) % 2 == 0
out["pi_acts_as_scalar_on_E0[263]"] = out["263_divides_t-2a"] and out["parity_match"]
# tau eigenvalues mod 263: roots of x^2 + x + 2
out["tau_eigs_mod_263"] = [x for x in range(263) if (x * x + x + 2) % 263 == 0]
out["v263_q+1-t"] = next(k for k in range(10) if (q + 1 - t) % 263 ** (k + 1) != 0)
json.dump(out, open("extra_checks.json", "w"), indent=1)
print(json.dumps(out, indent=1))
