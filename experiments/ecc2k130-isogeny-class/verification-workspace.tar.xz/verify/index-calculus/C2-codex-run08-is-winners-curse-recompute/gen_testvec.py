# Reference vectors from Sage (NTL GF2E) for rcount's field arithmetic.
from sage.all import GF, PolynomialRing, set_random_seed
import random
PR = PolynomialRing(GF(2), 't'); t = PR.gen()
F = GF(2**131, name='z', modulus=t**131 + t**13 + t**2 + t + 1)
rnd = random.Random(12345)
lines_in, lines_exp = [], []
cases = [1, 2, 3, (1 << 131) - 1, 1 << 130, 1 << 129] + [rnd.getrandbits(131) for _ in range(2000)]
for i, ai in enumerate(cases):
    bi = rnd.getrandbits(131)
    a = F.from_integer(ai); b = F.from_integer(bi)
    p = (a * b).to_integer()
    ia = (1 / a).to_integer() if a != 0 else 0
    tr = int(a.trace())
    lines_in.append(f"{ai:x} {bi:x}")
    lines_exp.append((p, ia, tr))
open('testvec.in', 'w').write("\n".join(lines_in) + "\n")
import json
json.dump([[str(p), str(ia), tr] for p, ia, tr in lines_exp], open('testvec.expected.json', 'w'))
tm = sum(1 << i for i in range(131) if int((F.gen() ** i).trace()))
print("sage tmask hex", hex(tm))
