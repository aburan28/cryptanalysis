/*
 * rcount.c -- independent exact counter of "rational x" on nested F2-subspaces
 * for curves E_b : y^2 + x*y = x^3 + b over F_{2^131} = F_2[z]/(z^131+z^13+z^2+z+1).
 *
 * Written from scratch for the C2 verification (does not reuse Codex's or the sweep's code).
 *
 * Predicate (x != 0):  E_b has a point with abscissa x  <=>  Tr(x + b/x^2) = 0.
 * Algorithm here (different code path from Codex, which forms rhs = x + b*(1/x^2) then traces):
 *   Tr(x + b*w) with w = (1/x)^2  =  <tmask, x>  XOR  <L_b, w>
 *   where tmask_i = Tr(z^i) and L_b is the linear functional w -> Tr(b*w), L_b,i = Tr(b*z^i).
 *   Inverses are computed for a whole subspace by Montgomery batch inversion
 *   (one Itoh-Tsujii inversion per subspace), then shared by all curves.
 *
 * Subspace enumeration: x[mask] = XOR_{bit i of mask} basis[i], mask = 0..2^16-1,
 * so V_k = { x[mask] : mask < 2^k }.  Output: for every (curve, subspace) the number of
 * nonzero x in V_k passing the predicate, k = 8..16 (cumulative, nested).
 *
 * Modes:
 *   rcount test  < vectors      : reads "a b" hex pairs, prints "a*b  a^-1  Tr(a)" in hex
 *   rcount count < job > counts : job = S, S lines of 16 hex basis ints, C, C lines of hex b
 *                                  prints C*S lines "c s n8 n9 ... n16"
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { uint64_t w[3]; } fe;   /* bit i of the 131-bit integer = coeff of z^i */

static const uint64_t TOPMASK = (1ULL << 3) - 1; /* word 2 keeps bits 128..130 */

/* ---- 64x64 carry-less multiply (portable, plain shift-and-add; reference path) ---- */
static inline void clmul64(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    uint64_t l = 0, h = 0;
    for (int i = 0; i < 64; i++) {
        if ((b >> i) & 1) {
            l ^= a << i;
            if (i) h ^= a >> (64 - i);
        }
    }
    *lo = l; *hi = h;
}

#if defined(__ARM_FEATURE_AES) || defined(__ARM_FEATURE_CRYPTO)
#include <arm_neon.h>
static inline void clmul64_fast(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    poly128_t r = vmull_p64((poly64_t)a, (poly64_t)b);
    uint64x2_t v = vreinterpretq_u64_p128(r);
    *lo = vgetq_lane_u64(v, 0);
    *hi = vgetq_lane_u64(v, 1);
}
#define HAVE_FAST 1
#else
#define clmul64_fast clmul64
#define HAVE_FAST 0
#endif

static int use_fast = 1;

static inline void cl(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    if (use_fast) clmul64_fast(a, b, lo, hi); else clmul64(a, b, lo, hi);
}

/* reduce a 5-word (<= 261-bit) polynomial modulo z^131 + z^13 + z^2 + z + 1 */
static inline fe reduce5(const uint64_t p[5]) {
    /* H = p >> 131 */
    uint64_t h0 = (p[2] >> 3) | (p[3] << 61);
    uint64_t h1 = (p[3] >> 3) | (p[4] << 61);
    uint64_t h2 = (p[4] >> 3);
    uint64_t r0 = p[0], r1 = p[1], r2 = p[2] & TOPMASK;
    /* r ^= H ^ H<<1 ^ H<<2 ^ H<<13  (result may reach bit 142) */
    uint64_t s0, s1, s2;
    r0 ^= h0; r1 ^= h1; r2 ^= h2;
    s0 = h0 << 1; s1 = (h1 << 1) | (h0 >> 63); s2 = (h2 << 1) | (h1 >> 63);
    r0 ^= s0; r1 ^= s1; r2 ^= s2;
    s0 = h0 << 2; s1 = (h1 << 2) | (h0 >> 62); s2 = (h2 << 2) | (h1 >> 62);
    r0 ^= s0; r1 ^= s1; r2 ^= s2;
    s0 = h0 << 13; s1 = (h1 << 13) | (h0 >> 51); s2 = (h2 << 13) | (h1 >> 51);
    r0 ^= s0; r1 ^= s1; r2 ^= s2;
    /* second fold: G = r >> 131 (<= 12 bits) */
    uint64_t g = r2 >> 3;
    r2 &= TOPMASK;
    r0 ^= g ^ (g << 1) ^ (g << 2) ^ (g << 13);
    fe out = {{r0, r1, r2}};
    return out;
}

static inline fe fe_mul(fe a, fe b) {
    uint64_t p[6] = {0, 0, 0, 0, 0, 0};
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            uint64_t lo, hi;
            cl(a.w[i], b.w[j], &lo, &hi);
            p[i + j] ^= lo;
            p[i + j + 1] ^= hi;
        }
    }
    /* p[5] must be 0 since deg <= 260 */
    return reduce5(p);
}

static inline fe fe_sqr(fe a) { return fe_mul(a, a); }

static inline int fe_iszero(fe a) { return (a.w[0] | a.w[1] | a.w[2]) == 0; }

/* Itoh-Tsujii: a^(2^131 - 2) = (a^(2^130 - 1))^2, chain 1,2,4,8,16,32,64,128,129,130 */
static fe fe_pow2k_mul(fe x, int k, fe y) { /* x^(2^k) * y */
    for (int i = 0; i < k; i++) x = fe_sqr(x);
    return fe_mul(x, y);
}
static fe fe_inv(fe a) {
    fe b1 = a;                              /* a^(2^1-1) */
    fe b2 = fe_pow2k_mul(b1, 1, b1);        /* 2^2-1 */
    fe b4 = fe_pow2k_mul(b2, 2, b2);
    fe b8 = fe_pow2k_mul(b4, 4, b4);
    fe b16 = fe_pow2k_mul(b8, 8, b8);
    fe b32 = fe_pow2k_mul(b16, 16, b16);
    fe b64 = fe_pow2k_mul(b32, 32, b32);
    fe b128 = fe_pow2k_mul(b64, 64, b64);
    fe b129 = fe_pow2k_mul(b128, 1, a);
    fe b130 = fe_pow2k_mul(b129, 1, a);
    return fe_sqr(b130);
}

/* absolute trace by the definition: sum_{j=0}^{130} a^(2^j); must land in {0,1} */
static int fe_trace_def(fe a) {
    fe acc = a, s = a;
    for (int j = 1; j < 131; j++) {
        s = fe_sqr(s);
        acc.w[0] ^= s.w[0]; acc.w[1] ^= s.w[1]; acc.w[2] ^= s.w[2];
    }
    if (acc.w[1] || acc.w[2] || (acc.w[0] >> 1)) {
        fprintf(stderr, "trace not in F2 -- arithmetic bug\n");
        exit(2);
    }
    return (int)(acc.w[0] & 1);
}

static fe TMASK;  /* bit i = Tr(z^i) */

static inline int par3(fe m, fe x) {
    return __builtin_parityll((m.w[0] & x.w[0]) ^ (m.w[1] & x.w[1]) ^ (m.w[2] & x.w[2]));
}

static fe zpow(int i) { fe r = {{0, 0, 0}}; r.w[i >> 6] = 1ULL << (i & 63); return r; }

static void init_tmask(void) {
    memset(&TMASK, 0, sizeof TMASK);
    for (int i = 0; i < 131; i++)
        if (fe_trace_def(zpow(i))) TMASK.w[i >> 6] |= 1ULL << (i & 63);
}

/* L_b: bit i = Tr(b * z^i), computed via tmask on the product */
static fe functional(fe b) {
    fe L = {{0, 0, 0}};
    fe zi = {{1, 0, 0}};
    fe zgen = zpow(1);
    for (int i = 0; i < 131; i++) {
        if (par3(TMASK, fe_mul(b, zi))) L.w[i >> 6] |= 1ULL << (i & 63);
        zi = fe_mul(zi, zgen);
    }
    return L;
}

static int parse_hex(const char *s, fe *out) {
    /* hex string, possibly with 0x prefix, up to 33 hex digits */
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r' || s[n - 1] == ' ')) n--;
    fe r = {{0, 0, 0}};
    for (size_t i = 0; i < n; i++) {
        char c = s[i];
        int v;
        if (c >= '0' && c <= '9') v = c - '0';
        else if (c >= 'a' && c <= 'f') v = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') v = c - 'A' + 10;
        else return -1;
        /* r = r*16 + v */
        r.w[2] = (r.w[2] << 4) | (r.w[1] >> 60);
        r.w[1] = (r.w[1] << 4) | (r.w[0] >> 60);
        r.w[0] = (r.w[0] << 4) | (uint64_t)v;
    }
    if (r.w[2] >> 3) return -2;  /* more than 131 bits */
    *out = r;
    return 0;
}

static void print_hex(fe a) {
    printf("%01llx%016llx%016llx", (unsigned long long)a.w[2], (unsigned long long)a.w[1],
           (unsigned long long)a.w[0]);
}

#define K 16
#define NV (1 << K)

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: rcount test|count [slow]\n"); return 1; }
    if (argc >= 3 && strcmp(argv[2], "slow") == 0) use_fast = 0;
    init_tmask();
    if (strcmp(argv[1], "test") == 0) {
        char sa[128], sb[128];
        printf("# fast=%d tmask=", use_fast && HAVE_FAST); print_hex(TMASK); printf("\n");
        while (scanf("%127s %127s", sa, sb) == 2) {
            fe a, b;
            if (parse_hex(sa, &a) || parse_hex(sb, &b)) { fprintf(stderr, "bad hex\n"); return 1; }
            fe p = fe_mul(a, b);
            fe ia = fe_iszero(a) ? a : fe_inv(a);
            print_hex(p); printf(" "); print_hex(ia); printf(" %d\n", fe_trace_def(a));
        }
        return 0;
    }
    if (strcmp(argv[1], "count") != 0) { fprintf(stderr, "unknown mode\n"); return 1; }
    int S, C;
    char buf[128];
    if (scanf("%d", &S) != 1) return 1;
    fe *bases = malloc(sizeof(fe) * S * K);
    for (int s = 0; s < S; s++)
        for (int i = 0; i < K; i++) {
            if (scanf("%127s", buf) != 1 || parse_hex(buf, &bases[s * K + i])) { fprintf(stderr, "bad basis\n"); return 1; }
        }
    if (scanf("%d", &C) != 1) return 1;
    fe *Ls = malloc(sizeof(fe) * C);
    for (int c = 0; c < C; c++) {
        fe b;
        if (scanf("%127s", buf) != 1 || parse_hex(buf, &b)) { fprintf(stderr, "bad b\n"); return 1; }
        Ls[c] = functional(b);
    }
    fe *x = malloc(sizeof(fe) * NV);
    fe *w = malloc(sizeof(fe) * NV);
    fe *pre = malloc(sizeof(fe) * NV);
    uint8_t *tx = malloc(NV);
    int *out = calloc((size_t)C * S * 9, sizeof(int));
    for (int s = 0; s < S; s++) {
        fe *B = &bases[s * K];
        x[0].w[0] = x[0].w[1] = x[0].w[2] = 0;
        for (int m = 1; m < NV; m++) {
            int low = __builtin_ctz(m);
            fe prev = x[m & (m - 1)];
            x[m].w[0] = prev.w[0] ^ B[low].w[0];
            x[m].w[1] = prev.w[1] ^ B[low].w[1];
            x[m].w[2] = prev.w[2] ^ B[low].w[2];
            if (fe_iszero(x[m])) { fprintf(stderr, "basis %d dependent\n", s); return 3; }
        }
        /* Montgomery batch inversion of x[1..NV-1] */
        pre[1] = x[1];
        for (int m = 2; m < NV; m++) pre[m] = fe_mul(pre[m - 1], x[m]);
        fe inv = fe_inv(pre[NV - 1]);
        for (int m = NV - 1; m >= 2; m--) {
            fe im = fe_mul(inv, pre[m - 1]);  /* 1/x[m] */
            inv = fe_mul(inv, x[m]);           /* 1/(x[1]..x[m-1]) */
            w[m] = fe_sqr(im);
        }
        w[1] = fe_sqr(inv);
        /* spot check a few inverses */
        for (int m = 1; m < NV; m += 4099) {
            fe t = fe_mul(fe_mul(w[m], x[m]), x[m]);
            if (t.w[0] != 1 || t.w[1] || t.w[2]) { fprintf(stderr, "inverse check failed\n"); return 4; }
        }
        for (int m = 1; m < NV; m++) tx[m] = (uint8_t)par3(TMASK, x[m]);
        for (int c = 0; c < C; c++) {
            fe L = Ls[c];
            int *o = &out[((size_t)c * S + s) * 9];
            int cnt = 0;
            int m = 1;
            for (int k = 8; k <= 16; k++) {
                int end = 1 << k;
                for (; m < end; m++) cnt += (tx[m] ^ par3(L, w[m])) == 0;
                o[k - 8] = cnt;
            }
        }
    }
    for (int c = 0; c < C; c++)
        for (int s = 0; s < S; s++) {
            int *o = &out[((size_t)c * S + s) * 9];
            printf("%d %d", c, s);
            for (int k = 0; k < 9; k++) printf(" %d", o[k]);
            printf("\n");
        }
    return 0;
}
