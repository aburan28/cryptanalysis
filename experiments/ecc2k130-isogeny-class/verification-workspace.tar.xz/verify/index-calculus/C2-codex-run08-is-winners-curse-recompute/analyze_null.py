"""Compare Codex Run-08's per-k best (and median) attempt ratios with exact-count null replicas."""
import glob, json
import numpy as np
import rc

KS = rc.KS
# observed: my recomputation of Codex's actual run (identical to Codex's files, see reproduce_codex.json)
counts = np.load("codex_family_real_curves_counts.npy")
_, obs_chosen, _ = rc.select(counts)
obs_R = 2.0 ** (obs_chosen[1:] - obs_chosen[0][None, :])
obs = {"min": obs_R.min(axis=0), "median": np.median(obs_R, axis=0),
       "q05": np.quantile(obs_R, .05, axis=0), "q95": np.quantile(obs_R, .95, axis=0),
       "num": obs_chosen[1:].min(axis=0), "e0": obs_chosen[0]}
sweep = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/index-calculus/stats.json"))["codex_run08_null_replica"]["per_k"]

def pct(a):
    return [float(np.quantile(a, q)) for q in (.05, .5, .95)]

def load(variant):
    fs = sorted(glob.glob(f"runs/{variant}_*.npz"))
    if not fs:
        return None
    ch = np.concatenate([np.load(f)["chosen"] for f in fs])
    ties = np.concatenate([np.load(f)["ties"] for f in fs])
    return ch, ties

out = {"observed_codex": {s: [float(x) for x in obs[s]] for s in ("min", "median", "q05", "q95")},
       "observed_best_curves": None, "variants": {}}
for variant in ("N1", "N2", "N3", "N4"):
    L = load(variant)
    if L is None:
        continue
    ch, ties = L
    R = 2.0 ** (ch[:, 1:, :] - ch[:, :1, :])          # [reps, 262, 9]
    mins = R.min(axis=1); meds = np.median(R, axis=1)
    q05 = np.quantile(R, .05, axis=1); q95 = np.quantile(R, .95, axis=1)
    num = ch[:, 1:, :].min(axis=1); e0 = ch[:, 0, :]
    nrep = ch.shape[0]
    v = {"replicas": int(nrep), "replicas_with_any_exact_selection_tie": int((ties > 0).sum()), "per_k": {}}
    for i, k in enumerate(KS):
        v["per_k"][k] = {
            "codex_best": float(obs["min"][i]),
            "sim_best_mean": float(mins[:, i].mean()), "sim_best_5_50_95": pct(mins[:, i]),
            "frac_sim_best_le_codex": float((mins[:, i] <= obs["min"][i]).mean()),
            "codex_median": float(obs["median"][i]), "sim_median_5_50_95": pct(meds[:, i]),
            "frac_sim_median_le_codex": float((meds[:, i] <= obs["median"][i]).mean()),
            "frac_sim_q05_le_codex": float((q05[:, i] <= obs["q05"][i]).mean()),
            "frac_sim_q95_le_codex": float((q95[:, i] <= obs["q95"][i]).mean()),
            # numerator only (best descendant's own log2 targets) and E0 baseline, in log2 units
            "frac_sim_bestdesc_log2targets_le_codex": float((num[:, i] <= obs["num"][i]).mean()),
            "frac_sim_E0_log2targets_ge_codex": float((e0[:, i] >= obs["e0"][i]).mean()),
        }
    # joint tests over the 9 correlated per-k minima (empirical ranks within the replica set)
    def ranks(x, col):  # fraction of replicas with value <= x in column col
        return (mins[:, col][None, :] <= np.atleast_1d(x)[:, None]).mean(axis=1)
    P = np.stack([ranks(mins[:, i], i) for i in range(9)], axis=1)       # [reps, 9]
    Pobs = np.array([ranks(obs["min"][i], i)[0] for i in range(9)])
    Tlow = P.min(axis=1); Tlow_obs = Pobs.min()
    two = np.minimum(P, 1 - P + 1.0 / nrep); two_obs = np.minimum(Pobs, 1 - Pobs + 1.0 / nrep)
    G = np.log(mins).mean(axis=1); G_obs = np.log(obs["min"]).mean()
    v["joint"] = {
        "per_k_percentiles_codex": [float(x) for x in Pobs],
        "min_k_percentile_codex": float(Tlow_obs),
        "p_value_min_k_percentile_low": float((Tlow <= Tlow_obs).mean()),
        "p_value_two_sided_min": float((two.min(axis=1) <= two_obs.min()).mean()),
        "geomean_best_codex": float(np.exp(G_obs)), "geomean_best_sim_5_50_95": [float(np.exp(x)) for x in pct(G)],
        "p_value_geomean_low": float((G <= G_obs).mean()),
        "frac_reps_min_k8_le_0.7075": float((mins[:, 0] <= 0.7075436940695617).mean()),
        "frac_reps_min_k16_le_0.9766": float((mins[:, 8] <= 0.9765921655170985).mean()),
        "frac_reps_min_k16_ge_0.9766": float((mins[:, 8] >= 0.9765921655170985).mean()),
    }
    out["variants"][variant] = v
out["sweep_binomial_model_for_reference"] = {k: {"sim_best_mean": sweep[k]["sim_best_mean"],
                                                  "sim_best_5_50_95": sweep[k]["sim_best_5_50_95"],
                                                  "frac_sim_best_le_codex": sweep[k]["frac_sim_best_le_codex"]}
                                              for k in sweep}
json.dump(out, open("null_comparison.json", "w"), indent=1)
for variant, v in out["variants"].items():
    print(f"== {variant}  reps={v['replicas']}  reps_with_ties={v['replicas_with_any_exact_selection_tie']}")
    print(" k  codex  simbest_mean  [5,50,95]            P(sim<=codex) | sweep_binom_mean P  | P(med<=codex) P(bestdesc<=) P(E0>=)")
    for k in KS:
        r = v["per_k"][k]; s = out["sweep_binomial_model_for_reference"][str(k)]
        print(f"{k:2d} {r['codex_best']:.4f} {r['sim_best_mean']:.4f} [{', '.join(f'{x:.4f}' for x in r['sim_best_5_50_95'])}] "
              f"{r['frac_sim_best_le_codex']:.3f} | {s['sim_best_mean']:.4f} {s['frac_sim_best_le_codex']:.3f} | "
              f"{r['frac_sim_median_le_codex']:.3f} {r['frac_sim_bestdesc_log2targets_le_codex']:.3f} {r['frac_sim_E0_log2targets_ge_codex']:.3f}")
    print(" joint:", json.dumps(v["joint"]))
