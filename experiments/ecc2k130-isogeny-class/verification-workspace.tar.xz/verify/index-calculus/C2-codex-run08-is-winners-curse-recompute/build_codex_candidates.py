# Rebuild Codex Run-08's 64 nested candidate subspaces (extended to 16 dims) from the
# deterministic definitions in its protocol (screen_subspaces.candidates + scale_finalists.extended_basis):
#   poly      : z^0..z^15
#   scale-XX  : s*z^0..s*z^15, s = z^e, e = SHA256("run08-scale:XX") mod (2^131-1)
#   random-XX : Python random.Random(SHA256("run08-random:XX")) getrandbits(131), keep if rank grows
# Only these definitions are taken from Codex; field arithmetic is Sage's, rank is my own code.
import hashlib, json, random
from sage.all import GF, PolynomialRing
PR = PolynomialRing(GF(2), 't'); t = PR.gen()
F = GF(2**131, name='z', modulus=t**131 + t**13 + t**2 + t + 1)
z = F.gen()

def rank_gf2(vals):
    rows = []
    for v in vals:
        for r in rows:
            v = min(v, v ^ r)
        if v:
            rows.append(v)
            rows.sort(reverse=True)
    return len(rows)

cands = [("poly", [int((z**d).to_integer()) for d in range(16)])]
for i in range(31):
    e = int.from_bytes(hashlib.sha256(f"run08-scale:{i}".encode()).digest(), "big") % ((1 << 131) - 1)
    s = z**e
    cands.append((f"scale-{i:02d}", [int((s * z**d).to_integer()) for d in range(16)]))
for i in range(32):
    seed = int.from_bytes(hashlib.sha256(f"run08-random:{i}".encode()).digest(), "big")
    rng = random.Random(seed)
    vals = []
    while len(vals) < 16:
        c = rng.getrandbits(131)
        if rank_gf2(vals + [c]) == len(vals) + 1:
            vals.append(c)
    cands.append((f"random-{i:02d}", vals))
for cid, b in cands:
    assert rank_gf2(b) == 16, cid
json.dump([{"candidate_id": cid, "basis": [str(v) for v in b]} for cid, b in cands],
          open("codex_candidates16.json", "w"), indent=0)
print(len(cands), "candidates; first 10 of random-29:", [hex(v) for v in dict(cands)["random-29"][:2]])
