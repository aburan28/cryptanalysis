"""Null for the sweep's 'canonical V' bullet: fixed polynomial basis 1,z,..,z^15 (no selection),
E0 (b=1) as baseline, 262 random b (Tr(b)=1) per replica. Records per-k best ratio and winner persistence."""
import json, random, collections
import numpy as np
import rc

TMASK = (1 << 0) | (1 << 129)
def rand_b(rng):
    while True:
        b = rng.getrandbits(131)
        if b and (bin(b & TMASK).count("1") & 1) == 1:
            return b

poly = [1 << i for i in range(16)]
labels, real_bs = rc.load_curves()
real = rc.run_rcount([poly], real_bs)[:, 0, :]          # [263, 9]
LTr = rc.lt_array(real)
obs = 2.0 ** (LTr[1:] - LTr[0][None, :])
obs_min = obs.min(axis=0); obs_win = [labels[1 + i] for i in obs.argmin(axis=0)]
obs_maxwins = max(collections.Counter(obs_win).values())
R_TOTAL, BATCH = 1000, 100
mins, maxwins, ndistinct = [], [], []
for start in range(0, R_TOTAL, BATCH):
    rng = random.Random(f"C2-canon:{start}")
    bs = [1] + [rand_b(rng) for _ in range(262 * BATCH)]
    cnt = rc.run_rcount([poly], bs)[:, 0, :]
    LT = rc.lt_array(cnt)
    for r in range(BATCH):
        blk = LT[1 + 262 * r: 1 + 262 * (r + 1)]
        rat = 2.0 ** (blk - LT[0][None, :])
        mins.append(rat.min(axis=0))
        w = rat.argmin(axis=0)
        maxwins.append(max(collections.Counter(w.tolist()).values())); ndistinct.append(len(set(w.tolist())))
mins = np.array(mins); maxwins = np.array(maxwins); ndistinct = np.array(ndistinct)
res = {"E0_poly_counts_k8_16": real[0].tolist(),
       "observed_best": [float(x) for x in obs_min], "observed_winners": obs_win,
       "observed_max_wins_one_curve": obs_maxwins, "observed_distinct_winners": len(set(obs_win)),
       "sim_best_mean": [float(x) for x in mins.mean(axis=0)],
       "frac_sim_best_le_obs": [float(x) for x in (mins <= obs_min[None, :]).mean(axis=0)],
       "sim_max_wins_distribution": {int(k): int(v) for k, v in sorted(collections.Counter(maxwins.tolist()).items())},
       "frac_sim_max_wins_ge_obs": float((maxwins >= obs_maxwins).mean()),
       "sim_distinct_winners_distribution": {int(k): int(v) for k, v in sorted(collections.Counter(ndistinct.tolist()).items())},
       "replicas": int(len(mins))}
json.dump(res, open("canon_null.json", "w"), indent=1)
print(json.dumps(res, indent=1))
