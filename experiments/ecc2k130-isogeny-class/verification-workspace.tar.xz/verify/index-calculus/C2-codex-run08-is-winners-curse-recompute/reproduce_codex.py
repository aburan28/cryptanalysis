"""Step 1: recompute Codex Run-08 (real curves x Codex's 64 candidates) with my own kernel,
and compare to Codex's own outputs (analysis-summary.json, all-persistent-scaling.json)."""
import json, time, sys
import numpy as np
import rc

D = "/Users/adamburan/Documents/Codex/2026-09-22/prior-conversation-with-codex-conversation-role-2/outputs/curve-comparison/run-08-descendant-subspaces"
labels, bs = rc.load_curves()
cands = json.load(open("codex_candidates16.json"))
cids = [c["candidate_id"] for c in cands]
bases = [[int(v) for v in c["basis"]] for c in cands]
t0 = time.time()
counts = rc.run_rcount(bases, bs)
sec = time.time() - t0
np.save("codex_family_real_curves_counts.npy", counts)
choice, chosen, ties = rc.select(counts)
R = rc.ratios_vs_e0(chosen)
floor = labels[1:]
res = {"seconds_kernel": sec, "exact_ties_at_selection": ties,
       "E0_choice": cids[choice[0]], "E0_counts_k8_16": counts[0, choice[0]].tolist(), "per_k": {}}
for i, k in enumerate(rc.KS):
    r = R[:, i]
    j = int(r.argmin())
    res["per_k"][k] = {"min": float(r.min()), "argmin": floor[j], "argmin_cand": cids[choice[j + 1]],
                       "median": float(np.median(r)), "q05": float(np.quantile(r, .05)), "q95": float(np.quantile(r, .95)),
                       "max": float(r.max())}
# compare with Codex's files
an = json.load(open(f"{D}/analysis-summary.json"))
sc = json.load(open(f"{D}/all-persistent-scaling.json"))
codex_rows = {(r["curve_id"], r["k"]): r for r in sc["rows"]}
mism_cand = mism_cnt = 0
for c, lab in enumerate(labels):
    for i, k in enumerate(rc.KS):
        row = codex_rows[(lab, k)]
        if row["candidate_id"] != cids[choice[c]]:
            mism_cand += 1
        if row["factor_base_x_count"] != counts[c, choice[c], i]:
            mism_cnt += 1
res["vs_codex_all_persistent_scaling"] = {"cells": len(labels) * 9, "candidate_mismatch_cells": mism_cand,
                                          "count_mismatch_cells": mism_cnt}
dd = an["distribution_by_dimension"]; bc = an["best_single_dimension_cells"]
res["vs_codex_analysis_summary"] = {k: {"codex_min": dd[str(k)]["min"], "mine_min": res["per_k"][k]["min"],
                                        "codex_best_curve": bc[str(k)]["curve_id"], "mine_best_curve": res["per_k"][k]["argmin"],
                                        "codex_median": dd[str(k)]["median"], "mine_median": res["per_k"][k]["median"],
                                        "codex_q05": dd[str(k)]["q05"], "mine_q05": res["per_k"][k]["q05"],
                                        "codex_q95": dd[str(k)]["q95"], "mine_q95": res["per_k"][k]["q95"]}
                                    for k in rc.KS}
# E0 on canonical (poly) basis, as in the sweep's "canonical V" bullet
ip = cids.index("poly")
LT = rc.lt_array(counts[:, ip, :])
Rc = 2.0 ** (LT[1:] - LT[0][None, :])
res["canonical_poly_basis"] = {k: {"min": float(Rc[:, i].min()), "argmin": floor[int(Rc[:, i].argmin())]}
                               for i, k in enumerate(rc.KS)}
json.dump(res, open("reproduce_codex.json", "w"), indent=1)
print(json.dumps({k: v for k, v in res.items() if k not in ("per_k",)}, indent=1))
