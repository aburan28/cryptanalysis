"""Shared helpers for the C2 recompute (my own code; calls the rcount C kernel)."""
import json, math, os, subprocess, tempfile
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
RCOUNT = os.path.join(HERE, "rcount")
KS = list(range(8, 17))
GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"


def load_curves():
    g = json.load(open(GT))
    labels = [c["label"] for c in g["curves"]]
    bs = [int(c["b_int"]) for c in g["curves"]]
    assert all(c["a2"] == 0 for c in g["curves"])
    return labels, bs


def run_rcount(bases, bs):
    """bases: list of S lists of 16 ints; bs: list of C ints -> counts[C, S, 9] (k=8..16)."""
    S, C = len(bases), len(bs)
    lines = [str(S)] + [" ".join(format(v, "x") for v in B) for B in bases] + [str(C)] + [format(b, "x") for b in bs]
    tmpdir = os.environ.get("TMPDIR", HERE)
    with tempfile.NamedTemporaryFile("w", dir=tmpdir, suffix=".job", delete=False) as fh:
        fh.write("\n".join(lines) + "\n")
        path = fh.name
    try:
        out = subprocess.run([RCOUNT, "count"], stdin=open(path), capture_output=True, text=True, check=True).stdout
    finally:
        os.unlink(path)
    arr = np.zeros((C, S, 9), dtype=np.int64)
    for line in out.split("\n"):
        if not line:
            continue
        p = list(map(int, line.split()))
        arr[p[0], p[1], :] = p[2:]
    return arr


def log2_targets(b):
    """Codex Run-08 uniform-tag model, without the common log2(N-1) term (cancels in ratios and in argmin)."""
    return math.log2(math.ceil(1.10 * b)) - math.log2(4 * math.comb(b, 4))


_LT = {}
def lt_array(counts):
    """vectorised log2_targets on an int array (memoised per value)."""
    flat = counts.ravel()
    out = np.empty(flat.shape, dtype=np.float64)
    for i, v in enumerate(flat.tolist()):
        r = _LT.get(v)
        if r is None:
            r = _LT[v] = log2_targets(v)
        out[i] = r
    return out.reshape(counts.shape)


def select(counts):
    """counts[C, S, 9]. Each curve keeps the candidate minimising sum_{k=8,9,10} log targets
    (first index on exact ties; Codex's ANF tie-breaks are not modelled).
    Returns chosen index per curve, chosen log-target matrix [C, 9], and #curves with an exact tie."""
    LT = lt_array(counts)
    obj = LT[:, :, 0:3].sum(axis=2)
    choice = obj.argmin(axis=1)
    mins = obj.min(axis=1)
    ties = int(sum(int(np.sum(np.isclose(obj[c], mins[c], rtol=0, atol=1e-12))) > 1 for c in range(obj.shape[0])))
    chosen = LT[np.arange(LT.shape[0]), choice, :]
    return choice, chosen, ties


def ratios_vs_e0(chosen, e0_index=0):
    """attempt ratios of every non-E0 curve vs optimised E0, per k -> [C-1, 9]"""
    r = 2.0 ** (chosen - chosen[e0_index][None, :])
    return np.delete(r, e0_index, axis=0)
