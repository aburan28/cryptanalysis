"""Independent check of the counting predicate: for a few (curve, candidate) pairs, count x in V_k\\{0}
(k=8,9) for which Sage finds a rational point with that abscissa (E.lift_x), and compare to rcount."""
import json, numpy as np
from sage.all import GF, PolynomialRing, EllipticCurve
import rc
PR = PolynomialRing(GF(2), 't'); t = PR.gen()
F = GF(2**131, name='z', modulus=t**131 + t**13 + t**2 + t + 1)
labels, bs = rc.load_curves()
cands = json.load(open("codex_candidates16.json")); cids = [c["candidate_id"] for c in cands]
counts = np.load("codex_family_real_curves_counts.npy")
out = []
for lab, cid in [("E0", "random-29"), ("B002", "random-19"), ("A073", "poly"), ("B130", "scale-07")]:
    c = labels.index(lab); s = cids.index(cid)
    b = F.from_integer(bs[c]); E = EllipticCurve(F, [1, 0, 0, 0, b])
    basis = [F.from_integer(int(v)) for v in cands[s]["basis"]]
    res = {}
    for k in (8, 9):
        n = 0
        for m in range(1, 1 << k):
            x = sum((basis[i] for i in range(k) if (m >> i) & 1), F(0))
            try:
                E.lift_x(x); n += 1
            except ValueError:
                pass
        res[k] = (n, int(counts[c, s, k - 8]))
    out.append({"curve": lab, "cand": cid, "sage_liftx_vs_rcount": res})
    print(out[-1], flush=True)
json.dump(out, open("check_predicate_sage.json", "w"), indent=1)
