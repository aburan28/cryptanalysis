"""Exact-count null replicas of the Codex Run-08 selection protocol.
usage: python3 sim.py VARIANT START COUNT OUTPREFIX
VARIANT:
  N1  E0 = real (b=1); 262 descendants = random b (Tr(b)=1, like the real floor); 64 fresh random nested 16-dim subspaces
  N2  all 263 real curves (ground truth b); 64 fresh random nested 16-dim subspaces
  N3  E0 = real (b=1); 262 random b; Codex's fixed 64 candidates  (=> E0 baseline is exactly Codex's actual one)
  N4  263 random b (E0 replaced by a random b too); Codex's fixed 64 candidates
For each replica: per-curve persistent choice (argmin sum_{k=8..10} log targets), then the chosen log-targets
matrix [263, 9] is saved (row 0 = the E0 slot)."""
import json, random, sys, time
import numpy as np
import rc

TMASK = (1 << 0) | (1 << 129)   # Tr(z^i)=1 only for i=0,129 (checked against Sage in gen_testvec.py)
def tr(v): return bin(v & TMASK).count("1") & 1

def rank16(vals):
    rows = []
    for v in vals:
        for r in rows:
            v = min(v, v ^ r)
        if v:
            rows.append(v); rows.sort(reverse=True)
    return len(rows)

def rand_basis(rng):
    while True:
        B = [rng.getrandbits(131) for _ in range(16)]
        if rank16(B) == 16:
            return B

def rand_b(rng):
    while True:
        b = rng.getrandbits(131)
        if b and tr(b) == 1:
            return b

variant, start, count, outp = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
labels, real_bs = rc.load_curves()
assert all(tr(b) == 1 for b in real_bs), "real curves not all Tr(b)=1"
codex = [[int(v) for v in c["basis"]] for c in json.load(open("codex_candidates16.json"))]
chosen_all, ties_all, choice_all = [], [], []
t0 = time.time()
for rep in range(start, start + count):
    rng = random.Random(f"C2-recompute:{variant}:{rep}")
    if variant in ("N1", "N2"):
        bases = [rand_basis(rng) for _ in range(64)]
    else:
        bases = codex
    if variant == "N2":
        bs = real_bs
    elif variant in ("N1", "N3"):
        bs = [1] + [rand_b(rng) for _ in range(262)]
    elif variant == "N4":
        bs = [rand_b(rng) for _ in range(263)]
    counts = rc.run_rcount(bases, bs)
    choice, chosen, ties = rc.select(counts)
    chosen_all.append(chosen.astype(np.float64)); ties_all.append(ties); choice_all.append(choice)
np.savez_compressed(outp, chosen=np.array(chosen_all), ties=np.array(ties_all), choice=np.array(choice_all),
                    reps=np.arange(start, start + count))
print(json.dumps({"variant": variant, "start": start, "count": count, "seconds": time.time() - t0}), flush=True)
