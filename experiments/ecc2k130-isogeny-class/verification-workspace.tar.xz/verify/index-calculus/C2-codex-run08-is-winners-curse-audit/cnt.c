/* Exact rational-x counts over nested F2-subspaces of GF(2^131), Codex Run-08 protocol.
 *
 * Field GF(2)[z]/(z^131 + z^13 + z^2 + z + 1), bit i = z^i.
 * For curve y^2 + xy = x^3 + b and x != 0 the x lifts to a rational point iff Tr(x + b/x^2) = 0.
 * Codex count b_k = #{x in V_k \ {0} : Tr(x + b/x^2) = 0}, V_k = span(first k basis vectors).
 *
 * Tr(x + b u) with u = 1/x^2 = parity(tmask & x) ^ parity(L_b & u), L_b bit i = Tr(b z^i).
 * Per subspace we store u in 131 bit-planes over the 2^16 enumeration masks (mask m <-> x = sum of
 * basis[i] for bits i of m), so one curve costs XOR of the planes selected by L_b.
 *
 * Modes:
 *   cnt repro BASES CURVES OUT         all counts k=1..16 for every (curve, candidate)
 *   cnt null  BASES CURVES OUT R SEED SUBMODE E0MODE
 *        SUBMODE: codex (the 64 subspaces from BASES, fixed) | fresh (64 new random subspaces/replica)
 *        E0MODE : fixed (curve 0 = b from CURVES line 1, i.e. E0 b=1) | random
 *        descendants 1..262: fresh uniform b with Tr(b) = 1 each replica.
 *        Output per replica, per curve: selected candidate + counts k=8..16 of that candidate,
 *        and (for the first 2 replicas) nothing else.  Selection: argmin_c sum_{k=8,9,10} LT(b_k),
 *        LT(b) = log2(ceil(1.1 b)) - log2(4 C(b,4))  (Codex screen_subspaces.py; N cancels).
 *   cnt selftest
 */
#include <arm_neon.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { uint64_t w[3]; } fe;
#define NB 16
#define NM (1u << NB)
#define NW (NM / 64)
#define NCAND 64
#define NCURVE 263

static inline void clmul(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
  poly128_t r = vmull_p64((poly64_t)a, (poly64_t)b);
  uint64x2_t v = vreinterpretq_u64_p128(r);
  *lo = vgetq_lane_u64(v, 0);
  *hi = vgetq_lane_u64(v, 1);
}

static inline fe reduce6(const uint64_t p[6]) {
  uint64_t h0 = (p[2] >> 3) | (p[3] << 61), h1 = (p[3] >> 3) | (p[4] << 61), h2 = (p[4] >> 3) | (p[5] << 61);
  uint64_t l0 = p[0], l1 = p[1], l2 = p[2] & 7;
  /* t = H ^ H<<1 ^ H<<2 ^ H<<13 (H < 2^128+..: h2 small) */
  uint64_t t0 = h0 ^ (h0 << 1) ^ (h0 << 2) ^ (h0 << 13);
  uint64_t t1 = h1 ^ ((h1 << 1) | (h0 >> 63)) ^ ((h1 << 2) | (h0 >> 62)) ^ ((h1 << 13) | (h0 >> 51));
  uint64_t t2 = h2 ^ ((h2 << 1) | (h1 >> 63)) ^ ((h2 << 2) | (h1 >> 62)) ^ ((h2 << 13) | (h1 >> 51));
  l0 ^= t0; l1 ^= t1; l2 ^= t2;
  uint64_t ov = l2 >> 3;
  l2 &= 7;
  l0 ^= ov ^ (ov << 1) ^ (ov << 2) ^ (ov << 13);
  fe r = {{l0, l1, l2}};
  return r;
}

static inline fe fmul(fe a, fe b) {
  uint64_t p[6] = {0}, lo, hi;
  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++) {
      clmul(a.w[i], b.w[j], &lo, &hi);
      p[i + j] ^= lo;
      p[i + j + 1] ^= hi;
    }
  return reduce6(p);
}
static inline fe fadd(fe a, fe b) { fe r = {{a.w[0] ^ b.w[0], a.w[1] ^ b.w[1], a.w[2] ^ b.w[2]}}; return r; }
static inline int fzero(fe a) { return !(a.w[0] | a.w[1] | a.w[2]); }
static inline int fone(fe a) { return a.w[0] == 1 && !a.w[1] && !a.w[2]; }
static fe finv(fe a) { /* a^(2^131-2) */
  fe r = a;
  for (int i = 1; i < 130; i++) r = fmul(fmul(r, r), a);
  return fmul(r, r);
}
/* Tr(v): computed generically in selftest; the mask is 2^129 + 1 (checked there). */
static fe TMASK;
static inline int par3(fe a, fe m) {
  return __builtin_parityll((a.w[0] & m.w[0]) ^ (a.w[1] & m.w[1]) ^ (a.w[2] & m.w[2]));
}
static int trace_slow(fe v) {
  fe s = v;
  fe x = v;
  for (int j = 1; j < 131; j++) { x = fmul(x, x); s = fadd(s, x); }
  if (!(fzero(s) || fone(s))) { fprintf(stderr, "trace not in F2\n"); exit(1); }
  return fone(s);
}
static fe zpow(int i) { fe r = {{0, 0, 0}}; r.w[i / 64] = 1ull << (i % 64); return r; }
static fe mulz(fe a) { /* a*z */
  uint64_t p[6] = {a.w[0] << 1, (a.w[1] << 1) | (a.w[0] >> 63), (a.w[2] << 1) | (a.w[1] >> 63), 0, 0, 0};
  return reduce6(p);
}
static fe Lmask(fe b) { /* bit i = Tr(b z^i) */
  fe m = {{0, 0, 0}}, v = b;
  for (int i = 0; i < 131; i++) {
    if (par3(v, TMASK)) m.w[i / 64] |= 1ull << (i % 64);
    v = mulz(v);
  }
  return m;
}

/* ---- parsing decimal big ints ---- */
static fe parse_dec(const char *s) {
  fe r = {{0, 0, 0}};
  for (; *s >= '0' && *s <= '9'; s++) { /* r = r*10 + d over integers (not field) */
    unsigned __int128 c = *s - '0';
    for (int i = 0; i < 3; i++) {
      unsigned __int128 t = (unsigned __int128)r.w[i] * 10 + c;
      r.w[i] = (uint64_t)t;
      c = t >> 64;
    }
  }
  return r;
}

/* ---- RNG ---- */
static uint64_t rs[4];
static uint64_t splitmix(uint64_t *x) {
  uint64_t z = (*x += 0x9e3779b97f4a7c15ull);
  z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ull;
  z = (z ^ (z >> 27)) * 0x94d049bb133111ebull;
  return z ^ (z >> 31);
}
static void seed_rng(uint64_t s) { for (int i = 0; i < 4; i++) rs[i] = splitmix(&s); }
static inline uint64_t rotl(uint64_t x, int k) { return (x << k) | (x >> (64 - k)); }
static uint64_t rnd(void) {
  uint64_t r = rotl(rs[1] * 5, 7) * 9, t = rs[1] << 17;
  rs[2] ^= rs[0]; rs[3] ^= rs[1]; rs[1] ^= rs[2]; rs[0] ^= rs[3]; rs[2] ^= t; rs[3] = rotl(rs[3], 45);
  return r;
}
static fe rnd_fe(void) { fe r = {{rnd(), rnd(), rnd() & 7}}; return r; }

static int rank_fe(const fe *v, int n) {
  fe a[NB + 1];
  memcpy(a, v, n * sizeof(fe));
  int rank = 0;
  for (int bit = 130; bit >= 0 && rank < n; bit--) {
    int w = bit / 64; uint64_t m = 1ull << (bit % 64);
    int p = -1;
    for (int i = rank; i < n; i++) if (a[i].w[w] & m) { p = i; break; }
    if (p < 0) continue;
    fe t = a[rank]; a[rank] = a[p]; a[p] = t;
    for (int i = 0; i < n; i++) if (i != rank && (a[i].w[w] & m)) a[i] = fadd(a[i], a[rank]);
    rank++;
  }
  return rank;
}

/* ---- subspace preparation ---- */
typedef struct {
  uint64_t tx[NW];          /* Tr(x) plane */
  uint64_t pl[131][NW];     /* bit i of u = 1/x^2 */
} sub_t;

static fe *X, *PRE;
static void prepare(sub_t *S, const fe *basis) {
  X[0] = (fe){{0, 0, 0}};
  for (uint32_t m = 1; m < NM; m++) {
    uint32_t low = m & -m;
    X[m] = fadd(X[m ^ low], basis[__builtin_ctz(m)]);
    if (fzero(X[m])) { fprintf(stderr, "dependent basis\n"); exit(1); }
  }
  /* batch inversion of X[1..NM-1] */
  PRE[0] = (fe){{1, 0, 0}};
  for (uint32_t m = 1; m < NM; m++) PRE[m] = fmul(PRE[m - 1], X[m]);
  fe inv = finv(PRE[NM - 1]);
  memset(S, 0, sizeof(*S));
  for (uint32_t m = NM - 1; m >= 1; m--) {
    fe ix = fmul(inv, PRE[m - 1]);
    inv = fmul(inv, X[m]);
    if (m % 4099 == 1 && !fone(fmul(ix, X[m]))) { fprintf(stderr, "inverse check failed\n"); exit(1); }
    fe u = fmul(ix, ix);
    if (par3(X[m], TMASK)) S->tx[m >> 6] |= 1ull << (m & 63);
    for (int w = 0; w < 3; w++) {
      uint64_t bits = u.w[w];
      while (bits) {
        int i = __builtin_ctzll(bits);
        bits &= bits - 1;
        S->pl[w * 64 + i][m >> 6] |= 1ull << (m & 63);
      }
    }
  }
}

/* counts[k] for k = 1..16 (nonzero liftable x in V_k) */
static void count(const sub_t *S, fe L, int *counts) {
  uint64_t acc[NW];
  memcpy(acc, S->tx, sizeof(acc));
  for (int w = 0; w < 3; w++) {
    uint64_t bits = L.w[w];
    while (bits) {
      int i = __builtin_ctzll(bits);
      bits &= bits - 1;
      const uint64_t *p = S->pl[w * 64 + i];
      for (int j = 0; j < NW; j++) acc[j] ^= p[j];
    }
  }
  /* bit m of acc = Tr(x + b u) for x = X[m]; mask 0 (x=0) has acc bit 0 = 0 and is excluded */
  int ones = 0;
  for (int k = 1; k <= 6; k++) {
    uint64_t mk = (k == 6) ? ~0ull : ((1ull << (1 << k)) - 1);
    int o = __builtin_popcountll(acc[0] & mk);
    counts[k] = (1 << k) - o - 1;
  }
  ones = __builtin_popcountll(acc[0]);
  int done = 1;
  for (int k = 7; k <= NB; k++) {
    int upto = 1 << (k - 6);
    for (int j = done; j < upto; j++) ones += __builtin_popcountll(acc[j]);
    done = upto;
    counts[k] = (1 << k) - ones - 1;
  }
}

static double LT(int b) {
  if (b < 4) return INFINITY;
  double c = ceil(1.10 * (double)b);
  return log2(c) - (2.0 + log2((double)b) + log2((double)b - 1) + log2((double)b - 2) + log2((double)b - 3) - log2(24.0));
}

static int read_bases(const char *fn, fe B[NCAND][NB], char ids[NCAND][32]) {
  FILE *f = fopen(fn, "r");
  if (!f) { perror(fn); exit(1); }
  char tok[256];
  for (int c = 0; c < NCAND; c++) {
    if (fscanf(f, "%31s", ids[c]) != 1) { fprintf(stderr, "bases parse\n"); exit(1); }
    for (int i = 0; i < NB; i++) { if (fscanf(f, "%255s", tok) != 1) exit(1); B[c][i] = parse_dec(tok); }
  }
  fclose(f);
  return 0;
}
static void read_curves(const char *fn, fe *b, char lab[NCURVE][16]) {
  FILE *f = fopen(fn, "r");
  if (!f) { perror(fn); exit(1); }
  char tok[256];
  for (int c = 0; c < NCURVE; c++) {
    if (fscanf(f, "%15s %255s", lab[c], tok) != 2) { fprintf(stderr, "curves parse\n"); exit(1); }
    b[c] = parse_dec(tok);
  }
  fclose(f);
}

static void selftest(void) {
  fe tm = {{0, 0, 0}};
  for (int i = 0; i < 131; i++) if (trace_slow(zpow(i))) tm.w[i / 64] |= 1ull << (i % 64);
  printf("tmask words %llu %llu %llu (expect 1, 0, 2 for 2^129+1)\n", (unsigned long long)tm.w[0],
         (unsigned long long)tm.w[1], (unsigned long long)tm.w[2]);
  TMASK = tm;
  seed_rng(1);
  for (int t = 0; t < 200; t++) {
    fe a = rnd_fe(), b = rnd_fe(), c = rnd_fe();
    fe l = fmul(fmul(a, b), c), r = fmul(a, fmul(b, c));
    fe d1 = fmul(a, fadd(b, c)), d2 = fadd(fmul(a, b), fmul(a, c));
    if (memcmp(&l, &r, sizeof l) || memcmp(&d1, &d2, sizeof d1)) { printf("assoc/distrib FAIL\n"); exit(1); }
    if (!fzero(a) && !fone(fmul(a, finv(a)))) { printf("inv FAIL\n"); exit(1); }
    if (trace_slow(a) != par3(a, TMASK)) { printf("trace FAIL\n"); exit(1); }
    fe az = mulz(a), az2 = fmul(a, zpow(1));
    if (memcmp(&az, &az2, sizeof az)) { printf("mulz FAIL\n"); exit(1); }
  }
  /* z^131 = z^13 + z^2 + z + 1 */
  fe z130 = zpow(130), z131 = mulz(z130);
  printf("z^131 words %llu %llu %llu (expect 8199)\n", (unsigned long long)z131.w[0], (unsigned long long)z131.w[1],
         (unsigned long long)z131.w[2]);
  printf("selftest ok\n");
}

int main(int argc, char **argv) {
  if (argc < 2) { fprintf(stderr, "usage\n"); return 1; }
  TMASK = (fe){{1, 0, 2}}; /* 2^129 + 1, verified in selftest and by Sage (gen_inputs.py) */
  if (!strcmp(argv[1], "selftest")) { selftest(); return 0; }
  X = malloc(sizeof(fe) * NM);
  PRE = malloc(sizeof(fe) * NM);
  static fe B[NCAND][NB];
  static char ids[NCAND][32];
  static fe bc[NCURVE];
  static char lab[NCURVE][16];
  read_bases(argv[2], B, ids);
  read_curves(argv[3], bc, lab);
  sub_t *S = malloc(sizeof(sub_t) * NCAND);
  if (!S) { fprintf(stderr, "oom\n"); return 1; }

  if (!strcmp(argv[1], "repro")) {
    for (int c = 0; c < NCAND; c++) prepare(&S[c], B[c]);
    FILE *o = fopen(argv[4], "w");
    for (int v = 0; v < NCURVE; v++) {
      fe L = Lmask(bc[v]);
      for (int c = 0; c < NCAND; c++) {
        int cnt[NB + 1];
        count(&S[c], L, cnt);
        fprintf(o, "%s %s", lab[v], ids[c]);
        for (int k = 1; k <= NB; k++) fprintf(o, " %d", cnt[k]);
        fprintf(o, "\n");
      }
    }
    fclose(o);
    return 0;
  }
  if (!strcmp(argv[1], "null")) {
    int R = atoi(argv[5]);
    uint64_t seed = strtoull(argv[6], 0, 10);
    int fresh = !strcmp(argv[7], "fresh");
    int e0fixed = !strcmp(argv[8], "fixed");
    if (!fresh) for (int c = 0; c < NCAND; c++) prepare(&S[c], B[c]);
    FILE *o = fopen(argv[4], "w");
    for (int r = 0; r < R; r++) {
      seed_rng(seed * 1000003ull + r);
      if (fresh) {
        for (int c = 0; c < NCAND; c++) {
          fe nb[NB];
          do { for (int i = 0; i < NB; i++) nb[i] = rnd_fe(); } while (rank_fe(nb, NB) < NB);
          prepare(&S[c], nb);
        }
      }
      for (int v = 0; v < NCURVE; v++) {
        fe b;
        if (v == 0 && e0fixed) b = bc[0];
        else { b = rnd_fe(); if (!par3(b, TMASK)) b.w[0] ^= 1; }
        fe L = Lmask(b);
        int best = -1; double bl = INFINITY; int bestc[NB + 1];
        for (int c = 0; c < NCAND; c++) {
          int cnt[NB + 1];
          count(&S[c], L, cnt);
          double s = LT(cnt[8]) + LT(cnt[9]) + LT(cnt[10]);
          if (s < bl) { bl = s; best = c; memcpy(bestc, cnt, sizeof cnt); }
        }
        fprintf(o, "%d %d %d", r, v, best);
        for (int k = 8; k <= NB; k++) fprintf(o, " %d", bestc[k]);
        fprintf(o, "\n");
      }
      fflush(o);
    }
    fclose(o);
    return 0;
  }
  return 1;
}
