"""Is the floor's liftable-x density on Codex's 64 subspaces shifted relative to the null?

z(cell) = (b - det - coins/2)/sqrt(coins/4), det = [1 in V_k] (x = 1 is liftable iff Tr(b) = 1, true for
all class curves and all null draws), coins = 2^k - 1 - det.  Only 'poly' contains 1 (checked below).
(a) all 262 x 64 floor cells, per k: mean z, sd z; also per family.
(b) the 262 selected (persistent) candidates: mean z per k, vs the exact null replicas N1 (same
    subspaces, random Tr(b)=1 descendants): percentile of the floor's mean selected z.
Run: python3 meanz_check.py
"""
import glob, json, math
from collections import defaultdict
import numpy as np

HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C2-codex-run08-is-winners-curse-audit:/"
KS = list(range(8, 17))
bases = {}
for line in open(HERE + "codex_bases.txt"):
    f = line.split(); bases[f[0]] = [int(v) for v in f[1:]]


def rank(vs):
    piv = {}
    for v in vs:
        while v:
            p = v.bit_length() - 1
            if p in piv: v ^= piv[p]
            else: piv[p] = v; break
    return len(piv)


one_in = {c: {k: rank(B[:k] + [1]) == k for k in range(1, 17)} for c, B in bases.items()}
print("candidates containing 1 at k=8..16:", sorted({c for c in one_in for k in KS if one_in[c][k]}))
cids = list(bases)


def z(b, cid, k):
    det = 1 if one_in[cid][k] else 0
    coins = (1 << k) - 1 - det
    return (b - det - coins / 2) / math.sqrt(coins / 4)


cnt = defaultdict(dict)
for line in open(HERE + "repro_counts.txt"):
    f = line.split(); cnt[f[0]][f[1]] = [None] + [int(v) for v in f[2:]]
floor = [l for l in cnt if l != "E0"]
sel = json.load(open(HERE + "repro_codex.json"))["selected"]
out = {"all_cells": {}, "selected": {}}
for k in KS:
    Z = np.array([[z(cnt[l][c][k], c, k) for c in cids] for l in floor])
    fam = {f: Z[:, [i for i, c in enumerate(cids) if c.split("-")[0] == f]] for f in ("poly", "scale", "random")}
    out["all_cells"][k] = {"mean_z": float(Z.mean()), "sd_z": float(Z.std(ddof=1)),
                           "se_if_independent": float(1 / math.sqrt(Z.size)),
                           "per_family_mean_z": {f: float(v.mean()) for f, v in fam.items()},
                           "E0_mean_z_over_64": float(np.mean([z(cnt["E0"][c][k], c, k) for c in cids]))}
# null N1: selected-candidate mean z per k (candidate index 0 = poly)
cid_by_idx = cids
null_mean = {k: [] for k in KS}
for fn in sorted(glob.glob(HERE + "runs/N1_*.txt")):
    rows = defaultdict(list)
    for line in open(fn):
        f = [int(v) for v in line.split()]; rows[f[0]].append(f[1:])
    for r, rr in rows.items():
        if len(rr) != 263: continue
        rr = sorted(rr)
        for i, k in enumerate(KS):
            null_mean[k].append(np.mean([z(row[2 + i], cid_by_idx[row[1]], k) for row in rr[1:]]))
for k in KS:
    obs = float(np.mean([z(cnt[l][sel[l]][k], sel[l], k) for l in floor]))
    nm = np.array(null_mean[k])
    out["selected"][k] = {"floor_mean_z_selected": obs, "null_mean": float(nm.mean()), "null_sd": float(nm.std(ddof=1)),
                          "null_5_50_95": [float(np.quantile(nm, a)) for a in (.05, .5, .95)],
                          "P_null_ge_obs": float((nm >= obs).mean()), "replicas": int(nm.size)}
json.dump(out, open(HERE + "meanz_check.json", "w"), indent=1)
for k in KS:
    a, s = out["all_cells"][k], out["selected"][k]
    print("k=%2d all 262x64 cells: mean z %+.4f (se %.4f) sd %.3f fam %s E0 %+.3f | selected: floor %+.3f null %.3f+-%.3f P(null>=obs)=%.3f" % (
        k, a["mean_z"], a["se_if_independent"], a["sd_z"], {f: round(v, 3) for f, v in a["per_family_mean_z"].items()},
        a["E0_mean_z_over_64"], s["floor_mean_z_selected"], s["null_mean"], s["null_sd"], s["P_null_ge_obs"]))
