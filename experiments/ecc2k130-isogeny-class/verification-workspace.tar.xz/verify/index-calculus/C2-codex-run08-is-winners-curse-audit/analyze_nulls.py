"""Compare Codex Run-08's best-descendant ratios with EXACT-count null replicas (cnt null).

N1: Codex's 64 fixed subspaces, E0 = the real E0 (b = 1), 262 random b with Tr(b) = 1
N2: Codex's 64 fixed subspaces, E0 random as well
N3: 64 fresh random nested 16-dim subspaces per replica, all 263 b random
Row format (runs/N?_*.txt): replica curve selected_candidate b_8 ... b_16 (Codex b = nonzero liftable x)
Ratios with Codex's formula (log2 ceil(1.1 b) - log2 4C(b,4); N cancels).
Also: post-hoc 'poly-chooser' statistics (in Run-08 the k=13..16 winners B113, B063 are 2 of the 3
floor curves whose persistent candidate is 'poly'), winner persistence, and a global statistic.
Run: python3 analyze_nulls.py
"""
import glob, json, math
from collections import defaultdict
import numpy as np

HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C2-codex-run08-is-winners-curse-audit:/"
KS = list(range(8, 17))
CODEX = json.load(open(HERE + "repro_codex.json"))
CODEX_BEST = {k: CODEX["per_k"][str(k)]["best"] for k in KS}
CODEX_MED = {k: CODEX["per_k"][str(k)]["median"] for k in KS}
CODEX_Q05 = {k: CODEX["per_k"][str(k)]["q05"] for k in KS}
CODEX_Q95 = {k: CODEX["per_k"][str(k)]["q95"] for k in KS}
LT = np.full((1 << 16) + 1, np.inf)
for b in range(4, (1 << 16) + 1):
    LT[b] = math.log2(math.ceil(1.10 * b)) - math.log2(4 * math.comb(b, 4))


def load(prefix):
    reps = {}
    for fn in sorted(glob.glob(HERE + "runs/%s_*.txt" % prefix)):
        rows = defaultdict(list)
        for line in open(fn):
            f = [int(v) for v in line.split()]
            rows[f[0]].append(f[1:])
        for r, rr in rows.items():
            if len(rr) == 263:
                reps[(fn, r)] = np.array(sorted(rr))
    return list(reps.values())


def stats_for(arrs):
    out = {"replicas": len(arrs)}
    best = {k: [] for k in KS}; med = {k: [] for k in KS}; q05 = {k: [] for k in KS}; q95 = {k: [] for k in KS}
    win_poly = {k: [] for k in KS}
    n_poly, all4_poly, ge3_poly, distinct_winners, sumlog = [], [], [], [], []
    same_cand_any, same_cand_2curves = [], []
    for a in arrs:
        sel = a[:, 1]
        cnt = a[:, 2:]
        lt = LT[cnt]
        r = 2 ** (lt[1:] - lt[0])            # 262 x 9
        wins = r.argmin(axis=0) + 1          # curve index of best per k
        for i, k in enumerate(KS):
            col = r[:, i]
            best[k].append(col.min()); med[k].append(np.median(col))
            q05[k].append(np.quantile(col, .05)); q95[k].append(np.quantile(col, .95))
            win_poly[k].append(sel[wins[i]] == 0)
        n_poly.append(int((sel[1:] == 0).sum()))
        wp = [sel[wins[i]] == 0 for i in range(5, 9)]  # k = 13..16
        all4_poly.append(all(wp)); ge3_poly.append(sum(wp) >= 3)
        wc = {int(wins[i]) for i in range(5, 9)}
        sc = {int(sel[w]) for w in wc}
        same_cand_any.append(len(sc) == 1); same_cand_2curves.append(len(sc) == 1 and len(wc) >= 2)
        distinct_winners.append(len(set(wins.tolist())))
        sumlog.append(float(np.log(r.min(axis=0)).sum()))
    per_k = {}
    for k in KS:
        b = np.array(best[k])
        per_k[k] = {"codex_best": CODEX_BEST[k], "null_best_mean": float(b.mean()),
                    "null_best_5_50_95": [float(np.quantile(b, a)) for a in (.05, .5, .95)],
                    "P_null_best_le_codex": float((b <= CODEX_BEST[k]).mean()),
                    "codex_median": CODEX_MED[k], "P_null_median_le_codex": float((np.array(med[k]) <= CODEX_MED[k]).mean()),
                    "null_median_5_50_95": [float(np.quantile(med[k], a)) for a in (.05, .5, .95)],
                    "codex_q05": CODEX_Q05[k], "P_null_q05_le_codex": float((np.array(q05[k]) <= CODEX_Q05[k]).mean()),
                    "codex_q95": CODEX_Q95[k], "P_null_q95_le_codex": float((np.array(q95[k]) <= CODEX_Q95[k]).mean()),
                    "P_winner_is_poly_chooser": float(np.mean(win_poly[k]))}
    out["per_k"] = per_k
    # global: sum over k of log(best ratio); codex value and its null percentile
    cs = float(sum(math.log(CODEX_BEST[k]) for k in KS))
    out["sum_log_best"] = {"codex": cs, "null_mean": float(np.mean(sumlog)),
                           "P_null_le_codex": float((np.array(sumlog) <= cs).mean())}
    # multiplicity-corrected min percentile over k (rank-based within this null sample)
    B = np.array([best[k] for k in KS]).T  # reps x 9
    ranks = (B[:, None, :] <= B[None, :, :]).mean(axis=0)  # fraction of replicas <= each replica's value
    minp_null = ranks.min(axis=1)
    codex_p = np.array([(B[:, i] <= CODEX_BEST[k]).mean() for i, k in enumerate(KS)])
    out["min_percentile_over_k"] = {"codex_min_p": float(codex_p.min()),
                                    "P_null_minp_le_codex": float((minp_null <= codex_p.min()).mean())}
    out["poly_choosers"] = {"null_mean_count": float(np.mean(n_poly)), "codex_count": 3,
                            "P_all_winners_k13_16_poly_chooser": float(np.mean(all4_poly)),
                            "P_ge3_of_4_winners_k13_16_poly_chooser": float(np.mean(ge3_poly))}
    out["winners_k13_16_share_candidate"] = {"codex": "B113,B063 both poly: yes, 2 distinct curves",
        "P_null_all_same_candidate": float(np.mean(same_cand_any)),
        "P_null_same_candidate_and_ge2_distinct_curves": float(np.mean(same_cand_2curves))}
    out["distinct_winners_k8_16"] = {"codex": 7, "null_mean": float(np.mean(distinct_winners)),
                                     "null_hist": {int(v): int(c) for v, c in zip(*np.unique(distinct_winners, return_counts=True))}}
    return out


res = {}
for prefix in ("N1", "N2", "N3"):
    arrs = load(prefix)
    if not arrs:
        continue
    res[prefix] = stats_for(arrs)
    s = res[prefix]
    print("== %s  replicas %d" % (prefix, s["replicas"]))
    for k in KS:
        p = s["per_k"][k]
        print("  k=%2d codex %.4f  null mean %.4f 5/50/95 %s  P(best<=codex)=%.3f | median P=%.3f q05 P=%.3f q95 P=%.3f | P(win poly-chooser)=%.3f" % (
            k, p["codex_best"], p["null_best_mean"], ["%.4f" % v for v in p["null_best_5_50_95"]], p["P_null_best_le_codex"],
            p["P_null_median_le_codex"], p["P_null_q05_le_codex"], p["P_null_q95_le_codex"], p["P_winner_is_poly_chooser"]))
    print("  sum log best:", s["sum_log_best"], " min-percentile:", s["min_percentile_over_k"])
    print("  poly:", s["poly_choosers"], " distinct winners:", s["distinct_winners_k8_16"])
    print("  k13-16 winners share candidate:", s["winners_k13_16_share_candidate"])
json.dump(res, open(HERE + "null_exact_results.json", "w"), indent=1)
