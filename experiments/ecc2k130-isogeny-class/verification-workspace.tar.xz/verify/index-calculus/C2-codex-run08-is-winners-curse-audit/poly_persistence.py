"""Is Codex's 'poly' subspace special for the floor?  (Run-08 k=13..16 winners B113, B063 both use it.)

Shell statistic per (curve, candidate): split V_16 into the 9 disjoint pieces V_8\\{0}, V_9\\V_8, ...,
V_16\\V_15; zs_j = normalized liftable excess in piece j (null: independent, mean 0, sd 1; for 'poly' the
x = 1 point is deterministic and removed).  Q = sum_j zs_j / 3 (scale-free persistence, null N(0,1)).
Compare, for each of the 64 candidates, the top-2 Q among the 262 floor curves with (a) the other 63
candidates on the real floor and (b) 40 null sets of 262 random Tr(b)=1 curves on the same candidate.
Run: python3 poly_persistence.py
"""
import glob, json, math
from collections import defaultdict
import numpy as np

HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C2-codex-run08-is-winners-curse-audit:/"


def load(fn, skip_first):
    cnt = defaultdict(dict); order = []
    for line in open(fn):
        f = line.split()
        if f[0] not in cnt: order.append(f[0])
        cnt[f[0]][f[1]] = [None] + [int(v) for v in f[2:]]
    labs = order[1:] if skip_first else order
    return cnt, labs


def shells(c, poly):
    det = 1 if poly else 0
    out = []
    n8 = 255 - det
    out.append((c[8] - det - n8 / 2) / math.sqrt(n8 / 4))
    for k in range(9, 17):
        n = 1 << (k - 1)
        out.append(((c[k] - c[k - 1]) - n / 2) / math.sqrt(n / 4))
    return np.array(out)


def qtab(cnt, labs):
    cids = list(cnt[labs[0]])
    Q = {c: np.array([shells(cnt[l][c], c == "poly").sum() / 3 for l in labs]) for c in cids}
    return cids, Q


real, labs = load(HERE + "repro_counts.txt", True)
cids, Qr = qtab(real, labs)
top = {c: sorted(Qr[c])[-2:] for c in cids}
poly_top2 = top["poly"][0]
rank_top2 = sum(1 for c in cids if top[c][0] >= poly_top2)
rank_top1 = sum(1 for c in cids if top[c][1] >= top["poly"][1])
who = [labs[i] for i in np.argsort(Qr["poly"])[-3:]]
null_poly_top1, null_poly_top2, null_any_top2 = [], [], []
null_sd_poly, null_mean_poly = [], []
for fn in sorted(glob.glob(HERE + "runs/randcurves/counts_*.txt")):
    cn, lb = load(fn, True)
    _, Qn = qtab(cn, lb)
    s = sorted(Qn["poly"])
    null_poly_top1.append(s[-1]); null_poly_top2.append(s[-2])
    null_any_top2.append(max(sorted(Qn[c])[-2] for c in Qn))
    null_mean_poly.append(float(Qn["poly"].mean())); null_sd_poly.append(float(Qn["poly"].std(ddof=1)))
res = {"floor_poly_top3_curves": who, "floor_poly_top2_Q": top["poly"],
       "floor_poly_Q_mean_sd": [float(Qr["poly"].mean()), float(Qr["poly"].std(ddof=1))],
       "floor_all_candidates_Q_mean_sd": [float(np.mean([Qr[c].mean() for c in cids])),
                                          float(np.mean([Qr[c].std(ddof=1) for c in cids]))],
       "poly_rank_of_second_largest_Q_among_64_candidates": rank_top2,
       "poly_rank_of_largest_Q_among_64_candidates": rank_top1,
       "floor_max_over_candidates_of_second_largest_Q": float(max(top[c][0] for c in cids)),
       "null_sets": len(null_poly_top1),
       "null_poly_top1_mean_max": [float(np.mean(null_poly_top1)), float(np.max(null_poly_top1))],
       "null_poly_top2_mean_max": [float(np.mean(null_poly_top2)), float(np.max(null_poly_top2))],
       "P_null_poly_top2_ge_floor": float(np.mean(np.array(null_poly_top2) >= top["poly"][0])),
       "null_max_over_64_candidates_of_top2": [float(np.mean(null_any_top2)), float(np.quantile(null_any_top2, .05)),
                                               float(np.quantile(null_any_top2, .95))],
       "null_poly_Q_mean_sd_avg": [float(np.mean(null_mean_poly)), float(np.mean(null_sd_poly))],
       "B113_B063_poly_shell_z": {l: [round(v, 3) for v in shells(real[l]["poly"], True)] for l in ("B113", "B063")}}
json.dump(res, open(HERE + "poly_persistence.json", "w"), indent=1)
for k, v in res.items():
    print(k, v)
