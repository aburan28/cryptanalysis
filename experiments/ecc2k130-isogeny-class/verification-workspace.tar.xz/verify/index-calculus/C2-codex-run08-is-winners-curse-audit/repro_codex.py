"""Re-run Codex Run-08's selection + k=8..16 scaling from our own exact counts (cnt repro).

Formula copied from Codex screen_subspaces.py / scale_all_persistent.py:
  log2 targets = log2(ceil(1.10 b)) + log2(N-1) - log2(4 C(b,4))
  persistent choice per curve = argmin over 64 candidates of (sum_{k=8,9,10} log2 targets,
     max ANF degree, sum ANF terms, candidate_id)   [ANF tie-break needed only on exact ties: checked]
  ratio(curve, k) = 2^(log2 targets(curve) - log2 targets(E0))  with E0 also optimised.
Run: python3 repro_codex.py
"""
import json, math
from collections import defaultdict

HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C2-codex-run08-is-winners-curse-audit:/"
N = 680564733841876926932320129493409985129
cnt = defaultdict(dict)
order = []
for line in open(HERE + "repro_counts.txt"):
    f = line.split()
    lab, cid = f[0], f[1]
    if lab not in cnt:
        order.append(lab)
    cnt[lab][cid] = [None] + [int(v) for v in f[2:]]


def lt(b):
    return math.log2(math.ceil(1.10 * b)) + math.log2(N - 1) - math.log2(4 * math.comb(b, 4))


sel, ties = {}, []
for lab in order:
    sums = sorted((sum(lt(cnt[lab][c][k]) for k in (8, 9, 10)), c) for c in cnt[lab])
    if abs(sums[0][0] - sums[1][0]) < 1e-12:
        ties.append((lab, sums[0], sums[1]))
    sel[lab] = sums[0][1]

res = {"ties_at_minimum": ties, "E0_choice": sel["E0"], "E0_counts_k8_16": cnt["E0"][sel["E0"]][8:17]}
per_k = {}
FLOOR = [l for l in order if l != "E0"]
ratios = {}
for lab in FLOOR:
    ratios[lab] = [2 ** (lt(cnt[lab][sel[lab]][k]) - lt(cnt["E0"][sel["E0"]][k])) for k in range(8, 17)]


def q(v, a):  # numpy default 'linear' quantile
    v = sorted(v); pos = a * (len(v) - 1); lo = int(math.floor(pos)); hi = min(lo + 1, len(v) - 1)
    return v[lo] + (v[hi] - v[lo]) * (pos - lo)


for i, k in enumerate(range(8, 17)):
    col = [(ratios[l][i], l) for l in FLOOR]
    best = min(col)
    vals = [r for r, _ in col]
    per_k[k] = {"best": best[0], "best_curve": best[1], "best_candidate": sel[best[1]],
                "q05": q(vals, .05), "median": q(vals, .5), "q95": q(vals, .95), "max": max(vals)}
res["per_k"] = per_k
from collections import Counter
res["choice_family_counts"] = dict(Counter(sel[l].split("-")[0] for l in FLOOR))
res["n_floor_choosing_poly"] = sum(1 for l in FLOOR if sel[l] == "poly")
res["floor_choosing_poly"] = [l for l in FLOOR if sel[l] == "poly"]
res["selected"] = sel
json.dump(res, open(HERE + "repro_codex.json", "w"), indent=1)
print("ties:", ties)
print("E0 choice", sel["E0"], cnt["E0"][sel["E0"]][8:17])
for k in range(8, 17):
    p = per_k[k]
    print(k, "best %.4f %s %s | q05 %.4f med %.4f q95 %.4f max %.4f" % (p["best"], p["best_curve"], p["best_candidate"],
                                                                       p["q05"], p["median"], p["q95"], p["max"]))
print("families:", res["choice_family_counts"], "poly:", res["floor_choosing_poly"])
