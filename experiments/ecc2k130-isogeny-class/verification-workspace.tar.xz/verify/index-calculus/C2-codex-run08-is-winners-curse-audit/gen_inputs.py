"""Rebuild Codex Run-08's 64 candidate subspaces (16-dim, nested) and the 263 curve b values.

Candidate construction copied from Codex run-08 screen_subspaces.py::candidates() and
scale_finalists.py::extended_basis()/random_basis() (read-only originals in the Codex outputs dir):
  poly      : W^d, d = 0..15
  scale-i   : W^e_i * W^d, e_i = int(sha256("run08-scale:i")) mod (2^131 - 1)
  random-i  : random.Random(int(sha256("run08-random:i"))).getrandbits(131), keep if GF(2)-independent
Field: GF(2)[w]/(w^131 + w^13 + w^2 + w + 1), integer encoding bit i = w^i.
b values from the ground-truth loader (labels E0, A000..A130, B000..B130).
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python gen_inputs.py
"""
import hashlib, random, sys, json
from sage.all import GF, PolynomialRing

sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k

OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C2-codex-run08-is-winners-curse-audit:/"
PR = PolynomialRing(GF(2), 't'); t = PR.gen()
F = GF(2**131, name='w', modulus=t**131 + t**13 + t**2 + t + 1)
W = F.gen()
enc = lambda u: int(u.to_integer())
assert list(F.modulus()) == list(t**131 + t**13 + t**2 + t + 1)
assert int(ecc2k.MODULUS_INT) == (1 << 131) | (1 << 13) | 7


def gf2_rank(values):
    piv = {}
    for v in values:
        while v:
            p = v.bit_length() - 1
            if p in piv:
                v ^= piv[p]
            else:
                piv[p] = v
                break
    return len(piv)


def random_basis(index, size):
    seed = int.from_bytes(hashlib.sha256(f"run08-random:{index}".encode()).digest(), "big")
    rng = random.Random(seed)
    vals = []
    while len(vals) < size:
        c = rng.getrandbits(131)
        if gf2_rank(vals + [c]) == len(vals) + 1:
            vals.append(c)
    return vals


cands = [("poly", [enc(W**d) for d in range(16)])]
for i in range(31):
    e = int.from_bytes(hashlib.sha256(f"run08-scale:{i}".encode()).digest(), "big") % ((1 << 131) - 1)
    s = W**e
    cands.append((f"scale-{i:02d}", [enc(s * W**d) for d in range(16)]))
for i in range(32):
    cands.append((f"random-{i:02d}", random_basis(i, 16)))
assert len(cands) == 64
for cid, B in cands:
    assert gf2_rank(B) == 16, cid

with open(OUT + "codex_bases.txt", "w") as f:
    for cid, B in cands:
        f.write(cid + " " + " ".join(str(v) for v in B) + "\n")

with open(OUT + "curves.txt", "w") as f:
    for l in ecc2k.LABELS:
        f.write(l + " " + ecc2k.RECORDS[l]["b_int"] + "\n")

# trace mask and a slow direct Sage recount for a few cells (cross-check of the C counter)
tmask = sum(1 << i for i in range(131) if int((W**i).trace()))
checks = []
for lab, cid in [("E0", "random-29"), ("B062", "random-16"), ("B113", "poly"), ("B002", "random-19"),
                 ("A035", "scale-24"), ("B094", "scale-15")]:
    B = dict(cands)[cid]
    b = F.from_integer(int(ecc2k.RECORDS[lab]["b_int"]))
    basis = [F.from_integer(v) for v in B[:12]]
    vals = [F.zero()] * (1 << 12)
    cnt = {}
    c = 0
    for m in range(1, 1 << 12):
        low = m & -m
        vals[m] = vals[m ^ low] + basis[low.bit_length() - 1]
    for m in range(1, 1 << 12):
        x = vals[m]
        if int((x + b / (x * x)).trace()) == 0:
            c += 1
        if (m + 1) & m == 0:  # m = 2^k - 1
            cnt[(m + 1).bit_length() - 1] = c
    checks.append({"curve": lab, "candidate": cid, "counts_k1_12_excl_x0": [cnt[k] for k in range(1, 13)]})
json.dump({"tmask": str(tmask), "sage_direct_counts": checks}, open(OUT + "sage_crosscheck.json", "w"), indent=1)
print("tmask", tmask)
for c in checks:
    print(c)
