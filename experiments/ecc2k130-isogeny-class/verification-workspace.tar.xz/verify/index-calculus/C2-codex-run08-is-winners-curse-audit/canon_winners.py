"""Canonical V (= Codex 'poly'): best ratio per k vs E0 on the same V, winners, and the null
distribution of winner persistence on ONE fixed nested subspace (40 random-curve sets x 64 candidates).
Run: python3 canon_winners.py
"""
import glob, json, math
from collections import defaultdict, Counter
import numpy as np
HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C2-codex-run08-is-winners-curse-audit:/"
KS = range(8, 17)
t = lambda b: math.ceil(1.10 * b) / (4 * math.comb(b, 4))
def load(fn):
    cnt = defaultdict(dict); order = []
    for line in open(fn):
        f = line.split()
        if f[0] not in cnt: order.append(f[0])
        cnt[f[0]][f[1]] = [None] + [int(v) for v in f[2:]]
    return cnt, order
real, order = load(HERE + "repro_counts.txt")
floor = order[1:]
res = {"canon": {}}
wins = []
for k in KS:
    r = {l: t(real[l]["poly"][k]) / t(real["E0"]["poly"][k]) for l in floor}
    w = min(r, key=r.get); wins.append(w)
    res["canon"][k] = {"best": r[w], "winner": w}
    print(k, "%.4f" % r[w], w)
res["canon_distinct_winners"] = len(set(wins)); res["canon_max_wins_one_curve"] = max(Counter(wins).values())
dist, mx = [], []
for fn in sorted(glob.glob(HERE + "runs/randcurves/counts_*.txt")):
    cn, od = load(fn)
    labs = od[1:]
    for c in cn[labs[0]]:
        ws = [max(labs, key=lambda l: cn[l][c][k]) for k in KS]   # max count = min targets
        dist.append(len(set(ws))); mx.append(max(Counter(ws).values()))
dist, mx = np.array(dist), np.array(mx)
res["null_single_subspace"] = {"samples": int(dist.size), "distinct_winners_mean": float(dist.mean()),
    "P_distinct_le_obs": float((dist <= res["canon_distinct_winners"]).mean()),
    "max_wins_mean": float(mx.mean()), "P_maxwins_ge_obs": float((mx >= res["canon_max_wins_one_curve"]).mean()),
    "distinct_hist": {int(a): int(b) for a, b in zip(*np.unique(dist, return_counts=True))}}
print(json.dumps({k: v for k, v in res.items() if k != "canon"}, indent=1))
json.dump(res, open(HERE + "canon_winners.json", "w"), indent=1)
