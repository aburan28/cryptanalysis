#!/bin/bash
# N1: Codex's 64 fixed subspaces, E0 fixed (b=1), 262 random b (Tr b = 1)   10 x 100 replicas
# N2: Codex's 64 fixed subspaces, E0 random too                              10 x 100 replicas
# N3: 64 fresh random nested 16-dim subspaces per replica, E0 random         10 x 50 replicas
export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
cd "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C2-codex-run08-is-winners-curse-audit:/"
for s in $(seq 1 10); do
  timeout 2400 ./cnt null codex_bases.txt curves.txt runs/N1_$s.txt 100 $((1000+s)) codex fixed &
done
wait
for s in $(seq 1 10); do
  timeout 2400 ./cnt null codex_bases.txt curves.txt runs/N2_$s.txt 100 $((2000+s)) codex random &
done
wait
for s in $(seq 1 10); do
  timeout 2400 ./cnt null codex_bases.txt curves.txt runs/N3_$s.txt 50 $((3000+s)) fresh random &
done
wait
echo ALLDONE
