"""Later-shell excess vs selection rank (real floor, Codex's 64 candidates, exact counts).
For each floor curve rank the 64 candidates by Codex's score sum_{k=8,9,10} log2 targets (rank 1 =
persistent choice).  w(10->K) = normalized excess of liftable x in V_K minus V_10 (null: mean 0, sd 1,
independent of the selection).  Report mean w per rank group, and z_K of the chosen cells.
Run: python3 rank_shell_check.py
"""
import math, json, numpy as np
from collections import defaultdict
HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C2-codex-run08-is-winners-curse-audit:/"
N = 680564733841876926932320129493409985129
cnt = defaultdict(dict)
for line in open(HERE + "repro_counts.txt"):
    f = line.split(); cnt[f[0]][f[1]] = [None] + [int(v) for v in f[2:]]
floor = [l for l in cnt if l != "E0"]
lt = lambda b: math.log2(math.ceil(1.10 * b)) + math.log2(N - 1) - math.log2(4 * math.comb(b, 4))
groups = {"rank1": (0, 1), "rank2": (1, 2), "rank3-4": (2, 4), "rank5-8": (4, 8), "rank9-16": (8, 16), "rank17-64": (16, 64)}
res = {}
for K in (11, 12, 13, 14, 16):
    acc = {g: [] for g in groups}
    for l in floor:
        order = sorted(cnt[l], key=lambda c: sum(lt(cnt[l][c][k]) for k in (8, 9, 10)))
        for g, (a, b) in groups.items():
            for c in order[a:b]:
                shell = cnt[l][c][K] - cnt[l][c][10]
                n = (1 << K) - (1 << 10)
                acc[g].append((shell - n / 2) / math.sqrt(n / 4))
    res[K] = {g: {"mean_w": float(np.mean(v)), "se": float(1 / math.sqrt(len(v))), "n": len(v)} for g, v in acc.items()}
    print("shell 10->%d: " % K + "  ".join("%s %+.3f(se %.3f)" % (g, r["mean_w"], r["se"]) for g, r in res[K].items()))
json.dump(res, open(HERE + "rank_shell_check.json", "w"), indent=1)
