"""Independent re-implementation of the binomial null replica of Codex Run-08 (cheap, many replicas).

B-uncond : every curve (E0 included) and candidate: b_8 ~ Bin(255,1/2), b_{k+1} = b_k + Bin(2^k,1/2)
           (b = nonzero liftable x count; Codex's b).  E0 selected like every curve.
B-cond   : same, but E0 fixed at its actual Run-08 choice random-29 with the exact counts from our
           own C counter: 143 275 522 1026 2073 4107 8245 16494 32933 (k=8..16).
Selection: argmin_c sum_{k=8,9,10} LT(b), LT = log(ceil(1.1 b)) - log(4 C(b,4)) (Codex formula).
Run: python3 binom_replica.py
"""
import json, math
import numpy as np

HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/index-calculus/C2-codex-run08-is-winners-curse-audit:/"
rng = np.random.default_rng(424242)
KS = list(range(8, 17))
E0_ACT = dict(zip(KS, [143, 275, 522, 1026, 2073, 4107, 8245, 16494, 32933]))
CODEX_BEST = {8: 0.7075, 9: 0.8088, 10: 0.7429, 11: 0.7891, 12: 0.8874, 13: 0.9043, 14: 0.9447, 15: 0.9716, 16: 0.9766}
LT = np.full((1 << 16) + 1, np.inf)
for b in range(4, (1 << 16) + 1):
    LT[b] = math.log(math.ceil(1.10 * b)) - math.log(4 * math.comb(b, 4))

NC, NS, REPS = 263, 64, 4000
out = {}
for mode in ("uncond", "cond"):
    best = {k: [] for k in KS}
    for rep in range(REPS):
        x = rng.binomial(255, 0.5, size=(NC, NS))
        cnt = {8: x}
        for k in range(9, 17):
            x = x + rng.binomial(1 << (k - 1), 0.5, size=(NC, NS))
            cnt[k] = x
        sel = np.argmin(LT[cnt[8]] + LT[cnt[9]] + LT[cnt[10]], axis=1)
        for k in KS:
            ck = cnt[k][np.arange(NC), sel]
            e0 = E0_ACT[k] if mode == "cond" else ck[0]
            best[k].append(float(np.exp(LT[ck[1:]] - LT[e0]).min()))
    res = {}
    for k in KS:
        b = np.array(best[k])
        res[k] = {"mean": float(b.mean()), "q05_50_95": [float(np.quantile(b, a)) for a in (.05, .5, .95)],
                  "P_null_best_le_codex": float((b <= CODEX_BEST[k]).mean())}
    out[mode] = res
    print(mode)
    for k in KS:
        print("  k=%d mean %.4f  5/50/95 %s  P(best<=codex %.4f) = %.3f" % (
            k, res[k]["mean"], ["%.4f" % v for v in res[k]["q05_50_95"]], CODEX_BEST[k], res[k]["P_null_best_le_codex"]))
json.dump({"reps": REPS, "seed": 424242, "results": out}, open(HERE + "binom_replica.json", "w"), indent=1)
