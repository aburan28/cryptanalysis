# RT15 summary numbers, derived only from rt15_core.json, rt15_params_d1200_a30.json, rt15_params_d1200_a29.json
import json, math
core = json.load(open("rt15_core.json")); P30 = json.load(open("rt15_params_d1200_a30.json"))
E0 = core["log2 rho E0 (neg+tau)"]; NEG = core["log2 rho neg only"]; C = math.log2(6.0)
def add(a, b): return math.log2(2**a + 2**b)
best_opt = P30["(ii) best 5 by optimistic model"][0]["best"]["optimistic(ell^g)"]["log2 transport F_q-mults"]
best_rob = P30["(ii) best 3 by Robert-notes model"][0]["best"]["Robert-notes 2.8"]["log2 transport F_q-mults"]
ci = P30["(i) costs"]
rows = {"dim2 optimistic (best a<2^30)": best_opt, "dim2 Robert-notes (best a<2^30)": best_rob,
        "dim4 optimistic (C4 example M)": ci["dim 4 (two squares) | optimistic(ell^g)"]["log2 transport F_q-mults"],
        "dim8 optimistic (C4 example M; Thm 1 as proved)": ci["dim 8 (four squares, Theorem 1 as proved) | optimistic(ell^g)"]["log2 transport F_q-mults"]}
out = {"log2 rho E0": E0, "log2 rho neg-only": NEG, "log2 sqrt p": core["log2 sqrt(p)"]}
for k, T in rows.items():
    Tr = T - C
    tot = add(E0, Tr)
    out[k] = {"log2 transport F_q-mults": T, "log2 transport rho-its": round(Tr, 2),
              "implied 'polylog' factor over sqrt(p), bits (F_q-mults)": round(T - core["log2 sqrt(p)"], 2),
              "log2 total (E0 rho + transport), rho-its": round(tot, 2),
              "saving vs 64.33, bits": round(NEG - tot, 2),
              "extra constant factor (bits) that erases the saving": round(math.log2(2**NEG - 2**E0) - Tr, 2)}
out["transport (rho-its) allowed for >=3-bit / >=2-bit / >0 saving"] = [round(math.log2(2**(NEG-3) - 2**E0), 2),
    round(math.log2(2**(NEG-2) - 2**E0), 2), round(math.log2(2**NEG - 2**E0), 2)]
json.dump(out, open("rt15_summary.json", "w"), indent=1); print(json.dumps(out, indent=1))
