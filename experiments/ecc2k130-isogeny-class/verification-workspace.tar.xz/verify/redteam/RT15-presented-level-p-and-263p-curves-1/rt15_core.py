#!/usr/bin/env sage -python
"""RT15 adversarial check, part 1 (Sage 10.9):
  A. re-derive the constants the idea relies on (t, f, p, N, kronecker(-7,p), h(O_p), orbit sizes,
     log2 sqrt p, rho baselines, pi-scalar on E0[p] and its order r),
  B. characteristic-2 torsion facts that decide whether the Kani/theta machinery of Galbraith's
     Theorem 1 can be instantiated as written (E[2^k] of an ordinary char-2 curve is cyclic),
  C. table of usable odd primes ell for the Kani modulus M (Frobenius type, extension degree d(ell^e)
     over which E[ell^e] is rational, number of Frobenius/End-equivariant, Weil-compatible guesses).
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; timeout 2400 sage -python rt15_core.py
Writes rt15_core.json.
"""
from sage.all import (GF, EllipticCurve, PolynomialRing, ZZ, Integers, Zmod, kronecker, is_prime,
                      factor, log, RR, pi as PI, sqrt, primes, lcm, Mod, set_random_seed, gcd, next_prime)
import json, time, math, sys
T0 = time.time()
set_random_seed(20260924)
out = {}
def rec(k, v):
    out[k] = v
    print(k, "=", v, flush=True)

# ---------------- A. constants ----------------
q = ZZ(2)**131
# Lucas recurrence for the trace of tau^k, #E0(F_2) = 4 -> t1 = 2 + 1 - 4 = -1, tau^2 - t1 tau + 2 = 0
t_prev, t_cur = ZZ(2), ZZ(-1)
for k in range(2, 132):
    t_prev, t_cur = t_cur, (-1)*t_cur - 2*t_prev
t = t_cur
rec("t", str(t))
card = q + 1 - t
N = card // 4
assert card % 4 == 0 and is_prime(N)
rec("N", str(N)); rec("log2 N", float(RR(N).log(2)))
D = t**2 - 4*q
assert D % (-7) == 0
f = ZZ((D // -7)).isqrt(); assert f**2 * (-7) == D
rec("f", str(f)); rec("factor f", str(factor(f)))
p = ZZ(146505763881528721)
assert f == 263*p and ZZ(p).is_prime(proof=True)
rec("log2 p", float(RR(p).log(2)))
rec("log2 sqrt(p)", float(RR(p).log(2)/2))
rec("kronecker(-7,p)", int(kronecker(-7, p)))
rec("kronecker(-7,263)", int(kronecker(-7, 263)))
# h(O_c) = c * prod_{l|c}(1 - (-7/l)/l) * h(O_K) / [O_K^*:O_c^*],  O_K^* = {+-1}
h_p = p - kronecker(-7, p)
h_263p = (263 - kronecker(-7, 263)) * (p - kronecker(-7, p))
rec("h(O_p)", str(h_p)); rec("h(O_263p)", str(h_263p))
rec("h(O_p) mod 131", int(h_p % 131))
rec("log2 h(O_p)", float(RR(h_p).log(2))); rec("log2 h(O_263p)", float(RR(h_263p).log(2)))
rho_E0 = float((RR(PI)*N/(4*131)).sqrt().log(2)); rho_neg = float((RR(PI)*N/4).sqrt().log(2))
rec("log2 rho E0 (neg+tau)", rho_E0); rec("log2 rho neg only", rho_neg)
lam = ((t - f)//2) % p
assert (lam**2 - q) % p == 0
Fp = GF(p)
r = Fp(lam).multiplicative_order()
rec("lambda = (t-f)/2 mod p", str(lam)); rec("r = ord_p(lambda)", str(r)); rec("log2 r", float(RR(r).log(2)))
# Galbraith Thm 4 / Problem B scale and random-search scale for *constructing* a level-p curve
rec("log2 sqrt(q) (Galbraith Thm 4, constructing a descended curve)", 65.5)
rec("log2 (2q/(p+1)) random (b,a2) trials per level-p curve", float(RR(2*q/h_p).log(2)))
rec("log2 (2q/(263(p+1))) random trials per level-p-or-263p curve",
    float(RR(2*q/(h_p + h_263p)).log(2)))
rec("log2 (q/(2*263*p)) [proposer's 2^64.9?]", float(RR(q/(2*263*p)).log(2)))

# ---------------- B. char-2 torsion structure ----------------
Rz = PolynomialRing(GF(2), 'z'); z = Rz.gen()
modpoly = z**131 + z**13 + z**2 + z + 1
K = GF(q, 'z', modulus=modpoly)
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
assert E0.cardinality(extension_degree=1) == card if False else True  # (cardinality known; skip re-count)
Rx = PolynomialRing(K, 'x')
res_B = {}
for m in [2, 4, 8, 3, 9]:
    psi = E0.division_polynomial(m, two_torsion_multiplicity=0)
    psi = Rx(psi)
    rad = psi // psi.gcd(psi.derivative()) if psi.derivative() != 0 else None
    # squarefree part via factor (degrees small)
    fac = psi.factor()
    distinct_x = sum(g.degree() for g, e in fac)
    res_B[str(m)] = {"deg psi_m (no 2-torsion factor)": int(psi.degree()),
                     "distinct x-roots over Fbar (sum of degrees of distinct irreducible factors)": int(distinct_x),
                     "irreducible factor degrees": [int(g.degree()) for g, e in fac],
                     "multiplicities": [int(e) for g, e in fac],
                     "roots (as integers, deg-1 factors)": [str((-g[0]/g[1]).to_integer()) for g, e in fac if g.degree() == 1]}
# number of geometric points of E0[m]: 2-torsion factor x (char 2: 2y + a1 x + a3 = x) adds x = 0
rec("B: division polynomials of E0 over F_q", res_B)
# explicit: E0(F_{q^k})[4] and [2^k] for a few k via group structure over extensions is expensive;
# the Fbar count follows from the separable degree of [2^k] = 2^k for ordinary curves in char 2.
# Check: #E0[2](Fbar) = 1 + #distinct roots of the 2-division factor
psi2 = Rx(E0.division_polynomial(2))
rec("B: 2-division polynomial of E0 (char 2: psi_2 = x)", str(psi2))
# ordinary check: Hasse invariant = a1 = 1 != 0
rec("B: E0 ordinary (a1 != 0, t odd)", bool(t % 2 == 1))

# ---------------- C. table of usable odd primes ----------------
def charpoly_order(ell, e):
    """order of x in (Z/ell^e)[x]/(x^2 - t x + q): order of pi on E[ell^e] when pi acts cyclically"""
    R = Integers(ell**e)
    S = PolynomialRing(R, 'X'); X = S.gen()
    Q = S.quotient(X**2 - R(t)*X + R(q))
    xb = Q(X)
    # the unit group of Q has order dividing ell^(2(e-1)) * (ell^2 - 1) * ell  (safe multiple)
    Mbig = ell**e * (ell**2 - 1)
    o = ZZ(Mbig)
    assert xb**o == 1
    for l_, _ in factor(o):
        while o % l_ == 0 and xb**(o // l_) == 1:
            o //= l_
    return int(o)

def guesses(ell, e, typ):
    """# of Weil-compatible, O_K-equivariant maps E[ell^e] -> E0[ell^e] (= |ker Norm on (O_K/ell^e)^*|)"""
    if typ == "split" or typ == "split-scalar(263)":
        return ell**(e-1) * (ell - 1)
    if typ == "inert":
        return ell**(e-1) * (ell + 1)
    if typ == "ramified":
        # (O_K/7^e)^* has 6*7^(2e-1) elements; the norm maps onto the squares of (Z/7^e)^* (3*7^(e-1))
        return 2 * ell**e
    raise ValueError

table = {}
for ell in primes(3, 1200):
    if ell == 2: continue
    kr = kronecker(-7, ell)
    typ = {1: "split", -1: "inert", 0: "ramified"}[int(kr)]
    if ell == 263:
        typ = "split-scalar(263)"
    row = {"type": typ, "ell mod 4": int(ell % 4)}
    for e in ([1, 2, 3, 4, 5, 6] if ell <= 7 else ([1, 2] if ell < 60 else [1])):
        if ell == 263:
            # pi acts on E[263] and E0[263] as the scalar t/2 = -1 (263 does not divide the conductor
            # of End(E) for E at level 1 or p); E[263^2]: order of pi is 2*263 (not scalar mod 263^2)
            d = 2 if e == 1 else None
            if d is None: continue
        else:
            d = charpoly_order(ell, e)
        row[f"d(ell^{e})"] = d
        row[f"guesses(ell^{e})"] = guesses(ell, e, typ)
    table[int(ell)] = row
rec("C: first 40 table rows", {k: table[k] for k in list(table)[:40]})
json.dump(table, open("rt15_prime_table.json", "w"), indent=1, default=int)
rec("C: #usable odd primes < 1200", len(table))
rec("elapsed_s", round(time.time() - T0, 1))
json.dump(out, open("rt15_core.json", "w"), indent=1, default=str)
