#!/usr/bin/env sage -python
"""RT15 part 2: concrete instantiation and cost of Galbraith's Kani route (ePrint 2024/924 = RNT 11:7
(2025), Theorem 1 with N = p) for transporting a presented level-p curve E to E0.

(i)  The route as PROVED in Theorem 1 (four squares, 8-dim product E^4 x E0^4) and its two-squares
     variant (4-dim), using the C4 audit's example modulus M = 3^3 * (23*29*37*53*71)^2 and the
     complexity statement of Robert's notes (ePrint 2024/406, 'Complexity Analysis 2.8'): an ell-isogeny
     in dimension g costs O(ell^g) ops in the field k' of the kernel points if ell = 1 mod 4 and
     O(ell^{2g}) if ell = 3 mod 4.
(ii) The only dimension for which a characteristic-2 theta-isogeny algorithm exists in the literature we
     have (Robert's notes, lines 114-120: [BCR10b], dimension 2): Kani in dimension 2 needs
     M - p = a^2 (F = [[a, phi^],[-phi, a]] on E x E0).  We search a with M = p + a^2 smooth over
     usable odd primes, split M = M1*M2 (coprime) and cost a table meet-in-the-middle over the
     Frobenius-equivariant, Weil-compatible guesses of phi on E[M1] and on E[M2].
Costs are in F_q-multiplications; F_{q^d} multiplication = d^log2(3) F_q-mults (Karatsuba).
Rho conversion: one rho iteration ~ 6 F_q-mults (Bernstein et al. 'Breaking ECC2K-130':
(I-3M)/batch + 5M + 21S, squarings ~free in normal basis).
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; timeout 2400 sage -python rt15_params.py
"""
from sage.all import ZZ, GF, Integers, factor, is_prime, kronecker, sqrt, RR, PolynomialRing
import json, math, time, itertools
import numpy as np
T0 = time.time()
out = {}
def rec(k, v):
    out[k] = v; print(k, "=", v, flush=True)

p = ZZ(146505763881528721)
tab = {int(k): v for k, v in json.load(open("rt15_prime_table.json")).items()}
LOG3 = math.log2(3)
def Mul(d): return d ** LOG3
C_RHO = 6.0
L_RHO_E0 = 60.80903656396743; L_RHO_NEG = 64.32574806473616
rec("log2 F_q-mults, rho on E0 (2^60.81 its x 6M)", L_RHO_E0 + math.log2(C_RHO))
rec("log2 F_q-mults, rho on level-p E (2^64.33 its x 6M)", L_RHO_NEG + math.log2(C_RHO))

def step_cost(ell, g, d, model):
    if model == "optimistic(ell^g)":
        ops = ell ** g
    else:  # Robert notes Complexity 2.8
        ops = ell ** g if ell % 4 == 1 else ell ** (2 * g)
    return ops * Mul(d)

def d_of(ell, e):
    return tab[ell].get(f"d(ell^{e})")
def g_of(ell, e):
    return tab[ell].get(f"guesses(ell^{e})")

# ---------------- (i) Theorem 1 as proved (g = 4 squares -> dim 8) and 2-squares (dim 4) ----------
S = [23, 29, 37, 53, 71]; n = 3
A = 1
for l in S: A *= l
M = 3**n * A**2; m = M - p
rec("(i) A_S", A); rec("(i) M = 3^3 A_S^2", int(M)); rec("(i) log2 M", float(RR(M).log(2)))
rec("(i) m = M - p", int(m))
# two-squares test
def is_sum_two_squares(x):
    for l, e in factor(ZZ(x)):
        if l % 4 == 3 and e % 2: return False
    return True
rec("(i) m sum of two squares", is_sum_two_squares(m))
G = 1
for l in S: G *= g_of(l, 1)
G3 = g_of(3, 2)  # 3^ceil(n/2) = 9 part of M1
rec("(i) guesses = prod(ell-1) x guesses(9)", int(G * G3)); rec("(i) log2 guesses", math.log2(G * G3))
res_i = {}
for dimname, gdim in [("dim 8 (four squares, Theorem 1 as proved)", 8), ("dim 4 (two squares)", 4)]:
    for model in ["optimistic(ell^g)", "Robert-notes 2.8"]:
        per = 0.0
        for l in S:
            per += 2 * step_cost(l, gdim, d_of(l, 1), model)      # once in F1 and once in F2bar
        per += 3 * step_cost(3, gdim, d_of(3, 2), model)          # 3^2 in F1, 3^1 in F2bar
        tot = math.log2(G * G3) + math.log2(per)
        res_i[f"{dimname} | {model}"] = {"log2 per-guess F_q-mults": round(math.log2(per), 2),
                                         "log2 transport F_q-mults": round(tot, 2),
                                         "log2 transport in rho-iteration units": round(tot - math.log2(C_RHO), 2)}
rec("(i) costs", res_i)

# ---------------- (ii) dimension-2 variant: M = p + a^2 smooth -----------------------------------
import sys
DCAP = int(sys.argv[1]) if len(sys.argv) > 1 else 400
usable = []   # (ell, e, d, guesses)
for ell, row in tab.items():
    for e in range(1, 7):
        d = row.get(f"d(ell^{e})")
        if d is None: break
        if d <= DCAP:
            usable.append((ell, e, d, row[f"guesses(ell^{e})"]))
max_e = {}
for ell, e, d, g in usable:
    max_e[ell] = max(max_e.get(ell, 0), e)
rec("(ii) d cap", DCAP)
rec("(ii) usable prime powers (ell: max e with d(ell^e) <= cap)", max_e)

A_MAX = 1 << (int(sys.argv[2]) if len(sys.argv) > 2 else 26)
target = math.log2(float(p))  # M >= p
CH = 1 << 25
roots = []
for ell, emax in max_e.items():
    for e in range(1, emax + 1):
        q_ = ell ** e
        rts = [x for x in range(q_) if (x * x + int(p)) % q_ == 0]
        for r0 in rts:
            roots.append((q_, (r0 * pow(2, -1, q_)) % q_, math.log2(ell)))
cand_a = []
for start in range(0, A_MAX // 2, CH):          # index i <-> a = 2*i
    n_ = min(CH, A_MAX // 2 - start)
    logs = np.zeros(n_, dtype=np.float32)
    for q_, i0, lg in roots:
        first = (i0 - start) % q_
        logs[first::q_] += lg
    idx = np.nonzero(logs >= target - 0.01)[0]
    cand_a.extend(int(2 * (start + j)) for j in idx)
pmod = int(p)
rec("(ii) a range searched (even a < 2^26)", int(A_MAX // 2))
rec("(ii) sieve candidates", len(cand_a))

def best_split(fac):
    """fac: list of (ell, e). Minimise G1*C1 + G2*C2 over coprime splits, per cost model."""
    best = {}
    items = fac
    for model in ["optimistic(ell^g)", "Robert-notes 2.8"]:
        bb = None
        for mask in range(1, (1 << len(items)) - 1):
            G1 = G2 = 1; C1 = C2 = 0.0; M1 = M2 = 1
            for i, (ell, e) in enumerate(items):
                d = d_of(ell, e); g = g_of(ell, e)
                c = sum(step_cost(ell, 2, d, model) for _ in range(e))
                if mask >> i & 1: G1 *= g; C1 += c; M1 *= ell ** e
                else: G2 *= g; C2 += c; M2 *= ell ** e
            T = G1 * C1 + G2 * C2
            if bb is None or T < bb[0]:
                bb = (T, G1, G2, C1, C2, M1, M2)
        T, G1, G2, C1, C2, M1, M2 = bb
        best[model] = {"log2 transport F_q-mults": round(math.log2(T), 2),
                       "log2 transport rho-iteration units": round(math.log2(T) - math.log2(C_RHO), 2),
                       "log2 G1, G2 (guesses per side)": [round(math.log2(G1), 2), round(math.log2(G2), 2)],
                       "log2 per-guess C1, C2": [round(math.log2(C1), 2), round(math.log2(C2), 2)],
                       "log2 table entries": round(math.log2(min(G1, G2)), 2),
                       "M1": int(M1), "M2": int(M2)}
    return best

hits = []
for aa in cand_a:
    MM = pmod + aa * aa
    rem = MM; fac = []
    ok = True
    for ell in sorted(max_e):
        if rem % ell: continue
        e = 0
        while rem % ell == 0: rem //= ell; e += 1
        if e > max_e[ell]: ok = False; break
        fac.append((ell, e))
    if not ok or rem != 1: continue
    hits.append((aa, MM, fac))
rec("(ii) #a with p + a^2 fully factored over usable prime powers", len(hits))
results = []
for aa, MM, fac in hits:
    b = best_split(fac)
    results.append({"a": aa, "M": int(MM), "log2 M": round(math.log2(MM), 3),
                    "factorisation": " * ".join(f"{l}^{e}" if e > 1 else str(l) for l, e in fac),
                    "check M == p + a^2 and gcd(M, 2p) == 1": bool(MM == pmod + aa * aa and math.gcd(MM, 2 * pmod) == 1),
                    "best": b})
results.sort(key=lambda r: r["best"]["optimistic(ell^g)"]["log2 transport F_q-mults"])
rec("(ii) best 5 by optimistic model", results[:5])
if results:
    results_r = sorted(results, key=lambda r: r["best"]["Robert-notes 2.8"]["log2 transport F_q-mults"])
    rec("(ii) best 3 by Robert-notes model", results_r[:3])
    rec("(ii) min log2 transport (optimistic, Robert-notes)",
        [results[0]["best"]["optimistic(ell^g)"]["log2 transport F_q-mults"],
         results_r[0]["best"]["Robert-notes 2.8"]["log2 transport F_q-mults"]])
rec("elapsed_s", round(time.time() - T0, 1))
json.dump(out, open(f"rt15_params_d{DCAP}_a{int(math.log2(A_MAX))}.json", "w"), indent=1, default=str)
