# RT15 toy (characteristic 2): the guess space of Galbraith's Kani route for an ascending/descending
# isogeny of large prime degree between a crater curve and a floor curve, in the same shape as
# ECC2K-130's level p.
# Toy: E0: y^2+xy=x^3+1 over F_{2^37}; t^2-4q = -7 f^2, f = 73*2663; 73 is INERT in Q(sqrt-7) (as p is),
# E0 is the unique crater curve (h(-7)=1), E1 = E0/<Q0> is a level-73 floor curve, phi: E0 -> E1 of
# degree N = 73.  Kani modulus in dimension 2: M = N + a^2 with M coprime to 2*73.
#   a = 20: M = 473 = 11*43 (both split, Elkies);  a = 2: M = 77 = 7*11 (7 ramified).
# For every ell | M we verify on explicit torsion (over F_{q^d(ell)}):
#   (1) phi is pi-equivariant: it sends E0[ell] into E1[ell] commuting with pi (no 73-torsion is used);
#   (2) the pi-equivariant maps E0[ell] -> E1[ell] satisfying the Weil condition
#       e(u P, u pi P) = e(P, pi P)^N are exactly |ker Norm| many (ell-1 split, ell+1 inert, 2*ell ramified),
#       and the true phi|E0[ell] is one of them;
#   (3) every such candidate u gives a subgroup K_u = {([a]P, u(P))} of (E0 x E1)[ell] that is isotropic
#       for the product Weil pairing (so isotropy does not prune the candidates; only running the
#       2-dim isogeny can), while a random non-Weil-compatible equivariant map does not.
# Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; timeout 2400 sage rt15_toy.sage
import json, time
T0 = time.time(); set_random_seed(int(20260924))
out = {}
def rec(k, v):
    out[k] = v; print(k, "=", v, flush=True)
m = 37; q = 2^m
t0, t1 = 2, -1
for k in range(1, m): t0, t1 = t1, -t1 - 2*t0
t = t1
f = isqrt((4*q - t^2)//7); assert -7*f^2 == t^2 - 4*q
L = 73; assert f % L == 0 and kronecker(-7, L) == -1
rec("toy t", t); rec("toy f", str(factor(f)))
def tk(k):
    a_, b_ = 2, t
    for _ in range(k - 1): a_, b_ = b_, t*b_ - q*a_
    return b_ if k >= 1 else 2
c = GF(L)(t)/2; r = c.multiplicative_order()
rec("toy: order r of pi-scalar c = t/2 on E0[73]", r)
K37.<g> = GF(2^m)
E0 = EllipticCurve(K37, [1, 0, 0, 0, 1]); assert E0.order() == q + 1 - t
# ---- build phi: E0 -> E1 (degree 73) from a 73-torsion point over F_{q^r} ----
Kr.<zr> = GF(2^(m*r))
rts = K37.modulus().change_ring(Kr).roots(multiplicities=False)
embr = K37.hom([rts[0]], Kr); secr = embr.section()
E0r = EllipticCurve(Kr, [embr(ai) for ai in E0.a_invariants()])
Nr = q^r + 1 - tk(r); vr = valuation(Nr, L)
while True:
    Q0 = (Nr // L^vr) * E0r.random_point()
    if Q0.is_zero(): continue
    while not (L*Q0).is_zero(): Q0 = L*Q0
    break
Rr.<X> = Kr[]
h = prod(X - (k*Q0)[0] for k in range(1, (L - 1)//2 + 1))
h0 = PolynomialRing(K37, 'X')([secr(co) for co in h.list()])
phi = E0.isogeny(h0); E1 = phi.codomain()
assert phi.degree() == L and E1.order() == E0.order() and E1.j_invariant() != 1
rec("toy: phi degree", phi.degree()); rec("toy: j(E1) in F_2 ?", E1.j_invariant() in [0, 1])
rec("toy: build phi seconds", round(time.time() - T0, 1))
Xm, Ym = phi.rational_maps()

def dord(l):
    R = GF(l); S.<Z> = R[]; Qq = S.quotient(Z^2 - R(t)*Z + R(q)); xb = Qq(Z)
    o = l*(l^2 - 1)
    for pp, _ in factor(o):
        while o % pp == 0 and xb^(o//pp) == 1: o //= pp
    return o

def analyse(ell, a):
    typ = {1: "split", -1: "inert", 0: "ramified"}[kronecker(-7, ell)]
    d = dord(ell)
    Kd = GF(2^(m*d), 'w')
    rt = K37.modulus().change_ring(Kd).roots(multiplicities=False)[0]
    emb = K37.hom([rt], Kd)
    Ea = EllipticCurve(Kd, [emb(ai) for ai in E0.a_invariants()])
    Eb = EllipticCurve(Kd, [emb(ai) for ai in E1.a_invariants()])
    Nd = q^d + 1 - tk(d); v = valuation(Nd, ell)
    def frob(P):
        return P.curve()(P[0]^q, P[1]^q) if not P.is_zero() else P
    def gen_module(E):   # a point P of order ell with P, pi(P) independent (F_ell[pi]-generator)
        while True:
            P = (Nd // ell^v) * E.random_point()
            if P.is_zero(): continue
            while not (ell*P).is_zero(): P = ell*P
            if P.weil_pairing(frob(P), ell) != 1:
                return P
    P = gen_module(Ea); R = gen_module(Eb)
    # evaluate phi (rational maps over F_q) on P and pi(P)
    def phi_ev(Pt):
        x, y = Pt.xy()
        Xe = Xm.numerator()(x, y) / Xm.denominator()(x, y) if hasattr(Xm, 'numerator') else Xm(x, y)
        Ye = Ym.numerator()(x, y) / Ym.denominator()(x, y)
        return Eb(Xe, Ye)
    # map coefficients of the rational maps into Kd
    Rxy = PolynomialRing(Kd, ['x', 'y'])
    def lift(poly):
        return Rxy({e: emb(cf) for e, cf in poly.dict().items()})
    Xn, Xdn = lift(Xm.numerator()), lift(Xm.denominator())
    Yn, Ydn = lift(Ym.numerator()), lift(Ym.denominator())
    def phi_ev(Pt):
        x, y = Pt.xy()
        return Eb(Xn(x, y)/Xdn(x, y), Yn(x, y)/Ydn(x, y))
    phiP = phi_ev(P); phipiP = phi_ev(frob(P))
    equivariant = (phipiP == frob(phiP))
    zeta = P.weil_pairing(frob(P), ell)          # primitive ell-th root of unity
    rhs = zeta^L
    base = R.weil_pairing(frob(R), ell)
    # coordinates of phi(P) in the basis (R, pi R) via pairings: phi(P) = x R + y pi R
    def coords(S):
        e1 = S.weil_pairing(frob(R), ell)   # = base^x
        e2 = R.weil_pairing(S, ell)         # = base^y
        x = next(i for i in range(ell) if base^i == e1)
        y = next(i for i in range(ell) if base^i == e2)
        return x, y
    xt, yt = coords(phiP)
    assert phiP == xt*R + yt*frob(R)
    # all pi-equivariant candidates u_{x,y}: P -> xR + y piR; Weil condition e(uP, u piP) = rhs
    cands = []
    for x in range(ell):
        for y in range(ell):
            if x == 0 and y == 0: continue
            S = x*R + y*frob(R)
            if S.weil_pairing(frob(S), ell) == rhs:
                cands.append((x, y))
    true_in = (xt, yt) in cands
    # isotropy of K_u = {([a]T, u(T)) : T in E0[ell]} under the product Weil pairing, generated by
    # (aP, uP) and (a piP, pi uP):  e(aP, a piP) * e(uP, pi uP) = zeta^(a^2) * e(uP, pi uP)
    def isotropic(S):
        return (zeta^(a^2)) * S.weil_pairing(frob(S), ell) == 1
    iso_all = all(isotropic(x*R + y*frob(R)) for x, y in cands)
    noncands = [(x, y) for x in range(ell) for y in range(ell) if (x, y) != (0, 0) and (x, y) not in cands]
    import random as _r; _r.seed(int(ell))
    sample = _r.sample(noncands, min(20, len(noncands)))
    iso_non = sum(1 for x, y in sample if isotropic(x*R + y*frob(R)))
    expected = {"split": ell - 1, "inert": ell + 1, "ramified": 2*ell}[typ]
    return {"type": typ, "d (F_{q^d} holds E[ell])": int(d), "phi pi-equivariant on E0[ell]": bool(equivariant),
            "#Weil-compatible equivariant candidates": len(cands), "expected |ker Norm|": int(expected),
            "true phi among candidates": bool(true_in), "all candidates isotropic (M = 73 + a^2)": bool(iso_all),
            "isotropic among 20 non-compatible equivariant maps": int(iso_non),
            "seconds": round(time.time() - T0, 1)}

res = {}
for a, M in [(20, 473), (2, 77)]:
    assert M == L + a^2 and gcd(M, 2*L) == 1
    for ell, _ in factor(M):
        key = f"a={a}, M={M}, ell={ell}"
        res[key] = analyse(ell, a)
        rec(key, res[key])
tot = {a_: prod(res[k]["#Weil-compatible equivariant candidates"] for k in res if k.startswith(f"a={a_},")) for a_ in [20, 2]}
rec("total guesses per M (product over ell | M)", {str(k): int(v) for k, v in tot.items()})
rec("elapsed_s", round(time.time() - T0, 1))
json.dump(out, open("rt15_toy.json", "w"), indent=1, default=str)
