m = 37; q = 2^m
t0, t1 = 2, -1
for k in range(1, m): t0, t1 = t1, -t1 - 2*t0
t = t1; f = isqrt((4*q - t^2)//7); assert -7*f^2 == t^2 - 4*q
print("t", t, "f", factor(f))
def dord(l):
    R = GF(l); S.<X> = R[]; Q = S.quotient(X^2 - R(t)*X + R(q)); xb = Q(X)
    o = l*(l^2-1)
    for pp, _ in factor(o):
        while o % pp == 0 and xb^(o//pp) == 1: o //= pp
    return o
for a in range(2, 80, 2):
    M = 73 + a^2
    fa = factor(M)
    info = [(l, e, kronecker(-7, l), dord(l) if f % l else None) for l, e in fa]
    if all(e == 1 and l < 60 and f % l for l, e in fa):
        print(a, M, info)
