# one-time cost of gamma for the c=81 example: horizontal steps 67, 631, 1877, 5023 need an eigen-point of E1[l]
import json, builtins
q=2^131; tk=[2,-1]
for k in range(2,132): tk.append(-tk[-1]-2*tk[-2])
t=tk[131]
out={}
tot=0
for l in (67,631,1877,5023):
    F=GF(l); X=polygen(F); r=(X^2-t*X+q).roots(multiplicities=False)
    o=sorted(F(x).multiplicative_order() for x in r)
    k=o[0]                                     # use the cheaper eigen-line
    cost=131*k*10*float(k)^1.585 + 2*l*float(k)^1.585   # ladder (10 M/bit) + Velu/kernel poly O(l) in F_{q^k}
    tot+=cost
    out[str(l)]=dict(orders=[int(v) for v in o], cheapest_line_degree=int(k), log2_onetime_Fq_mults=builtins.round(float(log(cost,2)),2))
out['log2_total']=builtins.round(float(log(tot,2)),2)
print(json.dumps(out))
json.dump(out,open('raw/s4_gamma_onetime.json','w'),indent=1)
