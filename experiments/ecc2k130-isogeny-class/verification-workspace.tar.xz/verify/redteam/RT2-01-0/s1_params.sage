# RT2-01 adversarial check, script 1: re-derive every number-theoretic input of the idea.
#  - constants and rho baselines
#  - Elkies primes < 4000, eigenvalue orders, and the FULL E[l] field degree (lcm of both eigen-orders)
#  - order of pi on E[p] (why direct Velu of the p-isogeny is out of reach)
#  - the proposer's example parameter sets (dim 4 two-squares; dim 2 c=81; dim 2 c=3)
#  - kronecker(-7,p), class numbers of the p and 263p levels
import json, sys, math, time
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-01-0/raw/s1_params.json"
res = {}
q = 2^131
tk = [2, -1]
for k in range(2, 132): tk.append(-tk[-1] - 2*tk[-2])
t = ZZ(tk[131]); assert t == ecc2k.t
N = ZZ((q + 1 - t) / 4); assert N == ecc2k.N
f2 = (t^2 - 4*q) / (-7); f = ZZ(isqrt(f2)); assert f^2 == f2 and f == ecc2k.f
p = f // 263; assert p == ecc2k.p and is_prime(p) and is_prime(N)
res['t'] = str(t); res['N'] = str(N); res['p'] = str(p)
res['log2_N'] = float(log(N, 2)); res['log2_p'] = float(log(p, 2))
res['rho_E0_log2_iter'] = float(log(sqrt(pi.n(200) * N / (4 * 131)), 2))
res['rho_neg_only_log2_iter'] = float(log(sqrt(pi.n(200) * N / 4), 2))
res['kron_-7_p'] = int(kronecker(-7, p)); res['kron_-7_263'] = int(kronecker(-7, 263))
hp = p - kronecker(-7, p)            # h(O_p) = h(O_K) * (p - (-7/p)), unit index 1
h263p = 262 * hp
res['h_level_p'] = str(hp); res['h_level_263p'] = str(h263p)
res['log2_levels_p_plus_263p'] = float(log(hp + h263p, 2))
# order of pi on E[p]: pi = (t + f sqrt(-7))/2 == t/2 mod p O_K
a = Mod(t, p) / 2
assert a^2 == Mod(q, p)
fac = factor(p - 1)
res['p_minus_1_factor'] = str(fac)
oa = a.multiplicative_order()
ox = oa // 2 if (oa % 2 == 0 and a^(oa // 2) == -1) else oa
res['ord_p_of_pi_on_Ep'] = str(oa); res['log2_ord'] = float(log(oa, 2))
res['x_degree_Ep'] = str(ox); res['log2_x_degree'] = float(log(ox, 2))
# Elkies primes
t0 = time.time()
elk = []
for l in primes(3, 4000):
    if l in (7, 263): continue
    if kronecker(-7, l) != 1: continue
    F = GF(l); X = polygen(F)
    rts = [r for r, e in (X^2 - t * X + q).roots()]
    assert len(rts) == 2 and rts[0] != rts[1]
    o = [F(r).multiplicative_order() for r in rts]
    ox_ = []
    for r in rts:
        oo = F(r).multiplicative_order()
        ox_.append(oo // 2 if (oo % 2 == 0 and F(r)^(oo // 2) == -1) else oo)
    elk.append(dict(l=int(l), eig=[int(r) for r in rts], ord=[int(x) for x in o], xdeg=[int(x) for x in ox_],
                    max_ord=int(max(o)), full_deg=int(lcm(o)), full_xdeg=int(lcm(ox_))))
res['n_elkies_below_4000'] = len(elk)
res['elkies_table'] = elk
res['elkies_time_s'] = time.time() - t0
# compare with the proposer's table
prop = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/redteam-2/raw/rt2_elkies.json'))
mism = []
tab = {e['l']: e for e in elk}
for l, k, kx in prop['elkies_first_40']:
    e = tab.get(l)
    if e is None or e['max_ord'] != k or max(e['xdeg']) != kx:
        mism.append((l, k, kx, None if e is None else (e['max_ord'], max(e['xdeg']))))
res['proposer_table_mismatches'] = mism
res['primes_where_full_deg_gt_max_ord'] = [(e['l'], e['ord'], e['full_deg']) for e in elk if e['full_deg'] > e['max_ord'] and e['l'] < 400]
# ---- parameter sets ----
def elk_ok(l): return l in tab
def two_sq(m):
    return all(not (l % 4 == 3 and e % 2) for l, e in factor(m))
def phi_(n): return euler_phi(n)
ps = {}
# (a) dim 4 two-squares, c = 1
S = [23, 37, 53, 67, 137]; A = prod(S)
m = A^2 - p
ps['dim4_example'] = dict(A=int(A), primes=S, all_elkies=all(elk_ok(l) for l in S), m=str(m), m_positive=bool(m > 0),
    m_factor=str(factor(m)), m_sum_two_squares=bool(two_sq(m)), gcd_m_p=int(gcd(m, p)), M_odd=bool(A % 2 == 1),
    guesses=str(phi_(A) // 2), log2_guesses=float(log(phi_(A) / 2, 2)),
    max_ord=max(tab[l]['max_ord'] for l in S), full_degs=[tab[l]['full_deg'] for l in S],
    lcm_all_full_degs=int(lcm([tab[l]['full_deg'] for l in S])))
if two_sq(m):
    xs, ys = two_squares(m); ps["dim4_example"]["m_as_x2_plus_y2"] = [int(xs), int(ys)]
# (b) dim 2, c = 81, horizontal gamma
S = [29, 71, 137, 179]; A = prod(S); c = 81
M = c * A^2; m = M - p
fm = factor(m)
kinds = {}
for l, e in fm:
    if l == 2: kinds[str(l)] = ('Frobenius power', int(e)); continue
    kinds[str(l)] = ('split' if kronecker(-7, l) == 1 else ('ramified' if l == 7 else 'inert'), int(e))
cg = 4 * 3^((4 + 1)//2 - 1)     # c-part guesses (proposer's formula for c = 3^4)
ps['dim2_c81_example'] = dict(A=int(A), primes=S, all_elkies=all(elk_ok(l) for l in S), M=str(M), m=str(m),
    m_factor=str(fm), prime_kinds=kinds, inert_even=all(e % 2 == 0 for l, e in fm if l != 2 and l != 7 and kronecker(-7, l) == -1),
    phiA_over_2=str(phi_(A) // 2), c_guesses=int(cg), log2_guesses=float(log(phi_(A) / 2 * cg, 2)),
    full_degs=[tab[l]['full_deg'] for l in S], lcm_all_full_degs=int(lcm([tab[l]['full_deg'] for l in S])))
# (c) dim 2, c = 3 example of the cost file
S = [11, 23, 79, 107, 109]; A = prod(S); c = 3
M = c * A^2; m = M - p
fm = factor(m)
kinds = {}
for l, e in fm:
    if l == 2: kinds[str(l)] = ('Frobenius power', int(e)); continue
    kinds[str(l)] = ('split' if kronecker(-7, l) == 1 else ('ramified' if l == 7 else 'inert'), int(e))
ps['dim2_c3_example'] = dict(A=int(A), primes=S, all_elkies=all(elk_ok(l) for l in S), M=str(M), m=str(m), m_positive=bool(m > 0),
    m_factor=str(fm), prime_kinds=kinds, inert_even=all(e % 2 == 0 for l, e in fm if l != 2 and l != 7 and kronecker(-7, l) == -1),
    log2_guesses=float(log(phi_(A) / 2 * 4, 2)),
    full_degs=[tab[l]['full_deg'] for l in S], lcm_all_full_degs=int(lcm([tab[l]['full_deg'] for l in S])))
res['param_sets'] = ps
# the order of pi on E[3^2] (inert prime 3, needed for the c = 81 part) and on E[9]
# pi acts on E[3^k] as the image of pi in O_K/3^k (3 does not divide f)
K.<w> = NumberField(polygen(QQ)^2 - polygen(QQ) + 2)          # w = (1+sqrt(-7))/2
OK = K.maximal_order()
pi_K = (t - f) / 2 + f * w
assert pi_K.norm() == q and pi_K.trace() == t
for n in (1, 2):
    I = OK.ideal(3^n)
    Q = OK.quotient(I, 'b') if False else None
    # multiplicative order of pi mod 3^n O_K by brute force over the finite ring
    R = Zmod(3^n)
    # represent pi as matrix on the Z-basis (1, w)
    Mw = matrix(ZZ, [[0, -2], [1, 1]])        # w^2 = w - 2 : multiplication-by-w matrix (columns = images of 1, w)
    Pm = matrix(R, ((t - f) / 2) * identity_matrix(2) + f * Mw)
    o = 1; Pk = Pm
    while Pk != identity_matrix(R, 2):
        Pk *= Pm; o += 1
    res['ord_pi_on_E[3^%d]' % n] = int(o)
json.dump(res, open(OUT, 'w'), indent=1, default=str)
print(json.dumps({k: v for k, v in res.items() if k not in ('elkies_table',)}, indent=1, default=str))
