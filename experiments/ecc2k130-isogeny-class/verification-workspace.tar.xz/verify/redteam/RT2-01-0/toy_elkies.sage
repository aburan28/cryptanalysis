for n in (37, 20):
    tk=[2,-1]
    for k in range(2,200): tk.append(-tk[-1]-2*tk[-2])
    t=tk[n]; q=2^n; f=isqrt((4*q-t^2)/7)
    print('n',n,'t',t,'f',factor(f), '#E0', factor(q+1-t))
    for L in (18, 36, 9, 6, 12):
        out=[]
        for l in primes(3,400):
            if l==7 or f%l==0 or kronecker(-7,l)!=1: continue
            F=GF(l); X=polygen(F); r=(X^2-t*X+q).roots(multiplicities=False)
            o=[F(x).multiplicative_order() for x in r]
            if L % lcm(o)==0: out.append((l,o))
        print('  L',L,'Elkies with full degree | L:',out)
