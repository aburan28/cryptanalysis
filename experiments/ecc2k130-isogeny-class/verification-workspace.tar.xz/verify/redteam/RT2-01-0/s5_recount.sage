# independent recount of the proposer's parameter-set counts (234 dim-4 sets, 3574 dim-2 sets)
import json, itertools, math
S1=json.load(open('raw/s1_params.json')); p=int(S1['p'])
pool=[int(e['l']) for e in S1['elkies_table'] if e['l']<260]
def is_sum2sq(m):
    return all(not (l%4==3 and e%2) for l,e in factor(ZZ(m)))
# dim 4: M=A^2, sqrt(p)<A<3 sqrt(p), m=A^2-p sum of two squares, gcd(m,p)=1
s=math.isqrt(p); n4=0; best=None
for r in range(2,9):
    for S in itertools.combinations(pool,r):
        A=math.prod(S)
        if not (s<A<3*s): continue
        m=A*A-p
        if m<=0 or math.gcd(m,p)!=1 or not is_sum2sq(m): continue
        n4+=1
        g=euler_phi(A)//2
        if best is None or g<best[0]: best=(int(g),S)
# dim 2 (proposer's rt2c condition): M=3^n A^2, m=M-p = 2^k * (norm from O_K: inert primes even exponent)
n2=0
for n in range(0,9):
    c=3**n; lo=math.isqrt(p//c); hi=3*lo
    for r in range(2,8):
        for S in itertools.combinations(pool,r):
            A=math.prod(S)
            if not (lo<A<hi): continue
            m=c*A*A-p
            if m<=0: continue
            mo=m>>((m&-m).bit_length()-1)
            if mo%p==0: continue
            if all(e%2==0 or l==7 or kronecker(-7,l)==1 for l,e in factor(ZZ(mo))): n2+=1
out=dict(pool_size=len(pool), dim4_count=n4, dim4_min_guesses=best[0], dim4_min_guess_log2=float(log(best[0],2)), dim4_min_primes=best[1], dim2_rt2c_count=n2)
print(out); json.dump(out,open('raw/s5_recount.json','w'),indent=1,default=str)
