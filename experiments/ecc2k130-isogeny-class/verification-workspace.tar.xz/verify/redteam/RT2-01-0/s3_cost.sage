# RT2-01 adversarial check, script 3: end-to-end cost of the Kani transport, re-modelled.
# The proposer's model (redteam-2/rt4_transport_cost.py) charges every node of the guess tree in F_{q^k_d}, k_d = the
# larger eigen-order of the prime being stepped over.  Two things it leaves out:
#   (1) an (l,l)-step needs BOTH eigen-lines, so its field is F_{q^K}, K = lcm(ord(lam1), ord(lam2)) (differs for 37, 211, ...)
#   (2) pushing the eigen-points of a LATER prime l_j through the l_d-step is done where both the l_d-kernel and the
#       pushed point live: F_{q^lcm(K_d, ord_j)}.  (Galbraith 2024/924 p.12 notes the compositum issue.)
# Model L = proposer's tree with (1)+(2).  Model R = no pushing: at every node recompute the next prime's eigen-torsion
# on the intermediate surface by a cofactor ladder (cost_ladder M per bit, ~2*131*K bits), F1 and F2bar trees decoupled
# (hash-table meet in the middle, l+1 lines per prime instead of l-1).  For each tree node the cheaper of L/R is NOT
# mixed; we report both and the min.  M(F_{q^K}) = K^1.585 F_q mults (as the proposer).  C = per-(l^g) constant.
import json, itertools, math, sys, time, builtins
rnd = lambda x, k=2: builtins.round(float(x), k)
S1 = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-01-0/raw/s1_params.json'))
p = ZZ(S1['p'])
ELK = {e['l']: e for e in S1['elkies_table']}
LOG2_E0_RHO_M = 63.394          # proposer's E0 rho cost: 2^60.809 it x ~6 M (redteam-2/raw/rt3_misc.json)
LOG2_NATIVE_M = 66.911          # level-p native: 2^64.326 it x 6 M
ITER_M = 6.0
def Mk(K): return float(K)^1.585
def c_guess(c):
    if c == 1: return 1
    n = valuation(c, 3); assert 3^n == c
    return 4 * 3^((n + 1) // 2 - 1)
C3 = {1: 1, 2: 8, 3: 24}         # ord of pi on E[3^k] (s1: 8, 24); E[27] not needed below
def model_P(order, c, g, C):
    # exact re-implementation of redteam-2/rt4_transport_cost.py
    root = c_guess(c) if c > 1 else 1
    total = 0.0; nodes = root / 2
    for d, l in enumerate(order):
        nodes *= (l - 1)
        k = ELK[l]['max_ord']
        npush = 2 * (len(order) - d - 1)
        total += nodes * (1 + npush) * C * l^g * k^1.585
    return 2 * total
def model_L(order, c, g, C):
    root = c_guess(c) if c > 1 else 1
    total = 0.0; nodes = root / 2
    for d, l in enumerate(order):
        nodes *= (l - 1)
        K = ELK[l]['full_deg']
        cost = C * l^g * Mk(K)
        for lj in order[d + 1:]:
            for oj in ELK[lj]['ord']:
                cost += C * l^g * Mk(lcm(K, oj))
        total += nodes * cost
    return 2 * total
def model_R(order, c, g, C, ladder=25.0):
    # two independent trees (F1, F2bar); branching l+1; +-1 symmetry halves the product once
    root = c_guess(c) if c > 1 else 1
    total = 0.0; nodes = root / 2.0
    for d, l in enumerate(order):
        # before branching on l: torsion for l on the current surface, once per parent node
        tors = sum(ladder * (2 * 131 * o) * Mk(o) for o in ELK[l]['ord'])
        total += nodes * tors
        nodes *= (l + 1)
        total += nodes * C * l^g * Mk(ELK[l]['full_deg'])
    return 2 * total
def best_order(primes, c, g, C, fn):
    best = None
    for perm in itertools.permutations(primes):
        v = fn(list(perm), c, g, C)
        if best is None or v < best[0]: best = (v, list(perm))
    return best
def lg(x): return float(log(x, 2))
def eff_iter(cost_M):   # effective log2 E0-rho-iteration equivalents after transport
    return lg(2^LOG2_E0_RHO_M + cost_M) - lg(ITER_M)
def breakeven_C(fn, order, c, g, target_log2):
    unit = fn(order, c, g, 1.0)
    return 2^target_log2 / unit
out = {'assumptions': dict(M_Fqk='K^1.585 F_q mults', ladder_M_per_bit=25, E0_rho_log2_M=LOG2_E0_RHO_M,
                           native_log2_M=LOG2_NATIVE_M, iter_M=ITER_M)}
cases = {
  'dim2_c81_A=29.71.137.179': ([int(29), int(71), int(137), int(179)], int(81), int(2)),
  'dim2_c3_A=11.23.79.107.109': ([int(v) for v in (11, 23, 79, 107, 109)], int(3), int(2)),
  'dim4_c1_A=23.37.53.67.137': ([int(v) for v in (23, 37, 53, 67, 137)], int(1), int(4)),
}
res = {}
for name, (pr, c, g) in cases.items():
    prop_order = sorted(pr, reverse=True)
    row = {}
    for C in (9, 100, 1000, 10000):
        P_ = model_P(prop_order, c, g, C)
        L_ = model_L(prop_order, c, g, C)
        Lb = best_order(pr, c, g, C, model_L)
        Rb = best_order(pr, c, g, C, model_R)
        row['C=%d' % C] = dict(proposer_log2=rnd(lg(P_), 2), compositum_proposer_order_log2=rnd(lg(L_), 2),
            compositum_best_order_log2=rnd(lg(Lb[0]), 2), compositum_best_order=Lb[1],
            recompute_best_order_log2=rnd(lg(Rb[0]), 2), recompute_best_order=Rb[1],
            min_log2=rnd(lg(min(Lb[0], Rb[0])), 2),
            eff_iter_proposer=rnd(eff_iter(P_), 3), eff_iter_corrected=rnd(eff_iter(min(Lb[0], Rb[0])), 3))
    Lb1 = best_order(pr, c, g, 1.0, model_L); Rb1 = best_order(pr, c, g, 1.0, model_R)
    unit = min(Lb1[0], Rb1[0])
    row['breakeven_C_vs_E0_rho'] = float(2^LOG2_E0_RHO_M / unit)
    row['breakeven_C_vs_native'] = float(2^LOG2_NATIVE_M / unit)
    row['unit_cost_log2_per_C'] = rnd(lg(unit), 2)
    row['full_degs'] = [ELK[l]['full_deg'] for l in pr]; row['ords'] = [ELK[l]['ord'] for l in pr]
    res[name] = row
    print(name, json.dumps(row, default=str))
out['proposer_cases'] = res
# ---------- search the dim-2 family under the corrected model ----------
# M = c A^2, c = 3^n (n <= 6), A = product of distinct Elkies primes < 260 (the proposer's pool),
# m = M - p = 2^k * s * n0^2 with s squarefree, all primes of s split (or 7) and <= Bsplit (horizontal steps),
# inert primes only to even powers (absorbed in [n0]).
t0 = time.time()
pool = [int(l) for l in sorted(ELK) if l < 260]
Bsplit = int(sys.argv[1]) if len(sys.argv) > 1 else 2000
hits = []
pint = int(p)
for n3 in range(0, 9):
    c = int(3)**n3
    lo = math.isqrt(pint // c); hi = 3 * lo
    for r in range(2, 7):
        for S in itertools.combinations(pool, r):
            A = math.prod(S)
            if not (lo < A < hi): continue
            M = c * A * A; m = M - pint
            if m <= 0 or math.gcd(m, pint) != 1 or M % 2 == 0: continue
            k2 = (m & -m).bit_length() - 1; mo = m >> k2
            ok = True; smax = 1
            for l, e in factor(ZZ(mo)):
                if e % 2 == 0: continue
                if l == 7: continue
                if kronecker(-7, l) != 1 or l > Bsplit: ok = False; break
                smax = max(smax, int(l))
            if not ok: continue
            G = euler_phi(A) // 2 * c_guess(c)
            hits.append(dict(c=int(c), primes=[int(x) for x in S], A=int(A), m=str(m), frob=int(k2), max_split_step=int(smax),
                             log2_guesses=rnd(lg(G), 3)))
out['search'] = dict(pool_max=259, Bsplit=Bsplit, n_hits=len(hits), time_s=rnd(time.time() - t0, 1))
print('hits', len(hits), 'time', time.time() - t0)
# evaluate corrected cost for all hits (best order over permutations), C = 1 unit
ev = []
for h in hits:
    Lb = best_order(h['primes'], h['c'], 2, 1.0, model_L)
    Rb = best_order(h['primes'], h['c'], 2, 1.0, model_R)
    Pp = model_P(sorted(h['primes'], reverse=True), h['c'], 2, 1.0)
    h2 = dict(h); h2['unit_log2_corrected'] = rnd(lg(min(Lb[0], Rb[0])), 2)
    h2['unit_log2_proposer'] = rnd(lg(Pp), 2)
    h2['best'] = 'L' if Lb[0] <= Rb[0] else 'R'; h2['order'] = Lb[1] if Lb[0] <= Rb[0] else Rb[1]
    ev.append(h2)
ev.sort(key=lambda h: h['unit_log2_corrected'])
out['search_best_corrected'] = ev[:15]
out['search_best_proposer_model'] = sorted(ev, key=lambda h: h['unit_log2_proposer'])[:5]
if ev:
    b = ev[0]
    out['best_breakeven_C_vs_E0_rho'] = float(2^(LOG2_E0_RHO_M - b['unit_log2_corrected']))
    out['best_breakeven_C_vs_native'] = float(2^(LOG2_NATIVE_M - b['unit_log2_corrected']))
    out['best_eff_iter_at_C'] = {str(C): rnd(eff_iter(C * 2^b['unit_log2_corrected']), 3) for C in (9, 100, 1000, 10000, 100000)}
print(json.dumps({k: out[k] for k in out if k.startswith("best") or k == "search"}, indent=1, default=str))
for h in ev[:8]: print(h)
json.dump(out, open('/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-01-0/raw/s3_cost_B%d.json' % Bsplit, 'w'), indent=1, default=str)
