# find toy analogues: E0: y^2+xy=x^3+1 over F_{2^n}, t_n^2-4*2^n = -7 f_n^2, small odd prime p' | f_n
tk=[2,-1]
for k in range(2,200): tk.append(-tk[-1]-2*tk[-2])
for n in range(11,90):
    t=tk[n]; q=2^n; f2=(4*q-t^2)/7; f=isqrt(f2); assert f^2==f2
    if f==1: continue
    fac=factor(f)
    small=[(l,e) for l,e in fac if l not in (2,7) and l<80]
    if not small: continue
    out=[]
    for l,e in small:
        a=Mod(t,l)/2; o=a.multiplicative_order()
        out.append((l,e,o,kronecker(-7,l)))
    print(n, 'f=',fac, 'small p (p,e,ord pi on E0[p],kron):', out)
