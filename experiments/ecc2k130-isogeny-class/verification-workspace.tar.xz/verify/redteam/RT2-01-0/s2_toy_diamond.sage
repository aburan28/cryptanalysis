# RT2-01 adversarial check, script 2: toy validation of the ALGEBRA of the idea (not of the dim-2 isogeny step).
# Toy: E0: y^2+xy=x^3+1 over F_q, q=2^n (same Koblitz curve, j=1, tau^2+tau+2=0), with a small INERT prime pp | f
# playing the role of p. Everything is computed inside FK = F_{q^L} where E0[pp] and E[l] (l Elkies) are rational.
#  T1 descend E0 -> E1 (level pp); E1(FK)[pp] cyclic (pi non-scalar on E1[pp]) while E0(FK)[pp] = full
#  T2 ascending pp-isogeny phi: E1 -> E0 is F_q-rational (commutes with pi_q) and lands on E0 (not its twist)
#  T3 Elkies l: phi maps pi-eigenvectors to pi-eigenvectors; Weil pairing leaves exactly l-1 (mu1,mu2) candidates
#  T4 diamond with gamma = [x] o sigma^s : tau^s [x] o phi == +-phi' o gamma  (phi' computed independently)
#  T5 diamond with gamma = horizontal Elkies l-isogeny: alpha o phi == +-phi'' o gamma, alpha in Z[tau], N(alpha)=l
#  T6 Kani matrix identity  Ft o F = [M] on E1 x E0, M = pp + 2^s x^2, F = [[phi, -gt'],[gamma, phit']]
#  T7 DLP transport: log on E1(F_q) recovered on E0
import json, sys, time, random
set_random_seed(20260924); random.seed(int(20260924))
OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-01-0/raw/s2_toy_%s.json"

def trace_seq(m):
    tk = [2, -1]
    for k in range(2, m + 1): tk.append(-tk[-1] - 2 * tk[-2])
    return tk

def run(n, pp, L, ell, s=3, xg=5):
    T0 = time.time(); R = {'n': n, 'pp': pp, 'L': L, 'ell': ell, 's': s, 'x': xg}
    q = 2^n; tk = trace_seq(n * L); t = tk[n]
    f = isqrt((4 * q - t^2) / 7); assert 7 * f^2 == 4 * q - t^2 and f % pp == 0 and kronecker(-7, pp) == -1
    FK = GF(2^(n * L), 'u', modulus='minimal_weight')
    cardK = 2^(n * L) + 1 - tk[n * L]          # #E(F_{q^L}) for every curve F_q-isogenous to E0
    cardq = q + 1 - t
    Fr = lambda c: c^q                          # q-power Frobenius on FK
    in_Fq = lambda c: c^q == c
    def piq(E, P):
        if P.is_zero(): return P
        return E(Fr(P[0]), Fr(P[1]))
    def sig(E2, P, k):                          # sigma^k: (x,y) -> (x^(2^k), y^(2^k)) into E2
        if P.is_zero(): return E2(0)
        return E2(P[0]^(2^k), P[1]^(2^k))
    def tors(E, l, want=1):
        v = valuation(cardK, l); co = cardK // l^v
        while True:
            P = co * E.random_point()
            if P.is_zero(): continue
            while not (l * P).is_zero(): P = l * P
            return P
    E0 = EllipticCurve(FK, [1, 0, 0, 0, 1])
    assert (cardK * E0.random_point()).is_zero()
    # ---- T1 descend ----
    P0 = tors(E0, pp)
    # E0(FK)[pp] full: find a second independent point
    while True:
        P0b = tors(E0, pp)
        if P0.weil_pairing(P0b, pp) != 1: break
    R['T1_E0_pp_torsion_full'] = True
    phid = E0.isogeny(P0)
    E1 = phid.codomain()
    R['T1_E1_coeffs_in_Fq'] = all(in_Fq(c) for c in E1.a_invariants())
    j1 = E1.j_invariant(); R['T1_j1_in_Fq'] = bool(in_Fq(j1)); R['T1_j1_ne_1'] = bool(j1 != 1)
    R['T1_j1_degree_over_F2'] = int(j1.minpoly().degree())
    assert (cardK * E1.random_point()).is_zero()
    pts = [tors(E1, pp) for _ in range(6)]
    R['T1_E1_pp_torsion_cyclic'] = all(a.weil_pairing(b, pp) == 1 for a in pts for b in pts)
    # ---- T2 ascend ----
    P1 = pts[0]
    phi0 = E1.isogeny(P1)
    C = phi0.codomain(); R['T2_codomain_j'] = str(C.j_invariant()); assert C.j_invariant() == 1
    isos = C.isomorphisms(E0)
    good = []
    for iso in isos:
        ok = True
        for _ in range(4):
            Q = E1.random_point()
            if iso(phi0(piq(E1, Q))) != piq(E0, iso(phi0(Q))): ok = False; break
        if ok: good.append(iso)
    R['T2_n_isos'] = len(isos); R['T2_n_Fq_rational_isos'] = len(good)
    assert len(good) >= 1
    iso = good[0]
    phi = lambda Q: iso(phi0(Q))
    # ---- T3 Elkies l ----
    Fl = GF(ell); X = polygen(Fl)
    lam = (X^2 - t * X + q).roots(multiplicities=False); assert len(lam) == 2
    lam = [ZZ(a) for a in lam]
    def eig(E, which):
        while True:
            Q = tors(E, ell)
            Pv = piq(E, Q) - lam[1 - which] * Q
            if not Pv.is_zero():
                assert piq(E, Pv) == lam[which] * Pv
                return Pv
    P1e = [eig(E1, 0), eig(E1, 1)]; Q0e = [eig(E0, 0), eig(E0, 1)]
    mus = []
    for i in range(2):
        img = phi(P1e[i])
        R['T3_phi_maps_eigvec_to_eigvec_%d' % i] = bool(piq(E0, img) == lam[i] * img and not img.is_zero())
        mu = next(k for k in range(1, ell) if k * Q0e[i] == img)
        mus.append(mu)
    e1 = P1e[0].weil_pairing(P1e[1], ell); e0 = Q0e[0].weil_pairing(Q0e[1], ell)
    assert e0^(mus[0] * mus[1]) == e1^pp
    cands = [(m1, m2) for m1 in range(1, ell) for m2 in range(1, ell) if e0^(m1 * m2) == e1^pp]
    R['T3_pairing_candidates'] = len(cands); R['T3_true_in_candidates'] = tuple(mus) in cands
    R['T3_expected_l_minus_1'] = ell - 1
    # ---- T4 diamond with Frobenius power ----
    E2 = EllipticCurve(FK, [c^(2^s) for c in E1.a_invariants()])
    P2 = tors(E2, pp)
    phi2_0 = E2.isogeny(P2); C2 = phi2_0.codomain(); assert C2.j_invariant() == 1
    iso2 = [i2 for i2 in C2.isomorphisms(E0) if all(i2(phi2_0(piq(E2, Q))) == piq(E0, i2(phi2_0(Q))) for Q in [E2.random_point() for _ in range(3)])][0]
    phi2 = lambda Q: iso2(phi2_0(Q))
    tau = lambda Q: sig(E0, Q, 1)
    def taus(Q, k):
        for _ in range(k): Q = tau(Q)
        return Q
    gam = lambda Q: xg * sig(E2, Q, s)
    gamp = lambda Q: xg * taus(Q, s)
    signs = set()
    for _ in range(10):
        Q = E1.random_point()
        a_ = gamp(phi(Q)); b_ = phi2(gam(Q))
        signs.add(1 if a_ == b_ else (-1 if a_ == -b_ else 0))
    R['T4_diamond_signs'] = sorted(signs); R['T4_diamond_holds'] = (0 not in signs and len(signs) == 1)
    sg = list(signs)[0]
    # ---- T5 diamond with horizontal Elkies step ----
    gh0 = E1.isogeny(P1e[0]); E1h = gh0.codomain()
    R['T5_E1h_coeffs_in_Fq'] = all(in_Fq(c) for c in E1h.a_invariants())
    P1h = tors(E1h, pp)
    ph0 = E1h.isogeny(P1h); Ch = ph0.codomain(); assert Ch.j_invariant() == 1
    isoh = [ih for ih in Ch.isomorphisms(E0) if all(ih(ph0(piq(E1h, Q))) == piq(E0, ih(ph0(Q))) for Q in [E1h.random_point() for _ in range(3)])][0]
    phih = lambda Q: isoh(ph0(Q))
    # alpha = u + v tau with N(alpha) = u^2 - u v + 2 v^2 = ell, killing the lam[0]-eigenline of E0[ell]
    alpha = None
    B = isqrt(4 * ell) + 2
    for u in range(-B, B + 1):
        for v in range(-B, B + 1):
            if u * u - u * v + 2 * v * v == ell:
                if (u * Q0e[0] + v * tau(Q0e[0])).is_zero():
                    alpha = (u, v); break
        if alpha: break
    R['T5_alpha_u_v'] = alpha
    al = lambda Q: alpha[0] * Q + alpha[1] * tau(Q)
    signs = set()
    for _ in range(10):
        Q = E1.random_point()
        a_ = al(phi(Q)); b_ = phih(gh0(Q))
        signs.add(1 if a_ == b_ else (-1 if a_ == -b_ else 0))
    R['T5_diamond_signs'] = sorted(signs); R['T5_diamond_holds'] = (0 not in signs and len(signs) == 1)
    # ---- T6 Kani matrix identity for gamma = [x] sigma^s ----
    M = pp + 2^s * xg^2; R['T6_M'] = int(M)
    # Sage has no dual() in char 2: build each dual as the Velu isogeny from E0 whose kernel is the image
    # of E[pp] (= the descending line we know), then fix the isomorphism/sign by psi o fwd == [pp].
    def dual_via(kerpt, target, fwd, dom):
        psi0 = E0.isogeny(kerpt)
        for ii in psi0.codomain().isomorphisms(target):
            if all(ii(psi0(fwd(Q))) == pp * Q for Q in [dom.random_point() for _ in range(3)]):
                return (lambda Qe0, ii=ii, psi0=psi0: ii(psi0(Qe0)))
        return None
    phihat = dual_via(P0, E1, phi, E1)
    phi2hat = dual_via(taus(P0, s), E2, phi2, E2)
    R['T6_duals_found'] = (phihat is not None and phi2hat is not None)
    Nq = 2^(n * L)
    def sig_inv(Etarget, Q, k):                 # sigma^{-k} pointwise on FK-points
        if Q.is_zero(): return Etarget(0)
        e = Nq // 2^k if False else None
        # inverse of x -> x^(2^k) on FK is x -> x^(2^(nL-k))
        return Etarget(Q[0]^(2^(n * L - k)), Q[1]^(2^(n * L - k)))
    gamhat = lambda Q2: xg * (2^s * sig_inv(E1, Q2, s))            # [x] V^s, V^s = [2^s] sigma^-s
    taubar = lambda Q: -Q - tau(Q)                                  # tau + taubar = t_1 = -1
    def gamphat(Q):
        for _ in range(s): Q = taubar(Q)
        return xg * Q
    ok6 = True
    for _ in range(6):
        P = E1.random_point(); Rr = E0.random_point()
        Aa = phi(P) - gamphat(Rr)                      # F = [[phi, -gamma_p_hat],[gamma, sg*phi2_hat]], phi_p = sg*phi2 (T4)
        Bb = gam(P) + sg * phi2hat(Rr)
        U = phihat(Aa) + gamhat(Bb)
        V = -gamp(Aa) + sg * phi2(Bb)
        if not (U == M * P and V == M * Rr): ok6 = False
    R['T6_kani_FtF_equals_M'] = ok6
    # ---- T7 DLP transport ----
    rr = max(l for l, e in factor(cardq))
    NormExp = (2^(n * L) - 1) // (2^n - 1)
    while True:
        xx = FK.random_element()^NormExp
        try:
            Pq = E1.lift_x(xx)
        except Exception:
            continue
        if piq(E1, Pq) != Pq: Pq = None
        if Pq is None: continue
        Pq = (cardq // rr) * Pq
        if not Pq.is_zero(): break
    kk = randint(1, rr - 1); Qq = kk * Pq
    a0 = phi(Pq); b0 = phi(Qq)
    a0.set_order(rr); kk2 = discrete_log(b0, a0, ord=rr, operation='+')
    R['T7_order_r'] = int(rr); R['T7_log_recovered'] = bool(kk2 == kk)
    R['time_s'] = time.time() - T0
    return R

allres = {}
for (n, pp, L, ell) in [(20, 19, 18, 37), (37, 73, 36, 37)]:
    r = run(n, pp, L, ell)
    print(json.dumps(r, default=str))
    allres['n%d_p%d' % (n, pp)] = r
json.dump(allres, open(OUT % 'all', 'w'), indent=1, default=str)
