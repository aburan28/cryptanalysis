/* RT0-6: multi-target (Kuhn-Struik) distinguished-point rho on a Koblitz-type toy curve
 *   E : y^2 + x y = x^3 + a2 x^2 + b over F_{2^n} (n <= 63, polynomial basis z^n + tail),
 * working in the order-N subgroup <G> with equivalence classes {+-tau^j R : 0 <= j < n}
 * (tau(x,y) = (x^2,y^2) acts as [s]).  The walk is the Frobenius-and-add map of Bailey et al.
 * (ECC2K-130, 2009):  R -> canon(R + tau^c R),  c = c0 + (hash(x) mod r),
 * which is well defined on classes and independent of the target, so ONE distinguished-point
 * database serves every target: targets T_0, T_1, ... of a trial are solved one after another
 * (log_G T_i), and all earlier trails stay in the database.
 *
 * For every target it reports:
 *   draws    = points generated until the first collision with ANY earlier point (starts count
 *              as points; the colliding walk is re-walked to find its exact merge index)  <- KS quantity
 *   iters    = all iterations actually spent (incl. the tail to the DP and abandoned walks)
 *   walks, abandoned walks, and the recovered log (checked in C: [log]G == T).
 *
 * usage: ksrho <targets file> <dpbits> <r> <c0> <seed> <trial_lo> <trial_hi>
 * Build: clang -O3 -mcpu=apple-m1 -o ksrho ksrho.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <arm_neon.h>

typedef unsigned __int128 u128;
static int FN;
static uint64_t TAIL, FMASK, A2, BB;
static uint64_t NN, SS;

static inline u128 clmul(uint64_t a, uint64_t b) {
    return (u128)vmull_p64((poly64_t)a, (poly64_t)b);
}
static inline uint64_t fred(u128 p) {
    while (p >> FN) {
        uint64_t hi = (uint64_t)(p >> FN);
        p &= (u128)FMASK;
        p ^= clmul(hi, TAIL);
    }
    return (uint64_t)p;
}
static inline uint64_t fmul(uint64_t a, uint64_t b) { return fred(clmul(a, b)); }
static inline uint64_t fsqr(uint64_t a) { return fred(clmul(a, a)); }
static uint64_t finv(uint64_t a) { /* a^(2^n - 2), Itoh-Tsujii on m = n-1 */
    int m = FN - 1, top = 63 - __builtin_clzll((uint64_t)m);
    uint64_t beta = a; int k = 1;
    for (int i = top - 1; i >= 0; i--) {
        uint64_t t = beta;
        for (int j = 0; j < k; j++) t = fsqr(t);
        beta = fmul(t, beta); k *= 2;
        if ((m >> i) & 1) { beta = fmul(fsqr(beta), a); k += 1; }
    }
    return fsqr(beta);
}

typedef struct { uint64_t x, y; int inf; } pt;
static pt padd(pt P, pt Q);
static pt pdbl(pt P) {
    if (P.inf || P.x == 0) { pt O = {0, 0, 1}; return O; }
    uint64_t lam = P.x ^ fmul(P.y, finv(P.x));
    uint64_t x3 = fsqr(lam) ^ lam ^ A2;
    uint64_t y3 = fsqr(P.x) ^ fmul(lam ^ 1, x3);
    pt R = {x3, y3, 0}; return R;
}
static pt padd(pt P, pt Q) {
    if (P.inf) return Q;
    if (Q.inf) return P;
    if (P.x == Q.x) {
        if (P.y == Q.y) return pdbl(P);
        pt O = {0, 0, 1}; return O;              /* Q = -P */
    }
    uint64_t lam = fmul(P.y ^ Q.y, finv(P.x ^ Q.x));
    uint64_t x3 = fsqr(lam) ^ lam ^ P.x ^ Q.x ^ A2;
    uint64_t y3 = fmul(lam, P.x ^ x3) ^ x3 ^ P.y;
    pt R = {x3, y3, 0}; return R;
}
static pt pmul(uint64_t k, pt P) {
    pt R = {0, 0, 1};
    for (int i = 63; i >= 0; i--) {
        R = pdbl(R);
        if ((k >> i) & 1) R = padd(R, P);
    }
    return R;
}
static int on_curve(pt P) {
    if (P.inf) return 1;
    uint64_t x = P.x, y = P.y, x2 = fsqr(x);
    return (fsqr(y) ^ fmul(x, y)) == (fmul(x2, x) ^ fmul(A2, x2) ^ BB);
}

static inline uint64_t mulmod(uint64_t a, uint64_t b) { return (uint64_t)(((u128)a * b) % NN); }
static uint64_t powmod(uint64_t a, uint64_t e) {
    uint64_t r = 1; a %= NN;
    while (e) { if (e & 1) r = mulmod(r, a); a = mulmod(a, a); e >>= 1; }
    return r;
}
static inline uint64_t invmod(uint64_t a) { return powmod(a, NN - 2); }
static inline uint64_t submod(uint64_t a, uint64_t b) { return a >= b ? a - b : a + NN - b; }
static inline uint64_t addmod(uint64_t a, uint64_t b) { uint64_t c = a + b; return c >= NN ? c - NN : c; }

static uint64_t rng_s[4];
static inline uint64_t rotl(uint64_t x, int k) { return (x << k) | (x >> (64 - k)); }
static uint64_t rng(void) { /* xoshiro256** */
    uint64_t r = rotl(rng_s[1] * 5, 7) * 9, t = rng_s[1] << 17;
    rng_s[2] ^= rng_s[0]; rng_s[3] ^= rng_s[1]; rng_s[1] ^= rng_s[2]; rng_s[0] ^= rng_s[3];
    rng_s[2] ^= t; rng_s[3] = rotl(rng_s[3], 45); return r;
}
static void rng_seed(uint64_t s) {
    for (int i = 0; i < 4; i++) {
        s += 0x9e3779b97f4a7c15ULL; uint64_t z = s;
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL; z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        rng_s[i] = z ^ (z >> 31);
    }
}
static inline uint64_t mix(uint64_t z) {
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL; z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

/* ---- walk on classes */
static uint64_t SPOW[64], ONEPLUS[64];
static int R_BR, C0, DPBITS;
static uint64_t HKEY, DPMASK;
static uint64_t conjv[64];

/* canonical representative of the class of (x,y): min integer x over conjugates, then min y.
   multiplies *mu by the eigenvalue of the map used.  Leaves conjv[j] = xcanon^(2^j). */
static inline void canon(uint64_t *x, uint64_t *y, uint64_t *mu) {
    uint64_t c[64];
    uint64_t cx = *x, bx = cx; int best = 0; c[0] = cx;
    for (int j = 1; j < FN; j++) { cx = fsqr(cx); c[j] = cx; if (cx < bx) { bx = cx; best = j; } }
    uint64_t yy = *y;
    for (int j = 0; j < best; j++) yy = fsqr(yy);
    uint64_t y2 = yy ^ bx;
    uint64_t m = mulmod(*mu, SPOW[best]);
    if (y2 < yy) { yy = y2; m = (m == 0) ? 0 : NN - m; }
    for (int j = 0; j < FN; j++) { int k = best + j; if (k >= FN) k -= FN; conjv[j] = c[k]; }
    *x = bx; *y = yy; *mu = m;
}
static inline int branch(uint64_t x) { return (int)((mix(x ^ HKEY) >> 7) % (uint64_t)R_BR); }
static inline int is_dp(uint64_t x) { return ((mix(x ^ HKEY) >> 40) & DPMASK) == 0; }
/* one step from a canonical point (conjv valid) */
static inline void step(uint64_t *x, uint64_t *y, uint64_t *mu) {
    int c = C0 + branch(*x);
    uint64_t tx = conjv[c % FN], ty = *y;
    for (int j = 0; j < c; j++) ty = fsqr(ty);
    uint64_t lam = fmul(*y ^ ty, finv(*x ^ tx));
    uint64_t x3 = fsqr(lam) ^ lam ^ *x ^ tx ^ A2;
    uint64_t y3 = fmul(lam, *x ^ x3) ^ x3 ^ *y;
    *mu = mulmod(*mu, ONEPLUS[c]);
    *x = x3; *y = y3;
    canon(x, y, mu);
}

/* ---- database */
typedef struct { uint64_t sx, sy, mu0, a, b, mudp; int tgt; long len; long next; } walkrec;
static walkrec *W; static long nW, capW;
static uint64_t *HK; static long *HV; static long HCAP; static long *used; static long nused;
static long db_find(uint64_t x) {
    long i = (long)(mix(x) & (uint64_t)(HCAP - 1));
    while (HK[i]) { if (HK[i] == x) return i; i = (i + 1) & (HCAP - 1); }
    return -1 - i;
}

/* exact merge index of walk w into the trails listed at slot */
static long merge_index(long w, long head) {
    long tot = 0;
    for (long v = head; v >= 0; v = W[v].next) tot += W[v].len + 1;
    long cap = 16; while (cap < 4 * tot) cap <<= 1;
    uint64_t *hs = calloc(cap, 8);
    for (long v = head; v >= 0; v = W[v].next) {
        uint64_t x = W[v].sx, y = W[v].sy, mu = 1;
        canon(&x, &y, &mu);
        for (long i = 0; i <= W[v].len; i++) {
            long p = (long)(mix(x) & (uint64_t)(cap - 1));
            while (hs[p] && hs[p] != x) p = (p + 1) & (cap - 1);
            hs[p] = x;
            if (i < W[v].len) step(&x, &y, &mu);
        }
    }
    uint64_t x = W[w].sx, y = W[w].sy, mu = 1;
    canon(&x, &y, &mu);
    long res = W[w].len;
    for (long i = 0; i <= W[w].len; i++) {
        long p = (long)(mix(x) & (uint64_t)(cap - 1));
        int hit = 0;
        while (hs[p]) { if (hs[p] == x) { hit = 1; break; } p = (p + 1) & (cap - 1); }
        if (hit) { res = i; break; }
        if (i < W[w].len) step(&x, &y, &mu);
    }
    free(hs);
    return res;
}

int main(int argc, char **argv) {
    if (argc < 8) { fprintf(stderr, "usage\n"); return 1; }
    FILE *fh = fopen(argv[1], "r");
    DPBITS = atoi(argv[2]); R_BR = atoi(argv[3]); C0 = atoi(argv[4]);
    uint64_t seed = strtoull(argv[5], 0, 10);
    int tlo = atoi(argv[6]), thi = atoi(argv[7]);
    char key[64]; int trials = 0, M = 0; pt G = {0, 0, 0};
    pt *T = NULL;
    char line[512];
    while (fgets(line, sizeof line, fh)) {
        if (sscanf(line, "%63s", key) != 1) continue;
        if (!strcmp(key, "n")) sscanf(line, "%*s %d", &FN);
        else if (!strcmp(key, "tail")) sscanf(line, "%*s %llx", (unsigned long long *)&TAIL);
        else if (!strcmp(key, "a2")) sscanf(line, "%*s %llu", (unsigned long long *)&A2);
        else if (!strcmp(key, "b")) sscanf(line, "%*s %llx", (unsigned long long *)&BB);
        else if (!strcmp(key, "N")) sscanf(line, "%*s %llu", (unsigned long long *)&NN);
        else if (!strcmp(key, "s")) sscanf(line, "%*s %llu", (unsigned long long *)&SS);
        else if (!strcmp(key, "G")) sscanf(line, "%*s %llx %llx", (unsigned long long *)&G.x, (unsigned long long *)&G.y);
        else if (!strcmp(key, "trials")) sscanf(line, "%*s %d", &trials);
        else if (!strcmp(key, "targets")) { sscanf(line, "%*s %d", &M); T = calloc((size_t)trials * M, sizeof(pt)); }
        else if (!strcmp(key, "t")) {
            int ti, k; unsigned long long x, y;
            sscanf(line, "%*s %d %d %llx %llx", &ti, &k, &x, &y);
            T[(size_t)ti * M + k].x = x; T[(size_t)ti * M + k].y = y;
        }
    }
    fclose(fh);
    FMASK = (FN == 64) ? ~0ULL : ((1ULL << FN) - 1);
    DPMASK = (1ULL << DPBITS) - 1;
    for (int j = 0; j < FN; j++) SPOW[j] = powmod(SS, j);
    for (int c = 0; c < 64; c++) ONEPLUS[c] = addmod(1, powmod(SS, c));
    /* sanity: G on curve, N G = O, tau(G) = s G, 1 + s^c != 0 on used branches */
    if (!on_curve(G) || !pmul(NN, G).inf) { fprintf(stderr, "bad G\n"); return 2; }
    pt tG = {fsqr(G.x), fsqr(G.y), 0}, sG = pmul(SS, G);
    if (sG.x != tG.x || sG.y != tG.y) { fprintf(stderr, "bad s\n"); return 2; }
    for (int c = C0; c < C0 + R_BR; c++) if (ONEPLUS[c] == 0 || c % FN == 0) { fprintf(stderr, "bad branch %d\n", c); return 2; }
    printf("# n=%d N=%llu dpbits=%d r=%d c0=%d trials=[%d,%d) M=%d\n", FN, (unsigned long long)NN, DPBITS, R_BR, C0, tlo, thi, M);
    HCAP = 1L << 22; HK = calloc(HCAP, 8); HV = calloc(HCAP, sizeof(long)); used = calloc(HCAP, sizeof(long));
    capW = 1 << 16; W = malloc(capW * sizeof(walkrec));
    long maxlen = 20L << DPBITS;
    uint64_t *klog = calloc(M, 8);
    for (int ti = tlo; ti < thi; ti++) {
        rng_seed(seed * 1000003ULL + (uint64_t)ti);
        HKEY = rng();
        for (long u = 0; u < nused; u++) HK[used[u]] = 0;
        nused = 0; nW = 0;
        for (int tg = 0; tg < M; tg++) {
            pt Tt = T[(size_t)ti * M + tg];
            if (!on_curve(Tt) || !pmul(NN, Tt).inf) { fprintf(stderr, "bad target %d %d\n", ti, tg); return 3; }
            long draws = 0, iters = 0, walks = 0, aband = 0; int solved = 0; uint64_t k = 0;
            while (!solved) {
                uint64_t a = 1 + rng() % (NN - 1), b = 1 + rng() % (NN - 1);
                pt S = padd(pmul(a, G), pmul(b, Tt));
                if (S.inf) continue;
                uint64_t x = S.x, y = S.y, mu = 1;
                canon(&x, &y, &mu);
                if (nW == capW) { capW *= 2; W = realloc(W, capW * sizeof(walkrec)); }
                long w = nW;
                W[w].sx = S.x; W[w].sy = S.y; W[w].a = a; W[w].b = b; W[w].tgt = tg; W[w].mu0 = mu; W[w].next = -1;
                long len = 0; int ab = 0;
                while (!is_dp(x)) {
                    step(&x, &y, &mu); len++;
                    if (len > maxlen) { ab = 1; break; }
                }
                iters += len; walks++;
                if (ab) { aband++; draws += len + 1; continue; }
                W[w].len = len; W[w].mudp = mu; nW++;
                long slot = db_find(x);
                if (slot < 0) {                      /* new DP */
                    slot = -1 - slot; HK[slot] = x; HV[slot] = w; used[nused++] = slot;
                    draws += len + 1;
                    continue;
                }
                /* collision at an existing DP: try to solve with any trail ending there */
                long head = HV[slot];
                for (long v = head; v >= 0 && !solved; v = W[v].next) {
                    uint64_t kk;
                    if (W[v].tgt < tg) {
                        uint64_t Lv = mulmod(W[v].mudp, addmod(W[v].a, mulmod(W[v].b, klog[W[v].tgt])));
                        kk = mulmod(submod(mulmod(Lv, invmod(mu)), a), invmod(b));
                    } else {
                        uint64_t den = submod(mulmod(mu, b), mulmod(W[v].mudp, W[v].b));
                        if (den == 0) continue;
                        kk = mulmod(submod(mulmod(W[v].mudp, W[v].a), mulmod(mu, a)), invmod(den));
                    }
                    pt chkp = pmul(kk, G);
                    if (!chkp.inf && chkp.x == Tt.x && chkp.y == Tt.y) { solved = 1; k = kk; }
                }
                long m = merge_index(w, head);
                draws += m + 1;
                W[w].next = HV[slot]; HV[slot] = w;  /* keep the trail */
            }
            klog[tg] = k;
            printf("r %d %d %ld %ld %ld %ld %llu\n", ti, tg, draws, iters, walks, aband, (unsigned long long)k);
        }
        fflush(stdout);
    }
    return 0;
}
