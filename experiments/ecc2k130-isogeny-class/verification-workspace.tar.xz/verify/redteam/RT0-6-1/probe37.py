import time
from sage.all import *
n=37; a=0; l=73
R=PolynomialRing(GF(2),'z'); z=R.gen()
tail=1
while not (z**n+R([ (tail>>i)&1 for i in range(8)])).is_irreducible(): tail+=2
K=GF(2**n,'z',modulus=z**n+R([ (tail>>i)&1 for i in range(8)]))
E0=EllipticCurve(K,[1,a,0,0,1]); card=E0.cardinality(); print('tail',tail,'card',factor(card))
t=2**n+1-card; lam=GF(l)(t)/2; print('lam',lam,'ord',lam.multiplicative_order())
t0=time.time()
isos=E0.isogenies_prime_degree(l)
print('n isogenies',len(isos),'time',time.time()-t0)
js=[phi.codomain().j_invariant() for phi in isos]
print('distinct j',len(set(js)),'j=1 count',sum(1 for j in js if j==1))
