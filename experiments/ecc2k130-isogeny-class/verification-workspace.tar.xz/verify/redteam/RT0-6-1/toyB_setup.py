"""RT0-6 toy B: KS scaling on a larger Koblitz toy with cofactor 4 (like ECC2K-130), no transport.
E0: y^2+xy = x^3+1 over F_{2^41}, #E0 = 4*N, N = 549756390943 (39.0 bits), classes (N-1)/82.
Targets: T_i = k_i G with planted k_i.
usage: sage -python toyB_setup.py <trials> <targets_per_trial>
"""
import sys, json, os
from sage.all import GF, PolynomialRing, EllipticCurve, Integer, set_random_seed, randint, factor

HERE = os.path.dirname(os.path.abspath(__file__))
TT, M = int(sys.argv[1]), int(sys.argv[2])
set_random_seed(4141)
n, a = 41, 0
F2 = PolynomialRing(GF(2), 'z'); z = F2.gen()
tail = 1
while not (z**n + F2([(tail >> i) & 1 for i in range(16)])).is_irreducible():
    tail += 2
K = GF(2**n, 'z', modulus=z**n + F2([(tail >> i) & 1 for i in range(16)]))
E0 = EllipticCurve(K, [1, a, 0, 0, 1])
card = E0.cardinality()
N = max(p for p, e in factor(card))
assert card == 4 * N and N.is_prime(proof=True) and N == 549756390943
enc = lambda u: int(u.to_integer())
while True:
    G = 4 * E0.random_point()
    if G != 0:
        break
Rn = PolynomialRing(GF(N), 'X'); X = Rn.gen()
s = [Integer(r) for r in (X**2 + X + 2).roots(multiplicities=False) if int(r) * G == E0(G[0]**2, G[1]**2)][0]
assert pow(s, n, N) == 1
planted = []
with open(os.path.join(HERE, 'toyB_targets.txt'), 'w') as fh:
    fh.write(f"n {n}\ntail {tail:x}\na2 {a}\nb 1\nN {N}\ns {s}\nG {enc(G[0]):x} {enc(G[1]):x}\ntrials {TT}\ntargets {M}\n")
    for ti in range(TT):
        row = []
        for k in range(M):
            lg = randint(1, int(N) - 1)
            P = lg * G
            fh.write(f"t {ti} {k} {enc(P[0]):x} {enc(P[1]):x}\n")
            row.append(int(lg))
        planted.append(row)
json.dump(dict(n=n, a=a, tail=tail, N=int(N), s=int(s), classes=int((N - 1) // (2 * n)), planted=planted),
          open(os.path.join(HERE, 'toyB_planted.json'), 'w'))
print('ok', n, tail, N, s)
