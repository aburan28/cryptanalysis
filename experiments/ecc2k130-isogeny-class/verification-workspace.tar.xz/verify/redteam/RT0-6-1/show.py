import json,sys; d=json.load(sys.stdin)
for k in ['name','trials','targets_per_trial','rho','logs_checked','logs_wrong','abandoned_walks','base_ideal','base_eff','first_target','last_target']: print(k, d[k])
for c in d['cumulative']: print(c)
for b in d['blocks']: print(b)
