"""Search toy Koblitz analogues y^2+xy=x^3+a x^2+1 over F_{2^n} (n prime) for the RT0-6 batch test:
N = largest prime of #E with 30 <= log2 N <= 38, N^2 not | #E, and a small odd prime l | f
(t^2-4q = -7 f^2) with kronecker(-7,l) = +1 (as for 263) and l not | #E.
run: sage -python toy_params.py
"""
from sage.all import Integer, factor, kronecker, prime_range, is_prime, log
out = []
for n in prime_range(31, 64):
    for a in (0, 1):
        t1 = -1 if a == 0 else 1
        tt = [Integer(2), Integer(t1)]
        for _ in range(2, n + 1):
            tt.append(t1 * tt[-1] - 2 * tt[-2])
        t = tt[n]; q = Integer(2) ** n; card = q + 1 - t
        fac = factor(card); N = max(p for p, e in fac)
        if card % (N * N) == 0:
            continue
        lg = float(log(N, 2))
        D = t * t - 4 * q; f2 = -D // 7; f = f2.isqrt()
        assert f * f == f2
        ls = [l for l in prime_range(3, 80) if f % l == 0 and kronecker(-7, l) == 1 and card % l != 0]
        out.append((n, a, lg, str(fac), str(factor(f)), ls))
        if 29 <= lg <= 40 and ls:
            print(n, a, round(lg, 2), fac, '| f =', factor(f), '| l candidates', ls, flush=True)
