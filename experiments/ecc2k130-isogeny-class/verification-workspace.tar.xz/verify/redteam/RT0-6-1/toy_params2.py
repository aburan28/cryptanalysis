"""Relaxed toy search: print every (n,a) with n prime in [23,63], N = largest prime of #E, the
factorization of f, and odd primes l <= 400 dividing f (with kronecker(-7,l))."""
from sage.all import Integer, factor, kronecker, prime_range, log
for n in prime_range(23, 64):
    for a in (0, 1):
        t1 = -1 if a == 0 else 1
        tt = [Integer(2), Integer(t1)]
        for _ in range(2, n + 1):
            tt.append(t1 * tt[-1] - 2 * tt[-2])
        t = tt[n]; q = Integer(2) ** n; card = q + 1 - t
        fac = factor(card); N = max(p for p, e in fac)
        D = t * t - 4 * q; f = (-D // 7).isqrt()
        ls = [(l, kronecker(-7, l), card % l == 0) for l in prime_range(3, 400) if f % l == 0]
        print(n, a, round(float(log(N, 2)), 1), fac, '| f =', factor(f), '|', ls)
