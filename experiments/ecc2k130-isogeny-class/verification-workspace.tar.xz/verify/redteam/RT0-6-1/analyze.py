"""Analyze ksrho outputs against the Kuhn-Struik prediction.
usage: python3 analyze.py <name> <planted.json> <mode: B|Aindep|Ashared> <classes l> <r> <out1> [<out2> ...]
Writes <name>_analysis.json.
Prediction for target i (0-indexed) of a trial:  E_i = sqrt(pi * l_eff / 2) * C(2i,i)/4^i, where
l_eff = l / (1 - rho) and rho = (1/r) * (fraction of draws that are walk iterations rather than
fresh starts): an iteration f(X) = g_{h(X)}(X) (g_c bijections on classes) cannot land on a stored
point whose predecessor used the same branch.  rho = 0 gives the ideal random-walk figure.
"""
import sys, json, math
from math import comb, sqrt, pi, log2

name, planted_f, mode, ell, r = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5])
outs = sys.argv[6:]
rows = {}
N = None
for fn in outs:
    for line in open(fn):
        if line.startswith('# '):
            N = int(line.split('N=')[1].split()[0])
        if not line.startswith('r '):
            continue
        _, ti, tg, draws, iters, walks, ab, k = line.split()
        rows[(int(ti), int(tg))] = dict(draws=int(draws), iters=int(iters), walks=int(walks), ab=int(ab), k=int(k))
trials = sorted({t for t, _ in rows})
M = max(g for _, g in rows) + 1
trials = [t for t in trials if all((t, g) in rows for g in range(M))]
T = len(trials)
P = json.load(open(planted_f))
# ---- log verification against planted values
bad = 0; checked = 0
for t in trials:
    if mode == 'B':
        pl = P['planted'][t]
        for g in range(M):
            checked += 1; bad += rows[(t, g)]['k'] != pl[g]
    elif mode == 'Aindep':
        for m in range(M // 2):
            lp, lq = rows[(t, 2 * m)]['k'], rows[(t, 2 * m + 1)]['k']
            kk = lq * pow(lp, -1, N) % N
            checked += 1; bad += kk != P[t][m]['k']
    elif mode == 'Ashared':
        for g in range(M):
            checked += 1; bad += rows[(t, g)]['k'] != P[t][g]['log_G']
tot_draws = sum(v['draws'] for v in rows.values())
tot_walks = sum(v['walks'] for v in rows.values())
tot_iters = sum(v['iters'] for v in rows.values())
tot_ab = sum(v['ab'] for v in rows.values())
frac_iter = 1 - tot_walks / tot_draws
rho = frac_iter / r
base_ideal = sqrt(pi * ell / 2)
base_eff = sqrt(pi * ell / (2 * (1 - rho)))
c = lambda i: comb(2 * i, i) / 4 ** i
per = []
for g in range(M):
    xs = [rows[(t, g)]['draws'] for t in trials]
    mu = sum(xs) / T
    sd = sqrt(sum((x - mu) ** 2 for x in xs) / (T - 1))
    per.append(dict(i=g, mean=mu, se=sd / sqrt(T), pred_eff=base_eff * c(g), pred_ideal=base_ideal * c(g)))
cum = []
for L in sorted({1, 2, 4, 8, 16, 32, 64, 128, 256, 512, M} & set(range(1, M + 1))):
    xs = [sum(rows[(t, g)]['draws'] for g in range(L)) for t in trials]
    mu = sum(xs) / T
    sd = sqrt(sum((x - mu) ** 2 for x in xs) / (T - 1))
    S = sum(c(i) for i in range(L))
    pe = base_eff * S
    iters = sum(sum(rows[(t, g)]['iters'] for g in range(L)) for t in trials) / T
    cum.append(dict(L=L, mean_total_draws=round(mu, 1), se=round(sd / sqrt(T), 1), pred_eff=round(pe, 1),
                    ratio=round(mu / pe, 4), z=round((mu - pe) / (sd / sqrt(T)), 2),
                    pred_ideal=round(base_ideal * S, 1), mean_total_iters_incl_DP_tails=round(iters, 1),
                    measured_gain_vs_L_separate=round(L * per[0]['mean'] / mu, 3) if mu else None,
                    KS_gain_pred=round(L / S, 3)))
# per-target ratio profile in blocks
blocks = []
edges = [0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512]
for lo, hi in zip(edges, edges[1:]):
    if lo >= M:
        break
    hi = min(hi, M)
    m = sum(per[g]['mean'] for g in range(lo, hi)); p = sum(per[g]['pred_eff'] for g in range(lo, hi))
    se = sqrt(sum(per[g]['se'] ** 2 for g in range(lo, hi)))
    blocks.append(dict(targets=f'{lo}..{hi - 1}', mean_sum=round(m, 1), pred_sum=round(p, 1), ratio=round(m / p, 4), z=round((m - p) / se, 2)))
res = dict(name=name, mode=mode, trials=T, targets_per_trial=M, classes=ell, r=r, rho=rho,
           logs_checked=checked, logs_wrong=bad, abandoned_walks=tot_ab, total_draws=tot_draws, total_iters=tot_iters,
           base_ideal=base_ideal, base_eff=base_eff, cumulative=cum, blocks=blocks,
           first_target=dict(mean=per[0]['mean'], se=per[0]['se'], pred_eff=per[0]['pred_eff']),
           last_target=dict(mean=per[-1]['mean'], se=per[-1]['se'], pred_eff=per[-1]['pred_eff']))
json.dump(res, open(f'{name}_analysis.json', 'w'), indent=1)
print(json.dumps(res, indent=1))
