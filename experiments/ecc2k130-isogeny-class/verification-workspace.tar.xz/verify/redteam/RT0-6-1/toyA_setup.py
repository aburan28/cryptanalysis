"""RT0-6 toy A: end-to-end analogue of the B1 batch.

E0: y^2 + xy = x^3 + 1 over F_{2^37} (modulus z^37 + z^5+z^4+z^3+z^2+z+1), #E0 = 4*149*N,
N = 230603167.  f = 73 * 2663 and 73 | f, (-7/73) = -1, so E0 (crater, End = O_K) has 74
descending F_q-rational 73-isogenies and no horizontal ones: 74 floor curves (2 Frobenius
orbits of 37), each with a unique rational 73-isogeny back up to E0.

This script (Sage) builds:
  * the 74 descending isogenies phi_c : E0 -> E_c (Sage isogenies_prime_degree),
  * the ascending isogeny psi_c : E_c -> E0 for each floor curve, WITHOUT Sage's dual (not
    implemented in char 2): ker psi_c = phi_c(C') for another E0 subgroup C'; its kernel
    polynomial is a characteristic polynomial over F_q (see below),
  * checks: codomain(psi_c) ~= E0 (not the twist), iso o psi_c o phi_c = +-73 on <G>,
  * planted DLP instances on the 75 curves (E0 + 74 floor), transported to E0.
Targets for the C multi-instance rho are written to text files; planted logs to JSON.

usage: sage -python toyA_setup.py <trials_indep> <inst_per_trial_indep> <trials_shared> <inst_per_trial_shared>
"""
import sys, json, time, os
from sage.all import (GF, PolynomialRing, EllipticCurve, Integer, set_random_seed, randint, factor)

HERE = os.path.dirname(os.path.abspath(__file__))
TI, MI, TS, MS = (int(x) for x in sys.argv[1:5])
set_random_seed(20260924)
T0 = time.time()
LOG = []


def chk(label, cond, **info):
    LOG.append(dict(check=label, ok=bool(cond), t=round(time.time() - T0, 1), **{k: str(v) for k, v in info.items()}))
    print(('OK  ' if cond else 'FAIL'), label, info if info else '', flush=True)
    assert cond, label


n, a, l, tail = 37, 0, 73, 63
F2 = PolynomialRing(GF(2), 'z'); z = F2.gen()
mod = z**n + F2([(tail >> i) & 1 for i in range(8)])
chk('modulus irreducible', mod.is_irreducible(), modulus=mod)
K = GF(2**n, 'z', modulus=mod)
E0 = EllipticCurve(K, [1, a, 0, 0, 1])
card = E0.cardinality()
N = Integer(230603167)
h = card // N
chk('#E0 = 4*149*N, N prime', card == 4 * 149 * N and N.is_prime(proof=True), card=factor(card))
t = 2**n + 1 - card
f = ((4 * 2**n - t * t) // 7).isqrt()
chk('t^2-4q = -7 f^2, 73 || f', t * t - 4 * 2**n == -7 * f * f and f % 73 == 0 and f % (73 * 73) != 0, f=factor(f))
enc = lambda u: int(u.to_integer())
dec = lambda v: K.from_integer(int(v))

while True:
    G = h * E0.random_point()
    if G != 0:
        break
chk('N*G = 0', N * G == 0)
Rn = PolynomialRing(GF(N), 'X'); X = Rn.gen()
s = None
for r in (X**2 + X + 2).roots(multiplicities=False):
    if int(r) * G == E0(G[0]**2, G[1]**2):
        s = Integer(r)
chk('tau acts on <G> as s, s^37 = 1', s is not None and pow(s, n, N) == 1 and s != 1, s=s)

# ---- descending isogenies from E0
tb = time.time()
down = E0.isogenies_prime_degree(l)
chk('74 rational 73-isogenies from E0, 74 distinct floor j, none = 1',
    len(down) == 74 and len(set(ph.codomain().j_invariant() for ph in down)) == 74
    and all(ph.codomain().j_invariant() != 1 for ph in down), secs=round(time.time() - tb, 1))

# normalized floor models [1, a2, 0, 0, 1/j] with the same order as E0
floor = {}
for ph in down:
    j = ph.codomain().j_invariant()
    for a2 in (0, 1):
        Ec = EllipticCurve(K, [1, a2, 0, 0, 1 / j])
        if Ec.cardinality() == card:
            break
    else:
        raise AssertionError('no model with #E0 points')
    iso = ph.codomain().isomorphism_to(Ec)
    floor[j] = dict(E=Ec, a2=a2, phi=(ph, iso))
chk('every floor curve has a model [1,a2,0,0,1/j] with #E = #E0', len(floor) == 74)

# Frobenius orbits of the floor j's
js = sorted(floor.keys(), key=enc)
orbits, seen = [], set()
for j in js:
    if j in seen:
        continue
    orb = [j]
    while True:
        nj = orb[-1]**2
        if nj == j:
            break
        orb.append(nj)
    for u in orb:
        seen.add(u)
    orbits.append(orb)
chk('2 Frobenius orbits of 37', sorted(len(o) for o in orbits) == [37, 37])
labels = {}
for oi, orb in enumerate(orbits):
    for i, j in enumerate(orb):
        labels[j] = f'{"AB"[oi]}{i:02d}'
        floor[j]['label'] = labels[j]
        floor[j]['frob_index'] = i

# ---- ascending isogeny psi_c : E_c -> E0 without Sage's dual (not implemented in char 2) and
# without factoring E_c's 73-division polynomial (PARI stack overflow on the floor curves):
# ker psi_c = phi_c(C') for ANY other 73-subgroup C' of E0 (C' meets ker phi_c trivially).
# With kappa' = kernel polynomial of C' (degree 36 over F_q), the kernel polynomial of psi_c is the
# characteristic polynomial of u = phi_c_x(x) in F_q[x]/(kappa'): its roots are x(phi_c(Q)), Q in C'/+-.
RK = PolynomialRing(K, 'Y')
up_kernel = {}
tb = time.time()
for idx, j in enumerate(js):
    ph, isoc = floor[j]['phi']
    j2 = js[(idx + 1) % len(js)]
    kp2 = floor[j2]['phi'][0].kernel_polynomial()
    A = kp2.parent().quotient(kp2)
    xm = ph.x_rational_map()
    u = A(xm.numerator()) * A(xm.denominator())**-1
    up_kernel[j] = RK(u.charpoly('Y').list())
chk('ascending kernel polynomials via charpoly (degree 36 each)', all(k.degree() == 36 for k in up_kernel.values()),
    secs=round(time.time() - tb, 1))

transport = {}
sign_counts = {'+73': 0, '-73': 0}
for j in js:
    ph, isoc = floor[j]['phi']
    Ecod = ph.codomain()
    psi = Ecod.isogeny(up_kernel[j])
    cod = psi.codomain()
    ok_j = cod.j_invariant() == 1
    iso0 = cod.isomorphism_to(E0)        # raises if cod is the quadratic twist of E0
    back = ~isoc                         # normalized model E_c -> Ecod (inverse isomorphism)
    GG = iso0(psi(ph(G)))
    sg = '+73' if GG == 73 * G else ('-73' if GG == -73 * G else 'FAIL')
    sign_counts[sg] = sign_counts.get(sg, 0) + 1
    transport[j] = (psi, iso0, back)
    floor[j]['sign'] = sg
    assert ok_j and sg != 'FAIL', floor[j]['label']
chk('all 74 ascending isogenies land on E0 (not its twist) and iso o psi o phi = +-73 on <G>',
    sign_counts.get('FAIL', 0) == 0 and sum(sign_counts.values()) == 74, signs=sign_counts)


def tr(j, P):
    psi, iso0, back = transport[j]
    return iso0(psi(back(P)))


curves = ['E0'] + js           # 75 curves


def rand_pt(E):
    while True:
        P = h * E.random_point()
        if P != 0:
            return P


def write_targets(fname, trials):
    with open(fname, 'w') as fh:
        fh.write(f"n {n}\ntail {tail:x}\na2 {a}\nb 1\nN {N}\ns {s}\nG {enc(G[0]):x} {enc(G[1]):x}\n")
        fh.write(f"trials {len(trials)}\ntargets {len(trials[0])}\n")
        for ti, tg in enumerate(trials):
            for k, P in enumerate(tg):
                fh.write(f"t {ti} {k} {enc(P[0]):x} {enc(P[1]):x}\n")


# ---- independent bases: instance (P, Q = kP) on curve c; targets psi(P), psi(Q)
tb = time.time()
trials, planted, n_ok = [], [], 0
for ti in range(TI):
    tg, pl = [], []
    for m in range(MI):
        c = curves[(ti * MI + m) % len(curves)]
        E = E0 if c == 'E0' else floor[c]['E']
        P = rand_pt(E)
        k = randint(1, int(N) - 1)
        Q = k * P
        if c == 'E0':
            Pt, Qt = P, Q
        else:
            Pt, Qt = tr(c, P), tr(c, Q)
        n_ok += (Qt == k * Pt and N * Pt == 0 and Pt != 0)
        tg += [Pt, Qt]
        pl.append(dict(curve='E0' if c == 'E0' else floor[c]['label'], k=int(k)))
    trials.append(tg)
    planted.append(pl)
    if ti % 25 == 0:
        print('indep trial', ti, round(time.time() - tb, 1), flush=True)
chk('independent-base instances: transported Q = k * transported P, order N', n_ok == TI * MI,
    count=n_ok, secs=round(time.time() - tb, 1))
write_targets(os.path.join(HERE, 'toyA_indep_targets.txt'), trials)
json.dump(planted, open(os.path.join(HERE, 'toyA_indep_planted.json'), 'w'))

# ---- shared base: P_c = phi_c(G) (E0 instances: P = G); target psi(Q) with log_G = +-73 k
tb = time.time()
trials, planted, n_ok = [], [], 0
for ti in range(TS):
    tg, pl = [], []
    for m in range(MS):
        c = curves[(ti * MS + m) % len(curves)]
        k = randint(1, int(N) - 1)
        if c == 'E0':
            Qt, lg = k * G, k
        else:
            if 'Pc' not in floor[c]:
                ph, isoc = floor[c]['phi']
                floor[c]['Pc'] = isoc(ph(G))
            Pc = floor[c]['Pc']
            Qc = k * Pc
            Qt = tr(c, Qc)
            lg = (73 * k if floor[c]['sign'] == '+73' else -73 * k) % N
        n_ok += (Qt == lg * G)
        tg.append(Qt)
        pl.append(dict(curve='E0' if c == 'E0' else floor[c]['label'], k=int(k), log_G=int(lg)))
    trials.append(tg)
    planted.append(pl)
chk('shared-base instances: transported Q = (+-73 k) G', n_ok == TS * MS, count=n_ok, secs=round(time.time() - tb, 1))
write_targets(os.path.join(HERE, 'toyA_shared_targets.txt'), trials)
json.dump(planted, open(os.path.join(HERE, 'toyA_shared_planted.json'), 'w'))

meta = dict(n=n, a=a, l=l, tail=tail, N=int(N), card=int(card), s=int(s), f=str(factor(f)), t=int(t),
            G=[enc(G[0]), enc(G[1])], classes=int((N - 1) // (2 * n)),
            floor=[dict(label=floor[j]['label'], j_int=enc(j), b_int=enc(1 / j), a2=floor[j]['a2'],
                        sign=floor[j]['sign'], up_kernel=[enc(c) for c in up_kernel[j].list()]) for j in js],
            log=LOG, secs=round(time.time() - T0, 1))
json.dump(meta, open(os.path.join(HERE, 'toyA_meta.json'), 'w'), indent=1)
print('done', round(time.time() - T0, 1))
