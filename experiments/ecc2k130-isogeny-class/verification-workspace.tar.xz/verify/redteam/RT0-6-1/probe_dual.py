import time
from sage.all import *
n=37; a=0; l=73; tail=63
R=PolynomialRing(GF(2),'z'); z=R.gen()
K=GF(2**n,'z',modulus=z**n+R([ (tail>>i)&1 for i in range(8)]))
E0=EllipticCurve(K,[1,a,0,0,1])
# small test first: the 7-isogenies? use any small prime isogeny of E0 to test dual support
t0=time.time()
kp = None
for ll in (3,5,7,11,13):
    iso = E0.isogenies_prime_degree(ll)
    print(ll, len(iso))
    if iso:
        phi=iso[0]
        try:
            d=phi.dual(); print('dual ok', d.degree(), d.codomain().j_invariant()==1, time.time()-t0)
        except Exception as e:
            print('dual fail', type(e), e)
        break
