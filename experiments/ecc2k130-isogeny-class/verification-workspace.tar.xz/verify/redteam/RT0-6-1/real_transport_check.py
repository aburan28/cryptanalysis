"""RT0-6 real-curve spot check of the only class-specific ingredient of the batch: transporting a
floor-curve DLP instance to E0.  For a few floor curves, rebuild the ascending 263-isogeny with
Sage's own Kohel construction from the kernel x-coordinates stored by transport-263
(kernels_all.json, read-only), then check: codomain ~= E0 over F_q, planted Q = kP maps to
psi(Q) = k psi(P) with psi(P) of order N, and tau(psi P) = [s] psi(P) (so E0's +-tau classes apply).
run: sage -python real_transport_check.py A000 A064 B000 B130
"""
import sys, json, time, os
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import PolynomialRing, prod, EllipticCurve, randint, set_random_seed, Integer

set_random_seed(6161)
HERE = os.path.dirname(os.path.abspath(__file__))
labels = sys.argv[1:]
K, curves = ecc2k.load(['E0'] + labels)
E0 = curves['E0']
N, s = Integer(ecc2k.N), Integer(ecc2k.TAU_EIGEN)
kern = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json'))
RK = PolynomialRing(K, 'X'); X = RK.gen()
out = {}
for lab in labels:
    t0 = time.time()
    E = curves[lab]
    xs = [K.from_integer(int(h, 16)) for h in kern[lab]]
    kp = prod(X - u for u in xs)
    psi = E.isogeny(kp)                       # Sage Kohel/Velu, check=True validates the kernel
    cod = psi.codomain()
    iso = cod.isomorphism_to(E0)              # fails if the codomain were the twist
    tb = time.time() - t0
    ok = 0
    M = 5
    for _ in range(M):
        while True:
            P = 4 * E.random_point()
            if P != 0:
                break
        k = randint(1, int(N) - 1)
        Pt, Qt = iso(psi(P)), iso(psi(k * P))
        tauP = E0(Pt[0]**2, Pt[1]**2)
        ok += (N * P == 0 and Pt != 0 and N * Pt == 0 and Qt == k * Pt and tauP == s * Pt)
    out[lab] = dict(n_kernel_x=len(xs), distinct=len(set(xs)), degree=int(psi.degree()), codomain_j_is_1=bool(cod.j_invariant() == 1),
                    iso_to_E0=True, planted_ok=f'{ok}/{M}', build_s=round(tb, 1), total_s=round(time.time() - t0, 1))
    print(lab, out[lab], flush=True)
json.dump(out, open(os.path.join(HERE, 'real_transport_check.json'), 'w'), indent=1)
