"""RT0-6 check 1: exact Kuhn-Struik (KS) numbers for the ECC2K-130 B1 batch, recomputed
independently of redteam-0/ks_bases.py (exact rationals + mpmath at 60 digits instead of floats),
plus the structural facts the batch needs on E0.

run:  export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python ks_exact.py
writes ks_exact.json next to this file.

Model (KS 2001, birthday/Poisson form): with l equivalence classes and a random walk on classes,
the i-th DLP (0-indexed) solved with all earlier walk points stored costs in expectation
  E_i = sqrt(pi l / 2) * C(2i,i)/4^i,
and sum_{i<L} C(2i,i)/4^i = 2L C(2L,L)/4^L = 2 Gamma(L+1/2)/(sqrt(pi) Gamma(L)),
so the total is sqrt(2 l) Gamma(L+1/2)/Gamma(L) ~ sqrt(2 l L).
"""
import json, sys, os
from fractions import Fraction
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import Integer, factor, binomial, GF, is_prime
import mpmath as mp

mp.mp.dps = 60
HERE = os.path.dirname(os.path.abspath(__file__))
N, q, t = Integer(ecc2k.N), Integer(ecc2k.q), Integer(ecc2k.t)
s = Integer(ecc2k.TAU_EIGEN)
out = {}

# ---- basic facts
assert q + 1 - t == 4 * N and is_prime(N)
assert (s * s + s + 2) % N == 0
ords = [j for j in range(1, 132) if pow(s, j, N) == 1]
assert ords[0] == 131
assert (N - 1) % 262 == 0
ell = (N - 1) // 262           # number of non-trivial classes {+-tau^j R}
out["classes_ell"] = str(ell)
out["classes_log2"] = float(mp.log(ell, 2))
L2 = lambda x: float(mp.log(x, 2))
rho1 = mp.sqrt(mp.pi * ell / 2)
out["rho_one_log2"] = L2(rho1)
rho_neg = mp.sqrt(mp.pi * mp.mpf(N) / 4)       # floor curve alone: only negation
out["rho_floor_neg_only_log2"] = L2(rho_neg)


def S(L):
    """exact sum_{i<L} C(2i,i)/4^i"""
    return sum(Fraction(int(binomial(2 * i, i)), 4 ** i) for i in range(L))


def closed(L):
    return Fraction(2 * L * int(binomial(2 * L, L)), 4 ** L)


rows = {}
for L in (1, 2, 131, 262, 263, 525, 526, 1000):
    SL = S(L)
    assert SL == closed(L), L                  # identity check, exact
    tot = rho1 * mp.mpf(SL.numerator) / SL.denominator
    rows[L] = dict(sum_exact_float=float(SL), total_log2=L2(tot), per_instance_log2=L2(tot / L),
                   naive_log2=L2(L * rho1), gain_bits=L2(L * rho1) - L2(tot),
                   asympt_sqrt_2lL_log2=L2(mp.sqrt(2 * ell * L)),
                   marginal_last_log2=L2(rho1 * mp.mpf(int(binomial(2 * (L - 1), L - 1))) / 4 ** (L - 1)))
out["KS"] = {str(k): v for k, v in rows.items()}

# claims to check (from the RT0-6 statement)
claims = {"L263_shared_total": (rows[263]["total_log2"], 65.00),
          "L263_indep_total(2L=526)": (rows[526]["total_log2"], 65.50),
          "L263_shared_per_inst": (rows[263]["total_log2"] - float(mp.log(263, 2)), 56.96),
          "L263_indep_per_inst": (rows[526]["total_log2"] - float(mp.log(263, 2)), 57.46),
          "L263_separately": (rows[263]["naive_log2"], 68.85),
          "L2_total": (rows[2]["total_log2"], 61.39),
          "L131_total": (rows[131]["total_log2"], 64.50),
          "L1000_total": (rows[1000]["total_log2"], 65.97),
          "rho_one": (out["rho_one_log2"], 60.81)}
out["claims"] = {k: dict(recomputed=round(v[0], 4), claimed=v[1], match_2dp=abs(v[0] - v[1]) < 0.006)
                 for k, v in claims.items()}
# 2L-1 variant: take G := psi_1(P_1), so instance 1 needs only log_G(psi_1 Q_1)
out["L263_indep_2L-1_total_log2"] = rows[525]["total_log2"]
# baseline if floor instances were NOT transported (each floor DLP alone, negation only)
out["L263_separately_no_transport_log2"] = L2(rho1 + 262 * rho_neg)

# ---- Frobenius-and-add walk (Bailey et al. 2009 style: R -> R + tau^c R, c in 3..10) is purely
# multiplicative on logs: x -> (1+s^c) x.  Walks from start x0 stay in the coset x0*H,
# H = <-1, s, 1+s^c>.  Compute [F_N^* : H] (if > 1, the database splits into cosets).
fac = factor(N - 1)
out["N_minus_1_factorization"] = str(fac)
gens = [N - 1, s] + [(1 + pow(s, c, N)) % N for c in range(3, 11)]
index = Integer(1)
per_prime = {}
for (r, e) in fac:
    # largest r^k such that all generators are r^k-th powers
    k = 0
    while k < e and all(pow(int(g), int((N - 1) // r ** (k + 1)), int(N)) == 1 for g in gens):
        k += 1
    per_prime[str(r)] = k
    index *= r ** k
out["frob_add_walk_multiplier_group_index"] = str(index)
out["frob_add_walk_index_by_prime"] = per_prime

# ---- practical side conditions for the batch (KS with distinguished points, m parallel walks):
# each new instance needs its m fresh walks to run ~1/theta steps before any DP can be reported,
# so the marginal cost of instance i is >= m/theta; memory = total * theta DPs.
side = {}
for (lm, lth) in ((20, 30), (24, 30), (20, 25), (30, 30)):
    side[f"m=2^{lm},theta=2^-{lth}"] = dict(
        per_instance_floor_log2=lm + lth,
        vs_marginal_last_of_263_log2=rows[263]["marginal_last_log2"],
        stored_DPs_log2_for_L263=rows[263]["total_log2"] - lth)
out["DP_side_conditions"] = side

json.dump(out, open(os.path.join(HERE, "ks_exact.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
