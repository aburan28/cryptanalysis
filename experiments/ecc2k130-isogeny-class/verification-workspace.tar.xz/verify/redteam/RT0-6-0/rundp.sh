#!/bin/bash
# DP / parallel-walk Kuhn-Struik on the n=41 scale model, L=263, two walk-count x DP-rate settings
cd /Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-6-0
export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
H=in41_hdr.txt
timeout 2400 ./ksdp $H 25 501 263 10 8 6 20 > runs/dp_M8_dp6_s501.json 2> runs/dp_M8_dp6_s501.err &
timeout 2400 ./ksdp $H 25 502 263 10 8 6 20 > runs/dp_M8_dp6_s502.json 2> runs/dp_M8_dp6_s502.err &
timeout 2400 ./ksdp $H 25 503 263 10 64 6 20 > runs/dp_M64_dp6_s503.json 2> runs/dp_M64_dp6_s503.err &
timeout 2400 ./ksdp $H 25 504 263 10 64 6 20 > runs/dp_M64_dp6_s504.json 2> runs/dp_M64_dp6_s504.err &
wait
echo done
