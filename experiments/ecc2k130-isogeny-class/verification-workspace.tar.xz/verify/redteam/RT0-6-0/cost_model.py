# RT0-6 end-to-end cost model at real scale (ECC2K-130 class, 263 curves).
# Inputs and where they come from:
#   KS iteration counts ............ ks_exact.json (this directory; closed form, exact class count)
#   2^60.9 realistic single-DLP work  repo paper/sec-ecc2k-arith.tex:13, sec-ecc2k-campaign.tex:48 (Bailey et al. walk)
#   2^28.41 iterations per DP, 32-byte DP records, 6,160,384 logical walks, maxIters 2^30
#                                    repo paper/sec-ecc2k-campaign.tex (live campaign config / Table cutoff 32)
#   14.1e9 iterations/s per RTX PRO 6000 while collecting   repo paper/sec-ecc2k-gpu.tex:18,155
#   ~11 field multiplications per iteration (inversion = 8 of ~11)  repo paper/sec-ecc2k-arith.tex
#   transport cost: eval ops/point {M:914,S:131,I:1,A:787}; upper bound incl. kernel build 2^15.59 M
#                                    /Volumes/SSD990/ecdlp-hardness-work/transport-263/summary.json
import json, math
from math import comb
HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-6-0/"
ks = json.load(open(HERE + "ks_exact.json"))
tr = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/summary.json"))
lg = math.log2
rows = ks["rows"]
rho1 = rows["1"]["total_log2"]
WALK_FACTOR_LOG2 = 60.9 - rho1          # realistic (Bailey-type) walk vs ideal random walk, from the documented 2^60.9
IT_PER_DP_LOG2 = 28.41
DP_BYTES = 32
W = 6160384
MAXITERS_LOG2 = 30
RATE = 14.1e9
M_PER_IT = 11.0
YEAR = 365.25 * 86400
ev = json.loads(tr["eval_ops_per_point_distinct"][0])
IT_INV_M, IT_INV_S = tr["calibration"]["IT_inversion_M"], tr["calibration"]["IT_inversion_S"]
# field-mult equivalents per transported point, counting S and A as free (normal basis) -> lower; S=M, A=0 -> upper
tp_lo = ev["M"] + ev["I"] * IT_INV_M
tp_hi = ev["M"] + ev["S"] + ev["I"] * (IT_INV_M + IT_INV_S)
build_hi = tr["transport_cost_M_equiv_upper"]["max"]           # per floor curve, incl. kernel build (upper)

def scenario(name, n_dlp, n_inst, n_transported_points, n_curves_built):
    it_ideal_log2 = rows[str(n_dlp)]["total_log2"] if str(n_dlp) in rows else None
    it_real = 2 ** (it_ideal_log2 + WALK_FACTOR_LOG2)
    dps = it_real / 2 ** IT_PER_DP_LOG2
    latency_ub = n_dlp * W * 2 ** IT_PER_DP_LOG2            # counts every detection delay as fully wasted (upper bound)
    starts = n_dlp * W * 2 * 131 * 1.5                       # W fresh starts per DLP, 2 scalar mults ~1.5*131 ops each
    replay_ub = n_dlp * 2 * 2 ** MAXITERS_LOG2
    # transport-263's per-curve upper bound already includes the kernel build AND two point evaluations (P and Q):
    # 45210 (build, I = 8M+130S, S = M) + 2*1183 = 47576 for A000 -> use it per floor instance; extra points at tp_hi.
    transport_M = n_curves_built * build_hi + max(0, n_transported_points - 2 * n_curves_built) * tp_hi
    transport_it = transport_M / M_PER_IT
    # DP-latency model (validated on the toy, see dp_model below): collisions that happen while an instance's
    # solution is still in flight (detection + switch-over window ~ 2W/theta iterations) are wasted.
    # Wasted fraction of collisions w = (2/3) sqrt(pi*L) * (2W/theta) / rho1; cost x sqrt(1+w); duplicates L(1+w)/theta.
    rho1_real = 2 ** (rho1 + WALK_FACTOR_LOG2)
    w = (2 / 3) * math.sqrt(math.pi * n_dlp) * (2 * W * 2 ** IT_PER_DP_LOG2) / rho1_real
    it_dp = it_real * math.sqrt(1 + w) + n_dlp * (1 + w) * 2 ** IT_PER_DP_LOG2 + W * 2 ** IT_PER_DP_LOG2
    total_ub = it_real + latency_ub + starts + replay_ub + transport_it
    total_model = it_dp + starts + replay_ub + transport_it
    return dict(scenario=name, dlps=n_dlp, instances=n_inst,
                iterations_ideal_log2=it_ideal_log2,
                iterations_real_walk_log2=lg(it_real),
                overhead_latency_ub_log2=lg(latency_ub), overhead_starts_log2=lg(starts),
                overhead_replay_ub_log2=lg(replay_ub),
                transport_Mequiv_log2=lg(transport_M) if transport_M else None,
                transport_iteration_equiv_log2=lg(transport_it) if transport_it else None,
                total_upper_log2=lg(total_ub),
                dp_wasted_collision_fraction_w=w, total_with_dp_latency_model_log2=lg(total_model),
                per_instance_model_log2=lg(total_model / n_inst),
                gpu_years_model=total_model / RATE / YEAR,
                overhead_fraction_ub=(total_ub - it_real) / it_real,
                per_instance_log2=lg(total_ub / n_inst),
                dp_records_log2=lg(dps), dp_storage_TB=dps * DP_BYTES / 1e12,
                gpu_years_at_14p1Gits=total_ub / RATE / YEAR)

out = {"inputs": dict(WALK_FACTOR_LOG2=WALK_FACTOR_LOG2, IT_PER_DP_LOG2=IT_PER_DP_LOG2, DP_BYTES=DP_BYTES, W=W,
                      W_log2=lg(W), MAXITERS_LOG2=MAXITERS_LOG2, RATE=RATE, M_PER_IT=M_PER_IT,
                      transport_point_M_lo=tp_lo, transport_point_M_hi=tp_hi, transport_build_M_hi=build_hi)}
sc = [scenario("one DLP (e.g. the challenge on E0)", 1, 1, 0, 0),
      scenario("one DLP on a floor curve via transport", 1, 1, 2, 1),
      scenario("263 instances, shared base (bases are isogeny images of one G)", 263, 263, 262, 262),
      scenario("263 instances, independent bases, 2L-1 DLPs (G := transported P_1)", 525, 263, 2 * 262, 262),
      scenario("263 instances, independent bases, 2L DLPs (proposer's model)", 526, 263, 2 * 262, 262)]
# separate solving: 263 x one DLP (fresh database each)
one = sc[0]
sep_real = 263 * 2 ** one["iterations_real_walk_log2"]
out["separate_263_real_walk_log2"] = lg(sep_real)
out["scenarios"] = sc
# marginal (i-th) instance costs in the shared-base batch, ideal walk
out["marginal_ideal_log2"] = {str(i): rho1 + lg(comb(2 * (i - 1), i - 1) / 4 ** (i - 1)) for i in (1, 2, 10, 50, 131, 263)}
# validate the DP-latency model against the toy DP runs (n=41, L=263): predicted ratio vs measured
try:
    dps_ = json.load(open(HERE + "dp_summary.json"))
    val = {}
    for tag, r in dps_.items():
        rho1_t = r["pred"] / sum(comb(2 * i, i) / 4 ** i for i in range(r["L"]))
        wt = (2 / 3) * math.sqrt(math.pi * r["L"]) * (2 * r["M_over_theta"]) / rho1_t
        pred_ratio = math.sqrt(1 + wt) + r["L"] * (1 + wt) * 2 ** r["dpbits"] / r["pred"]
        val[tag] = dict(M_over_theta=r["M_over_theta"], w=wt, model_ratio=pred_ratio, measured_ratio=r["ratio"],
                        measured_ratio_se=r["ratio_se"])
    out["dp_model_validation_toy"] = val
    # what raising the DP cutoff to cut storage would cost (independent bases, 526 DLPs)
    tr_ = {}
    for dpl in (28.41, 30, 32, 34):
        rho1_real = 2 ** (rho1 + WALK_FACTOR_LOG2)
        wv = (2 / 3) * math.sqrt(math.pi * 526) * (2 * W * 2 ** dpl) / rho1_real
        it = 2 ** (rows["526"]["total_log2"] + WALK_FACTOR_LOG2)
        tr_[str(dpl)] = dict(w=wv, total_log2=lg(it * math.sqrt(1 + wv)), storage_TB=it / 2 ** dpl * DP_BYTES / 1e12)
    out["dp_cutoff_tradeoff_526"] = tr_
except FileNotFoundError:
    pass
print(json.dumps(out, indent=1))
json.dump(out, open(HERE + "cost_model.json", "w"), indent=1)
