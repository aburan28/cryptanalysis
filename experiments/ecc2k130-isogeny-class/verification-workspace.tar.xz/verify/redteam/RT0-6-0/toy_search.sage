# Search small Koblitz analogues of ECC2K-130 (a2=0, y^2+xy=x^3+1 over F_{2^n}, n prime <= 63)
# with a large prime factor N' of #E0 (for rho) and a small prime ell | f (so that F_q-rational
# ell-isogenies descend from E0 to floor curves that can be built quickly).
import json
res = []
for n in prime_range(29, 64):
    q = 2**n
    t0, t1 = 2, -1          # a2 = 0: #E(F_2) = 4 -> t_1 = -1
    for _ in range(n - 1):
        t0, t1 = t1, -t1 - 2*t0
    t = t1
    card = q + 1 - t
    D = t**2 - 4*q
    assert D % 7 == 0 and is_square(-D // 7)
    f = isqrt(-D // 7)
    fc = factor(card)
    Np = max(pp for pp, e in fc)
    ells = [ZZ(pp) for pp, e in factor(f) if pp < 200]
    res.append(dict(n=int(n), t=int(t), card_fac=str(fc), Nprime=int(Np), log2Np=float(log(Np, 2)),
                    f_fac=str(factor(f)), small_ells=[int(x) for x in ells],
                    split=[int(kronecker(-7, x)) for x in ells]))
    print(n, fc, 'f =', factor(f), 'log2 Np = %.2f' % float(log(Np, 2)))
json.dump(res, open('/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-6-0/toy_search.json', 'w'), indent=1)
