# RT0-6 toy, end to end: Koblitz analogue E0: y^2+xy=x^3+1 over F_{2^37} (#E0 = 4*149*N', N' = 230603167),
# f = 73*2663, kronecker(-7,73) = -1, so E0 has 74 F_q-rational descending 73-isogenies psi_j to 74 floor curves E_j.
# For every floor curve we build a transport map phi_j: E_j[N'] -> E0[N'] and create instances ON E_j.
# (Sage 10.9 has no dual isogeny in characteristic 2, so phi_j = psi_j^{-1} restricted to N'-torsion, computed by
#  root finding: x(S) is the unique F_q-root of num_X(x) - x(R) den_X(x) (degree 73); on E_j[N'] this equals
#  (1/73) * dual(psi_j), i.e. the dual up to the known scalar 73.)
#   shared-base scenario : base G_j = psi_j(G), target Q_j = k_j G_j   (transported base = G; with the dual it would be [73]G)
#   independent scenario : base P_j random of order N' on E_j, target Q_j = k_j P_j
# plus one instance on E0 itself (no transport), exactly as RT0-6 counts "E0 + all floor curves".
# Everything transported is checked: on E0, order N', and phi_j(k P) == k phi_j(P) (Sage, exact).
# Also writes the n=41 parameters (#E0 = 4*prime, the closest analogue of 4N) for the E0-only scale model.
import json, time, sys
set_random_seed(20260924)
OUT = '/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-6-0/'
R.<x> = GF(2)[]

def setup(n):
    m = R.irreducible_element(n, algorithm='minimal_weight')
    K.<z> = GF(2**n, modulus=m)
    E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
    card = E0.order()
    Np = max(p for p, e in factor(card))
    cof = card // Np
    G = cof * E0.random_point()
    while G.is_zero():
        G = cof * E0.random_point()
    assert (Np * G).is_zero()
    # tau eigenvalue on E0[N']
    Rs.<X> = GF(Np)[]
    roots = [ZZ(r) for r, e in (X**2 + X + 2).roots()]
    tauG = E0(G[0]**2, G[1]**2)
    s = [r for r in roots if r * G == tauG]
    assert len(s) == 1
    s = s[0]
    assert Mod(s, Np).multiplicative_order() == n
    tail = ZZ(m.change_ring(ZZ)(2)) - 2**n
    return K, E0, m, tail, card, Np, cof, G, s

def ip(P):  # point -> (x_int, y_int)
    return (P[0].to_integer(), P[1].to_integer())

meta = {}
# ---------------------------------------------------------------- n = 41 (E0-only scale model)
K41, E41, m41, tail41, card41, N41, cof41, G41, s41 = setup(41)
meta['n41'] = dict(n=41, modulus=str(m41), tail=int(tail41), card=str(card41), card_fac=str(factor(card41)),
                   Nprime=int(N41), s=int(s41), G=[int(v) for v in ip(G41)],
                   classes=int((N41 - 1) // 82 + 1))
print('n41', meta['n41'])

# ---------------------------------------------------------------- n = 37 end to end
t0 = time.time()
K, E0, m, tail, card, Np, cof, G, s = setup(37)
ell = 73
isos = E0.isogenies_prime_degree(ell)
assert len(isos) == ell + 1
t_iso = time.time() - t0
recs = []
rows_shared, rows_indep = [], []
# E0 instance (index 0): shared base = G itself; independent base = random P on E0
k = ZZ.random_element(1, Np)
rows_shared.append(dict(curve='E0', target=ip(k * G), log_expected=int(k), k=int(k), c=1))
P = G * ZZ.random_element(1, Np)
k = ZZ.random_element(1, Np)
rows_indep.append(dict(curve='E0', P=ip(P), Q=ip(k * P), k=int(k)))
dual_times = []
point_times = []
for j, psi in enumerate(isos):
    Ej = psi.codomain()
    assert Ej.j_invariant() != 1
    td = time.time()
    Xmap = psi.rational_maps()[0]
    numX, denX = Xmap.numerator(), Xmap.denominator()
    RK = PolynomialRing(K, 'u'); u = RK.gen()
    numX = RK(numX.univariate_polynomial()) if hasattr(numX, 'univariate_polynomial') else RK(numX)
    denX = RK(denX.univariate_polynomial()) if hasattr(denX, 'univariate_polynomial') else RK(denX)
    def phi(Rpt, psi=psi, numX=numX, denX=denX):
        if Rpt.is_zero():
            return E0(0)
        rts = [r for r, e in (numX - Rpt[0] * denX).roots()]
        cands = []
        for x0 in rts:
            for S in E0.lift_x(x0, all=True):
                if psi(S) == Rpt and (Np * S).is_zero():
                    cands.append(S)
        assert len(cands) == 1, ('preimage count', len(cands), len(rts))
        return cands[0]
    dual_times.append(time.time() - td)
    # shared-base scenario
    Gj = psi(G)
    assert not Gj.is_zero() and (Np * Gj).is_zero()
    c = phi(Gj)                      # = G  (psi^{-1} psi = id on N'-torsion; the dual would give [73]G)
    assert c == G, 'phi psi = id'
    k = ZZ.random_element(1, Np)
    Qj = k * Gj
    TQ = phi(Qj)
    assert TQ == k * G
    rows_shared.append(dict(curve='F%02d' % j, j_int=int(Ej.j_invariant().to_integer()),
                            target=ip(TQ), log_expected=int(k % Np), k=int(k), c=1))
    # independent scenario: random base on E_j itself
    cj = Ej.order() // Np
    assert Ej.order() == card, 'isogenous => same order'
    Pj = cj * Ej.random_point()
    while Pj.is_zero():
        Pj = cj * Ej.random_point()
    k = ZZ.random_element(1, Np)
    Qj = k * Pj
    tp0 = time.time()
    TP, TQ = phi(Pj), phi(Qj)
    point_times.append((time.time() - tp0) / 2)
    assert TP in E0 and TQ in E0 and not TP.is_zero()
    assert (Np * TP).is_zero()
    assert TQ == k * TP, 'transport preserves the DLP'
    rows_indep.append(dict(curve='F%02d' % j, j_int=int(Ej.j_invariant().to_integer()),
                           P=ip(TP), Q=ip(TQ), k=int(k)))
meta['n37'] = dict(n=37, modulus=str(m), tail=int(tail), card=str(card), card_fac=str(factor(card)),
                   Nprime=int(Np), s=int(s), G=[int(v) for v in ip(G)], ell=ell,
                   n_floor=len(isos), floor_j_distinct=len(set(r['j_int'] for r in rows_shared[1:])),
                   classes=int((Np - 1) // 74 + 1),
                   isogeny_build_s=t_iso, transport_setup_s_median=float(sorted(dual_times)[len(dual_times) // 2]),
                   transport_point_s_median=float(sorted(point_times)[len(point_times) // 2]),
                   checks='all transported points on E0, order N-prime, psi(phi(R))=R, phi(kP)=k phi(P), phi psi(G)=G')
json.dump(dict(meta=meta, shared=rows_shared, indep=rows_indep), open(OUT + "toy_instances.json", "w"), indent=1, default=int)

# C input files: header + one target per line: "<x_hex> <y_hex> <expected_log or -1>"
def hdr(md):
    return 'n %d\ntail %x\nN %d\ns %d\nG %x %x\n' % (md['n'], md['tail'], md['Nprime'], md['s'], md['G'][0], md['G'][1])
with open(OUT + 'in37_shared.txt', 'w') as fh:
    fh.write(hdr(meta['n37']))
    for r in rows_shared:
        fh.write('T %x %x %d\n' % (r['target'][0], r['target'][1], r['log_expected']))
with open(OUT + 'in37_indep.txt', 'w') as fh:
    fh.write(hdr(meta['n37']))
    for r in rows_indep:
        fh.write('T %x %x -1\n' % tuple(r['P']))
        fh.write('T %x %x -1\n' % tuple(r['Q']))
with open(OUT + 'in41_hdr.txt', 'w') as fh:
    fh.write(hdr(meta['n41']))
print(json.dumps(meta, indent=1, default=int))
