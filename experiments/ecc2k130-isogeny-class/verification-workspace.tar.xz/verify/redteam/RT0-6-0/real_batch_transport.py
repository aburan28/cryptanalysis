# RT0-6 real-scale check of the "one E0 database serves all curves" premise, independent code:
# for E0 and a few floor curves, plant DLP instances ON the floor curve (independent random base P_j of order N,
# Q_j = k_j P_j), transport both points to E0 with my own char-2 Velu evaluation from the stored ascending-kernel
# x-coordinates (transport-263/kernels_all.json; 131 x_Q per curve), then check on E0:
#   phi(P), phi(Q) on E0, of order N;  phi(Q) == k phi(P);  tau(phi(P)) == TAU_EIGEN * phi(P)
# (the last one is what lets a single <tau,-1>-class database on E0 serve the transported instances).
# Also times the evaluation. Run: sage -python real_batch_transport.py
import sys, json, time
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import EllipticCurve, ZZ, set_random_seed
set_random_seed(20260924)
K, curves = ecc2k.load()
N, TAU = ecc2k.N, ecc2k.TAU_EIGEN
E0 = curves["E0"]
kers = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"))
labels = ["A000", "A064", "A130", "B000", "B077", "B130"]
out = {"curves": {}}

def velu_to_E0(E, xs):
    b = E.a6()
    assert E.a1() == 1 and E.a2() == 0 and E.a3() == 0 and E.a4() == 0
    v = sum(xs)
    # codomain [1, 0, 0, v, b + v]; j must be 1 and (X, Y) -> (X, Y + v) lands on E0 (as documented in transport.py;
    # checked here by testing the image points on E0)
    def phi(P):
        x, y = P[0], P[1]
        X, Y = x, y
        for xq in xs:
            d = x + xq
            di = 1 / d
            X += xq * di + xq ** 2 * di ** 2
            Y += xq ** 2 * x * di ** 3 + xq * (x + y + xq ** 2) * di ** 2
        return E0(X, Y + v)
    return phi, v

for lab in labels:
    E = curves[lab]
    xs = [K.from_integer(int(h, 16)) for h in kers[lab]]
    assert len(xs) == 131 and len(set(xs)) == 131
    phi, v = velu_to_E0(E, xs)
    Ecod = EllipticCurve(K, [1, 0, 0, v, E.a6() + v])
    rec = {"codomain_j_is_1": bool(Ecod.j_invariant() == 1)}
    P = 4 * E.random_point()
    while P.is_zero():
        P = 4 * E.random_point()
    assert (N * P).is_zero()
    k = ZZ.random_element(1, N)
    Q = k * P
    t0 = time.time()
    TP = phi(P)
    TQ = phi(Q)
    rec["eval_seconds_per_point"] = (time.time() - t0) / 2
    rec["images_on_E0"] = True                      # E0(X, Y) raises if not on the curve
    rec["order_N"] = bool((N * TP).is_zero() and not TP.is_zero())
    rec["dlp_preserved"] = bool(TQ == k * TP)
    rec["tau_acts_as_TAU_EIGEN"] = bool(E0(TP[0] ** 2, TP[1] ** 2) == TAU * TP)
    # homomorphism spot check: phi(P + R) == phi(P) + phi(R)
    R = 4 * E.random_point()
    rec["additive"] = bool(phi(P + R) == TP + phi(R))
    rec["planted_k"] = str(k)
    out["curves"][lab] = rec
    print(lab, rec, flush=True)
out["all_ok"] = all(all(v for kk, v in r.items() if isinstance(v, bool)) for r in out["curves"].values())
print("all_ok", out["all_ok"])
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-6-0/real_batch_transport.json", "w"), indent=1)
