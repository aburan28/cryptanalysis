#!/bin/bash
# n=41 E0-only scale model of the RT0-6 headline: L=263 (shared base) and 2L=526 (independent bases)
cd /Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-6-0
export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
H=in41_hdr_test.txt
timeout 2400 ./ks $H batch 100 101 263 10 > runs/n41_b263_s101.json 2> runs/n41_b263_s101.err &
timeout 2400 ./ks $H batch 100 102 263 10 > runs/n41_b263_s102.json 2> runs/n41_b263_s102.err &
timeout 2400 ./ks $H batch 100 201 526 10 > runs/n41_b526_s201.json 2> runs/n41_b526_s201.err &
timeout 2400 ./ks $H batch 100 202 526 10 > runs/n41_b526_s202.json 2> runs/n41_b526_s202.err &
timeout 2400 ./ks $H separate 1000 301 1 10 > runs/n41_sep1_s301.json 2> runs/n41_sep1_s301.err &
wait
echo done
