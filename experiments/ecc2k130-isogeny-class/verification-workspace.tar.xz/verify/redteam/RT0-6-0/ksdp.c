/* ksdp.c -- RT0-6 re-check: Kuhn-Struik with M parallel walks and distinguished points (the real-attack
 * structure), synthetic targets k*G on the Koblitz analogue, instance-independent walk (R_h = c_h G).
 * Walks work on the lowest unsolved target; a walk whose target got solved finishes its trail to the next
 * DP (so its points still land in the database) and then restarts on the current target.
 * Fruitless 2-cycles are left by doubling; trails longer than maxmult/theta are abandoned (counted).
 * Every recovered log is verified (x*G == T and x == planted k). Cost = all point operations of all walks. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <arm_neon.h>

typedef uint64_t u64;
typedef unsigned __int128 u128;
typedef __int128 i128;

static int NB;
static u64 TAIL, MASK;
static u64 NP, SEIG, SPOW[64];

static inline u128 clmul(u64 a, u64 b) { return (u128)vmull_p64((poly64_t)a, (poly64_t)b); }
static inline u64 red(u128 p) {
    while ((p >> NB) != 0) {
        u64 H = (u64)(p >> NB);
        p = (p & MASK) ^ clmul(H, TAIL);
    }
    return (u64)p;
}
static inline u64 fmul(u64 a, u64 b) { return red(clmul(a, b)); }
static inline u64 fsqr(u64 a) { return red(clmul(a, a)); }
static u64 fsqrn(u64 a, int k) { while (k-- > 0) a = fsqr(a); return a; }
static u64 finv(u64 a) {           /* Itoh-Tsujii: a^(2^n-2) = (a^(2^(n-1)-1))^2 */
    int e = NB - 1, top = 63 - __builtin_clzll((u64)e);
    u64 beta = a; int k = 1;
    for (int i = top - 1; i >= 0; i--) {
        beta = fmul(fsqrn(beta, k), beta); k *= 2;
        if ((e >> i) & 1) { beta = fmul(fsqr(beta), a); k += 1; }
    }
    return fsqr(beta);
}

typedef struct { u64 x, y; int inf; } pt;
static pt padd(pt P, pt Q);
static pt pdbl(pt P) {
    if (P.inf || P.x == 0) { pt O = {0, 0, 1}; return O; }
    u64 l = P.x ^ fmul(P.y, finv(P.x));
    u64 x3 = fsqr(l) ^ l;                     /* a2 = 0 */
    u64 y3 = fsqr(P.x) ^ fmul(l ^ 1, x3);
    pt R = {x3, y3, 0}; return R;
}
static pt padd(pt P, pt Q) {
    if (P.inf) return Q;
    if (Q.inf) return P;
    if (P.x == Q.x) {
        if (P.y == Q.y) return pdbl(P);
        pt O = {0, 0, 1}; return O;
    }
    u64 l = fmul(P.y ^ Q.y, finv(P.x ^ Q.x));
    u64 x3 = fsqr(l) ^ l ^ P.x ^ Q.x;
    u64 y3 = fmul(l, P.x ^ x3) ^ x3 ^ P.y;
    pt R = {x3, y3, 0}; return R;
}
static int oncurve(pt P) {         /* y^2 + xy = x^3 + 1 */
    if (P.inf) return 1;
    return (fsqr(P.y) ^ fmul(P.x, P.y)) == (fmul(fsqr(P.x), P.x) ^ 1);
}
static pt smul(u64 k, pt P) {
    pt R = {0, 0, 1};
    for (int i = 63; i >= 0; i--) { R = pdbl(R); if ((k >> i) & 1) R = padd(R, P); }
    return R;
}
static int peq(pt A, pt B) { if (A.inf || B.inf) return A.inf == B.inf; return A.x == B.x && A.y == B.y; }

/* ---- arithmetic mod N' ---- */
static inline u64 mmul(u64 a, u64 b) { return (u64)(((u128)a * b) % NP); }
static inline u64 madd(u64 a, u64 b) { u64 c = a + b; return c >= NP ? c - NP : c; }
static inline u64 msub(u64 a, u64 b) { return a >= b ? a - b : a + NP - b; }
static u64 minv(u64 a) {
    i128 t = 0, nt = 1, r = NP, nr = a;
    while (nr) { i128 qq = r / nr, tmp; tmp = t - qq * nt; t = nt; nt = tmp; tmp = r - qq * nr; r = nr; nr = tmp; }
    if (t < 0) t += NP;
    return (u64)t;
}

/* ---- canonical representative of the <tau,-1> class; returns multiplier m with rep = m*P ---- */
static pt canon(pt P, u64 *m) {
    u64 xs = P.x, best = P.x; int bi = 0;
    for (int i = 1; i < NB; i++) { xs = fsqr(xs); if (xs < best) { best = xs; bi = i; } }
    u64 y = fsqrn(P.y, bi);
    u64 mm = SPOW[bi];
    if ((best ^ y) < y) { y ^= best; mm = NP - mm; }
    pt R = {best, y, 0}; *m = mm; return R;
}

/* ---- rng ---- */
static u64 rs;
static u64 rnd(void) { u64 z = (rs += 0x9E3779B97F4A7C15ULL); z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL; return z ^ (z >> 31); }
static u64 rndmod(u64 n) { return (u64)(((u128)rnd() * n) >> 64); }

/* ---- table ---- */
typedef struct { u64 x, a, b; uint32_t gen; int32_t inst; } ent;
static ent *TB; static u64 TMASK; static int TBITS; static uint32_t GEN = 0;
static inline u64 tpos(u64 x) { return (x * 0x9E3779B97F4A7C15ULL) >> (64 - TBITS); }
static ent *tfind(u64 x) {
    u64 i = tpos(x);
    for (;;) { ent *e = &TB[i]; if (e->gen != GEN) return NULL; if (e->x == x) return e; i = (i + 1) & TMASK; }
}
static void tins(u64 x, u64 a, u64 b, int inst) {
    u64 i = tpos(x);
    while (TB[i].gen == GEN) i = (i + 1) & TMASK;
    TB[i].x = x; TB[i].a = a; TB[i].b = b; TB[i].inst = inst; TB[i].gen = GEN;
}


/* ======================= ksdp: parallel distinguished-point Kuhn-Struik ======================= */
typedef struct { pt P; u64 a, b; int inst; u64 x1; long long len; } walk;
#define MAXL 4096
static u64 HM, SALT, DPMASK; static int RB; static pt *RT; static u64 *RC; static pt G;
static inline int isdp(u64 x) { return ((((x ^ 0x5bd1e995ULL) * 0xD6E8FEB86659FD93ULL) >> 20) & DPMASK) == 0; }
static pt GT[64], TT[64]; static int TT_inst = -1;
static pt smul_tab(u64 k, pt *tab) { pt R = {0, 0, 1}; for (int i = 0; k; i++, k >>= 1) if (k & 1) R = padd(R, tab[i]); return R; }
static void wstart(walk *w, int inst, pt *T, long long *cnt) {
    u64 m;
    if (TT_inst != inst) { TT[0] = T[inst]; for (int i = 1; i < 64; i++) TT[i] = pdbl(TT[i - 1]); TT_inst = inst; }
    for (;;) {
        u64 a = rndmod(NP), b = 1 + rndmod(NP - 1);
        pt P = padd(smul_tab(a, GT), smul_tab(b, TT));
        (*cnt)++;
        if (P.inf) continue;
        w->P = canon(P, &m); w->a = mmul(a, m); w->b = mmul(b, m); w->inst = inst; w->x1 = 0; w->len = 0;
        return;
    }
}
int main(int argc, char **argv) {
    if (argc < 9) { fprintf(stderr, "usage: ksdp hdr trials seed L rbits M dpbits maxlen_mult\n"); return 1; }
    FILE *fh = fopen(argv[1], "r");
    int trials = atoi(argv[2]); u64 seed = strtoull(argv[3], 0, 10); int L = atoi(argv[4]);
    RB = atoi(argv[5]); int M = atoi(argv[6]); int dpbits = atoi(argv[7]); int maxmult = atoi(argv[8]);
    int n; u64 tail, gx, gy, nprime, s;
    if (fscanf(fh, " n %d tail %llx N %llu s %llu G %llx %llx", &n, &tail, &nprime, &s, &gx, &gy) != 6) return 1;
    fclose(fh);
    NB = n; TAIL = tail; MASK = (1ULL << n) - 1; NP = nprime; SEIG = s;
    SPOW[0] = 1; for (int i = 1; i < 64; i++) SPOW[i] = mmul(SPOW[i - 1], s);
    G.x = gx; G.y = gy; G.inf = 0;
    if (!oncurve(G) || !smul(NP, G).inf) return 1;
    GT[0] = G; for (int i = 1; i < 64; i++) GT[i] = pdbl(GT[i - 1]);
    DPMASK = (1ULL << dpbits) - 1;
    double ell = (double)((NP - 1) / (2 * n) + 1), rho1 = sqrt(M_PI * ell / 2.0);
    double S = 0, c = 1; for (int i = 0; i < L; i++) { S += c; c *= (2.0 * i + 1) / (2.0 * i + 2); }
    double pred = rho1 * S;
    TBITS = 1; while ((double)(1ULL << TBITS) < 4 * pred / (double)(1 << dpbits) + 1024) TBITS++;
    TMASK = (1ULL << TBITS) - 1; TB = calloc(1ULL << TBITS, sizeof(ent));
    int R = 1 << RB; RT = malloc(sizeof(pt) * R); RC = malloc(8 * R);
    static pt T[MAXL]; static u64 K[MAXL], X[MAXL]; static int solved[MAXL];
    walk *W = malloc(sizeof(walk) * M);
    long long maxlen = (long long)maxmult << dpbits;
    rs = seed;
    double sum = 0, sum2 = 0, sumdp = 0, sumab = 0, sumlast = 0;
    printf("{\"n\":%d,\"Nprime\":%llu,\"classes\":%.0f,\"L\":%d,\"trials\":%d,\"rbits\":%d,\"M\":%d,\"dpbits\":%d,"
           "\"M_over_theta\":%.0f,\"rho1_pred\":%.3f,\"S_L\":%.6f,\"pred_total\":%.3f,\n\"trial_totals\":[",
           n, (unsigned long long)NP, ell, L, trials, RB, M, dpbits, (double)M * (1 << dpbits), rho1, S, pred);
    for (int tr = 0; tr < trials; tr++) {
        HM = rnd() | 1; SALT = rnd();
        for (int i = 0; i < R; i++) { RC[i] = 1 + rndmod(NP - 1); RT[i] = smul(RC[i], G); }
        for (int i = 0; i < L; i++) { K[i] = 1 + rndmod(NP - 1); T[i] = smul(K[i], G); solved[i] = 0; }
        GEN++; TT_inst = -1;
        long long cnt = 0, ndp = 0, aband = 0, cnt_at_prev = 0; int cur = 0, nsolved = 0;
        for (int w = 0; w < M; w++) wstart(&W[w], cur, T, &cnt);
        while (nsolved < L) {
            for (int w = 0; w < M && nsolved < L; w++) {
                walk *q = &W[w]; u64 m;
                int h = (int)(((q->P.x ^ SALT) * HM) >> (64 - RB));
                pt Q = padd(q->P, RT[h]); cnt++; q->len++;
                if (Q.inf) { wstart(q, cur, T, &cnt); continue; }
                Q = canon(Q, &m);
                u64 na = mmul(madd(q->a, RC[h]), m), nb = mmul(q->b, m);
                if (Q.x == q->x1) {                      /* fruitless 2-cycle: leave by doubling */
                    pt D = pdbl(Q); cnt++;
                    if (D.inf) { wstart(q, cur, T, &cnt); continue; }
                    Q = canon(D, &m); na = mmul(madd(na, na), m); nb = mmul(madd(nb, nb), m);
                }
                q->x1 = q->P.x;                          /* x1 = the point before the new current one */
                q->P = Q; q->a = na; q->b = nb;
                if (q->len > maxlen) { aband++; wstart(q, cur, T, &cnt); continue; }
                if (!isdp(Q.x)) continue;
                ndp++;
                ent *e = tfind(Q.x);
                if (!e) { tins(Q.x, q->a, q->b, q->inst); wstart(q, cur, T, &cnt); continue; }
                int ks = solved[e->inst], kc = solved[q->inst];
                int tgt = -1; u64 xs = 0;
                if (ks && !kc) {
                    u64 Ls = madd(e->a, mmul(e->b, X[e->inst]));
                    tgt = q->inst; xs = mmul(msub(Ls, q->a), minv(q->b));
                } else if (!ks && kc) {
                    u64 Lc = madd(q->a, mmul(q->b, X[q->inst]));
                    tgt = e->inst; xs = mmul(msub(Lc, e->a), minv(e->b));
                } else if (!ks && !kc && e->inst == q->inst && !(e->a == q->a && e->b == q->b) && e->b != q->b) {
                    tgt = q->inst; xs = mmul(msub(e->a, q->a), minv(msub(q->b, e->b)));
                }
                if (tgt >= 0) {
                    if (!peq(smul(xs, G), T[tgt]) || xs != K[tgt]) { fprintf(stderr, "VERIFY FAIL\n"); return 3; }
                    X[tgt] = xs; solved[tgt] = 1; nsolved++;
                    if (nsolved == L) sumlast += (double)(cnt - cnt_at_prev);
                    cnt_at_prev = cnt;
                    while (cur < L && solved[cur]) cur++;
                }
                if (nsolved < L) wstart(q, cur < L ? cur : 0, T, &cnt);
            }
        }
        sum += cnt; sum2 += (double)cnt * cnt; sumdp += ndp; sumab += aband;
        printf("%s%lld", tr ? "," : "", cnt); fflush(stdout);
    }
    double mean = sum / trials, sd = sqrt(sum2 / trials - mean * mean), se = sd / sqrt(trials);
    printf("],\n\"mean_total\":%.3f,\"sd_total\":%.3f,\"se_total\":%.3f,\"ratio_mean_over_pred\":%.5f,\"ratio_se\":%.5f,"
           "\"dp_per_trial\":%.1f,\"abandoned_per_trial\":%.2f,\"mean_last_instance\":%.1f,\"all_logs_verified\":true}\n",
           mean, sd, se, mean / pred, se / pred, sumdp / trials, sumab / trials, sumlast / trials);
    return 0;
}
