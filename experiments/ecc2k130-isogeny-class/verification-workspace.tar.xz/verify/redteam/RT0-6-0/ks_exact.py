# RT0-6 re-check: Kuhn-Struik totals, computed independently of the proposer's loop.
# Method: closed form  S(L) = sum_{i<L} C(2i,i)/4^i = 2L*C(2L,L)/4^L  (exact rational via Python ints),
# evaluated with mpmath at 60 digits.  Class count uses the exact number of <tau,-1>-classes of E0[N]:
#   ell_exact = (N-1)/262 + 1  (N-1 divisible by 262; class of O has size 1).
import json, math
from fractions import Fraction
from math import comb
import mpmath as mp
mp.mp.dps = 60

N = 680564733841876926932320129493409985129
q = 2**131
t = -22283658519494248867
assert q + 1 - t == 4 * N
assert (N - 1) % 262 == 0
ell_prop = mp.mpf(N) / 262                    # proposer's l
ell_exact = mp.mpf((N - 1) // 262 + 1)        # exact class count

def S_closed(L):
    return Fraction(2 * L * comb(2 * L, L), 4 ** L)

def S_loop(L):
    return sum(Fraction(comb(2 * i, i), 4 ** i) for i in range(L))

for L in (1, 2, 3, 10, 50):
    assert S_closed(L) == S_loop(L), L

def rho1(ell):
    return mp.sqrt(mp.pi * ell / 2)

def lg(x):
    return float(mp.log(x, 2))

out = {"method": "closed form 2L*C(2L,L)/4^L, mpmath 60 digits",
       "rho1_log2_prop_ell": lg(rho1(ell_prop)), "rho1_log2_exact_ell": lg(rho1(ell_exact)),
       "rho_neg_only_log2": lg(mp.sqrt(mp.pi * mp.mpf(N) / 4)),
       "rows": {}}
r1 = rho1(ell_exact)
for L in (1, 2, 131, 262, 263, 525, 526, 1000):
    S = S_closed(L)
    Sm = mp.mpf(S.numerator) / S.denominator
    tot = r1 * Sm
    asym = mp.sqrt(2 * ell_exact * L)          # Stirling limit: sqrt(pi*ell/2)*2*sqrt(L/pi)
    # marginal cost of the L-th instance (i = L-1)
    marg = r1 * mp.mpf(comb(2 * (L - 1), L - 1)) / mp.mpf(4) ** (L - 1)
    out["rows"][str(L)] = dict(S=float(Sm), S_log2=lg(Sm), total_log2=lg(tot),
                               per_instance_log2=lg(tot / L), naive_log2=lg(r1 * L),
                               stirling_sqrt_2_ell_L_log2=lg(asym),
                               marginal_last_instance_log2=lg(marg))
# the RT0-6 headline scenarios, 263 instances one per curve
rows = out["rows"]
out["headline"] = {
    "shared_base_L263_total_log2": rows["263"]["total_log2"],
    "shared_base_per_instance_log2": rows["263"]["per_instance_log2"],
    "indep_bases_2L_526_total_log2": rows["526"]["total_log2"],
    "indep_bases_2L_526_per_instance_log2": lg(r1 * mp.mpf(S_closed(526).numerator) / S_closed(526).denominator / 263),
    "indep_bases_2L_minus_1_525_total_log2": rows["525"]["total_log2"],
    "separate_263_log2": lg(263 * r1),
    "gain_shared_log2": lg(263 * r1) - rows["263"]["total_log2"],
    "gain_indep_log2": lg(263 * r1) - rows["526"]["total_log2"],
}
print(json.dumps(out, indent=1))
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-6-0/ks_exact.json", "w"), indent=1)
