# Aggregate the RT0-6 toy runs: pooled mean/SE of total points vs the Kuhn-Struik prediction,
# marginal (i-th instance) profile vs sqrt(pi l/2) C(2i,i)/4^i, and the end-to-end k check for n=37.
import json, math, glob, os
from math import comb
H = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-6-0/"
lg = math.log2

def load(path):
    return json.load(open(path))

def pool(paths):
    ds = [load(p) for p in paths]
    tot = [x for d in ds for x in d["trial_totals"]]
    n = len(tot)
    mean = sum(tot) / n
    sd = math.sqrt(sum((x - mean) ** 2 for x in tot) / (n - 1))
    se = sd / math.sqrt(n)
    d0 = ds[0]
    pred = d0["pred_total"]
    L = d0["L"]
    res = dict(files=[os.path.basename(p) for p in paths], n=d0["n"], Nprime=d0["Nprime"], classes=d0["classes"],
               mode=d0.get("mode", "dp"), L=L, trials=n, rho1_pred=d0["rho1_pred"], S_L=d0["S_L"],
               pred_total=pred, mean_total=mean, se_total=se, ratio=mean / pred, ratio_se=se / pred,
               z=(mean - pred) / se)
    if all("verified_logs" in d for d in ds):
        res["verified_logs"] = sum(d["verified_logs"] for d in ds)
        res["expected_checked"] = sum(d["expected_checked"] for d in ds)
        res["expected_ok"] = sum(d["expected_ok"] for d in ds)
    if all("per_instance_mean" in d for d in ds) and res["mode"] == "batch":
        w = [d0_["trials"] for d0_ in ds]
        per = [sum(d["per_instance_mean"][i] * d["trials"] for d in ds) / sum(w) for i in range(L)]
        rho1 = d0["rho1_pred"]
        bins, i0 = [], 0
        for i1 in (1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024):
            if i0 >= L:
                break
            i1 = min(i1, L)
            obs = sum(per[i0:i1])
            prd = sum(rho1 * (comb(2 * i, i) / 4 ** i) for i in range(i0, i1))
            bins.append(dict(instances=f"{i0 + 1}..{i1}", observed_mean=obs, predicted=prd, ratio=obs / prd))
            i0 = i1
        res["marginal_bins"] = bins
        res["cumulative_ratio_first_k"] = {str(k): sum(per[:k]) / sum(rho1 * (comb(2 * i, i) / 4 ** i) for i in range(k))
                                          for k in (1, 10, 50, L)}
    if "M_over_theta" in d0:
        res.update(M=d0["M"], dpbits=d0["dpbits"], M_over_theta=d0["M_over_theta"],
                   dp_per_trial=sum(d["dp_per_trial"] * len(d["trial_totals"]) for d in ds) / n,
                   abandoned_per_trial=sum(d["abandoned_per_trial"] * len(d["trial_totals"]) for d in ds) / n,
                   overhead_over_pred=mean / pred - 1,
                   M_over_theta_over_rho1_log2=lg(d0["M_over_theta"] / d0["rho1_pred"]))
    return res

out = {}
groups = {
    "n41_L1_separate_control": ["runs/n41_sep1_s301.json"],
    "n41_L263_batch_shared": ["runs/n41_b263_s101.json", "runs/n41_b263_s102.json"],
    "n41_L526_batch_indep": ["runs/n41_b526_s201.json", "runs/n41_b526_s202.json"],
    "n37_e2e_75_shared_batch": ["runs/n37_shared_batch.json"],
    "n37_e2e_150_indep_batch": ["runs/n37_indep_batch.json"],
    "n37_e2e_75_shared_separate_control": ["runs/n37_shared_separate.json"],
}
for g in sorted(glob.glob(H + "runs/dp_*.json")):
    groups[os.path.basename(g)[:-5]] = [os.path.relpath(g, H)]
for k, ps in groups.items():
    ps = [H + p for p in ps]
    if all(os.path.exists(p) and os.path.getsize(p) > 0 for p in ps):
        try:
            out[k] = pool(ps)
        except Exception as e:  # unfinished run (no closing brace yet)
            out[k] = dict(error=str(e)[:200])

# end-to-end k check for n=37 from the first trial's recovered logs
inst = json.load(open(H + "toy_instances.json"))
Np = inst["meta"]["n37"]["Nprime"]
e2e = {}
p = H + "runs/w37i/ks_lastlogs.txt"
if os.path.exists(p):
    logs = [int(x) for x in open(p).read().split()]
    ok = 0
    for j, r in enumerate(inst["indep"]):
        xP, xQ = logs[2 * j], logs[2 * j + 1]
        k = xQ * pow(xP, -1, Np) % Np
        ok += (k == r["k"] % Np)
    e2e["indep_k_recovered_ok"] = ok
    e2e["indep_instances"] = len(inst["indep"])
p = H + "runs/n37_shared_lastlogs.txt"
if os.path.exists(p):
    logs = [int(x) for x in open(p).read().split()]
    e2e["shared_k_recovered_ok"] = sum(1 for j, r in enumerate(inst["shared"]) if logs[j] == r["log_expected"] % Np)
    e2e["shared_instances"] = len(inst["shared"])
out["n37_end_to_end_k_check_first_trial"] = e2e
print(json.dumps(out, indent=1))
json.dump(out, open(H + "aggregate.json", "w"), indent=1)
