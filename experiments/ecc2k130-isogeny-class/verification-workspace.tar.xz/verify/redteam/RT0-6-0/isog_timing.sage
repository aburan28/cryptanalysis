import time
R.<x> = GF(2)[]
for n in (37,41):
    print(n, R.irreducible_element(n, algorithm='minimal_weight'))
n=37
m = R.irreducible_element(n, algorithm='minimal_weight')
K.<z> = GF(2**n, modulus=m)
E0 = EllipticCurve(K,[1,0,0,0,1])
print(factor(E0.order()))
t0=time.time()
isos = E0.isogenies_prime_degree(73)
print('n isogenies', len(isos), 'time', time.time()-t0)
js = [phi.codomain().j_invariant() for phi in isos]
print('j=1 count', sum(1 for j in js if j==1), 'distinct', len(set(js)))
