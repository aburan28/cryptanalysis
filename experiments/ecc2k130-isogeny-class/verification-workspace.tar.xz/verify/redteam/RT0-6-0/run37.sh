#!/bin/bash
# n=37 end to end: 75 transported instances (E0 + 74 floor curves); shared base (75 DLPs) and independent bases (150 DLPs)
cd /Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-6-0
export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
mkdir -p runs/w37i runs/w37s
( cd runs/w37i && timeout 2400 ../../ks ../../in37_indep.txt batch 2000 402 0 10 > ../n37_indep_batch.json 2> ../n37_indep_batch.err ) &
( cd runs/w37s && timeout 2400 ../../ks ../../in37_shared.txt separate 300 403 0 10 > ../n37_shared_separate.json 2> ../n37_shared_separate.err ) &
wait
echo done
