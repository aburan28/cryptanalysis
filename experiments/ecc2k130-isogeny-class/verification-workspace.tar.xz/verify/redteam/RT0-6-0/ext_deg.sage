for n, l in [(37,73),(37,2663),(41,409),(41,1721),(59,5783)]:
    q=2**n; t0,t1=2,-1
    for _ in range(n-1): t0,t1=t1,-t1-2*t0
    t=t1
    c = Mod(t,l)/2
    print(n,l,'kron',kronecker(-7,l),'pi scalar mod l =',c,'order',c.multiplicative_order(), 'v_l(q+1-t)=',valuation(q+1-t,l),'v_l(q+1+t)=',valuation(q+1+t,l))
