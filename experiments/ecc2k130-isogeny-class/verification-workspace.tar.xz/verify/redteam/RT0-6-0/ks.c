/*
 * ks.c -- RT0-6 re-check: Kuhn-Struik multi-instance Pollard rho on a Koblitz analogue
 *         E0: y^2 + x y = x^3 + 1 over F_{2^n} (n <= 63, polynomial basis z^n + tail),
 *         in the prime-order-N' subgroup, walking on <tau,-1>-classes (size 2n).
 *
 * The walk is instance-independent (required for Kuhn-Struik): f(P) = canon(P + R_h(P)),
 * R_h = c_h * G for ONE fixed base G, r = 2^rbits partitions.  Every generated class
 * representative is stored (theta = 1, i.e. the birthday count KS predicts, no DP latency).
 * A walk for target T starts at a*G + b*T; a hit on a stored point of a solved target, or a
 * non-degenerate self-hit, solves T.  A self-hit with identical (a,b) is a fruitless cycle and
 * is left by doubling.  Every recovered log is verified by a scalar multiplication x*G == T.
 *
 * Modes:  batch    : one table for all targets (Kuhn-Struik)
 *         separate : table cleared before every target (control; each costs ~ sqrt(pi*l/2))
 * Usage:  ks <header+targets file> <batch|separate> <trials> <seed> [synthL] [rbits]
 *         synthL > 0: ignore the file's targets and draw synthL fresh random targets k*G per trial.
 * Counts: "points" = class representatives generated (walk starts + steps + cycle escapes).
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <arm_neon.h>

typedef uint64_t u64;
typedef unsigned __int128 u128;
typedef __int128 i128;

static int NB;
static u64 TAIL, MASK;
static u64 NP, SEIG, SPOW[64];

static inline u128 clmul(u64 a, u64 b) { return (u128)vmull_p64((poly64_t)a, (poly64_t)b); }
static inline u64 red(u128 p) {
    while ((p >> NB) != 0) {
        u64 H = (u64)(p >> NB);
        p = (p & MASK) ^ clmul(H, TAIL);
    }
    return (u64)p;
}
static inline u64 fmul(u64 a, u64 b) { return red(clmul(a, b)); }
static inline u64 fsqr(u64 a) { return red(clmul(a, a)); }
static u64 fsqrn(u64 a, int k) { while (k-- > 0) a = fsqr(a); return a; }
static u64 finv(u64 a) {           /* Itoh-Tsujii: a^(2^n-2) = (a^(2^(n-1)-1))^2 */
    int e = NB - 1, top = 63 - __builtin_clzll((u64)e);
    u64 beta = a; int k = 1;
    for (int i = top - 1; i >= 0; i--) {
        beta = fmul(fsqrn(beta, k), beta); k *= 2;
        if ((e >> i) & 1) { beta = fmul(fsqr(beta), a); k += 1; }
    }
    return fsqr(beta);
}

typedef struct { u64 x, y; int inf; } pt;
static pt padd(pt P, pt Q);
static pt pdbl(pt P) {
    if (P.inf || P.x == 0) { pt O = {0, 0, 1}; return O; }
    u64 l = P.x ^ fmul(P.y, finv(P.x));
    u64 x3 = fsqr(l) ^ l;                     /* a2 = 0 */
    u64 y3 = fsqr(P.x) ^ fmul(l ^ 1, x3);
    pt R = {x3, y3, 0}; return R;
}
static pt padd(pt P, pt Q) {
    if (P.inf) return Q;
    if (Q.inf) return P;
    if (P.x == Q.x) {
        if (P.y == Q.y) return pdbl(P);
        pt O = {0, 0, 1}; return O;
    }
    u64 l = fmul(P.y ^ Q.y, finv(P.x ^ Q.x));
    u64 x3 = fsqr(l) ^ l ^ P.x ^ Q.x;
    u64 y3 = fmul(l, P.x ^ x3) ^ x3 ^ P.y;
    pt R = {x3, y3, 0}; return R;
}
static int oncurve(pt P) {         /* y^2 + xy = x^3 + 1 */
    if (P.inf) return 1;
    return (fsqr(P.y) ^ fmul(P.x, P.y)) == (fmul(fsqr(P.x), P.x) ^ 1);
}
static pt smul(u64 k, pt P) {
    pt R = {0, 0, 1};
    for (int i = 63; i >= 0; i--) { R = pdbl(R); if ((k >> i) & 1) R = padd(R, P); }
    return R;
}
static int peq(pt A, pt B) { if (A.inf || B.inf) return A.inf == B.inf; return A.x == B.x && A.y == B.y; }

/* ---- arithmetic mod N' ---- */
static inline u64 mmul(u64 a, u64 b) { return (u64)(((u128)a * b) % NP); }
static inline u64 madd(u64 a, u64 b) { u64 c = a + b; return c >= NP ? c - NP : c; }
static inline u64 msub(u64 a, u64 b) { return a >= b ? a - b : a + NP - b; }
static u64 minv(u64 a) {
    i128 t = 0, nt = 1, r = NP, nr = a;
    while (nr) { i128 qq = r / nr, tmp; tmp = t - qq * nt; t = nt; nt = tmp; tmp = r - qq * nr; r = nr; nr = tmp; }
    if (t < 0) t += NP;
    return (u64)t;
}

/* ---- canonical representative of the <tau,-1> class; returns multiplier m with rep = m*P ---- */
static pt canon(pt P, u64 *m) {
    u64 xs = P.x, best = P.x; int bi = 0;
    for (int i = 1; i < NB; i++) { xs = fsqr(xs); if (xs < best) { best = xs; bi = i; } }
    u64 y = fsqrn(P.y, bi);
    u64 mm = SPOW[bi];
    if ((best ^ y) < y) { y ^= best; mm = NP - mm; }
    pt R = {best, y, 0}; *m = mm; return R;
}

/* ---- rng ---- */
static u64 rs;
static u64 rnd(void) { u64 z = (rs += 0x9E3779B97F4A7C15ULL); z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL; return z ^ (z >> 31); }
static u64 rndmod(u64 n) { return (u64)(((u128)rnd() * n) >> 64); }

/* ---- table ---- */
typedef struct { u64 x, a, b; uint32_t gen; int32_t inst; } ent;
static ent *TB; static u64 TMASK; static int TBITS; static uint32_t GEN = 0;
static inline u64 tpos(u64 x) { return (x * 0x9E3779B97F4A7C15ULL) >> (64 - TBITS); }
static ent *tfind(u64 x) {
    u64 i = tpos(x);
    for (;;) { ent *e = &TB[i]; if (e->gen != GEN) return NULL; if (e->x == x) return e; i = (i + 1) & TMASK; }
}
static void tins(u64 x, u64 a, u64 b, int inst) {
    u64 i = tpos(x);
    while (TB[i].gen == GEN) i = (i + 1) & TMASK;
    TB[i].x = x; TB[i].a = a; TB[i].b = b; TB[i].inst = inst; TB[i].gen = GEN;
}

#define MAXT 4096
int main(int argc, char **argv) {
    if (argc < 5) { fprintf(stderr, "usage\n"); return 1; }
    FILE *fh = fopen(argv[1], "r");
    int batch = strcmp(argv[2], "batch") == 0;
    int trials = atoi(argv[3]);
    u64 seed = strtoull(argv[4], 0, 10);
    int synthL = argc > 5 ? atoi(argv[5]) : 0;
    int rbits = argc > 6 ? atoi(argv[6]) : 10;
    int n; u64 tail, gx, gy, nprime, s;
    if (fscanf(fh, " n %d tail %llx N %llu s %llu G %llx %llx", &n, &tail, &nprime, &s, &gx, &gy) != 6) { fprintf(stderr, "hdr\n"); return 1; }
    NB = n; TAIL = tail; MASK = (n == 64) ? ~0ULL : ((1ULL << n) - 1); NP = nprime; SEIG = s;
    SPOW[0] = 1; for (int i = 1; i < 64; i++) SPOW[i] = mmul(SPOW[i - 1], s);
    pt G = {gx, gy, 0};
    if (!oncurve(G) || !smul(NP, G).inf) { fprintf(stderr, "G bad\n"); return 1; }
    /* tau check: tau(G) == s*G */
    { pt tg = {fsqr(gx), fsqr(gy), 0}; if (!peq(tg, smul(s, G))) { fprintf(stderr, "tau eig bad\n"); return 1; } }
    static pt T[MAXT]; static long long EXP[MAXT]; int nt = 0;
    { char tag[4]; u64 x, y; long long e;
      while (fscanf(fh, " %1s %llx %llx %lld", tag, &x, &y, &e) == 4) { pt P = {x, y, 0};
        if (!oncurve(P) || !smul(NP, P).inf) { fprintf(stderr, "target %d bad\n", nt); return 1; }
        T[nt] = P; EXP[nt] = e; nt++; } }
    fclose(fh);
    int L = synthL > 0 ? synthL : nt;
    double ell = (double)((NP - 1) / (2 * n) + 1);
    /* table big enough for ~ sqrt(2 ell L) * 4 points */
    double expect = sqrt(M_PI * ell / 2.0);
    double Ssum = 0, c = 1; for (int i = 0; i < L; i++) { Ssum += c; c *= (2.0 * i + 1) / (2.0 * i + 2); }
    double pred = batch ? expect * Ssum : expect * L;
    double need = batch ? 6 * expect * Ssum : 8 * expect;
    TBITS = 1; while ((double)(1ULL << TBITS) < 2 * need) TBITS++;
    TMASK = (1ULL << TBITS) - 1;
    TB = calloc(1ULL << TBITS, sizeof(ent));
    int R = 1 << rbits;
    pt *RT = malloc(sizeof(pt) * R); u64 *RC = malloc(8 * R);
    u64 *X = malloc(8 * L); double *perinst = calloc(L, sizeof(double)); double *perinst2 = calloc(L, sizeof(double));
    double sum = 0, sum2 = 0, fruit_tot = 0; long long verified = 0, expected_ok = 0, expected_n = 0;
    rs = seed;
    printf("{\"n\":%d,\"Nprime\":%llu,\"classes\":%.0f,\"mode\":\"%s\",\"L\":%d,\"trials\":%d,\"rbits\":%d,\"synth\":%d,"
           "\"rho1_pred\":%.3f,\"S_L\":%.6f,\"pred_total\":%.3f,\n\"trial_totals\":[", n, (unsigned long long)NP, ell,
           batch ? "batch" : "separate", L, trials, rbits, synthL, expect, Ssum, pred);
    for (int tr = 0; tr < trials; tr++) {
        u64 HM = rnd() | 1, salt = rnd();
        for (int i = 0; i < R; i++) { RC[i] = 1 + rndmod(NP - 1); RT[i] = smul(RC[i], G); }
        if (synthL > 0) for (int i = 0; i < L; i++) { u64 k = 1 + rndmod(NP - 1); T[i] = smul(k, G); EXP[i] = (long long)k; }
        GEN++;
        double tot = 0; long long fruit = 0;
        for (int ti = 0; ti < L; ti++) {
            if (!batch) GEN++;
            u64 a, b, m; pt P; long long pts = 0;
        restart:
            a = rndmod(NP); b = 1 + rndmod(NP - 1);
            P = padd(smul(a, G), smul(b, T[ti]));
            if (P.inf) goto restart;
            P = canon(P, &m); a = mmul(a, m); b = mmul(b, m); pts++;
            u64 xsol;
            for (;;) {
                ent *e = tfind(P.x);
                if (!e) {
                    tins(P.x, a, b, ti);
                    int h = (int)(((P.x ^ salt) * HM) >> (64 - rbits));
                    pt Q = padd(P, RT[h]);
                    if (Q.inf) { pts++; goto restart; }
                    P = canon(Q, &m); a = mmul(madd(a, RC[h]), m); b = mmul(b, m); pts++;
                    continue;
                }
                if (e->inst == ti) {
                    if (e->a == a && e->b == b) {      /* fruitless cycle: escape by doubling */
                        fruit++;
                        pt Q = pdbl(P); if (Q.inf) { pts++; goto restart; }
                        P = canon(Q, &m); a = mmul(madd(a, a), m); b = mmul(madd(b, b), m); pts++;
                        continue;
                    }
                    if (e->b == b) { fprintf(stderr, "impossible\n"); return 2; }
                    xsol = mmul(msub(e->a, a), minv(msub(b, e->b)));
                } else {
                    u64 Ls = madd(e->a, mmul(e->b, X[e->inst]));   /* stored point: known log */
                    xsol = mmul(msub(Ls, a), minv(b));
                }
                break;
            }
            X[ti] = xsol;
            if (!peq(smul(xsol, G), T[ti])) { fprintf(stderr, "VERIFY FAIL trial %d target %d\n", tr, ti); return 3; }
            verified++;
            if (EXP[ti] >= 0) { expected_n++; if ((long long)xsol == EXP[ti]) expected_ok++; }
            tot += pts; perinst[ti] += pts; perinst2[ti] += (double)pts * pts;
        }
        sum += tot; sum2 += tot * tot; fruit_tot += fruit;
        printf("%s%.0f", tr ? "," : "", tot);
        /* dump recovered logs of the first trial for external checking */
        if (tr == 0) { FILE *lf = fopen("ks_lastlogs.txt", "w"); for (int i = 0; i < L; i++) fprintf(lf, "%llu\n", (unsigned long long)X[i]); fclose(lf); }
        fflush(stdout);
    }
    double mean = sum / trials, sd = sqrt(sum2 / trials - mean * mean), se = sd / sqrt(trials);
    printf("],\n\"per_instance_mean\":[");
    for (int i = 0; i < L; i++) printf("%s%.2f", i ? "," : "", perinst[i] / trials);
    printf("],\n\"mean_total\":%.3f,\"sd_total\":%.3f,\"se_total\":%.3f,\"ratio_mean_over_pred\":%.5f,\"ratio_se\":%.5f,"
           "\"fruitless_per_trial\":%.3f,\"verified_logs\":%lld,\"expected_checked\":%lld,\"expected_ok\":%lld}\n",
           mean, sd, se, mean / pred, se / pred, fruit_tot / trials, verified, expected_n, expected_ok);
    return 0;
}
