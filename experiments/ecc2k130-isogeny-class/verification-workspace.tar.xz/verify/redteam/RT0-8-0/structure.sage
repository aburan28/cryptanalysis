import json, sys
sys.path.insert(0,'/Volumes/SSD990/ecdlp-hardness-work/ground_truth')
import ecc2k
set_random_seed(20260924)
q=2**131; t=Integer(ecc2k.t); tw=q+1+t
P114=Integer(19678316408850118605767852657510239)
Rz.<z>=GF(2)[]
K.<a>=GF(2**131, modulus=z^131+z^13+z^2+z+1)
Ep=EllipticCurve(K,[1,1,0,0,1])
out={}
# order check of E0' by point: random point times cofactor has order P114
P=Ep.random_point(); Q=(tw//P114)*P
while Q==0:
    P=Ep.random_point(); Q=(tw//P114)*P
out['Q_times_P114_is_O']=bool(P114*Q==0)
FQ=Ep(Q[0]^2,Q[1]^2)
r1=Integer(11620273277080081443521875815673184); r2=Integer(8058043131770037162245976841837056)
out['frob_eq_r1']=bool(FQ==r1*Q); out['frob_eq_r2']=bool(FQ==r2*Q)
# x-only arithmetic independence of a2: division polynomials over GF(2)(b)
Fb.<b>=FunctionField(GF(2))
Ea=EllipticCurve(Fb,[1,0,0,0,b]); Eb=EllipticCurve(Fb,[1,1,0,0,b])
same=True
for m in range(2,9):
    if Ea.division_polynomial(m)!=Eb.division_polynomial(m): same=False
out['division_polys_2to8_identical_for_a2_0_and_1']=same
# multiplication-by-m x-map equality (numerators/denominators) for m=2,3
xa=Ea.multiplication_by_m(2,x_only=True); xb=Eb.multiplication_by_m(2,x_only=True)
out['x_of_2P_identical']=bool(xa==xb); out['x_of_2P']=str(xa)
# every nonzero x in F_q lies on exactly one of E0, E0': check on random x's
E0=EllipticCurve(K,[1,0,0,0,1])
cnt=0
for i in range(200):
    x=K.random_element()
    if x==0: continue
    on0=len(E0.lift_x(x,all=True))>0; on1=len(Ep.lift_x(x,all=True))>0
    cnt+= int(on0!=on1)
out['random_x_on_exactly_one_of_E0_E0prime_out_of_200']=int(cnt)
print(json.dumps(out,indent=1))
json.dump(out,open('/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-8-0/structure.json','w'),indent=1)
