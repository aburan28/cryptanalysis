# RT0-8: parameter-level check of the twist (x-only) idea. No oracle, no key recovery:
# only group orders, factorizations, eigenvalue orders and rho cost formulas.
import json, sys
sys.path.insert(0,'/Volumes/SSD990/ecdlp-hardness-work/ground_truth')
import ecc2k
q=2**131; t=Integer(ecc2k.t); N=Integer(ecc2k.N)
out={}
card=q+1-t; tw=q+1+t
assert card==4*N
F=factor(tw); out['twist_card']=str(tw); out['twist_factor']=str(F)
P114=max(pp for pp,e in F)
out['P114']=str(P114); out['log2_P114']=float(log(P114,2))
out['P114_prime_proof']=bool(Integer(P114).is_prime(proof=True))
small=tw//P114; out['cofactor']=str(small); out['log2_cofactor']=float(log(small,2))
out['log2_twist']=float(log(tw,2)); out['log2_N']=float(log(N,2))
# twist Frobenius over F_2: E0'=[1,1,0,0,1], #E0'(F_2) = 2 -> trace +1: tau'^2 - tau' + 2 = 0
R.<X>=GF(P114)[]
rts=(X^2-X+2).roots(multiplicities=False)
out['tau_twist_roots_mod_P114']=[str(r) for r in rts]
out['tau_twist_root_orders']=[str(r.multiplicative_order()) for r in rts]
out['131_divides_P114_minus_1']=bool((P114-1)%131==0)
# E0 twist curve over F_2 count
E2=EllipticCurve(GF(2),[1,1,0,0,1]); out['E0prime_F2_card']=int(E2.cardinality())
# rho costs
def lg(x): return float(log(x,2))
out['rho_E0_neg_tau']=lg(sqrt(pi*N/(4*131)))
out['rho_E0_neg']=lg(sqrt(pi*N/4))
out['rho_P114_neg_tau']=lg(sqrt(pi*P114/(4*131)))
out['rho_P114_neg']=lg(sqrt(pi*P114/4))
out['rho_P114_generic']=lg(sqrt(pi*P114/2))
out['PH_small_part_263_rho']=lg(sqrt(pi*263/2))
out['residual_ambiguity_if_only_mod_P114_log2']=lg(N/P114)
out['lcm_bits_vs_N']=[lg(tw), lg(N)]
print(json.dumps(out,indent=1))
json.dump(out,open('/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-8-0/params.json','w'),indent=1)
