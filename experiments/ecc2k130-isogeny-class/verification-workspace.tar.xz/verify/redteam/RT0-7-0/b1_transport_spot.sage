# Independent spot check: ascending 263-isogeny floor curve -> E0 preserves DLPs (the transport RT0-7 relies on).
# Kernel from the twist: E'(F_q)[263^oo] = Z/263^2 (cyclic), [263]E'(F_q)[263^2] is the F_q-rational line; x-coords are twist-invariant.
import sys, json, time
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
set_random_seed(7070)
K, curves = ecc2k.load()
N = Integer(ecc2k.N); TW = Integer(ecc2k.TWIST_CARD); CARD = Integer(ecc2k.CARD)
E0 = curves["E0"]
R.<X> = PolynomialRing(K)
res = {}
for lab in ["A000", "B064", "A097"]:
    E = curves[lab]; b = E.a6(); assert E.a2() == 0
    Et = EllipticCurve(K, [1, 1, 0, 0, b])
    cof = TW // 263^2
    while True:
        Pt = cof * Et.random_point()
        if 263 * Pt != Et(0): break
    R0 = 263 * Pt; assert R0 != Et(0) and 263 * R0 == Et(0)
    xs = [(i * R0).xy()[0] for i in range(1, 132)]
    assert len(set(xs)) == 131
    psi = prod(X - x for x in xs)
    t0 = time.time(); phi = E.isogeny(psi); tb = time.time() - t0
    C = phi.codomain(); jC = C.j_invariant()
    iso = C.isomorphism_to(E0)
    ok = []
    t1 = time.time()
    for trial in range(3):
        P = 4 * E.random_point(); assert N * P == E(0) and P != E(0)
        k = randint(1, N - 1); Q = k * P
        PP = iso(phi(P)); QQ = iso(phi(Q))
        ok.append(bool(PP != E0(0) and N * PP == E0(0) and QQ == k * PP))
    te = (time.time() - t1) / 6
    res[lab] = dict(codomain_j_is_1=bool(jC == 1), planted_ok=ok, sage_build_s=float(round(tb, 2)), sage_eval_s_per_point=float(round(te, 4)),
                    degree=int(phi.degree()))
    print(lab, res[lab], flush=True)
json.dump(res, open("b1_transport_spot.json", "w"), indent=1)
