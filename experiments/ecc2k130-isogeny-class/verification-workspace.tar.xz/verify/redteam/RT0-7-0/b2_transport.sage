# RT0-7: can a level-p (B2) curve be transported to E0?  Any isogeny between curves whose
# endomorphism rings differ at p has degree divisible by p (Tate-module argument), so it has a
# cyclic degree-p factor whose kernel is the pi-eigenline of eigenvalue a = t/2 mod p
# (pi = a + f*omega, f = 263 p, omega = (1+sqrt(-7))/2, t odd).  Its points live in E(F_{q^k}), k = ord_p(a).
import sys, json
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
N, t, f, p, q = [Integer(v) for v in (ecc2k.N, ecc2k.t, ecc2k.f, ecc2k.p, ecc2k.q)]
assert t^2 - 4*q == -7*f^2 and f == 263*p and is_prime(p)
out = {}
a_int = (t - f) // 2                       # pi = a_int + f*omega exactly
assert 2*a_int == t - f
Fp = GF(p)
a = Fp(a_int); assert a == Fp(t)/2
out["a_mod_p"] = str(a)
out["a_squared_equals_q_mod_p"] = bool(a^2 == Fp(q))
fac = factor(p - 1); out["p_minus_1_factorization"] = str(fac)
k = a.multiplicative_order(); out["k_ord_a_mod_p"] = str(k); out["k_log2"] = float(log(k, 2))
out["ord_2_mod_p_log2"] = float(log(Fp(2).multiplicative_order(), 2))
out["kernel_poly_degree_(p-1)/2_log2"] = float(log((p - 1) / 2, 2))
# same question for the 263-part (floor curves, already transported in transport-263): eigenvalue mod 263
F263 = GF(263); a263 = F263(a_int)
out["a_mod_263"] = str(a263); out["ord_a_mod_263"] = str(a263.multiplicative_order())
# pi on E0[p] is the scalar a -> descending kernels of E0 also need F_{q^k}
# minimal extension where E0[p] is rational: q^k-Frobenius = a^k = 1 on E0[p]
out["field_bits_of_F_q^k_log2"] = float(log(131 * k, 2))
print(json.dumps(out, indent=1))
json.dump(out, open("b2_transport.json", "w"), indent=1)
