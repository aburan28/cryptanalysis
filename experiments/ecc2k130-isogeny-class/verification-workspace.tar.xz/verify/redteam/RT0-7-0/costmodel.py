"""RT0-7 end-to-end cost model (Bernstein-Lange precomputation on the ECC2K-130 class).
Run: python3 costmodel.py  -> costmodel.json
Inputs: N from ground_truth/ecc2k.py; BL constants from BL 2012 (eprint 2012/458, lit/bl2012_458.txt);
throughputs read from the repo's ecc2k130/README.md (lines 283-286); simulated constants from bl_sim results if present.
"""
import json, math, sys, os
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
N = ecc2k.N
L2 = math.log2
ell = N / 262.0                      # proposer's class-space size
ell_exact = (N - 1) // 262           # nonzero classes of <-1,tau> on E0(F_q)[N]
out = {"N_log2": L2(N), "ell_log2": L2(ell), "ell_exact_classes": str(ell_exact),
       "ell_cuberoot_log2": L2(ell) / 3}
rho = math.sqrt(math.pi * ell / 2)
rho_bailey = rho * 1.069993          # ECC2K-130 paper's non-randomness factor for its sigma walk
out["rho_log2"] = L2(rho); out["rho_bailey_log2"] = L2(rho_bailey)
consts = {"proposer_interval_1.21_1.93": (1.21, 1.93),
          "BL_group_abstract_1.24_1.77": (1.24, 1.77),
          "BL_table4.1_T512_N8T": (15.7167, 1.38323),
          "BL_table4.1_T1024_N_eq_T": (1.34187, 2.01289)}
tab = {}
for name, (cp, co) in consts.items():
    rows = {}
    for lt in (20, 30, 40):
        T = 2.0 ** lt
        pre = cp * math.sqrt(ell * T); onl = co * math.sqrt(ell / T)
        # instances needed before (precomp + M*online) < M*rho  (vs rho per instance)
        Mstar = pre / (rho - onl)
        rows[f"T2^{lt}"] = dict(precomp_log2=L2(pre), online_log2=L2(onl),
                                online_two_logs_log2=L2(2 * onl),       # base point also unknown
                                precomp_over_rho_log2=L2(pre / rho),
                                breakeven_instances_log2=L2(Mstar),
                                breakeven_instances=Mstar,
                                single_instance_total_log2=L2(pre + onl))
    # optimum T for M instances, amortised per-instance cost
    opt = {}
    for M in (1, 2, 263, 2 ** 10, 2 ** 20, 2 ** 30):
        Topt = max(1.0, (co / cp) * M)
        tot = cp * math.sqrt(ell * Topt) + M * co * math.sqrt(ell / Topt)
        opt[f"M{M}"] = dict(T_opt_log2=L2(Topt), total_log2=L2(tot), per_instance_log2=L2(tot / M),
                            vs_rho_per_instance_bits=L2(tot / M) - L2(rho))
    tab[name] = dict(cp=cp, co=co, by_T=rows, optimal_T_for_M=opt,
                     single_instance_min_total_over_rho=(2 * math.sqrt(cp * co) * math.sqrt(ell)) / rho)
out["bl"] = tab
# CGK 2018 generic lower bound  P*T + T^2 >= eps*ell  (constants dropped)
out["cgk_lower_bound"] = {f"online2^{lt}": dict(min_precomp_log2=L2(ell / 2 ** lt - 2 ** lt)) for lt in (41.31, 41.43, 51.31, 51.43)}
# storage: T entries; 16 B (64-bit seed + 64-bit hash, log recomputed by re-walk), 24 B (48-bit tag + 129-bit log), 32 B (repo record)
out["storage_bytes"] = {f"T2^{lt}": {f"{b}B": b * 2 ** lt for b in (16, 24, 32)} for lt in (20, 30, 40)}
out["storage_TiB_T2^40"] = {f"{b}B": b * 2 ** 40 / 2 ** 40 for b in (16, 24, 32)}
# throughputs from repo ecc2k130/README.md lines 283-286 (M4 Pro and RTX PRO 6000)
thr = {"M4Pro_cpu_14w": 150e6, "M4Pro_cpu_1w": 18.6e6, "M4Pro_metal": 390e6, "RTXPRO6000": 20080e6}
yr = 365.25 * 86400
wall = {}
for lt in (20, 40):
    cp, co = consts["BL_group_abstract_1.24_1.77"]
    T = 2.0 ** lt
    pre = cp * math.sqrt(ell * T); onl = co * math.sqrt(ell / T)
    W = 0.5 * math.sqrt(ell / T)       # alpha = 1/2 walk length (BL's T=65536 run)
    wall[f"T2^{lt}"] = {k: dict(precomp_years=pre / v / yr, online_seconds=onl / v,
                                 one_walk_latency_seconds_at_1worker=W / thr["M4Pro_cpu_1w"])
                        for k, v in thr.items()}
    wall[f"T2^{lt}"]["walk_length_log2_alpha_half"] = L2(W)
wall["rho_single"] = {k: dict(years=rho_bailey / v / yr) for k, v in thr.items()}
out["wallclock"] = wall
out["rtx_gpu_years_precomp_T2^40"] = 1.24 * math.sqrt(ell * 2 ** 40) / thr["RTXPRO6000"] / yr
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "costmodel.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
