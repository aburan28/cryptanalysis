"""RT0-7 end-to-end toy: Bernstein-Lange table on a real Koblitz curve with the ECC2K-130 style
sigma-walk on <-1, sigma> classes (P -> P + sigma^j(P), j = H(class) mod 8 + 3), and instances
posed on a *floor* curve (j not in F_2) that are transported to the Koblitz curve by the dual of a
descending l-isogeny, exactly the RT0-7 pipeline.  Also measures plain rho on the same class walk.

usage: sage -python toy_bl_koblitz.py n a2 l_iso(or 0) T_list(comma) Npool_factor alpha n_inst n_rho seed out.json
"""
import sys, json, time, math, random
from sage.all import (GF, EllipticCurve, Integer, factor, matrix, vector, PolynomialRing, prod,
                      set_random_seed, is_prime, Zmod)

n, a2, l_iso = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
T_list = [int(x) for x in sys.argv[4].split(",")]
NPF, ALPHA, N_INST, N_RHO, SEED, OUT = int(sys.argv[5]), float(sys.argv[6]), int(sys.argv[7]), int(sys.argv[8]), int(sys.argv[9]), sys.argv[10]
set_random_seed(SEED); rng = random.Random(SEED)
K = GF(2 ** n, 'z'); z = K.gen()
E = EllipticCurve(K, [1, a2, 0, 0, 1])
t1 = 2 + 1 - (4 if a2 == 0 else 2)
tt0, tt = 2, t1
for _ in range(n - 1):
    tt0, tt = tt, t1 * tt - 2 * tt0
q = 2 ** n; card = q + 1 - tt
assert E.cardinality() == card
N = max(p for p, e in factor(card)); cof = card // N
assert is_prime(N) and cof % N != 0
ZN = Zmod(N)
# base point and tau eigenvalue
while True:
    G = cof * E.random_point()
    if G != E(0): break
roots = [r for r in PolynomialRing(ZN, 'X')([2, -t1, 1]).roots(multiplicities=False)]
sigma = lambda P: E((P[0] ** 2, P[1] ** 2)) if P != E(0) else P
s = [int(r) for r in roots if int(r) * G == sigma(G)][0]
ords = ZN(s).multiplicative_order()
assert ords == n, ords
ell_cls = (N - 1) // (2 * n)
# normal basis conversion (poly-basis integer -> normal-basis bitmask), sigma = rotate-left by 1
def vec(u):
    v = u.to_integer(); return [(v >> i) & 1 for i in range(n)]
F2 = GF(2)
while True:
    beta = K.random_element()
    B = matrix(F2, [vec(beta ** (2 ** i)) for i in range(n)])   # row i = beta^(2^i) in poly coords
    if B.rank() == n: break
Binv = B.inverse()          # x_poly(row vec) = c * B  ->  c = x_poly * Binv
cols = [sum(int(Binv[r, i]) << r for r in range(n)) for i in range(n)]   # c_i = parity(col_i & x)
MASK = (1 << n) - 1
def nb(x):
    xi = x.to_integer()
    return sum((((c & xi).bit_count()) & 1) << i for i, c in enumerate(cols))
def canon_rot(v):
    best, br = v, 0
    for r in range(1, n):
        w = ((v << r) | (v >> (n - r))) & MASK
        if w < best: best, br = w, r
    return best, br
# sanity: sigma is rotate-left by 1 in this basis
xx = K.random_element(); v = nb(xx); assert nb(xx ** 2) == ((v << 1) | (v >> (n - 1))) & MASK
def mix(k, salt):
    x = (k * 0x9E3779B97F4A7C15 + salt) & 0xFFFFFFFFFFFFFFFF
    x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
    x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
    return x ^ (x >> 31)
SALT_J, SALT_D = rng.getrandbits(64), rng.getrandbits(64)
mult = [None] * 16
for j in range(3, 11):
    mult[j] = (1 + pow(s, j, N)) % N
    # no multiplier may lie in <-1, s> (would create fixed classes)
    assert all(mult[j] != pow(s, i, N) and mult[j] != (-pow(s, i, N)) % N for i in range(n))
a2K = K(a2)
def add(x1, y1, x2, y2):
    lam = (y1 + y2) / (x1 + x2)
    x3 = lam * lam + lam + x1 + x2 + a2K
    return x3, lam * (x1 + x3) + x3 + y1
def walk(x, y, W_thresh, cap):
    """sigma-walk from affine (x,y); returns (steps, key, xC, yC, M) where C is the canonical
    representative of the DP class and log(C) = M * log(start); or (steps, None...) if capped."""
    M = 1; steps = 0
    while True:
        key, r = canon_rot(nb(x))
        if mix(key, SALT_D) < W_thresh:
            break
        if steps >= cap:
            return steps, None, None, None, None
        j = mix(key, SALT_J) % 8 + 3
        xs, ys = x, y
        for _ in range(j):
            xs = xs * xs; ys = ys * ys
        x, y = add(x, y, xs, ys)
        M = M * mult[j] % N
        steps += 1
    # canonical representative: C = sigma^r(D), then choose the sign with the smaller y integer
    xc, yc = x, y
    for _ in range(r):
        xc = xc * xc; yc = yc * yc
    M = M * pow(s, r, N) % N
    ym = yc + xc
    if ym.to_integer() < yc.to_integer():
        yc = ym; M = (-M) % N
    return steps, key, xc, yc, M
# self-test of canonicalisation on random class members
P0 = 12345 * G
_, k0, xa, ya, Ma = walk(P0[0], P0[1], 2 ** 64, 0)
for i in (0, 1, 5, n - 1):
    for sg in (1, -1):
        Pm = sg * (pow(s, i, N) * P0)
        _, k1, xb, yb, Mb = walk(Pm[0], Pm[1], 2 ** 64, 0)
        assert k1 == k0 and xb == xa and yb == ya
assert E((xa, ya)) == Ma * P0
# addition formula self-test
Pa, Pb = 3 * G, 7 * G
assert E(add(Pa[0], Pa[1], Pb[0], Pb[1])) == 10 * G
res = dict(n=n, a2=a2, q_bits=n, card=str(card), N=str(N), N_log2=math.log2(N), cofactor=str(cof), tau_eigen=str(s),
           class_size=2 * n, ell_classes=str(ell_cls), ell_log2=math.log2(ell_cls), alpha=ALPHA, Npool_factor=NPF, seed=SEED)
print("setup", {k: res[k] for k in ("n", "N_log2", "ell_log2", "class_size")}, flush=True)

# ------------------------------------------------------------------ transport target (floor curve)
transport = None
if l_iso:
    Et = EllipticCurve(K, [1, 1 - a2 if a2 in (0, 1) else a2, 0, 0, 1])
    twc = q + 1 + tt
    assert Et.cardinality() == twc and twc % (l_iso ** 2) == 0
    cofl = twc
    while cofl % l_iso == 0: cofl //= l_iso
    # two independent l-torsion points on the twist
    def ltors():
        while True:
            R = cofl * Et.random_point()
            while R != Et(0) and l_iso * R != Et(0):
                R = l_iso * R
            if R != Et(0): return R
    R1 = ltors()
    while True:
        R2 = ltors()
        if R1.weil_pairing(R2, l_iso) != 1: break
    Rx = PolynomialRing(K, 'X'); X = Rx.gen()
    floor = None
    for c in range(l_iso):
        Rk = R2 + c * R1
        xs = list({(i * Rk)[0] for i in range(1, (l_iso - 1) // 2 + 1)})
        psi = prod(X - xv for xv in xs)
        phi = E.isogeny(psi)
        if phi.codomain().j_invariant() not in (K(0), K(1)):
            floor = phi; break
    E1 = floor.codomain()
    # Sage has no dual isogeny in char 2: build the ascending isogeny E1 -> E from its kernel
    # phi(E[l]), computed on the twist side where E[l] is F_q-rational (x-coordinates are shared).
    phi_t = Et.isogeny(psi)
    E1t = phi_t.codomain()
    assert E1t.a4() == E1.a4() and E1t.a6() == E1.a6() and E1t.a2() == E1.a2() + 1
    Rimg = phi_t(R1)
    assert Rimg != E1t(0) and l_iso * Rimg == E1t(0)
    xs_up = list({(i * Rimg)[0] for i in range(1, (l_iso - 1) // 2 + 1)})
    upiso = E1.isogeny(prod(X - xv for xv in xs_up))
    assert upiso.codomain().j_invariant() == E.j_invariant()
    iso = upiso.codomain().isomorphism_to(E)
    up = lambda P: iso(upiso(P))
    # check: up is a group isomorphism on the N-part
    P1 = cof * E1.random_point()
    assert P1 != E1(0) and up(P1) != E(0) and up(5 * P1) == 5 * up(P1)
    transport = dict(l_iso=l_iso, floor_j=str(E1.j_invariant().to_integer()), floor_j_in_F2=False,
                     floor_has_frobenius_endo=bool(E1.j_invariant() ** 2 == E1.j_invariant()))
    print("transport", transport, flush=True)

# ------------------------------------------------------------------ plain rho on the same class walk
Wr = 16.0
thr_r = int(2 ** 64 / Wr)
rho_steps = []
for trial in range(N_RHO):
    kq = rng.randrange(1, N); Q = kq * G
    seen = {}; total = 0
    while True:
        a, b = rng.randrange(N), rng.randrange(1, N)
        S = a * G + b * Q
        st, key, xc, yc, M = walk(S[0], S[1], thr_r, int(40 * Wr))
        total += st
        if key is None: continue
        A_, B_ = M * a % N, M * b % N          # log(C) = A_ + B_ k
        if key in seen:
            A2, B2 = seen[key]
            if (B_ - B2) % N:
                k = (A2 - A_) * pow(B_ - B2, -1, N) % N
                assert k == kq
                break
        else:
            seen[key] = (A_, B_)
    rho_steps.append(total)
rho_mean = sum(rho_steps) / len(rho_steps)
res["rho"] = dict(trials=N_RHO, mean_steps=rho_mean, mean_over_sqrt_pi_ell_over_2=rho_mean / math.sqrt(math.pi * ell_cls / 2),
                  mean_over_sqrt_ell=rho_mean / math.sqrt(ell_cls), W_dp=Wr, all_logs_correct=True)
print("rho", res["rho"], flush=True)

# ------------------------------------------------------------------ BL tables
res["bl"] = []
for T in T_list:
    W = ALPHA * math.sqrt(ell_cls / T)
    thr = int(2 ** 64 / W)
    pool = {}; pre_steps = 0; walks = 0; capped = 0
    t0 = time.time()
    while len(pool) < NPF * T:
        y0 = rng.randrange(1, N); S = y0 * G
        st, key, xc, yc, M = walk(S[0], S[1], thr, int(16 * W))
        pre_steps += st; walks += 1
        if key is None: capped += 1; continue
        e = pool.get(key)
        if e is None:
            pool[key] = [M * y0 % N, 1, st]
        else:
            assert e[0] == M * y0 % N         # same class, same canonical point -> same log
            e[1] += 1; e[2] += st
    tsel = sorted(pool.items(), key=lambda kv: -(kv[1][2] + 4 * W * kv[1][1]))[:T]
    table = {k: v[0] for k, v in tsel}
    t_pre = time.time() - t0
    # sanity: table logs are right
    for k, L in list(table.items())[:5]:
        C = L * G; assert canon_rot(nb(C[0]))[0] == k
    # online: instances on the Koblitz curve itself, and transported instances from the floor curve
    def solve_log(Qpt):
        steps = 0; nw = 0
        while True:
            y0 = rng.randrange(N)
            S = Qpt + y0 * G
            if S == E(0): continue
            st, key, xc, yc, M = walk(S[0], S[1], thr, int(8 * W))
            steps += st; nw += 1
            if key is not None and key in table:
                return (table[key] * pow(M, -1, N) - y0) % N, steps, nw
    on_steps = []; ok = 0
    t1_ = time.time()
    for i in range(N_INST):
        kq = rng.randrange(1, N); Q = kq * G
        k, st, nw = solve_log(Q)
        ok += (k == kq); on_steps.append(st)
    t_on = time.time() - t1_
    row = dict(T=T, W=W, pool=len(pool), pre_walks=walks, pre_capped=capped, pre_steps=pre_steps,
               pre_const=pre_steps / math.sqrt(ell_cls * T), pre_over_rho_measured=pre_steps / rho_mean,
               online_instances=N_INST, online_correct=ok, online_mean_steps=sum(on_steps) / N_INST,
               online_const=(sum(on_steps) / N_INST) / math.sqrt(ell_cls / T),
               online_over_rho_measured=(sum(on_steps) / N_INST) / rho_mean,
               pre_seconds=round(t_pre, 1), online_seconds=round(t_on, 1))
    if transport:
        tr_ok = 0; tr_steps = []; tr_time = []
        for i in range(max(1, N_INST // 2)):
            P1 = cof * E1.random_point()
            if P1 == E1(0): continue
            k1 = rng.randrange(1, N); Q1 = k1 * P1
            ta = time.time(); A = up(P1); B = up(Q1); tr_time.append(time.time() - ta)
            la, sa, _ = solve_log(A); lb, sb, _ = solve_log(B)
            k = lb * pow(la, -1, N) % N
            tr_ok += (k == k1 and k1 * P1 == Q1); tr_steps.append(sa + sb)
        row["transported"] = dict(instances=len(tr_steps), correct=tr_ok, mean_steps_two_logs=sum(tr_steps) / len(tr_steps),
                                  mean_over_single_log=(sum(tr_steps) / len(tr_steps)) / row["online_mean_steps"],
                                  transport_seconds_per_instance=sum(tr_time) / len(tr_time))
    print("BL", row, flush=True)
    res["bl"].append(row)
    json.dump(res, open(OUT, "w"), indent=1)
json.dump(res, open(OUT, "w"), indent=1)
print("done", flush=True)
