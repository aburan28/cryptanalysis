#!/bin/bash
# sweep of bl_sim; output JSON lines to bl_sweep.jsonl
cd "$(dirname "$0")"
: > bl_sweep.jsonl
L40=1099511627791; L48=281474976710597
for seed in 11 12 13; do
  # l = 2^48: T/l exponent ratios 1/6, 1/4, 1/3 (the claim's T=2^20, 2^30, 2^40 at l=2^121)
  for T in 256 4096 65536; do
    E=$(( T >= 65536 ? 65536 : 16384 ))
    timeout 2400 ./bl_sim $L48 $T $((2*T)) 0.5 $E $seed >> bl_sweep.jsonl
  done
  # l = 2^40: N/T and alpha variations at T = 2^13
  for NP in 1 2 8; do for A in 0.5 1.0; do
    timeout 2400 ./bl_sim $L40 8192 $((NP*8192)) $A 65536 $seed >> bl_sweep.jsonl
  done; done
done
echo done >> bl_sweep.done
