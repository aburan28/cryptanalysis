/* Bernstein-Lange "rho with a precomputed table" in a generic cyclic group Z/ell (additive),
 * base-g r-adding walk (r = 64) independent of the target, distinguished points with prob 1/W.
 * Precomputation: random starts, walk to a DP (cap 16W), until Npool distinct DPs; keep the T
 * with the largest weight (sum of walk lengths + 4W per walk, BL 2012 Sec. 3). Online: random
 * start (= h*g^y), walk to a DP (cap 8W), success iff DP in table. Cost = steps / successes.
 * usage: bl_sim ell T Npool alpha experiments seed
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <string.h>

static inline uint64_t mix64(uint64_t z) {
    z += 0x9e3779b97f4a7c15ULL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}
static uint64_t rng_state;
static inline uint64_t rnd(void) { rng_state += 0x9e3779b97f4a7c15ULL; return mix64(rng_state); }

typedef struct { uint64_t key; uint64_t walks; double len; int used; } slot_t;
static slot_t *tab; static uint64_t tmask;
static slot_t *find(uint64_t k, int ins, int *isnew) {
    uint64_t i = mix64(k ^ 0x1234567ULL) & tmask;
    for (;;) {
        if (!tab[i].used) { if (!ins) return NULL; tab[i].used = 1; tab[i].key = k; tab[i].walks = 0; tab[i].len = 0; *isnew = 1; return &tab[i]; }
        if (tab[i].key == k) { *isnew = 0; return &tab[i]; }
        i = (i + 1) & tmask;
    }
}
static uint64_t *set; static uint64_t smask;
static void set_ins(uint64_t k) { uint64_t i = mix64(k ^ 0x777ULL) & smask; while (set[i] != UINT64_MAX) i = (i + 1) & smask; set[i] = k; }
static int set_has(uint64_t k) { uint64_t i = mix64(k ^ 0x777ULL) & smask; while (set[i] != UINT64_MAX) { if (set[i] == k) return 1; i = (i + 1) & smask; } return 0; }
static int cmpw(const void *a, const void *b) { double x = *(const double *)a, y = *(const double *)b; return (x < y) - (x > y); }

int main(int argc, char **argv) {
    if (argc < 7) { fprintf(stderr, "usage\n"); return 1; }
    uint64_t ell = strtoull(argv[1], 0, 10), T = strtoull(argv[2], 0, 10), Np = strtoull(argv[3], 0, 10);
    double alpha = atof(argv[4]); uint64_t E = strtoull(argv[5], 0, 10); rng_state = strtoull(argv[6], 0, 10);
    double W = alpha * sqrt((double)ell / (double)T);
    uint64_t thresh = (uint64_t)(18446744073709551615.0 / W);
    uint64_t K1 = rnd(), K2 = rnd(), s[64];
    for (int i = 0; i < 64; i++) s[i] = rnd() % ell;
    uint64_t cap_pre = (uint64_t)(16 * W), cap_on = (uint64_t)(8 * W);
    uint64_t tsz = 1; while (tsz < 4 * Np) tsz <<= 1; tab = calloc(tsz, sizeof(slot_t)); tmask = tsz - 1;
    /* precomputation */
    uint64_t distinct = 0, pre_steps = 0, pre_walks = 0, pre_fail = 0;
    while (distinct < Np) {
        uint64_t x = rnd() % ell, n = 0; pre_walks++;
        for (;;) {
            if (mix64(x ^ K2) < thresh) break;
            x += s[mix64(x ^ K1) & 63]; if (x >= ell) x -= ell;
            if (++n >= cap_pre) break;
        }
        pre_steps += n;
        if (n >= cap_pre) { pre_fail++; continue; }
        int isnew; slot_t *sl = find(x, 1, &isnew); sl->walks++; sl->len += n; if (isnew) distinct++;
    }
    /* selection of T most useful */
    double *w = malloc(sizeof(double) * Np * 2); uint64_t *keys = malloc(sizeof(uint64_t) * Np); uint64_t m = 0;
    for (uint64_t i = 0; i < tsz; i++) if (tab[i].used) { w[2 * m] = tab[i].len + 4 * W * tab[i].walks; memcpy(&w[2 * m + 1], &tab[i].key, 8); m++; }
    qsort(w, m, 2 * sizeof(double), cmpw);
    uint64_t ssz = 1; while (ssz < 4 * T) ssz <<= 1; set = malloc(ssz * 8); memset(set, 0xff, ssz * 8); smask = ssz - 1;
    for (uint64_t i = 0; i < T && i < m; i++) { uint64_t k; memcpy(&k, &w[2 * i + 1], 8); set_ins(k); keys[i] = k; }
    /* online */
    uint64_t on_steps = 0, succ = 0, on_fail = 0;
    for (uint64_t e = 0; e < E; e++) {
        uint64_t x = rnd() % ell, n = 0;
        for (;;) {
            if (mix64(x ^ K2) < thresh) break;
            x += s[mix64(x ^ K1) & 63]; if (x >= ell) x -= ell;
            if (++n >= cap_on) break;
        }
        on_steps += n;
        if (n >= cap_on) { on_fail++; continue; }
        if (set_has(x)) succ++;
    }
    double pre_c = pre_steps / sqrt((double)ell * T), on_c = (double)on_steps / succ / sqrt((double)ell / T);
    printf("{\"ell\": %llu, \"T\": %llu, \"Npool\": %llu, \"alpha\": %.4f, \"W\": %.1f, \"pre_steps\": %llu, \"pre_walks\": %llu, "
           "\"pre_capped\": %llu, \"pre_const\": %.4f, \"online_experiments\": %llu, \"online_steps\": %llu, \"successes\": %llu, "
           "\"online_capped\": %llu, \"online_const\": %.4f, \"succ_rate_per_walk\": %.4f}\n",
           (unsigned long long)ell, (unsigned long long)T, (unsigned long long)Np, alpha, W, (unsigned long long)pre_steps,
           (unsigned long long)pre_walks, (unsigned long long)pre_fail, pre_c, (unsigned long long)E, (unsigned long long)on_steps,
           (unsigned long long)succ, (unsigned long long)on_fail, on_c, (double)succ / E);
    return 0;
}
