"""Aggregate RT0-7 evidence into rt07_summary.json (python3 aggregate.py)."""
import json, math, statistics as st, os
H = os.path.dirname(os.path.abspath(__file__))
rows = [json.loads(l) for l in open(os.path.join(H, "bl_sweep.jsonl")) if l.strip()]
grp = {}
for r in rows:
    k = (r["ell"], r["T"], r["Npool"] // r["T"], r["alpha"])
    grp.setdefault(k, []).append(r)
sweep = []
for (ell, T, u, a), rs in sorted(grp.items()):
    sweep.append(dict(ell_log2=round(math.log2(ell), 2), T_log2=round(math.log2(T), 2), T_exp_ratio=round(math.log2(T) / math.log2(ell), 3),
                      Npool_over_T=u, alpha=a, seeds=len(rs),
                      pre_const=[round(r["pre_const"], 3) for r in rs], online_const=[round(r["online_const"], 3) for r in rs],
                      pre_const_mean=round(st.mean(r["pre_const"] for r in rs), 3),
                      online_const_mean=round(st.mean(r["online_const"] for r in rs), 3),
                      successes=[r["successes"] for r in rs]))
out = {"generic_sweep": sweep}
for f in ("toy_n39_transport.json", "toy_n41.json", "b1_transport_spot.json", "b2_transport.json", "costmodel.json"):
    p = os.path.join(H, f)
    if os.path.exists(p):
        out[f] = json.load(open(p))
json.dump(out, open(os.path.join(H, "rt07_summary.json"), "w"), indent=1)
for s in sweep: print(s)
