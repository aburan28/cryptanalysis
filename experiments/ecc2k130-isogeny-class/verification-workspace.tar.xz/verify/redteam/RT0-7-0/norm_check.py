"""Check: in the order Z + p*O_K (K = Q(sqrt(-7)), O_K = Z[w], w^2 = w - 2), every element whose norm is
divisible by p has norm divisible by p^2 (so no endomorphism of a conductor-p curve has degree p*m with
gcd(m,p) = 1).  Algebraic proof: theta = A + p v w, N = A^2 + p A v + 2 p^2 v^2, p | N => p | A => p^2 | N.
Brute-force confirmation for the real p is impossible; this checks the identity symbolically and on
small primes exhaustively."""
import json, itertools
res = {}
for p in (3, 5, 11, 13, 263):
    bad = 0; tot = 0
    for A in range(-3 * p, 3 * p + 1):
        for v in range(-6, 7):
            n = A * A + p * A * v + 2 * p * p * v * v
            if n % p == 0:
                tot += 1
                bad += (n % (p * p) != 0)
    res[str(p)] = dict(elements_with_p_dividing_norm=tot, of_which_not_p2=bad)
json.dump(res, open("norm_check.json", "w"), indent=1); print(res)
