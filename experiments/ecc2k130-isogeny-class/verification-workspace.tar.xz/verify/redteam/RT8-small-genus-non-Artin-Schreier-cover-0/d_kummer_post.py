"""Post-processing of d_kummer_toy output (toy analogues of the mu_263-Kummer family).

For each toy (n, ell = 2n+1) and every Kummer class D (degree-0 divisor on E0(F_2) mod ell, up to
scaling), with r = #branch points and genus g(C1) = 1 + n r:
  S_c   = sum_{P in E0(F_q) unramified} psi^c(f(P))      (character sums, q = 2^n)
  #C1(F_q) = #E0(F_q) + sum_{c != 0} S_c                 (checked against the direct count)
  L(chi_c, T) = 1 + S_c T + ...   (degree r)
Criteria for "A_n is an isogeny factor of Jac(C)" (equivalently E0 is an F_q-factor of the Prym):
  r = 2: S_c must be rational and equal to -t_n (then Prym ~ E0^(2n) over F_q)
  r = 3: |S_c + t_n|^2 = q for some c (necessary and, with the functional equation, sufficient up to the root number)
  r = 4: necessary condition |S_c + t_n| <= 2 sqrt(q)   (reported only)
k = 2n check (n = 3, 11): for r = 2 classes the predicted #C1(F_{q^2}) = #E0(F_{q^2}) - 2n(tau'^2 - 2q),
tau' = -S (Prym ~ E'^(2n), E' of trace tau'), is compared with the direct count.
"""
import json, sys, cmath, math, itertools

def lucas(n):
    L = [2, -1]
    for k in range(2, n + 1):
        L.append(-L[-1] - 2 * L[-2])
    return L[n]

def classes(ell):
    seen = set()
    out = []
    for dT, dQ, dQp in itertools.product(range(ell), repeat=3):
        dO = (-(dT + dQ + dQp)) % ell
        D = (dT, dQ, dQp, dO)
        if D == (0, 0, 0, 0):
            continue
        # normalise: first nonzero entry = 1
        first = next(x for x in D if x)
        inv = pow(first, -1, ell)
        Dn = tuple((x * inv) % ell for x in D)
        if Dn in seen:
            continue
        seen.add(Dn)
        out.append(Dn)
    return out

def hist_for(hist, ell, e1, e2, e4):
    H = [0] * ell
    for r1 in range(ell):
        for r2 in range(ell):
            base = (r1 * ell + r2) * ell
            s12 = e1 * r1 + e2 * r2
            for r4 in range(ell):
                c = hist[base + r4]
                if c:
                    H[(s12 + e4 * r4) % ell] += c
    return H

def analyse(n, ell, fn_k, fn_2k=None):
    d = json.load(open(fn_k))
    assert d["ell"] == ell and d["k"] == n
    q = 2 ** n
    tn = lucas(n)
    E0 = d["E0_count"]
    assert E0 == q + 1 - tn, (E0, q + 1 - tn)
    hist = d["hist"]
    inv2 = pow(2, -1, ell)
    d2 = json.load(open(fn_2k)) if fn_2k else None
    if d2:
        assert d2["E0_count"] == q * q + 1 - lucas(2 * n)
    zeta = [cmath.exp(2j * math.pi * j / ell) for j in range(ell)]
    res = {"n": n, "ell": ell, "q": q, "t_n": tn, "E0_count": E0, "supersingular_traces": [0, 2 ** ((n + 1) // 2), -(2 ** ((n + 1) // 2))],
           "by_r": {}, "r2_classes": [], "r3_hits": [], "count_check_failures": 0}
    for D in classes(ell):
        dT, dQ, dQp, dO = D
        e2 = dQ
        e4 = ((dQp - dQ) * inv2) % ell
        e1 = ((dT - e4) * inv2) % ell
        assert (-(2 * e1 + 2 * e2 + 3 * e4)) % ell == dO
        unram = sum(1 for x in D if x == 0)
        r = 4 - unram
        H = hist_for(hist, ell, e1, e2, e4)
        count = ell * H[0] + ell * unram + r
        S = [sum(H[j] * zeta[(c * j) % ell] for j in range(ell)) + unram for c in range(ell)]
        # consistency: #C1 = #E0 + sum_{c != 0} S_c
        chk = E0 + sum(S[1:]).real
        if abs(chk - count) > 1e-6 * max(1, count):
            res["count_check_failures"] += 1
        g = 1 + n * r
        rec = res["by_r"].setdefault(str(r), {"classes": 0, "genus": g, "E0_factor_candidates": 0})
        rec["classes"] += 1
        if r == 2:
            rational = all(abs(S[c].imag) < 1e-6 and abs(S[c].real - S[1].real) < 1e-6 for c in range(1, ell))
            Sv = round(S[1].real) if rational else None
            tau = -Sv if rational else None
            item = {"D": D, "C1_count": count, "S_rational": rational, "S": Sv, "Eprime_trace": tau,
                    "A_in_Jac": bool(rational and tau == tn), "Eprime_ordinary": bool(rational and tau % 2 != 0),
                    "Eprime_supersingular": bool(rational and tau in res["supersingular_traces"])}
            if rational and tau == tn:
                rec["E0_factor_candidates"] += 1
            if d2 and rational:
                H2 = hist_for(d2["hist"], ell, e1, e2, e4)
                c2 = ell * H2[0] + ell * unram + r
                pred = d2["E0_count"] - 2 * n * (tau * tau - 2 * q)
                item["C1_count_q2"] = c2
                item["C1_count_q2_predicted_from_Prym_EprimePower"] = pred
                item["q2_structure_ok"] = (c2 == pred)
            res["r2_classes"].append(item)
        elif r == 3:
            dev = min(abs(abs(S[c] + tn) ** 2 - q) for c in range(1, ell))
            if dev < 1e-3:
                rec["E0_factor_candidates"] += 1
                res["r3_hits"].append({"D": D})
            rec.setdefault("min_abs_dev_|S+t|^2-q", dev)
            rec["min_abs_dev_|S+t|^2-q"] = min(rec["min_abs_dev_|S+t|^2-q"], dev)
        elif r == 4:
            ok = [c for c in range(1, ell) if abs(S[c] + tn) <= 2 * math.sqrt(q) + 1e-9]
            rec.setdefault("classes_passing_weak_necessary_test", 0)
            if len(ok) == ell - 1:
                rec["classes_passing_weak_necessary_test"] += 1
    return res

if __name__ == "__main__":
    base = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT8-small-genus-non-Artin-Schreier-cover-0/toy/"
    out = [analyse(3, 7, base + "k3_l7.json", base + "k6_l7.json"),
           analyse(11, 23, base + "k11_l23.json", base + "k22_l23.json"),
           analyse(23, 47, base + "k23_l47.json", None)]
    json.dump(out, open(sys.argv[1], "w"), indent=1)
    for r in out:
        print("n=%d ell=%d t_n=%d q=%d count_check_failures=%d" % (r["n"], r["ell"], r["t_n"], r["q"], r["count_check_failures"]))
        for k, v in sorted(r["by_r"].items()):
            print("   r=%s" % k, v)
        for it in r["r2_classes"]:
            print("   r=2", it)
