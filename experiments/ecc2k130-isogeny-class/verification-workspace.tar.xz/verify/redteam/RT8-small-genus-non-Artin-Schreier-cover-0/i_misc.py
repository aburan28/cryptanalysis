"""RT8 part I: (1) point-count positivity for Jacobians isogenous to E0^a x A^b over F_2 (no other factor);
(2) the next primes ell = 1 mod 131 with 131 | ord_ell(2) (the only cyclic degrees giving
Weil-restriction-shaped Pryms) and the smallest genus they can reach; (3) ell = 3 family check."""
import json, sys
from sympy import n_order, isprime
L = [2, -1]
for k in range(2, 300): L.append(-L[-1] - 2 * L[-2])
def trA(k):   # trace of Frob^k on A, 131 !| k
    assert k % 131
    return -L[k]
out = {}
bad = {}
for a in range(0, 5):
    for b in range(0, 4):
        if a == 0 and b == 0: continue
        cnts = []
        ok = True
        for k in range(1, 131):
            Nk = 2 ** k + 1 - (a * L[k] + b * trA(k))
            cnts.append(Nk)
        # place counts
        from sympy import mobius, divisors
        pl = []
        for k in range(1, 40):
            s = sum(mobius(k // d) * cnts[d - 1] for d in divisors(k))
            pl.append(s // k if s % k == 0 else None)
        neg_pt = [k + 1 for k, v in enumerate(cnts) if v < 0]
        neg_pl = [k + 1 for k, v in enumerate(pl) if v is None or v < 0]
        bad["E0^%d x A^%d (g=%d)" % (a, b, a + 130 * b)] = dict(N1_to_N4=cnts[:4], first_negative_point_count_degree=(neg_pt[0] if neg_pt else None),
                                                          first_bad_place_degree=(neg_pl[0] if neg_pl else None))
out["positivity"] = bad
nxt = []
for l in range(263, 4000, 131):
    if isprime(l):
        o = n_order(2, l)
        if o % 131 == 0:
            nxt.append(dict(ell=l, ord_2=o, min_genus_P1_r3=(l - 1) // 2 if o == 131 else None,
                            min_genus_elliptic_r2=1 + (l - 1)))
out["ell_with_131_dividing_ord2"] = nxt[:6]
json.dump(out, open(sys.argv[1], "w"), indent=1)
print(json.dumps(out, indent=1))
