/* RT8 adversarial check, part D: toy analogues of the only non-Artin-Schreier cover family that the
 * ECC2K-130 numerology hands us for free.
 *
 * At n = 131: ell = 263 divides 2^131 - 1, ord_263(2) = 131, so mu_263 is in F_q and Frobenius permutes
 * the 262 nontrivial characters of Z/263 in two 131-cycles.  A cyclic 263-cover C1 -> E0 whose Kummer
 * class is Frobenius-stable descends to a curve C over F_2 whose Prym is "Weil-restriction shaped"; it
 * contains A iff (over F_q) the Prym contains E0.  Branch points must be a Frobenius-stable set; with
 * r branch points in E0(F_2) the genus is 1 + 131 r (263, 394, 525).
 *
 * Toy analogues: E0: y^2 + xy = x^3 + 1 over F_{2^n} with n prime, ell = 2n + 1 prime, ell | 2^n - 1
 * (n = 3, 11, 23; ell = 7, 23, 47).  All exponent classes f = x^e1 (x+1)^e2 (y+1)^e4 (every degree-0
 * divisor supported on E0(F_2) = {O, T=(0,1), Q=(1,0), Q'=(1,1)} occurs mod ell) are evaluated at once
 * through the joint histogram of (log x, log(x+1), log(y+1)) mod ell over the affine points of
 * E0(F_{2^k}) outside E0(F_2).
 *
 * usage: d_kummer_toy k modulus_int ell  > out.json
 * prints: {"k":..,"ell":..,"E0_count":..,"hist":[ell^3 ints]} (hist index r1*ell^2 + r2*ell + r4)
 * the classes, character sums and verdicts are post-processed by d_kummer_post.py
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef uint64_t u64;
static int K;
static u64 MODP, ORD;
static uint32_t *EXPT, *LOGT;

static u64 mulslow(u64 a, u64 b) {
    u64 r = 0;
    while (b) {
        if (b & 1) r ^= a;
        b >>= 1;
        a <<= 1;
        if (a >> K) a ^= MODP;
    }
    return r;
}
static inline u64 fmul(u64 a, u64 b) {
    if (!a || !b) return 0;
    u64 l = (u64)LOGT[a] + LOGT[b];
    if (l >= ORD) l -= ORD;
    return EXPT[l];
}
static inline u64 finv(u64 a) { return EXPT[(ORD - LOGT[a]) % ORD]; }

int main(int argc, char **argv) {
    if (argc < 4) { fprintf(stderr, "usage: k modulus ell\n"); return 1; }
    K = atoi(argv[1]);
    MODP = strtoull(argv[2], 0, 10);
    int ell = atoi(argv[3]);
    u64 size = 1ULL << K;
    ORD = size - 1;
    if (ORD % ell) { fprintf(stderr, "ell does not divide 2^k-1\n"); return 1; }
    /* prime factors of ORD */
    u64 pf[64]; int npf = 0; u64 m = ORD;
    for (u64 p = 2; p * p <= m; p++) if (m % p == 0) { pf[npf++] = p; while (m % p == 0) m /= p; }
    if (m > 1) pf[npf++] = m;
    /* primitive element */
    u64 g = 2;
    for (;; g++) {
        int ok = 1;
        for (int i = 0; i < npf && ok; i++) {
            u64 e = ORD / pf[i], r = 1, b = g;
            while (e) { if (e & 1) r = mulslow(r, b); b = mulslow(b, b); e >>= 1; }
            if (r == 1) ok = 0;
        }
        if (ok) break;
    }
    EXPT = malloc(sizeof(uint32_t) * size);
    LOGT = malloc(sizeof(uint32_t) * size);
    u64 v = 1;
    for (u64 i = 0; i < ORD; i++) { EXPT[i] = (uint32_t)v; LOGT[v] = (uint32_t)i; v = mulslow(v, g); }
    if (v != 1) { fprintf(stderr, "generator failure\n"); return 1; }
    /* Artin-Schreier solver table: asol[c] = z with z^2 + z = c, or -1 */
    int32_t *asol = malloc(sizeof(int32_t) * size);
    for (u64 c = 0; c < size; c++) asol[c] = -1;
    for (u64 z = 0; z < size; z++) {
        u64 c = fmul(z, z) ^ z;
        if (asol[c] < 0) asol[c] = (int32_t)z;
    }
    long long *hist = calloc((size_t)ell * ell * ell, sizeof(long long));
    long long e0 = 4;  /* O, T, Q, Q' */
    for (u64 x = 2; x < size; x++) {
        u64 xi = finv(x);
        u64 c = x ^ fmul(xi, xi);           /* x + 1/x^2 */
        int32_t z0 = asol[c];
        if (z0 < 0) continue;
        u64 ys[2] = { fmul(x, (u64)z0), fmul(x, (u64)z0 ^ 1) };
        int r1 = (int)(LOGT[x] % ell);
        int r2 = (int)(LOGT[x ^ 1] % ell);
        for (int s = 0; s < 2; s++) {
            u64 y = ys[s];
            /* sanity: y^2 + x y = x^3 + 1 */
            if ((fmul(y, y) ^ fmul(x, y)) != (fmul(fmul(x, x), x) ^ 1)) { fprintf(stderr, "bad point\n"); return 1; }
            u64 y1 = y ^ 1;
            if (!y1) { fprintf(stderr, "unexpected y=1 off E0(F_2)\n"); return 1; }
            int r4 = (int)(LOGT[y1] % ell);
            hist[((size_t)r1 * ell + r2) * ell + r4]++;
            e0++;
        }
    }
    printf("{\"k\":%d,\"modulus\":%llu,\"ell\":%d,\"generator\":%llu,\"E0_count\":%lld,\"hist\":[",
           K, (unsigned long long)MODP, ell, (unsigned long long)g, e0);
    size_t nb = (size_t)ell * ell * ell;
    for (size_t i = 0; i < nb; i++) printf("%s%lld", i ? "," : "", hist[i]);
    printf("]}\n");
    return 0;
}
