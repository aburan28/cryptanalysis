from sage.all import *
R = PolynomialRing(GF(2), 'x')
cnt = {}
for line in open('c_smooth_check.txt'):
    a, v = line.split(); a = int(a); v = int(v)
    u = R([(a >> i) & 1 for i in range(64)])
    F = u.factor()
    smooth = all(g.degree() <= 7 for g, e in F)
    sqf = all(e == 1 for g, e in F)
    key = (smooth, sqf, v)
    cnt[key] = cnt.get(key, 0) + 1
bad = sum(c for (sm, sq, v), c in cnt.items() if (sm and sq and v == 0) or ((not sm) and v == 1))
print("counts (smooth, squarefree, C-verdict):", cnt)
print("errors (smooth+squarefree judged non-smooth, or non-smooth judged smooth):", bad)
