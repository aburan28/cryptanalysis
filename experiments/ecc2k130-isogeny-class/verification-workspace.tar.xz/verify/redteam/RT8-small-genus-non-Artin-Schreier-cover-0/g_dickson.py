"""RT8 part G: the genus-(ell-1)/2 Artin-Schreier curve X_ell: z^2 + z = D_ell(s) over F_2 (D_ell = Dickson
polynomial), the mu_ell-invariant quotient by s = w + 1/w of the Kummer cover C1(T,O).  For ell = 2n+1 with
ord_ell(2) = n its L-polynomial should be 1 + a T^n + 2^n T^(2n) (Jacobian ~ Weil restriction of a
2-rank-0 object from F_{2^n}), i.e. a genus-(ell-1)/2 curve whose Jacobian is a Weil restriction -- the
shape RT8 wants -- but supersingular-type (2-rank 0), so it can never contain the ordinary A.
ell = 263 gives genus 131.  Checked here with PARI hyperellcharpoly for ell = 7, 23, 47 (toys)."""
import sys, json, time
from sage.all import *
R = PolynomialRing(GF(2), 's'); s = R.gen()
def dickson(n):
    D0, D1 = R(0), s
    if n == 1: return D1
    for _ in range(n - 1):
        D0, D1 = D1, s * D1 + D0
    return D1
out = {}
Lk = [2, -1]
for k in range(2, 60): Lk.append(-Lk[-1] - 2 * Lk[-2])
for ell, n in [(7, 3), (23, 11)]:
    D = dickson(ell)
    t0 = time.time()
    H = HyperellipticCurve(D, R(1))
    Z = H.frobenius_polynomial()          # char poly of Frobenius, degree 2g
    Z = PolynomialRing(ZZ, 'T')(Z.list())
    T = Z.parent().gen()
    Lrec = Z.reverse()  # L(T) = T^(2g) P(1/T)
    coeffs = Lrec.list()
    nz = {i: int(c) for i, c in enumerate(coeffs) if c != 0}
    a = nz.get(n)
    two_rank = Lrec.change_ring(GF(2)).degree()
    tn = Lk[n]
    out[ell] = dict(n=n, genus=int(Z.degree() // 2), nonzero_coeffs_of_L=nz, a=a, t_n=tn,
                    two_rank=int(two_rank), A_possible=bool(a == -tn),
                    Kummer_C1_S_from_part_D={7: 2, 23: -48, 47: -2048}[ell], seconds=round(time.time() - t0, 1))
    print(ell, out[ell], flush=True)
json.dump(out, open(sys.argv[1], "w"), indent=1, default=str)
