/* RT8 adversarial check, part C: measured lower bound on the cost of ONE index-calculus trial on
 * Jac(C)(F_2) of genus g: the smoothness test of the degree-g polynomial/divisor alone
 * (no Jacobian arithmetic, no factoring of the smooth ones), on one Apple M4 Pro P-core with PMULL.
 *
 * Test used (standard): for squarefree u of degree g, u is t-smooth iff
 *     u | prod_{k = ceil(t/2)}^{t} (x^(2^k) - x)       (every d <= t has a multiple in (t/2, t])
 * cost: t squarings mod u + ~t/2 multiplications mod u (Barrett reduction, 2 products each).
 *
 * build: cc -O3 -mcpu=native c_smooth_bench.c -o c_smooth_bench
 * run:   ./c_smooth_bench bench g t iters       -> ns per test
 *        ./c_smooth_bench check                -> prints random polys and verdicts for a Sage cross-check
 */
#include <arm_neon.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef uint64_t u64;
#define MAXW 16

static inline void clmul(u64 a, u64 b, u64 *lo, u64 *hi) {
    poly128_t r = vmull_p64((poly64_t)a, (poly64_t)b);
    uint64x2_t v = vreinterpretq_u64_p128(r);
    *lo = vgetq_lane_u64(v, 0);
    *hi = vgetq_lane_u64(v, 1);
}

/* r[0..na+nb-1] = a * b */
static void pmul(const u64 *a, int na, const u64 *b, int nb, u64 *r) {
    memset(r, 0, sizeof(u64) * (na + nb));
    for (int i = 0; i < na; i++) {
        if (!a[i]) continue;
        for (int j = 0; j < nb; j++) {
            u64 lo, hi;
            clmul(a[i], b[j], &lo, &hi);
            r[i + j] ^= lo;
            r[i + j + 1] ^= hi;
        }
    }
}

/* r = a >> s (bits), a has na words, r gets nr words */
static void shr(const u64 *a, int na, int s, u64 *r, int nr) {
    int ws = s / 64, bs = s % 64;
    for (int i = 0; i < nr; i++) {
        int k = i + ws;
        u64 lo = (k < na) ? a[k] : 0;
        u64 hi = (k + 1 < na) ? a[k + 1] : 0;
        r[i] = bs ? ((lo >> bs) | (hi << (64 - bs))) : lo;
    }
}

static int deg(const u64 *a, int n) {
    for (int i = n - 1; i >= 0; i--)
        if (a[i]) return 64 * i + 63 - __builtin_clzll(a[i]);
    return -1;
}

typedef struct {
    int d, W;          /* degree of u, words for degree < d */
    u64 u[MAXW], m[MAXW];   /* modulus, Barrett constant floor(x^(2d)/u) */
} Mod;

/* long division, only for the setup */
static void setup(Mod *M, const u64 *u, int d) {
    M->d = d;
    M->W = (d + 63) / 64;
    memset(M->u, 0, sizeof M->u);
    memset(M->m, 0, sizeof M->m);
    memcpy(M->u, u, sizeof(u64) * ((d + 64) / 64));
    /* x^(2d) / u by schoolbook */
    u64 rem[2 * MAXW + 1];
    memset(rem, 0, sizeof rem);
    rem[(2 * d) / 64] |= 1ULL << ((2 * d) % 64);
    for (int k = 2 * d; k >= d; k--) {
        if ((rem[k / 64] >> (k % 64)) & 1) {
            int sh = k - d;
            M->m[sh / 64] |= 1ULL << (sh % 64);
            /* rem ^= u << sh */
            for (int b = 0; b <= d; b++)
                if ((u[b / 64] >> (b % 64)) & 1) rem[(b + sh) / 64] ^= 1ULL << ((b + sh) % 64);
        }
    }
}

/* r = a mod u, a has degree < 2d (2W+1 words) */
static void reduce(const Mod *M, const u64 *a, u64 *r) {
    int d = M->d, W = M->W;
    u64 hi[MAXW + 1], t1[2 * MAXW + 2], qq[MAXW + 1], t2[2 * MAXW + 2];
    int wm = (d + 64) / 64;     /* words of m (degree d) */
    int wu = (d + 64) / 64;
    shr(a, 2 * W + 1, d, hi, wm);            /* degree < d */
    pmul(hi, wm, M->m, wm, t1);              /* degree < 2d */
    shr(t1, 2 * wm, d, qq, wm);
    pmul(qq, wm, M->u, wu, t2);
    for (int i = 0; i < W; i++) r[i] = a[i] ^ t2[i];
    if (d % 64) r[W - 1] &= (1ULL << (d % 64)) - 1;
}

static void mulmod(const Mod *M, const u64 *a, const u64 *b, u64 *r) {
    u64 t[2 * MAXW + 2];
    memset(t, 0, sizeof t);
    pmul(a, M->W, b, M->W, t);
    reduce(M, t, r);
}

static void sqrmod(const Mod *M, const u64 *a, u64 *r) {
    u64 t[2 * MAXW + 2];
    memset(t, 0, sizeof t);
    for (int i = 0; i < M->W; i++) clmul(a[i], a[i], &t[2 * i], &t[2 * i + 1]);
    reduce(M, t, r);
}

/* returns 1 if (squarefree) u is t-smooth; also stores the final product in out */
static int smooth_test(const Mod *M, int t, u64 *out) {
    int W = M->W;
    u64 xp[MAXW], acc[MAXW], tmp[MAXW];
    memset(xp, 0, sizeof xp);
    memset(acc, 0, sizeof acc);
    /* x mod u (d >= 2) */
    xp[0] = 2;
    acc[0] = 1;
    int start = (t + 1) / 2;
    for (int k = 1; k <= t; k++) {
        sqrmod(M, xp, tmp);
        memcpy(xp, tmp, sizeof(u64) * W);
        if (k >= start) {
            u64 f[MAXW];
            memcpy(f, xp, sizeof(u64) * W);
            f[0] ^= 2;                         /* x^(2^k) - x */
            mulmod(M, acc, f, tmp);
            memcpy(acc, tmp, sizeof(u64) * W);
        }
    }
    memcpy(out, acc, sizeof(u64) * W);
    for (int i = 0; i < W; i++)
        if (acc[i]) return 0;
    return 1;
}

static u64 rs = 0x9E3779B97F4A7C15ULL;
static u64 rnd(void) { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }

static void random_poly(u64 *u, int d) {
    memset(u, 0, sizeof(u64) * MAXW);
    for (int i = 0; i <= d / 64; i++) u[i] = rnd();
    if ((d + 1) % 64) u[d / 64] &= (1ULL << ((d + 1) % 64)) - 1;
    u[d / 64] |= 1ULL << (d % 64);
    u[0] |= 1;
}

int main(int argc, char **argv) {
    if (argc >= 2 && !strcmp(argv[1], "check")) {
        /* print 400 random polys of degree 18 and verdict for t = 7 (hex, low word first) */
        for (int n = 0; n < 400; n++) {
            u64 u[MAXW], out[MAXW];
            random_poly(u, 18);
            Mod M; setup(&M, u, 18);
            int v = smooth_test(&M, 7, out);
            printf("%llu %d\n", (unsigned long long)u[0], v);
        }
        return 0;
    }
    if (argc < 5) { fprintf(stderr, "usage\n"); return 1; }
    int g = atoi(argv[2]), t = atoi(argv[3]);
    long iters = atol(argv[4]);
    int npolys = 64;
    Mod *Ms = malloc(sizeof(Mod) * npolys);
    for (int i = 0; i < npolys; i++) { u64 u[MAXW]; random_poly(u, g); setup(&Ms[i], u, g); }
    u64 sink[MAXW]; memset(sink, 0, sizeof sink);
    long hits = 0;
    struct timespec a, b;
    clock_gettime(CLOCK_MONOTONIC, &a);
    for (long it = 0; it < iters; it++) {
        u64 out[MAXW];
        hits += smooth_test(&Ms[it % npolys], t, out);
        for (int i = 0; i < Ms[0].W; i++) sink[i] ^= out[i];
    }
    clock_gettime(CLOCK_MONOTONIC, &b);
    double ns = ((b.tv_sec - a.tv_sec) * 1e9 + (b.tv_nsec - a.tv_nsec)) / iters;
    u64 s = 0; for (int i = 0; i < MAXW; i++) s ^= sink[i];
    printf("{\"g\":%d,\"t\":%d,\"iters\":%ld,\"ns_per_test\":%.1f,\"hits\":%ld,\"sink\":\"%llx\"}\n",
           g, t, iters, ns, hits, (unsigned long long)s);
    return 0;
}
