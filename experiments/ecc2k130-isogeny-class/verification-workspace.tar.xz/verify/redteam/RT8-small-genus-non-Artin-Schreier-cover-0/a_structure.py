"""RT8 adversarial check, part A: structural facts that constrain any curve C/F_2 with A in Jac(C).

Run: sage -python a_structure.py out.json
  A1  W_A(T) (degree 260) irreducible, W_A(1) = N, W_A | T^262 - t T^131 + q (so A_{F_q} ~ E0^130).
  A2  2-rank of A = 130 (A ordinary): any C with A in Jac(C) has 2-rank >= 130.
  A3  Genus-130 C with Jac(C) ~ A: exact zeta; #C(F_{2^k}) = #E0'(F_{2^k}) (twist of E0) for 131 !| k.
  A4  GHS parameter m(b) for all 263 ground-truth curves (m in {1, 130, 131}).
  A5  Arithmetic behind the only non-AS family forced by the numerology: 2^131-1 = 263 * P,
      ord_263(2) = 131, 263 = 1 mod 131 (descended mu_263-Kummer covers of E0 exist).
  A6  scalar by which pi acts on E0[p] and its multiplicative order (field of definition of E0[p]).
"""
import sys, json, time
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
from sage.all import *
import ecc2k

out = {}
N = Integer(ecc2k.N); t = Integer(ecc2k.t); q = Integer(2) ** 131; f = Integer(ecc2k.f); p = Integer(ecc2k.p)
R = PolynomialRing(ZZ, 'T'); T = R.gen()
PE0 = T**2 + T + 2          # char poly of tau (trace -1, #E0(F_2) = 4)
PRes = T**262 - t * T**131 + q
WA, r = PRes.quo_rem(PE0)
assert r == 0
out["A1"] = dict(deg_WA=int(WA.degree()), WA_irreducible=bool(WA.is_irreducible()),
                 WA_at_1_equals_N=bool(WA(1) == N),
                 WA_divides_T262_minus_tT131_plus_q=True,
                 note="roots of W_A are zeta*alpha (zeta^131=1, zeta!=1), so over F_q every eigenvalue^131 is alpha^131 or conj: A_{F_q} ~ E0^130")
# A2: 2-rank = number of 2-adic unit roots of the reciprocal polynomial L_A(T) = T^260 W_A(1/T)
LA = R(list(reversed(WA.list())))
LA2 = LA.change_ring(GF(2))
out["A2"] = dict(two_rank_A=int(LA2.degree()), LA_mod2_is_power_of=str(LA2.factor())[:200],
                 E0_two_rank=int(R(list(reversed(PE0.list()))).change_ring(GF(2)).degree()))
# A3: zeta of hypothetical genus-130 C with Jac(C) ~ A
PS = PowerSeriesRing(QQ, 'x', default_prec=140); x = PS.gen()
LAx = PS(LA.list())
Z = LAx / ((1 - x) * (1 - 2 * x))
virt = 1 / ((1 - x) * (1 - 2 * x) * (1 + x + 2 * x**2))
out["A3"] = dict(Z_C_equals_virtual_below_T131=bool(all(Z[i] == virt[i] for i in range(131))),
                 first_differing_degree=int(min(i for i in range(140) if Z[i] != virt[i])),
                 eff_divisors_deg_0_to_10=[str(Z[i]) for i in range(11)])
# A4: GHS m(b) for all curves: m = dim_F2 span{(1, sigma^i(sqrt b))}
K, curves = ecc2k.load()
def ghs_m(b):
    s = b.sqrt()
    vecs = []
    u = s
    for i in range(131):
        v = [1] + [int(c) for c in u.polynomial().list()] + [0] * (131 - len(u.polynomial().list()))
        vecs.append(v)
        u = u ** 2
    M = matrix(GF(2), vecs)
    return int(M.rank())
t0 = time.time()
ms = {}
for lab, E in curves.items():
    b = E.a6()
    ms[lab] = ghs_m(b)
hist = {}
for v in ms.values(): hist[v] = hist.get(v, 0) + 1
F2x = PolynomialRing(GF(2), 'X')
out["A4"] = dict(m_histogram={str(k): v for k, v in sorted(hist.items())}, m_E0=ms["E0"],
                 x131_minus_1_over_F2=str([(int(g.degree()), int(e)) for g, e in (F2x.gen()**131 - 1).factor()]),
                 genus_bound="GHS genus is 2^(m-1) or 2^(m-1)-1; m=1 (b in F_2) gives C=E0 with no A-component",
                 seconds=round(time.time() - t0, 1))
# A5: Kummer numerology
M131 = Integer(2)**131 - 1
fac = factor(M131)
out["A5"] = dict(factor_2_131_minus_1=str(fac), ord_263_of_2=int(Mod(2, 263).multiplicative_order()),
                 r263_mod_131=int(263 % 131), minus1_in_subgroup_generated_by_2_mod_263=bool(Mod(-1, 263) in [Mod(2, 263)**i for i in range(131)]),
                 factor_2_131_plus_1=str(factor(q + 1)),
                 kronecker_minus7_263=int(kronecker(-7, 263)),
                 note="descended cyclic 263-covers of E0 branched at r points of E0(F_2) have genus 1+131r")
# A6: pi on E0[p]
c = Mod((t - f) // 2, p)
assert (t - f) % 2 == 0
out["A6"] = dict(pi_scalar_on_E0p=int(c), order_of_scalar=str(c.multiplicative_order()),
                 log2_order=float(log(RR(c.multiplicative_order()), 2)),
                 factor_p_minus_1=str(factor(p - 1)))
json.dump(out, open(sys.argv[1], "w"), indent=1, default=str)
print(json.dumps(out, indent=1, default=str)[:6000])
