"""RT8 adversarial check, part E: exact 2-rank of the mu_ell-Kummer covers C1: w^ell = f of E0 (all over F_2)
via the Cartier operator, eigenspace by eigenspace.  ell = 263 is the ECC2K-130 case (2^131-1 = 263*P,
ord_263(2) = 131), ell = 7, 23, 47 are the toy analogues whose zeta functions were computed directly in
part D.  Any curve C with A in Jac(C) needs 2-rank(Jac C) >= 130 (A is ordinary; a_structure.py A2),
and for these covers A can only sit in the Prym, so a Prym of 2-rank 0 rules the cover out.

Holomorphic differentials of C1 split into eigenspaces V_c = { w^(-c) g omega0 : g in L(D_c) },
omega0 = dx/x (invariant differential of E0), D_c = -sum_P k_P(c) P with k_P(c) = ceil((c a_P + 1)/ell) - 1,
a_P = v_P(f).  Cartier: C(w^(-c) g omega0) = w^(-c') C(f^j g omega0), c = 2c' - ell j (c' = c/2 mod ell).
So Hasse-Witt is a block-cyclic map V_c -> V_{c'}; the Prym 2-rank is the sum over <2>-orbits of
(orbit length) * (stable rank of the composed block around the orbit).

Validation built in: f = x+1 (branch Q, Q', O) has Prym 2-rank ell-1 by Deuring-Shafarevich (C1 is the
Artin-Schreier curve z^2+z = u^ell + 1 + 1/(u^ell+1) over P^1_u with ell+1 poles), and f = x (branch T, O)
has Prym 2-rank 0 (Artin-Schreier with 2 poles).

Run: sage -python e_cartier_prank.py out.json
"""
import sys, json, time
from sage.all import *

K = FunctionField(GF(2), 'x'); xk = K.gen()
R = PolynomialRing(K, 'Y'); Y = R.gen()
L = K.extension(Y**2 + xk * Y + xk**3 + 1, 'y'); y = L.gen(); x = L(xk)
w0 = (1 / x) * x.differential()
assert w0.divisor() == 0 * w0.divisor()  # holomorphic, no zeros
assert w0.cartier() == w0                 # E0 ordinary (Hasse invariant 1)

def places_of(fn):
    return list(fn.divisor().support())

PO = (x).divisor_of_poles().support()[0]
PT = [P for P in places_of(x) if P != PO][0]
PQ = [P for P in places_of(y) if P != PO and P != PT][0]          # y = 0 at (1,0)
PQp = [P for P in places_of(y + 1) if P not in (PO, PT)][0]       # (1,1)
NAMES = {PO: "O", PT: "T", PQ: "Q", PQp: "Q'"}

def eig_basis(f, ell, c):
    D = f.divisor()
    Dc = 0 * D
    for P in set(list(D.support())):
        a = D.valuation(P)
        k = -((-(c * a + 1)) // ell) - 1        # ceil((c a + 1)/ell) - 1
        Dc = Dc - k * P
    # points not in supp(f): k = 0
    B = Dc.basis_function_space() if Dc.degree() >= 0 else []
    return list(B), Dc

def hw_block(f, ell, c, Bc, Bcp):
    cp = (c * pow(2, -1, ell)) % ell
    j = (2 * cp - c) // ell
    assert 2 * cp - c == ell * j and j in (0, 1)
    rows = []
    for g in Bc:
        img = (f**j * g * w0).cartier()
        phi = img / w0                           # function
        # express phi in the basis Bcp over F_2 (dims are tiny: brute force)
        sol = None
        for lam in GF(2)**len(Bcp):
            if sum((lam[i] * Bcp[i] for i in range(len(Bcp))), L(0)) == phi:
                sol = lam; break
        if sol is None:
            raise RuntimeError("Cartier image not in expected eigenspace (c=%d)" % c)
        rows.append(list(sol))
    # matrix of the map V_c -> V_c' (rows: basis of V_c)
    return matrix(GF(2), len(Bc), len(Bcp), rows) if Bc and Bcp else matrix(GF(2), len(Bc), len(Bcp))

def prym_prank(f, ell):
    t0 = time.time()
    bases = {}
    dims = {}
    for c in range(1, ell):
        B, Dc = eig_basis(f, ell, c)
        bases[c] = B; dims[c] = len(B)
    blocks = {}
    for c in range(1, ell):
        cp = (c * pow(2, -1, ell)) % ell
        blocks[c] = hw_block(f, ell, c, bases[c], bases[cp])
    inv2 = pow(2, -1, ell)
    seen = set(); total = 0; orbit_info = []
    for c0 in range(1, ell):
        if c0 in seen: continue
        orbit = []; c = c0
        while c not in seen:
            seen.add(c); orbit.append(c); c = (c * inv2) % ell
        # composed map V_c0 -> V_c0 : rows-convention, v * B_c0 * B_c1 * ...
        M = identity_matrix(GF(2), dims[c0])
        for c in orbit:
            M = M * blocks[c]
        st = (M ** max(1, dims[c0])).rank() if dims[c0] else 0
        orbit_info.append(dict(start=int(c0), length=len(orbit), dim=int(dims[c0]), stable_rank=int(st),
                               nonzero_blocks=int(sum(1 for c in orbit if blocks[c] != 0))))
        total += len(orbit) * st
    genus = 1 + sum(dims.values())
    return dict(genus=int(genus), prym_2rank=int(total), orbits=orbit_info, seconds=round(time.time() - t0, 1))

def run(ell, cases):
    out = {}
    for name, f in cases:
        D = f.divisor()
        r = sum(1 for P in D.support() if D.valuation(P) % ell)
        res = prym_prank(f, ell)
        res["branch"] = [NAMES.get(P, str(P)) for P in D.support() if D.valuation(P) % ell]
        res["r"] = r
        out[name] = res
        print(ell, name, {k: v for k, v in res.items() if k != "orbits"}, flush=True)
    return out

if __name__ == "__main__":
    h4 = x**2 + x + y            # div = 4Q - 4O
    h4p = x**2 + y               # div = 4Q' - 4O (image of h4 under negation)
    cases = [("r2_TO_f=x", x), ("r2_QO_f=x^2+x+y", h4), ("r2_Q'O_f=x^2+y", h4p),
             ("r3_QQ'O_f=x+1_(DS_check)", x + 1)]
    allres = {}
    for ell in (7, 23, 47, 263):
        allres[str(ell)] = run(ell, cases)
    json.dump(allres, open(sys.argv[1], "w"), indent=1, default=str)
