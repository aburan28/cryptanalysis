"""RT8 part F: break-even genus of index calculus on Jac(C)(F_2) versus rho on E0, in wall-clock units.

rho on E0: 2^60.81 iterations; one iteration = 48.8 ns on one M4 Pro P-core (ec2k-cpu bench --workers 1,
measured in this run: 20.47 M it/s, rho_bench.json).
IC trial: at least one smoothness test of a degree-g polynomial over F_2 (c_smooth_bench.jsonl, measured
on the same core, no Jacobian arithmetic counted), interpolated in g.
Scenarios (cost of one trial / one LA multiply-add, in rho iterations):
  unit       : 1 / 1                               (the proposer's implicit convention)
  generous   : measured/8 / 0.1                    (8x credit for a better smoothness test, LA op = 5 ns)
  measured   : measured / 1
Model: MP1 (P^1-like place counts), best of plain and single-large-prime (b_ic_cost.analyse).
"""
import json, math, sys
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT8-small-genus-non-Artin-Schreier-cover-0")
import b_ic_cost as B

RHO = 0.5 * math.log2(math.pi * 680564733841876926932320129493409985129 / (4 * 131))
RHO_NS = 1e9 / 20472509.0          # measured single-worker rate
bench = [json.loads(l) for l in open("/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT8-small-genus-non-Artin-Schreier-cover-0/c_smooth_bench.jsonl")]
pts = sorted((b["g"], b["ns_per_test"]) for b in bench)

def ns_test(g):
    if g <= pts[0][0]: return pts[0][1] * g / pts[0][0]
    for (g0, n0), (g1, n1) in zip(pts, pts[1:]):
        if g0 <= g <= g1:
            return n0 + (n1 - n0) * (g - g0) / (g1 - g0)
    g0, n0 = pts[-1]
    return n0 * (g / g0) ** 2

scen = {
    "unit": lambda g: (1.0, 1.0),
    "generous": lambda g: (ns_test(g) / RHO_NS / 8.0, 0.1),
    "measured": lambda g: (ns_test(g) / RHO_NS, 1.0),
}
out = {"rho_log2_iterations": RHO, "rho_ns_per_iteration": RHO_NS, "scenarios": {}}
grid = list(range(130, 451, 5)) + [249, 263, 394]
grid = sorted(set(grid))
for name, wf in scen.items():
    rows = {}
    be = None
    for g in grid:
        wT, wLA = wf(g)
        bp, blp, _ = B.analyse(B.aP1, g, 6, 46, g * 1.0, "MP1", lp=True, wT=wT, wLA=wLA)
        best = min(bp[0], blp[0])
        rows[g] = dict(log2_cost_rho_units=round(best, 2), wT=round(wT, 3), wLA=wLA,
                       plain=bp[1], lp=blp[1])
        if be is None and best >= RHO:
            be = g
    # refine break-even to 1
    if be is not None:
        lo = max(130, be - 5)
        for g in range(lo, be + 1):
            wT, wLA = wf(g)
            bp, blp, _ = B.analyse(B.aP1, g, 6, 46, g * 1.0, "MP1", lp=True, wT=wT, wLA=wLA)
            if min(bp[0], blp[0]) >= RHO:
                be = g; break
    out["scenarios"][name] = dict(break_even_genus=be, by_genus=rows)
    print(name, "break-even genus", be, {g: rows[g]["log2_cost_rho_units"] for g in (130, 200, 249, 263, 300, 350, 394)}, flush=True)
json.dump(out, open(sys.argv[1], "w"), indent=1)
