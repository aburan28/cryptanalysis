"""RT8 adversarial check, part B: concrete (non-asymptotic) index-calculus cost on Jac(C)(F_2), genus g.

Exact counting, no L-notation:
  a_k        = number of places of degree k on C (model below)
  A_n        = number of effective divisors of degree n  (~ 2^n; exact for model M130)
  S_n(t)     = number of t-smooth effective divisors of degree n = [x^n] prod_{k<=t} (1-x^k)^(-a_k)
  p0(g,t)    = S_g(t) / A_g  (probability that a random reduced divisor of degree g is t-smooth;
               standard heuristic used by Enge-Gaudry / Hess / Gaudry-Thome-Theriault-Diem)
  FB(t)      = sum_{k<=t} a_k   (factor base; Frobenius-closed already since C is over F_2)
  w(g,t)     = mean number of distinct places in a t-smooth degree-g divisor (exact)
Cost (minimised over t, and over the large-prime bound tL for the 1-LP variant):
  trials     = relations_needed / yield                       (relations_needed = FB + 16)
  LA         = 3 * FB * (FB * w)   multiply-adds mod N (Wiedemann/Lanczos, no filtering credit)
Models for a_k:
  M130   exact place counts of the hypothetical genus-130 C with Jac(C) ~ A
         (zeta = 1/((1-T)(1-2T)(1+T+2T^2)) below degree 131; verified in a_structure.py)
  MP1    P^1-like counts a_k = I_2(k) (+1 at k=1), used for every g (genus enters only through n=g)
  MFAC   consistent zeta: Jac(C) ~ A x E_x^(g-130), E_x an F_2-isogeny class of elliptic curves
         (trace s = -2..2); tests how much low-degree place counts can move the cost
Output: JSON with the optimum per g and model, and break-even genera vs rho.
"""
import sys, json, math  # noqa
from math import comb

def mobius(n):
    res, m, p = 1, n, 2
    while p * p <= m:
        if m % p == 0:
            m //= p
            if m % p == 0:
                return 0
            res = -res
        p += 1
    if m > 1:
        res = -res
    return res

def divisors(n):
    return [d for d in range(1, n + 1) if n % d == 0]

def places_from_counts(Nk, kmax):
    a = {}
    for k in range(1, kmax + 1):
        s = sum(mobius(k // d) * Nk(d) for d in divisors(k))
        assert s % k == 0
        a[k] = s // k
    return a

# Lucas sequence for tau: L_k = tau^k + taubar^k, tau^2 + tau + 2 = 0
Lk = [2, -1]
for k in range(2, 200):
    Lk.append(-Lk[-1] - 2 * Lk[-2])

KMAX = 64
# M130: N_k(C) = 2^k + 1 + L_k (131 !| k)
a130 = places_from_counts(lambda k: 2 ** k + 1 + Lk[k], KMAX)
# P^1
aP1 = places_from_counts(lambda k: 2 ** k + 1, KMAX)

def smooth_table(a, t, nmax):
    """S[n] = # effective divisors of degree n supported on places of degree <= t."""
    S = [0] * (nmax + 1)
    S[0] = 1
    for k in range(1, t + 1):
        ak = a[k]
        if ak == 0:
            continue
        # multiply by (1 - x^k)^(-ak) = sum_j C(ak+j-1, j) x^(kj)
        coeffs = [comb(ak + j - 1, j) for j in range(nmax // k + 1)]
        new = [0] * (nmax + 1)
        for n in range(nmax + 1):
            s = 0
            for j in range(n // k + 1):
                s += coeffs[j] * S[n - k * j]
            new[n] = s
        S = new
    return S

def log2big(x):
    if x <= 0:
        return float('-inf')
    b = x.bit_length()
    if b > 1000:
        return b - 1000 + math.log2(x >> (b - 1000))
    return math.log2(x)

def analyse(a, g, tmin, tmax, Ag_log2, label, lp=True, wT=1.0, wLA=1.0):
    """Return best plain and best 1-LP cost (log2) for genus g."""
    best_plain, best_lp = None, None
    S_by_t = {}
    for t in range(1, tmax + 1):
        S_by_t[t] = None
    # incremental smooth tables
    S = [0] * (g + 1); S[0] = 1
    rows = []
    for t in range(1, tmax + 1):
        ak = a[t]
        if ak > 0:
            coeffs = [comb(ak + j - 1, j) for j in range(g // t + 1)]
            new = [0] * (g + 1)
            for n in range(g + 1):
                s = 0
                for j in range(n // t + 1):
                    s += coeffs[j] * S[n - t * j]
                new[n] = s
            S = new
        if t < tmin:
            continue
        FB = sum(a[k] for k in range(1, t + 1))
        p0 = log2big(S[g]) - Ag_log2
        # mean number of distinct places: W_n = sum_k a_k S_{n-k} / S_n  (derivative of the bivariate GF)
        num = sum(a[k] * S[g - k] for k in range(1, t + 1) if k <= g)
        w = num / S[g] if S[g] else float('inf')
        need = FB + 16
        trials = math.log2(need) - p0
        la = math.log2(3) + 2 * math.log2(FB) + math.log2(w)
        plain = dict(t=t, FB_log2=round(math.log2(FB), 2), p0_log2=round(p0, 2), w=round(w, 1),
                     trials_log2=round(trials, 2), LA_log2=round(la, 2))
        rows.append(plain)
        if lp:
            # single large prime: partial relations with one place of degree d in (t, tL]
            for tL in range(t + 1, min(t + 12, g) + 1):
                # yield per trial of fulls and partials; collision yield ~ sum_d a_d (T q_d)^2 / 2
                # binary search for T (log2) with fulls + combos >= need
                lo, hi = 0.0, trials + 1
                for _ in range(60):
                    mid = (lo + hi) / 2
                    Tt = 2.0 ** mid
                    full = Tt * 2.0 ** p0
                    combo = 0.0
                    for d in range(t + 1, tL + 1):
                        if d > g: break
                        qd = 2.0 ** (log2big(S[g - d]) - Ag_log2)   # prob. that a given place of degree d is the large prime
                        lam = Tt * qd      # expected partials per large place; a bucket of m gives m-1 relations
                        combo += a[d] * (lam + math.expm1(-lam))
                    if full + combo >= need:
                        hi = mid
                    else:
                        lo = mid
                Tlp = hi
                LAlp = la  # same factor-base size (large primes eliminated by merging)
                cand = dict(t=t, tL=tL, trials_log2=round(Tlp, 2), LA_log2=round(LAlp, 2))
                tot = math.log2(wT * 2 ** Tlp + wLA * 2 ** LAlp)
                if best_lp is None or tot < best_lp[0]:
                    best_lp = (tot, cand)
        tot = math.log2(wT * 2 ** trials + wLA * 2 ** la)
        if best_plain is None or tot < best_plain[0]:
            best_plain = (tot, plain)
    return best_plain, best_lp, rows

def main(outpath):
    RHO = 0.5 * math.log2(math.pi * 680564733841876926932320129493409985129 / (4 * 131))
    res = {"rho_E0_log2_iterations": RHO, "models": {}}
    # M130 (exact) at g = 130
    # A_130 from the exact zeta: effective divisors of degree n = [T^n] 1/((1-T)(1-2T)(1+T+2T^2)) (n<=130)
    nmax = 130
    Z = [0] * (nmax + 1)
    # series of 1/((1-T)(1-2T)(1+T+2T^2)) by recurrence on the denominator
    den = [1, -2, 1]  # (1-T)(1-2T) = 1 - 3T + 2T^2 ; multiply by (1+T+2T^2)
    d1 = [1, -3, 2]
    d2 = [1, 1, 2]
    den = [0] * 5
    for i, x in enumerate(d1):
        for j, y in enumerate(d2):
            den[i + j] += x * y
    for n in range(nmax + 1):
        s = 1 if n == 0 else 0
        for i in range(1, 5):
            if n - i >= 0:
                s -= den[i] * Z[n - i]
        Z[n] = s
    bp, blp, rows = analyse(a130, 130, 4, 40, log2big(Z[130]), "M130")
    res["models"]["M130_g130"] = dict(A_130_log2=round(log2big(Z[130]), 3), best_plain=bp, best_1LP=blp,
                                      places_1_to_12=[a130[k] for k in range(1, 13)], rows=rows)
    print("M130 g=130", bp, blp, flush=True)
    # MP1 across genera
    out = {}
    for g in [130, 150, 175, 200, 225, 249, 263, 275, 300, 325, 350, 394, 400, 450, 500, 525, 600]:
        bp, blp, rows = analyse(aP1, g, 6, 44, g * 1.0, "MP1")
        out[g] = dict(best_plain=bp, best_1LP=blp)
        print("MP1", g, round(bp[0], 2), bp[1], round(blp[0], 2), blp[1], flush=True)
    res["models"]["MP1"] = out
    # MFAC: consistent models C with Jac(C) ~ A x E_x^b, b = g - 130, place counts and A_g from the
    # exact zeta L_A(T) L_x(T)^b / ((1-T)(1-2T)).  E_x ranges over the F_2 isogeny classes of elliptic
    # curves (trace s in {-2..2}); s = -2 (5 rational points) maximises low-degree places.
    t131 = -22283658519494248867
    q = 2 ** 131
    def series_mul(A, B, n):
        C = [0] * (n + 1)
        for i, x in enumerate(A):
            if i > n: break
            if x == 0: continue
            for j, y in enumerate(B):
                if i + j > n: break
                C[i + j] += x * y
        return C
    def series_inv(A, n):
        # A[0] = 1
        B = [0] * (n + 1); B[0] = 1
        for k in range(1, n + 1):
            s_ = 0
            for i in range(1, min(k, len(A) - 1) + 1):
                s_ += A[i] * B[k - i]
            B[k] = -s_
        return B
    outf = {}
    for s in [-2, -1, 0, 1, 2]:
        # eigenvalue power sums of E_x: e_k with e_0 = 2, e_1 = s, e_k = s e_{k-1} - 2 e_{k-2}
        e = [2, s]
        for k in range(2, 70): e.append(s * e[-1] - 2 * e[-2])
        outf[s] = {}
        for g in [200, 263, 300, 350, 394]:
            b = g - 130
            ax = places_from_counts(lambda k: 2 ** k + 1 + Lk[k] - b * e[k], KMAX)
            if min(ax.values()) < 0:
                outf[s][g] = "negative place count: no such curve"
                print("MFAC", s, g, "negative place count", flush=True)
                continue
            n = g
            LA_num = [0] * (n + 1); LA_num[0] = 1
            if 131 <= n: LA_num[131] = -t131
            if 262 <= n: LA_num[262] = q
            LA = series_mul(LA_num, series_inv([1, 1, 2], n), n)
            Lx = [1]
            for _ in range(b):
                Lx = series_mul(Lx, [1, -s, 2], n)
            Z = series_mul(series_mul(LA, Lx, n), series_inv([1, -3, 2], n), n)
            bp, blp, rows = analyse(ax, g, 6, 44, log2big(Z[g]), "MFAC")
            outf[s][g] = dict(best_plain=bp, best_1LP=blp, places_1_to_8=[ax[k] for k in range(1, 9)],
                              A_g_log2=round(log2big(Z[g]), 3))
            print("MFAC s=%d g=%d" % (s, g), round(bp[0], 2), bp[1], round(blp[0], 2), blp[1], [ax[k] for k in range(1, 9)], flush=True)
    res["models"]["MFAC"] = outf
    json.dump(res, open(outpath, "w"), indent=1)

if __name__ == "__main__":
    main(sys.argv[1])
