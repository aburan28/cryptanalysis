"""RT8 part H: mod-263 point-count obstruction for mu_263-Kummer covers C -> Y (Y over F_2, genus 0 or 1)
whose Prym would have to be E0^262 over F_q (forced whenever A is in Jac(C): the E0-multiplicity in a
Prym with Q(zeta_263)-action is a multiple of [Q(sqrt-7, zeta_263):Q]/2 = 262).
  #C(F_q) = #Y(F_q) - 262 t          (if Prym ~ E0^262)
  #C(F_q) = r_q  (mod 263)           (unramified fibres are Z/263-torsors: 0 or 263 rational points;
                                       each F_q-rational branch point has exactly one point above it)
so a family is excluded unless #Y(F_q) + t = r_q (mod 263)  (262 = -1 mod 263).
Genera in the threat window: Y = P^1 with r = 3 (g = 131) or r = 4 (g = 262); Y elliptic with r = 2 (g = 263)."""
import json, sys
q = 2 ** 131
t = -22283658519494248867
def lucas(s, n):
    a, b = 2, s
    for _ in range(n - 1):
        a, b = b, s * b - 2 * a
    return b
assert lucas(-1, 131) == t
out = {"t_mod_263": t % 263, "q_mod_263": q % 263}
# Y = P^1: #Y(F_q) = q+1
fam = []
# r = 4 on P^1: branch = {two F_2-points} u {omega, omega-bar} -> r_q = 2 ; {one F_2-point} u {cubic point} -> r_q = 1
for name, rq in [("P1_r4_two_F2_points_plus_F4_pair", 2), ("P1_r4_one_F2_point_plus_cubic_point", 1),
                 ("P1_r3_any (dim 131 not a multiple of 262: excluded before any congruence)", None)]:
    if rq is None:
        fam.append(dict(family=name, excluded=True, reason="E0-multiplicity must be 0 or 262 > 131")); continue
    lhs = (q + 1 - 262 * t) % 263
    fam.append(dict(family=name, genus=262, r_q=rq, count_if_Prym_is_E0_262_mod_263=lhs, excluded=(lhs != rq % 263)))
# Y elliptic over F_2 with F_2-trace s, r = 2 branch points in Y(F_2): r_q = 2
for s in (-2, -1, 0, 1, 2):
    tY = lucas(s, 131)
    lhs = (q + 1 - tY - 262 * t) % 263
    fam.append(dict(family="Y elliptic over F_2 with trace %d (#Y(F_2)=%d), r=2" % (s, 3 - s), genus=263,
                    tY_mod_263=tY % 263, r_q=2, count_if_Prym_is_E0_262_mod_263=lhs, excluded=(lhs != 2),
                    note=("only E0 itself (j=1) has trace -1 over F_2; handled by the exact 2-rank computation" if s == -1 else "")))
out["families"] = fam
json.dump(out, open(sys.argv[1], "w"), indent=1)
print(json.dumps(out, indent=1))
