from sage.all import *
m=37; a,b=2,-1
for _ in range(m-1): a,b=b,-b-2*a
t=b; print('t=',t, 't/2 mod 73 order:', (Mod(t,73)/2).multiplicative_order(), 't/2 mod 2663 order:', (Mod(t,2663)/2).multiplicative_order())
print('kronecker(-7,73)=',kronecker(-7,73),' kronecker(-7,2663)=',kronecker(-7,2663))
