from sage.all import *
# Koblitz a2=0: y^2+xy=x^3+1 over F_2 has trace t1 = -1 (#E(F_2)=4). t_m by Lucas: t_{k+1} = t1 t_k - 2 t_{k-1}
def trace(m):
    a, b = 2, -1
    for _ in range(m-1): a, b = b, -b - 2*a
    return b
for m in prime_range(13, 50):
    t = trace(m); q = 2**m; card = q + 1 - t
    D = t*t - 4*q; assert D % -7 == 0
    f2 = D // -7; f = isqrt(f2); assert f*f == f2
    nfac = factor(card); big = max(pr for pr, e in nfac)
    print(m, 'card=', nfac, ' log2(bigprime)=%.1f' % log(big, 2).n(), ' f=', factor(f))
