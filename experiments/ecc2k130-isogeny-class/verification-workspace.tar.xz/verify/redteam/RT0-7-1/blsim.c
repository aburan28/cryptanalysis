/* Bernstein-Lange "rho with precomputation" in a generic prime-order group.
   Group: order-ell subgroup of F_P^*, P = k*ell+1 < 2^62 prime.  Walk: R-adding walk x -> x*M[h(x)].
   Precomputation: walks from g^e (e random) until a distinguished point (DP, prob 1/W per step);
   collect u*T distinct DPs with hit counts, keep the T most-hit ones (u=1: first T found).
   Online: h = g^k, walk from h*g^r; on a DP in the table recover k and CHECK it; else restart.
   Output: one JSON line with measured c1 = precomp_steps/sqrt(ell*T), c2 = mean_online_steps/sqrt(ell/T).
   Usage: blsim ellbits log2T alpha u n_instances seed  */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
typedef uint64_t u64; typedef __uint128_t u128;
static u64 P, ell, g;
static inline u64 mulm(u64 a, u64 b, u64 m){ return (u64)((u128)a*b % m); }
static u64 powm(u64 a, u64 e, u64 m){ u64 r=1; while(e){ if(e&1) r=mulm(r,a,m); a=mulm(a,a,m); e>>=1;} return r; }
static int isprime(u64 n){ if(n<2) return 0; static const u64 sp[]={2,3,5,7,11,13,17,19,23,29,31,37};
  for(int i=0;i<12;i++){ if(n%sp[i]==0) return n==sp[i]; }
  u64 d=n-1; int s=0; while(!(d&1)){d>>=1;s++;}
  for(int i=0;i<12;i++){ u64 x=powm(sp[i],d,n); if(x==1||x==n-1) continue; int ok=0;
    for(int j=1;j<s;j++){ x=mulm(x,x,n); if(x==n-1){ok=1;break;} } if(!ok) return 0; } return 1; }
static u64 rs;
static inline u64 rnd(void){ u64 z=(rs+=0x9E3779B97F4A7C15ULL); z=(z^(z>>30))*0xBF58476D1CE4E5B9ULL; z=(z^(z>>27))*0x94D049BB133111EBULL; return z^(z>>31); }
static inline u64 mix(u64 z){ z+=0x632BE59BD9B4E019ULL; z=(z^(z>>30))*0xBF58476D1CE4E5B9ULL; z=(z^(z>>27))*0x94D049BB133111EBULL; return z^(z>>31); }
#define R 1024
static u64 Mv[R], Me[R];
static u64 dpthr; /* DP iff (hash>>10) < dpthr, prob 1/W */
/* hash table */
typedef struct { u64 key, lg; u64 cnt; } ent;
static ent *tab; static u64 cap, used;
static ent* find(u64 key){ u64 i=mix(key^0x1234567ULL)&(cap-1); while(tab[i].key){ if(tab[i].key==key) return &tab[i]; i=(i+1)&(cap-1);} return &tab[i]; }
static int cmpcnt(const void*a,const void*b){ u64 x=((const ent*)a)->cnt, y=((const ent*)b)->cnt; return x<y?1:(x>y?-1:0); }
int main(int argc, char**argv){
  if(argc<7){ fprintf(stderr,"usage\n"); return 1; }
  int ellbits=atoi(argv[1]); double lT=atof(argv[2]); double alpha=atof(argv[3]); double u=atof(argv[4]);
  int ninst=atoi(argv[5]); rs=strtoull(argv[6],0,10)*0x9E3779B97F4A7C15ULL+12345;
  /* ell: first prime >= 2^ellbits + (random offset) ; P = k ell + 1 prime */
  ell=(1ULL<<ellbits)+(rnd()%(1ULL<<(ellbits-4))); while(!isprime(ell)) ell++;
  u64 k=2; for(;;k+=2){ if(k*ell > (1ULL<<62)) { k=2; ell+=2; while(!isprime(ell)) ell++; } if(isprime(k*ell+1)) break; }
  P=k*ell+1; do { g=powm(2+rnd()%(P-3),k,P); } while(g==1);
  double T=pow(2.0,lT); u64 Ti=(u64)llround(T);
  double W=alpha*sqrt((double)ell/T); dpthr=(u64)((double)(1ULL<<54)/W);
  u64 capW=(u64)(20*W)+10;
  for(int j=0;j<R;j++){ Me[j]=rnd()%ell; Mv[j]=powm(g,Me[j],P); }
  u64 want=(u64)llround(u*T); cap=1; while(cap<4*want) cap<<=1; tab=calloc(cap,sizeof(ent)); used=0;
  /* ---- precomputation */
  u64 psteps=0, pwalks=0, pabandon=0, phits_dup=0;
  while(used<want){
    u64 e=rnd()%ell, x=powm(g,e,P); u64 st=0; pwalks++;
    for(;;){ u64 h=mix(x); if((h>>10)<dpthr) break; int j=h&(R-1); x=mulm(x,Mv[j],P); e+=Me[j]; if(e>=ell) e-=ell; st++; if(st>capW) break; }
    psteps+=st; if(st>capW){ pabandon++; continue; }
    ent* q=find(x); if(q->key){ q->cnt++; phits_dup++; if(q->lg!=e){ fprintf(stderr,"inconsistent log!\n"); return 2;} } else { q->key=x; q->lg=e; q->cnt=1; used++; }
  }
  /* keep T most popular */
  ent* all=malloc(used*sizeof(ent)); u64 m=0; for(u64 i=0;i<cap;i++) if(tab[i].key) all[m++]=tab[i];
  qsort(all,m,sizeof(ent),cmpcnt);
  memset(tab,0,cap*sizeof(ent)); for(u64 i=0;i<Ti && i<m;i++){ ent* q=find(all[i].key); *q=all[i]; }
  /* ---- online */
  double osteps=0, osq=0; u64 owalks=0, ofail=0; int bad=0;
  for(int it=0; it<ninst; it++){
    u64 kk=rnd()%ell, hh=powm(g,kk,P); u64 st_inst=0;
    for(;;){
      u64 r=rnd()%ell, x=mulm(hh,powm(g,r,P),P), e=r; u64 st=0; owalks++;
      for(;;){ u64 h=mix(x); if((h>>10)<dpthr) break; int j=h&(R-1); x=mulm(x,Mv[j],P); e+=Me[j]; if(e>=ell) e-=ell; st++; if(st>capW) break; }
      st_inst+=st; if(st>capW){ ofail++; continue; }
      ent* q=find(x); if(!q->key){ ofail++; continue; }
      u64 kr=(q->lg + ell - e)%ell; if(kr!=kk || powm(g,kr,P)!=hh) bad++;
      break;
    }
    osteps+=st_inst; osq+=(double)st_inst*st_inst;
  }
  double mean=osteps/ninst, sd=sqrt(osq/ninst-mean*mean);
  printf("{\"ellbits\":%d,\"ell\":%llu,\"P\":%llu,\"log2T\":%g,\"alpha\":%g,\"u\":%g,\"W\":%.1f,"
         "\"precomp_steps\":%llu,\"precomp_walks\":%llu,\"precomp_abandoned\":%llu,\"precomp_dup_hits\":%llu,"
         "\"c1\":%.4f,\"n_inst\":%d,\"online_mean\":%.1f,\"online_sd\":%.1f,\"c2\":%.4f,\"c2_stderr\":%.4f,"
         "\"online_walks_per_inst\":%.3f,\"wrong_logs\":%d,\"c1c2\":%.4f}\n",
    ellbits,(unsigned long long)ell,(unsigned long long)P,lT,alpha,u,W,(unsigned long long)psteps,(unsigned long long)pwalks,
    (unsigned long long)pabandon,(unsigned long long)phits_dup, psteps/sqrt((double)ell*T), ninst, mean, sd,
    mean/sqrt((double)ell/T), sd/sqrt((double)ninst)/sqrt((double)ell/T), (double)owalks/ninst, bad,
    psteps/sqrt((double)ell*T)*mean/sqrt((double)ell/T));
  return bad?3:0;
}
