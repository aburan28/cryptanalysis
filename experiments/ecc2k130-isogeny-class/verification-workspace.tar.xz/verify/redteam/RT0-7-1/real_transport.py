# Independent spot check at full size: ascending F_q-rational 263-isogeny psi: E_floor -> E0 for a few floor curves,
# built from the twist's unique rational 263-subgroup (x-coordinates are shared by the char-2 quadratic twist).
# Checks: codomain F_q-isomorphic to E0 (a2=0 model); psi maps order-N points to order-N points; psi(kP)=k psi(P);
# then a DLP instance (P, Q=kP) on the floor curve becomes (psi P, psi Q) in E0's N-subgroup, where E0's tau-classes apply.
import sys, json, time, random
sys.path.insert(0, '/Volumes/SSD990/ecdlp-hardness-work/ground_truth')
from sage.all import *
import ecc2k
set_random_seed(7)
K = ecc2k.field(); N = Integer(ecc2k.N); CARD = Integer(ecc2k.CARD); TW = Integer(ecc2k.TWIST_CARD)
E0 = EllipticCurve(K, [1, 0, 0, 0, 1]); s = Integer(ecc2k.TAU_EIGEN)
labels = sys.argv[1:] or ['A000', 'B077']
out = {}
for lab in labels:
    rec = ecc2k.RECORDS[lab]; b = ecc2k.dec(int(rec['b_int'])) if hasattr(ecc2k, 'dec') else K.from_integer(int(rec['b_int']))
    E = EllipticCurve(K, [1, 0, 0, 0, b]); Et = EllipticCurve(K, [1, 1, 0, 0, b])
    assert E.j_invariant() != 1 and E.j_invariant()**(2**131) == E.j_invariant()
    # j not in F_2 => no F_2-Frobenius endomorphism on E
    t0 = time.time()
    cof = TW // 263**2
    while True:
        Pt = cof * Et.random_point()
        if not (263 * Pt).is_zero(): break
    assert (263**2 * Pt).is_zero()       # 263-part of E'(F_q) cyclic of order 263^2
    Kp = 263 * Pt
    X = PolynomialRing(K, 'X').gen(); kp = X**0; Q = Kp
    for i in range(131): kp *= (X - Q[0]); Q = Q + Kp
    up = E.isogeny(kp); cod = up.codomain()
    assert cod.j_invariant() == 1
    iso = cod.isomorphism_to(E0)            # raises if codomain is the twist of E0
    psi = lambda P: iso(up(P))
    build = time.time() - t0
    ok = True; evs = []
    for _ in range(3):
        while True:
            P = 4 * E.random_point()
            if not P.is_zero(): break
        assert (N * P).is_zero()
        k = randrange(1, N); t1 = time.time(); U = psi(P); evs.append(time.time() - t1)
        V = psi(k * P)
        ok &= (not U.is_zero()) and (N * U).is_zero() and V == k * U
        # tau-class structure is available on the image: tau(U) = s*U
        ok &= (E0(U[0]**2, U[1]**2) == s * U)
    out[lab] = dict(j_int=rec['j_int'][:20] + '...', build_secs=build, eval_secs=evs, homomorphism_and_tau_checks=bool(ok),
                    codomain_isomorphic_to_E0_not_twist=True)
    print(lab, out[lab]); sys.stdout.flush()
json.dump(out, open('real_transport.json', 'w'), indent=1)
