# End-to-end toy of RT0-7 on a real tau-class walk, with transport from a floor curve.
# m = 37 Koblitz E0: y^2+xy=x^3+1 over F_{2^37}; prime subgroup n = 230603167; classes {+-tau^i P}, size 74.
# Floor curve E1 = codomain of a descending F_q-rational 73-isogeny from E0 (j(E1) not in F_2, so no tau on E1).
# Transport psi: E1 -> E0 = the unique F_q-rational (ascending) 73-isogeny of E1, composed with an F_q-isomorphism.
# Measures: BL precomputation / online steps, single-instance parallel rho steps, and checks every recovered log.
from sage.all import *
import json, time, random, math, sys
random.seed(20260924); set_random_seed(20260924)
d = json.load(open('toy_isogenies_m37_l73.json'))
m = d['m']; R = PolynomialRing(GF(2), 'z')
K = GF(2**m, 'z', modulus=R(d['modulus'])); fi = K.from_integer
E0 = EllipticCurve(K, [1, 0, 0, 0, 1]); card = Integer(d['card'])
n = Integer(230603167); assert card % n == 0 and is_prime(n); cof = card // n
res = dict(m=m, n=int(n), card=int(card))
def rand_order_n(E):
    while True:
        P = cof * E.random_point()
        if not P.is_zero():
            assert (n * P).is_zero(); return P
G = rand_order_n(E0)
# tau eigenvalue s on <G>
tauP = lambda P: P.curve()(P[0]**2, P[1]**2)
ss = [ZZ(r) for r in PolynomialRing(GF(n), 'X')('X^2+X+2').roots(multiplicities=False)]
s = [r for r in ss if tauP(G) == r * G][0]; assert Mod(s, n).multiplicative_order() == m
res['tau_eigenvalue'] = int(s)
spow = [power_mod(s, i, n) for i in range(m)]
cls = 2 * m; ell = n / cls; res['class_size'] = cls; res['log2_ell'] = float(log(ell, 2))
# ---------- class-compatible walk on raw coordinates
def canon(x, y):
    """canonical rep of the class {+-tau^i (x,y)}; returns (xc, yc, multiplier mu) with (xc,yc) = mu*(x,y)"""
    best = None; xi = x
    for i in range(m):
        v = xi.to_integer()
        if best is None or v < best[0]: best = (v, i)
        xi = xi * xi
    i = best[1]; xc = fi(best[0]); yc = y
    for _ in range(i): yc = yc * yc
    mu = spow[i]
    y2 = yc + xc  # negation on y^2+xy=x^3+b: (x,y)->(x,y+x)
    if y2.to_integer() < yc.to_integer(): yc = y2; mu = (-mu) % n
    return xc, yc, mu, best[0]
MASK = (1 << 64) - 1
def hsh(v, salt):
    v = (v * 0x9E3779B97F4A7C15 + salt) & MASK; v ^= v >> 29; v = (v * 0xBF58476D1CE4E5B9) & MASK; v ^= v >> 32; return v
JS = list(range(3, 11))  # tau^j with j in 3..10 as in the ECC2K-130 attack
mult = {j: (1 + spow[j % m]) % n for j in JS}
def add(x1, y1, x2, y2):  # affine add on y^2+xy=x^3+1, distinct x
    lam = (y1 + y2) / (x1 + x2); x3 = lam * lam + lam + x1 + x2; return x3, lam * (x1 + x3) + x3 + y1
def walk(x, y, a, b, W, cap):
    """walk from point (x,y) = a*G + b*H until a DP; returns (xc_int, yc, a, b, steps) of canonical DP rep, or None"""
    thr = int((1 << 64) / W); st = 0
    while True:
        xc, yc, mu, xint = canon(x, y)
        h = hsh(xint, 1)
        if h < thr:
            return xint, yc, a * mu % n, b * mu % n, st
        j = JS[hsh(xint, 2) % len(JS)]
        xj, yj = x, y
        for _ in range(j): xj = xj * xj; yj = yj * yj
        x, y = add(x, y, xj, yj); c = mult[j]; a = a * c % n; b = b * c % n
        st += 1
        if st > cap: return None
def pt(x, y): return E0(x, y)
# sanity: the walk tracks logs correctly
x0, y0 = G[0], G[1]
rr = walk(x0, y0, 1, 0, 50, 5000)
assert rr is not None and E0(fi(rr[0]), rr[1]) == rr[2] * G
# ---------- BL precomputation
def precompute(T, alpha, u=1):
    W = alpha * math.sqrt(ell / T); cap = int(20 * W) + 10
    table = {}; cnt = {}; steps = 0; walks = 0; abandoned = 0
    while len(table) < u * T:
        r = random.randrange(1, n); P = r * G; walks += 1
        out = walk(P[0], P[1], r, 0, W, cap)
        if out is None: abandoned += 1; steps += cap; continue
        xi, yc, a, b, st = out; steps += st
        if xi in table:
            assert table[xi] == a; cnt[xi] += 1
        else:
            table[xi] = a; cnt[xi] = 1
    keep = sorted(table, key=lambda k: -cnt[k])[:T]
    return {k: table[k] for k in keep}, dict(T=T, alpha=alpha, u=u, W=W, steps=steps, walks=walks, abandoned=abandoned,
                                            c1=steps / math.sqrt(ell * T))
def online_log(Hpt, table, W):
    """BL online: log_G(H) using table; returns (log, steps)"""
    cap = int(20 * W) + 10; total = 0
    while True:
        r = random.randrange(1, n); P = Hpt + r * G
        out = walk(P[0], P[1], r, 1, W, cap)
        if out is None: total += cap; continue
        xi, yc, a, b, st = out; total += st
        if xi in table:
            return (table[xi] - a) * inverse_mod(b, n) % n, total
# ---------- transport psi: E1 -> E0
iso_list = d['isog']
desc = [e for e in iso_list if not e['j_in_F2']]
res['n_73_isogenies_from_E0'] = len(iso_list); res['n_descending'] = len(desc)
e1 = desc[0]
E1 = EllipticCurve(K, [fi(c) for c in e1['a_invs']])
res['E1_j_int'] = e1['j_int']; res['E1_j_in_F2'] = e1['j_in_F2']
assert E1.cardinality() == card
t0 = time.time()
# kernel of the ascending isogeny = the unique 73-subgroup of E1 rational over F_{q^k}, k = ord_73(t/2) (Jordan block on E1[73])
def lucas(k):
    a, b = 2, -1
    for _ in range(k - 1): a, b = b, -b - 2 * a
    return b
t37 = lucas(m); kk = int((Mod(t37, 73) / 2).multiplicative_order()); res['k_embed_73'] = kk
L, emb = K.extension(kk, 'w', map=True); sec = emb.section()
E1L = EllipticCurve(L, [emb(c) for c in E1.a_invariants()])
NL = 2**(m * kk) + 1 - lucas(m * kk); v73 = valuation(NL, 73); coL = NL // 73**v73
res['E1_over_Fq^k_73_valuation'] = int(v73)
while True:
    Qk = coL * E1L.random_point()
    if not Qk.is_zero(): break
while not (73 * Qk).is_zero(): Qk = 73 * Qk
XL = PolynomialRing(L, 'X').gen(); kpL = XL**0; Qi = Qk
for i in range(36): kpL *= (XL - Qi[0]); Qi = Qi + Qk
kp = PolynomialRing(K, 'X')([sec(c) for c in kpL.list()])
assert kp.change_ring(emb) == kpL if hasattr(kp, 'change_ring') else True
up = E1.isogeny(kp)
res['E1_isog_secs'] = time.time() - t0
assert up.codomain().j_invariant() == 1
isoE0 = up.codomain().isomorphism_to(E0)
psi = lambda P: isoE0(up(P))
# check psi o phi = +-[73]
phi = E0.isogeny(PolynomialRing(K, 'X')([fi(c) for c in e1['kernel_poly']]))
isoE1 = phi.codomain().isomorphism_to(E1)
Pt = rand_order_n(E0); comp = psi(isoE1(phi(Pt)))
res['psi_phi_equals'] = '+73' if comp == 73 * Pt else ('-73' if comp == -73 * Pt else 'OTHER')
assert res['psi_phi_equals'] != 'OTHER'
# ---------- experiments
exps = []
for (T, alpha) in [(64, 0.875), (256, 0.875), (1024, 0.875)]:
    t0 = time.time()
    table, info = precompute(T, alpha)
    info['precomp_secs'] = time.time() - t0
    W = info['W']
    # E0 native instances and floor-curve instances via transport
    ok0 = 0; st0 = []; okt = 0; stt = []
    NI = 60
    for _ in range(NI):
        k = random.randrange(1, n); H = k * G
        lg, st = online_log(H, table, W); st0.append(st); ok0 += (lg == k)
    base_cache = {}
    P1 = rand_order_n(E1); U = psi(P1)
    lu, st = online_log(U, table, W); info['floor_base_log_steps'] = st   # one-off per floor curve
    for _ in range(NI):
        k = random.randrange(1, n); Q1 = k * P1; V = psi(Q1)
        assert V != E0(0) and (n * V).is_zero()
        lv, st = online_log(V, table, W); stt.append(st)
        kk = lv * inverse_mod(lu, n) % n; okt += (kk == k)
    info.update(E0_instances=NI, E0_correct=ok0, E0_online_mean=float(sum(st0)) / NI,
                floor_instances=NI, floor_correct=okt, floor_online_mean=float(sum(stt)) / NI,
                c2_E0=float(sum(st0)) / NI / math.sqrt(ell / T), c2_floor=float(sum(stt)) / NI / math.sqrt(ell / T))
    info['single_instance_total_E0'] = info['steps'] + info['E0_online_mean']
    print(json.dumps(info)); sys.stdout.flush()
    exps.append(info)
res['BL'] = exps
# ---------- single-instance parallel-collision rho on the same class walk (for comparison)
def rho_one(H, Wd=8):
    seen = {}; total = 0; cap = 40 * Wd
    while True:
        a = random.randrange(n); b = random.randrange(1, n); P = a * G + b * H
        out = walk(P[0], P[1], a, b, Wd, cap)
        if out is None: total += cap; continue
        xi, yc, a2, b2, st = out; total += st
        if xi in seen:
            a1, b1, y1 = seen[xi]
            if y1 != yc: continue   # canonical rep is unique, so y must agree
            if (b1 - b2) % n:
                return (a2 - a1) * inverse_mod(b1 - b2, n) % n, total
        else:
            seen[xi] = (a2, b2, yc)
rs = []; okr = 0; NR = 60
for _ in range(NR):
    k = random.randrange(1, n); lg, st = rho_one(k * G); rs.append(st); okr += (lg == k)
res['rho_single'] = dict(instances=NR, correct=okr, mean_steps=float(sum(rs)) / NR, c_rho=float(sum(rs)) / NR / math.sqrt(ell),
                         theory_c=math.sqrt(math.pi / 2))
print(json.dumps(res['rho_single']))
json.dump(res, open('toy_bl.json', 'w'), indent=1)
