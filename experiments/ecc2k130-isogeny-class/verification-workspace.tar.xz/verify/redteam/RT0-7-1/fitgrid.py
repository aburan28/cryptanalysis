import json, math, collections, statistics as st
rows=[json.loads(l) for l in open('grid.jsonl')]
assert all(r['wrong_logs']==0 for r in rows)
out={}
print('total instances solved and checked:', sum(r['n_inst'] for r in rows), 'wrong:', sum(r['wrong_logs'] for r in rows))
out['instances_checked']=sum(r['n_inst'] for r in rows)
def agg(sel):
    g=collections.defaultdict(list)
    for r in rows:
        k=sel(r)
        if k: g[k].append(r)
    return g
# grid1: ell=2^40, u=1, n=2000
g=agg(lambda r: (r['log2T'],r['alpha']) if r['ellbits']==40 and r['u']==1 and r['n_inst']==2000 and r['log2T']!=10 or (r['ellbits']==40 and r['log2T']==10 and r['alpha'] in (0.5,1.0)) else None)
print('\nGrid1 ell~2^40: log2T alpha  mean log2(precomp)  mean log2(online)  c1 c2')
fit=collections.defaultdict(list); g1={}
for (lT,a),rs in sorted(g.items()):
    lp=st.mean(math.log2(r['precomp_steps']) for r in rs); lo=st.mean(math.log2(r['online_mean']) for r in rs)
    c1=st.mean(r['c1'] for r in rs); c2=st.mean(r['c2'] for r in rs); ellb=st.mean(math.log2(r['ell']) for r in rs)
    print(f'{lT:5} {a:5} {lp:8.3f} {lo:8.3f}  {c1:.3f} {c2:.3f}  n_runs={len(rs)}')
    fit[a].append((lT,lp,lo)); g1[f'T2^{lT}_a{a}']=dict(log2_precomp=lp,log2_online=lo,c1=c1,c2=c2,log2_ell=ellb,runs=len(rs))
def slope(pts):
    n=len(pts); mx=sum(x for x,_ in pts)/n; my=sum(y for _,y in pts)/n
    return sum((x-mx)*(y-my) for x,y in pts)/sum((x-mx)**2 for x,_ in pts)
out['grid1_T_scaling']=g1
for a,pts in fit.items():
    sp=slope([(x,y) for x,y,_ in pts]); so=slope([(x,z) for x,_,z in pts])
    print(f'alpha={a}: slope d log2(precomp)/d log2T = {sp:.3f} (theory 0.5); d log2(online)/d log2T = {so:.3f} (theory -0.5)')
    out[f'grid1_slopes_alpha{a}']=dict(precomp_vs_log2T=sp, online_vs_log2T=so)
# grid2: ell scaling T=2^10 alpha 1
g=agg(lambda r: r['ellbits'] if r['log2T']==10 and r['alpha']==1.0 and r['u']==1 else None)
pts_p=[];pts_o=[]
print('\nGrid2 T=2^10 alpha=1: ellbits log2ell log2(precomp) log2(online)')
for lb,rs in sorted(g.items()):
    for r in rs:
        pts_p.append((math.log2(r['ell']),math.log2(r['precomp_steps']))); pts_o.append((math.log2(r['ell']),math.log2(r['online_mean'])))
    print(lb, [round(math.log2(r['precomp_steps']),3) for r in rs], [round(math.log2(r['online_mean']),3) for r in rs])
print('slopes vs log2 ell: precomp %.3f online %.3f (theory 0.5, 0.5)'%(slope(pts_p),slope(pts_o)))
out['grid2_ell_scaling_slopes']=dict(precomp=slope(pts_p),online=slope(pts_o))
# grid3: constants at ell=2^36 T=2^12
g=agg(lambda r: (r['alpha'],r['u']) if r['ellbits']==36 and r['log2T']==12 else None)
print('\nGrid3 ell~2^36 T=2^12: alpha u   c1   c2(+-se)   c1*c2')
g3={}
for (a,u),rs in sorted(g.items()):
    c1=st.mean(r['c1'] for r in rs); c2=st.mean(r['c2'] for r in rs); se=math.sqrt(sum(r['c2_stderr']**2 for r in rs))/len(rs)
    g3[f'a{a}_u{u}']=dict(alpha=a,u=u,c1=c1,c2=c2,c2_se=se,c1c2=c1*c2,runs=len(rs))
    print(f'{a:6} {u:3} {c1:6.3f} {c2:6.3f}({se:.3f}) {c1*c2:6.3f}')
out['grid3_constants']=g3
best=min(g3.values(), key=lambda d:d['c1c2'])
print('min c1*c2 over grid3:', best)
out['grid3_min_c1c2']=best
# pareto: for each c1 bound, min c2
json.dump(out,open('grid_fit.json','w'),indent=1)
