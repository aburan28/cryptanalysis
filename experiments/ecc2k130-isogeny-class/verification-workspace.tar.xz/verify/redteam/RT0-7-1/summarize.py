import json, math
A = json.load(open('analytic.json')); G = json.load(open('grid_fit.json'))
ell = 2**A['log2_ell']; rho = 2**A['rho_single_log2']
out = {'source_files': ['analytic.json', 'grid_fit.json', 'grid.jsonl', 'toy_bl.json', 'real_transport.json']}
pts = {k: G['grid3_constants'][k] for k in ('a0.875_u1', 'a1_u1', 'a0.5_u2', 'a0.25_u1')}
tab = {}
for name, c in pts.items():
    row = {}
    for lt in (20, 30, 40):
        T = 2.0**lt; P = c['c1']*math.sqrt(ell*T); O = c['c2']*math.sqrt(ell/T)
        row[f'T2^{lt}'] = dict(precomp_log2=round(math.log2(P), 2), online_log2=round(math.log2(O), 2))
    row['c1'] = c['c1']; row['c2'] = c['c2']; row['c1c2'] = c['c1c2']
    row['single_instance_best_total_log2'] = round(math.log2(2*math.sqrt(c['c1c2']*ell)), 2)
    row['single_instance_best_over_rho'] = 2*math.sqrt(c['c1c2']*ell)/rho
    tab[name] = row
out['ECC2K130_with_measured_constants'] = tab
out['min_measured_c1c2'] = G['grid3_min_c1c2']['c1c2']
out['single_instance_lower_envelope_log2'] = math.log2(2*math.sqrt(G['grid3_min_c1c2']['c1c2']*ell))
out['rho_log2'] = A['rho_single_log2']
try:
    T = json.load(open('toy_bl.json')); out['toy'] = {'rho': T['rho_single'], 'BL': [{k: b[k] for k in ('T', 'c1', 'c2_E0', 'c2_floor', 'E0_correct', 'floor_correct', 'E0_instances', 'floor_instances', 'steps', 'E0_online_mean', 'floor_online_mean', 'single_instance_total_E0')} for b in T['BL']]}
except Exception as e: out['toy'] = str(e)
json.dump(out, open('summary.json', 'w'), indent=1); print(json.dumps(out, indent=1))
