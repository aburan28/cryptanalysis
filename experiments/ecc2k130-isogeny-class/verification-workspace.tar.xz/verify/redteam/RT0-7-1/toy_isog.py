# Toy analogue of the ECC2K-130 transport: m = 37 Koblitz E0: y^2+xy=x^3+1, #E0 = 4*149*230603167,
# conductor f = 73*2663.  Build the 74 F_q-rational 73-isogenies from E0, pick descending ones, store kernel polys.
from sage.all import *
import json, time
m = 37
F2 = GF(2); R = PolynomialRing(F2, 'z'); z = R.gen()
modpoly = R.irreducible_element(m, algorithm='minimal_weight')
K = GF(2**m, 'z', modulus=modpoly); zz = K.gen()
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
card = E0.cardinality(); print('card', factor(card))
t0 = time.time()
isos = E0.isogenies_prime_degree(73)
print('n isogenies', len(isos), 'secs', time.time() - t0)
out = dict(m=m, modulus=str(modpoly), card=int(card), n_isog=len(isos), isog=[])
for phi in isos:
    E1 = phi.codomain(); j = E1.j_invariant()
    out['isog'].append(dict(j_int=int(j.to_integer()), j_in_F2=bool(j in [K(0), K(1)]), a_invs=[int(K(c).to_integer()) for c in E1.a_invariants()],
                            kernel_poly=[int(K(c).to_integer()) for c in phi.kernel_polynomial().list()]))
print('codomain j=1 count', sum(1 for d in out['isog'] if d['j_int'] == 1), ' distinct j', len(set(d['j_int'] for d in out['isog'])))
json.dump(out, open('toy_isogenies_m37_l73.json', 'w'))
