# RT0-7 (Bernstein-Lange precomputation) -- independent analytic recomputation.
# Run: sage -python analytic.py   (uses Sage only for exact integer checks)
import json, math, sys
sys.path.insert(0, '/Volumes/SSD990/ecdlp-hardness-work/ground_truth')
from sage.all import Integer, is_prime, Mod, factor, kronecker, pari
import ecc2k
L2 = lambda x: math.log2(x)
N, t, f, p, q = Integer(ecc2k.N), Integer(ecc2k.t), Integer(ecc2k.f), Integer(ecc2k.p), Integer(ecc2k.q)
out = {}
# --- base facts re-checked
assert q == 2**131 and 4*N == q + 1 - t and t*t - 4*q == -7*f*f and f == 263*p
assert is_prime(N) and is_prime(p)
s = Integer(ecc2k.TAU_EIGEN)
assert s*s + s + 2 == 0 or (s*s + s + 2) % N == 0
ords = Mod(s, N).multiplicative_order()
assert ords == 131
# class size: {+-s^i}: -1 in <s>?  <s> has odd order 131 -> -1 not in it
cls = 2*ords
ell = N / cls
out['class_size'] = int(cls)
out['log2_N'] = L2(float(N))
out['log2_ell'] = L2(float(ell))
rho1 = math.sqrt(math.pi*float(ell)/2)
out['rho_single_log2'] = L2(rho1)
rho_neg = math.sqrt(math.pi*float(N)/4)
out['rho_negation_only_log2'] = L2(rho_neg)
# --- proposer's S6 BL numbers (constants 1.21, 1.93 as proposer used)
S6 = {}
for c1, c2, tag in [(1.21, 1.93, 'proposer_constants'), (1.0, 1.0, 'pure_exponents')]:
    d = {}
    for lt in (20, 30, 40):
        T = 2.0**lt
        P = c1*math.sqrt(float(ell)*T); O = c2*math.sqrt(float(ell)/T)
        d[f'T2^{lt}'] = dict(precomp_log2=L2(P), online_log2=L2(O), product_over_ell=P*O/float(ell),
                             instances_to_break_even_vs_indep_rho=P/(rho1 - O))
    S6[tag] = d
out['BL_recomputed'] = S6
# --- single instance: min_T (c1 sqrt(ell T) + c2 sqrt(ell/T)) = 2 sqrt(c1 c2 ell)
def single(c1, c2):
    return 2*math.sqrt(c1*c2*float(ell))
out['single_instance_BL_min_total_log2'] = {'c1c2=1.21*1.93': L2(single(1.21, 1.93)), 'c1c2=1 (idealised floor)': L2(single(1, 1)),
                                           'rho': L2(rho1),
                                           'ratio_BLmin_over_rho_c1c2=1': single(1, 1)/rho1,
                                           'c1c2_needed_for_BL_single_to_tie_rho': (rho1/2)**2/float(ell)}
# --- M instances (e.g. one per curve, M = 263): BL with optimal T vs independent rho vs Kuhn-Struik batch rho
def ks_total(M):
    # Kuhn-Struik: sum_{i=0}^{M-1} sqrt(pi ell/2) * binom(2i,i)/4^i
    tot = 0.0; c = 1.0
    for i in range(M):
        tot += rho1*c
        c *= (2*i+1)/(2*i+2)
    return tot
M_tab = {}
for M in (1, 2, 6, 263, 2**10, 2**20):
    row = {}
    for c1, c2, tag in [(1.21, 1.93, 'BL_c=1.21,1.93'), (1.0, 1.0, 'BL_c=1,1')]:
        Topt = M*c2/c1
        row[tag + '_optT_log2'] = L2(Topt)
        row[tag + '_total_log2'] = L2(2*math.sqrt(c1*c2*M*float(ell)))
        row[tag + '_per_instance_log2'] = L2(2*math.sqrt(c1*c2*M*float(ell))/M)
    kt = ks_total(M) if M <= 2**20 else None
    row['indep_rho_total_log2'] = L2(M*rho1)
    row['kuhn_struik_total_log2'] = L2(kt)
    row['kuhn_struik_per_instance_log2'] = L2(kt/M)
    M_tab[str(M)] = row
out['M_instances'] = M_tab
# with fixed T = 2^40 how many instances until BL total beats indep rho / KS
T = 2.0**40; P = 1.21*math.sqrt(float(ell)*T); O = 1.93*math.sqrt(float(ell)/T)
out['T2^40_breakeven_vs_indep_rho_M_log2'] = L2(P/(rho1 - O))
# vs KS: KS total ~ sqrt(2 M ell) ; solve P + M O = sqrt(2 M ell)
lo, hi = 1.0, 2.0**80
for _ in range(400):
    mid = math.sqrt(lo*hi)
    if P + mid*O < math.sqrt(2*mid*float(ell)): hi = mid
    else: lo = mid
out['T2^40_breakeven_vs_KS_M_log2'] = L2(hi)
out['T2^40_table_bytes_if_24B_per_entry_log2'] = L2(24*T)
# --- B2 transport obstruction: Frobenius acts on E0[p] as scalar a = t/2 mod p; E0[p] rational over F_{q^r}, r = ord_p(a)
a = Mod(t, p)/2
assert a**2 == Mod(q, p)            # double root of x^2 - t x + q mod p
r = a.multiplicative_order()
out['B2'] = dict(a_mod_p=int(a), r=int(r), log2_r=L2(float(r)), factor_r=str(factor(r)),
                 p_minus_1_factor=str(factor(p-1)),
                 kernel_x_field_bits=int(131*r//2) if r % 2 == 0 else int(131*r),
                 note='kernel generator of any p-isogeny touching E0 lies in E0(F_{q^r}); x in F_{q^(r/2)} when -1 in <a>')
# same for 263: must be 2 (E0[263] over F_{q^2})
a263 = Mod(t, 263)/2
out['ord_263(t/2)'] = int(a263.multiplicative_order()); out['t/2 mod 263'] = int(a263)
out['kronecker(-7,p)'] = int(kronecker(-7, p))
json.dump(out, open('/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-7-1/analytic.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
