from sage.all import *
import json, time
d = json.load(open('toy_isogenies_m37_l73.json'))
R = PolynomialRing(GF(2), 'z'); K = GF(2**37, 'z', modulus=R(d['modulus'])); fi = K.from_integer
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
e1 = [e for e in d['isog'] if not e['j_in_F2']][0]
phi = E0.isogeny(PolynomialRing(K, 'X')([fi(c) for c in e1['kernel_poly']]))
t0 = time.time()
try:
    dl = phi.dual(); print('dual ok', time.time() - t0, dl.domain() == phi.codomain(), dl.codomain().j_invariant())
except Exception as ex:
    print('dual failed:', type(ex).__name__, str(ex)[:200])
