#!/bin/bash
# RT2-13-1: m=41 toy, random independent-base instances (-r). dpbits=5 (theta=1/32), r=512 steps.
cd /Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-13-1
B=./rho_mt; P=toy41_params.txt
run() { timeout 2400 $B $P "$@" >> runs/m41.jsonl; }
( run sep 1 300 5 512 101 -r; run common 2 200 5 512 102 ) &
( run common 8 100 5 512 103; run common 32 50 5 512 104; run common 128 30 5 512 105 ) &
( run distinct 2 200 5 512 106 -r; run distinct 8 100 5 512 107 -r ) &
( run distinct 32 50 5 512 108 -r ) &
( run distinct 128 30 5 512 109 -r ) &
wait
echo done >> runs/m41.done
