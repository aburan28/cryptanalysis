import time
from sage.all import GF, EllipticCurve, Integer, pari, PolynomialRing, factor
m = 37; K = GF(2**m, 'z'); z = K.gen()
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
print('modulus', K.modulus(), 'card', E0.order(), factor(E0.order()))
t0 = time.time()
phi = pari('polmodular(73, 0, Mod(1,2))')
print('polmodular deg', pari('poldegree')(phi) if False else phi.poldegree(), time.time() - t0)
R = PolynomialRing(K, 'Y')
coeffs = [K(int(c.lift())) for c in phi.Vec()][::-1]
P = R(coeffs)
rts = P.roots()
print('roots', len(rts), 'mults', sorted(set(e for r, e in rts)), time.time() - t0)
F2 = PolynomialRing(GF(2), 'Y')
print('factor mod 2 degrees', [(g.degree(), e) for g, e in F2([int(c.lift()) for c in phi.Vec()][::-1]).factor()])
t0 = time.time()
isos = E0.isogenies_prime_degree(73)
print('isogenies', len(isos), time.time() - t0)
