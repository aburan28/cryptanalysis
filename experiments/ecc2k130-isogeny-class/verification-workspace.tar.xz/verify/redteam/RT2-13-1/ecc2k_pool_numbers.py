"""RT2-13-1: multi-instance pooling numbers for the real ECC2K-130 class (plain python3).
Kuhn-Struik sequential multi-target rho: expected iterations for the (i+1)-th target after i are solved
  E_i = S1 * c_i,  c_i = binom(2i,i)/4^i,  S1 = sqrt(pi n'/2),  n' = number of {+-tau^j} classes.
Total for m targets: KS(m) = S1 * sum_{i<m} c_i  (~ sqrt(2 m n') for large m).
(The c_i model is checked empirically on toy curves by rho_mt.c in this directory.)
run: python3 ecc2k_pool_numbers.py"""
import json, math, sys
sys.path.insert(0, '/Volumes/SSD990/ecdlp-hardness-work/ground_truth')
import ecc2k
N, s = ecc2k.N, ecc2k.TAU_EIGEN
assert pow(s, 131, N) == 1 and s != 1          # ord(s) = 131 (odd prime) -> -1 not in <s> -> class size 262
cls = 2 * 131
nprime = (N - 1) / cls + 1
S1 = math.sqrt(math.pi * nprime / 2)
out = {'N': str(N), 'log2_N': math.log2(N), 'class_size': cls, 'log2_nprime': math.log2(nprime),
       'log2_S1_single_E0': math.log2(S1)}
def csum(m):
    c, tot = 1.0, 0.0
    for i in range(m):
        tot += c; c *= (2 * i + 1) / (2 * i + 2)
    return tot
rows = []
for L in [1, 2, 4, 8, 16, 64, 263, 1024, 2**14, 2**20]:
    common = S1 * csum(L)
    distinct = S1 * csum(2 * L - 1)          # base := P_1, targets Q_1, P_2, Q_2, ...
    distinct_pubG = S1 * csum(2 * L)         # every base is an extra target w.r.t. a public G
    claim = math.sqrt(L) * S1                # proposer: "about sqrt(L) * 2^60.81 in total"
    rows.append({'L': L,
        'log2_total_claim': math.log2(claim), 'log2_total_common_base': math.log2(common),
        'log2_total_distinct_bases': math.log2(distinct), 'log2_total_distinct_pubG': math.log2(distinct_pubG),
        'log2_total_separate': math.log2(L * S1),
        'log2_amortised_common': math.log2(common / L), 'log2_amortised_distinct': math.log2(distinct / L),
        'amortised_gain_bits_common': math.log2(S1) - math.log2(common / L),
        'amortised_gain_bits_distinct': math.log2(S1) - math.log2(distinct / L),
        'claimed_gain_bits_0.5log2L': 0.5 * math.log2(L),
        'log2_marginal_cost_of_last_distinct_instance': math.log2(S1 * (csum(2 * L - 1) - csum(2 * L - 3))) if L > 1 else math.log2(S1)})
out['rows'] = rows
# marginal cost of the 2nd target in a common-base pool
out['log2_second_target_common'] = math.log2(S1 * 0.5)
# asymptotics: KS(m)/sqrt(2 m n') -> 1
out['check_KS_vs_sqrt2mn_at_2^20'] = S1 * csum(2**20) / math.sqrt(2 * 2**20 * nprime)
# level-p ("B2") curves: per-curve transport cost caps amortisation (one instance per curve)
rhoM = 2 ** 63.394                    # E0 rho in F_q mults: 2^60.809 its x ~6 M (redteam-2/rt4_transport_cost.py)
Mper = rhoM / S1
b2 = {}
for name, Tc in [('RT2-01 Kani model, best case (dim2_c3, C=9)', 2 ** 50.02),
                 ('RT2-01 Kani model, dim2_c81 C=9', 2 ** 51.59),
                 ('RT2-01 Kani model, dim4 Galbraith C=1000', 2 ** 64.43),
                 ('p-levels: any kernel-polynomial method (>= 2^56 F_q ops)', 2 ** 56),
                 ('p-levels: sqrt-Velu over F_{q^(r/2)} lower bound', 2 ** 80.95)]:
    # smallest L at which the pooled amortised rho cost per instance (distinct bases) drops below Tc
    Lx = None
    for e in range(0, 64):
        L = 2 ** e
        m = 2 * L - 1
        ks = S1 * (2 * math.sqrt(m / math.pi) if m > 10**6 else csum(m))
        if ks * Mper / L <= Tc:
            Lx = L; break
    b2[name] = {'log2_Tc_Fq_mults': math.log2(Tc), 'log2_Tc_in_E0_iterations': math.log2(Tc / Mper),
                'first_power_of_2_L_where_amortised_rho_below_Tc': Lx,
                'log2_floor_on_amortised_cost_per_B2_instance_iterations': math.log2(Tc / Mper)}
out['B2_transport_floor'] = b2
out['M_per_iteration'] = Mper
json.dump(out, open('ecc2k_pool_numbers.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
