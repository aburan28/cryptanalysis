"""Convert toy_instances.json (from build_toy.py) to the plain-text params file read by rho_mt.c.
run: python3 to_params.py toy_instances.json toy37_params.txt"""
import json, sys
d = json.load(open(sys.argv[1]))
m = d['meta']['m']
with open(sys.argv[2], 'w') as fo:
    fo.write('%d %s %d %d %s %s %s %s %d\n' % (m, d['modulus_int'], d['a2'], d['a6'], d['N'], d['s'], d['Gx'], d['Gy'], len(d['instances'])))
    for r in d['instances']:
        fo.write('%s %s %s %s %s %s\n' % (r['curve'], r['k'], r['Px'], r['Py'], r['Qx'], r['Qy']))
print('wrote', sys.argv[2], len(d['instances']), 'instances')
