/* RT2-13-1: multi-target Pollard rho on a toy Koblitz curve E0: y^2+xy = x^3+a2 x^2+a6 over F_{2^M}
 * (M <= 63), with the negation map and the Frobenius tau (class {+-tau^j P} of size 2M), distinguished
 * points and the Kuhn-Struik sequential multi-target strategy.
 *
 * Modes (per trial, L instances):
 *   sep      : every instance (P_i, Q_i = k_i P_i) solved on its own (fresh table, base P_i)  -> L single rhos
 *   common   : L targets T_i = x_i G with ONE common base G, solved in one pool (Kuhn-Struik)
 *   distinct : L instances with INDEPENDENT bases P_i, pooled: base := P_1, targets Q_1,P_2,Q_2,...,P_L,Q_L
 *              (2L-1 targets), then k_i = log(Q_i)/log(P_i).  This is what "transport everything to E0 and
 *              run one multi-target rho" has to do when the class curves carry their own base points.
 * Instances for sep/distinct come from a file of transported floor-curve instances (one per distinct
 * floor curve, chosen at random each trial) or, with -r, are generated at random on E0.
 *
 * The cost metric is the number of walk iterations (one E0 addition + class canonicalisation each).
 * Every solved logarithm is verified by scalar multiplication; every k_i is compared with the planted k.
 *
 * build: clang -O2 -mcpu=apple-m1 -o rho_mt rho_mt.c -lm
 * usage: rho_mt params.txt mode L trials dpbits r seed [-r]
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <arm_neon.h>

typedef uint64_t fe;
typedef unsigned __int128 u128;
static int M; static fe MODLOW, MASK, A2, A6;
static uint64_t N, S; static uint64_t spow[64];

static inline u128 clmul(uint64_t a, uint64_t b) { return (u128)vmull_p64((poly64_t)a, (poly64_t)b); }
static inline fe fmul(fe a, fe b) {
    u128 p = clmul(a, b);
    while ((p >> M) != 0) { uint64_t hi = (uint64_t)(p >> M); p = (p & MASK) ^ clmul(hi, MODLOW); }
    return (fe)p;
}
static inline fe fsqr(fe a) { return fmul(a, a); }
static fe fsqrn(fe a, int n) { while (n--) a = fsqr(a); return a; }
static fe finv(fe a) {            /* Itoh-Tsujii: a^(2^M-2) = (a^(2^(M-1)-1))^2 */
    int n = M - 1; int top = 63 - __builtin_clzll((uint64_t)n);
    fe b = a; int k = 1;
    for (int i = top - 1; i >= 0; i--) {
        b = fmul(fsqrn(b, k), b); k *= 2;
        if ((n >> i) & 1) { b = fmul(fsqr(b), a); k += 1; }
    }
    return fsqr(b);
}
/* mod N arithmetic */
static inline uint64_t addN(uint64_t a, uint64_t b) { u128 s = (u128)a + b; return (uint64_t)(s % N); }
static inline uint64_t subN(uint64_t a, uint64_t b) { return a >= b ? a - b : a + (N - b); }
static inline uint64_t mulN(uint64_t a, uint64_t b) { return (uint64_t)(((u128)a * b) % N); }
static uint64_t powN(uint64_t a, uint64_t e) { uint64_t r = 1; while (e) { if (e & 1) r = mulN(r, a); a = mulN(a, a); e >>= 1; } return r; }
static uint64_t invN(uint64_t a) { return powN(a, N - 2); }   /* N prime */

typedef struct { fe x, y; int inf; } pt;
static const pt PINF = {0, 0, 1};
static int oncurve(pt P) {
    if (P.inf) return 1;
    fe l = fsqr(P.y) ^ fmul(P.x, P.y);
    fe x2 = fsqr(P.x);
    fe r = fmul(x2, P.x) ^ fmul(A2, x2) ^ A6;
    return l == r;
}
static pt pdbl(pt P) {
    if (P.inf || P.x == 0) return PINF;
    fe lam = P.x ^ fmul(P.y, finv(P.x));
    pt R; R.inf = 0;
    R.x = fsqr(lam) ^ lam ^ A2;
    R.y = fsqr(P.x) ^ fmul(lam ^ 1, R.x);
    return R;
}
static pt padd(pt P, pt Q) {
    if (P.inf) return Q; if (Q.inf) return P;
    if (P.x == Q.x) { if (P.y == Q.y) return pdbl(P); return PINF; }
    fe lam = fmul(P.y ^ Q.y, finv(P.x ^ Q.x));
    pt R; R.inf = 0;
    R.x = fsqr(lam) ^ lam ^ P.x ^ Q.x ^ A2;
    R.y = fmul(lam, P.x ^ R.x) ^ R.x ^ P.y;
    return R;
}
static pt pmul(uint64_t k, pt P) {
    pt R = PINF;
    for (int i = 63 - __builtin_clzll(k | 1); i >= 0; i--) { R = pdbl(R); if ((k >> i) & 1) R = padd(R, P); }
    return R;
}
static int peq(pt P, pt Q) { return P.inf == Q.inf && (P.inf || (P.x == Q.x && P.y == Q.y)); }

/* class representative of {+-tau^j P}: minimal x among x^(2^j), then minimal y among {y, y+x}.
   Returns mu with rep = mu * P on the order-N subgroup (tau acts as s). */
static inline pt canon(pt P, uint64_t *mu) {
    fe bx = P.x, cx = P.x; int bj = 0;
    for (int j = 1; j < M; j++) { cx = fsqr(cx); if (cx < bx) { bx = cx; bj = j; } }
    fe by = fsqrn(P.y, bj);
    int neg = 0; fe ny = by ^ bx; if (ny < by) { by = ny; neg = 1; }
    pt R = {bx, by, 0};
    *mu = neg ? (N - spow[bj]) % N : spow[bj];
    return R;
}

static uint64_t rng_state;
static inline uint64_t mix64(uint64_t z) {
    z += 0x9e3779b97f4a7c15ULL; z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL; return z ^ (z >> 31);
}
static inline uint64_t rnd64(void) { rng_state += 0x9e3779b97f4a7c15ULL; return mix64(rng_state); }
static uint64_t rndN(void) { uint64_t v; do { v = rnd64() % N; } while (v == 0); return v; }

/* ---------------- DP table ---------------- */
typedef struct { uint64_t key; int tgt; uint64_t a, b; } ent;
#define TBITS 22
static ent *tab; static uint32_t *used; static size_t nused;
static void tab_clear(void) { for (size_t i = 0; i < nused; i++) tab[used[i]].key = 0; nused = 0; }
static ent *tab_find(uint64_t key, int *found) {
    size_t mask = ((size_t)1 << TBITS) - 1, i = mix64(key) & mask;
    while (tab[i].key && tab[i].key != key) i = (i + 1) & mask;
    *found = tab[i].key != 0;
    if (!*found) { if (nused >= (mask >> 1)) { fprintf(stderr, "table full\n"); exit(2); } used[nused++] = (uint32_t)i; }
    return &tab[i];
}

/* ---------------- one pooled multi-target run ---------------- */
static int R_STEPS, DPBITS; static uint64_t walkkey, dpkey;
static pt *Rpt; static uint64_t *Rc;
static long long n_aborts, n_useless, n_escapes, n_verify_fail, n_useless_diff_a, n_useless_same_walk, n_walks, n_dp_new;

/* Solve logs of targets T[0..m-1] w.r.t. base B, sequentially (Kuhn-Struik).  its[i] = iterations
   spent on target i.  Returns logs in xs[]. */
static void pooled(pt B, pt *T, int m, uint64_t *xs, long long *its) {
    for (int h = 0; h < R_STEPS; h++) { Rc[h] = rndN(); Rpt[h] = pmul(Rc[h], B); }
    walkkey = rnd64(); dpkey = rnd64();
    tab_clear();
    long long maxlen = 40LL << DPBITS;
    /* cheap walk starts: an accumulator Sacc = sacc*B advanced by one random table step per new walk */
    uint64_t sacc = rndN(); pt Sacc = pmul(sacc, B);
    for (int i = 0; i < m; i++) {
        long long it = 0; int solved = 0;
        while (!solved) {
            int hs = (int)(rnd64() % (uint64_t)R_STEPS);
            Sacc = padd(Sacc, Rpt[hs]); sacc = addN(sacc, Rc[hs]);
            if (Sacc.inf) { sacc = rndN(); Sacc = pmul(sacc, B); continue; }
            uint64_t a = sacc, b = 1, mu;
            pt W = padd(Sacc, T[i]);
            if (W.inf) continue;
            W = canon(W, &mu); a = mulN(a, mu); b = mulN(b, mu);
            pt Wp = PINF; uint64_t ap = 0, bp = 0;
            long long len = 0;
            for (;;) {
                if ((mix64(W.x ^ dpkey) >> (64 - DPBITS)) == 0 && len > 0) break;   /* distinguished */
                if (len > maxlen) { n_aborts++; W.inf = 1; break; }
                int h = (int)(mix64(W.x ^ walkkey) % (uint64_t)R_STEPS);
                pt Z = padd(W, Rpt[h]);
                if (Z.inf) { n_aborts++; W.inf = 1; break; }
                uint64_t az = addN(a, Rc[h]), bz = b;
                Z = canon(Z, &mu); az = mulN(az, mu); bz = mulN(bz, mu);
                it++; len++;
                if (!Wp.inf && Z.x == Wp.x) {            /* fruitless 2-cycle {Wp, W}: escape by doubling min */
                    pt E; uint64_t ae, be;
                    if (Wp.x < W.x) { E = Wp; ae = ap; be = bp; } else { E = W; ae = a; be = b; }
                    Z = pdbl(E); az = addN(ae, ae); bz = addN(be, be);
                    if (Z.inf) { n_aborts++; W.inf = 1; break; }
                    Z = canon(Z, &mu); az = mulN(az, mu); bz = mulN(bz, mu);
                    it++; len++; n_escapes++;
                }
                Wp = W; ap = a; bp = b; W = Z; a = az; b = bz;
            }
            if (W.inf) continue;
            n_walks++;
            int found; ent *e = tab_find(W.x, &found);
            if (!found) { n_dp_new++; e->key = W.x; e->tgt = i; e->a = a; e->b = b; continue; }
            /* collision: a + b x_i = e->a + e->b x_j */
            uint64_t xi;
            if (e->tgt == i) {
                if (e->b == b) { n_useless++; if (e->a != a) n_useless_diff_a++; else n_useless_same_walk++; continue; }
                xi = mulN(subN(e->a, a), invN(subN(b, e->b)));
            } else {
                uint64_t xj = xs[e->tgt];
                xi = mulN(subN(addN(e->a, mulN(e->b, xj)), a), invN(b));
            }
            if (!peq(pmul(xi, B), T[i])) { n_verify_fail++; continue; }
            xs[i] = xi; solved = 1;
        }
        its[i] = it;
    }
}

/* ---------------- main ---------------- */
typedef struct { char curve[8]; uint64_t k; pt P, Q; } inst;
int main(int argc, char **argv) {
    if (argc < 8) { fprintf(stderr, "usage: %s params mode L trials dpbits r seed [-r]\n", argv[0]); return 1; }
    FILE *fp = fopen(argv[1], "r"); if (!fp) { perror("params"); return 1; }
    const char *mode = argv[2]; int L = atoi(argv[3]), trials = atoi(argv[4]);
    DPBITS = atoi(argv[5]); R_STEPS = atoi(argv[6]); rng_state = strtoull(argv[7], 0, 10);
    int randinst = (argc > 8 && !strcmp(argv[8], "-r"));
    unsigned long long modint, gx, gy, a2, a6; int ninst;
    if (fscanf(fp, "%d %llu %llu %llu %llu %llu %llu %llu %d", &M, &modint, &a2, &a6,
               (unsigned long long *)&N, (unsigned long long *)&S, &gx, &gy, &ninst) != 9) { fprintf(stderr, "bad params\n"); return 1; }
    MASK = (M == 64) ? ~0ULL : ((1ULL << M) - 1); MODLOW = modint & MASK; A2 = a2; A6 = a6;
    spow[0] = 1; for (int j = 1; j < M; j++) spow[j] = mulN(spow[j - 1], S);
    pt G = {gx, gy, 0};
    if (!oncurve(G) || !pmul(N, G).inf) { fprintf(stderr, "G check failed\n"); return 1; }
    { pt tg = {fsqr(G.x), fsqr(G.y), 0}; if (!peq(tg, pmul(S, G))) { fprintf(stderr, "tau eigen check failed\n"); return 1; } }
    inst *I = calloc(ninst > 0 ? ninst : 1, sizeof(inst));
    for (int i = 0; i < ninst; i++) {
        unsigned long long k, px, py, qx, qy;
        if (fscanf(fp, "%7s %llu %llu %llu %llu %llu", I[i].curve, &k, &px, &py, &qx, &qy) != 6) { fprintf(stderr, "bad inst\n"); return 1; }
        I[i].k = k; I[i].P = (pt){px, py, 0}; I[i].Q = (pt){qx, qy, 0};
        if (!oncurve(I[i].P) || !oncurve(I[i].Q) || !peq(pmul(k, I[i].P), I[i].Q) || !pmul(N, I[i].P).inf) { fprintf(stderr, "inst %d bad\n", i); return 1; }
    }
    fclose(fp);
    tab = calloc((size_t)1 << TBITS, sizeof(ent)); used = calloc((size_t)1 << TBITS, sizeof(uint32_t));
    Rpt = calloc(R_STEPS, sizeof(pt)); Rc = calloc(R_STEPS, sizeof(uint64_t));
    int maxT = 2 * L; pt *T = calloc(maxT, sizeof(pt)); uint64_t *xs = calloc(maxT, sizeof(uint64_t));
    long long *its = calloc(maxT, sizeof(long long));
    double *pos_sum = calloc(maxT, sizeof(double));
    /* distinct curves available in file */
    int *curve_first = calloc(ninst + 1, sizeof(int)), ncurves = 0;
    for (int i = 0; i < ninst; i++) if (i == 0 || strcmp(I[i].curve, I[i - 1].curve)) curve_first[ncurves++] = i;
    curve_first[ncurves] = ninst;
    if (!randinst && strcmp(mode, "common") && L > ncurves) { fprintf(stderr, "L > #curves in file\n"); return 1; }
    double sum = 0, sum2 = 0; long long k_ok = 0, k_tot = 0;
    int *perm = calloc(ncurves > 0 ? ncurves : 1, sizeof(int));
    for (int tr = 0; tr < trials; tr++) {
        /* pick L instances on L distinct curves (or random ones) */
        inst *sel = calloc(L, sizeof(inst));
        if (strcmp(mode, "common")) {
            if (randinst) {
                for (int i = 0; i < L; i++) { uint64_t u = rndN(), k = rndN(); sel[i].k = k; sel[i].P = pmul(u, G); sel[i].Q = pmul(k, sel[i].P); strcpy(sel[i].curve, "rand"); }
            } else {
                for (int c = 0; c < ncurves; c++) perm[c] = c;
                for (int c = ncurves - 1; c > 0; c--) { int d = (int)(rnd64() % (uint64_t)(c + 1)); int t = perm[c]; perm[c] = perm[d]; perm[d] = t; }
                for (int i = 0; i < L; i++) { int c = perm[i]; int lo = curve_first[c], hi = curve_first[c + 1];
                    sel[i] = I[lo + (int)(rnd64() % (uint64_t)(hi - lo))]; }
            }
        }
        long long total = 0; int m = 0;
        if (!strcmp(mode, "sep")) {
            for (int i = 0; i < L; i++) {
                T[0] = sel[i].Q; pooled(sel[i].P, T, 1, xs, its); total += its[0]; pos_sum[i] += its[0];
                k_tot++; k_ok += (xs[0] == sel[i].k);
            }
        } else if (!strcmp(mode, "common")) {
            uint64_t *truth = calloc(L, sizeof(uint64_t));
            for (int i = 0; i < L; i++) { truth[i] = rndN(); T[i] = pmul(truth[i], G); }
            pooled(G, T, L, xs, its); m = L;
            for (int i = 0; i < L; i++) { total += its[i]; pos_sum[i] += its[i]; k_tot++; k_ok += (xs[i] == truth[i]); }
            free(truth);
        } else if (!strcmp(mode, "distinct")) {
            pt B = sel[0].P; T[m++] = sel[0].Q;
            for (int i = 1; i < L; i++) { T[m++] = sel[i].P; T[m++] = sel[i].Q; }
            pooled(B, T, m, xs, its);
            for (int i = 0; i < m; i++) { total += its[i]; pos_sum[i] += its[i]; }
            k_tot++; k_ok += (xs[0] == sel[0].k);
            for (int i = 1; i < L; i++) { uint64_t kp = mulN(xs[2 * i], invN(xs[2 * i - 1])); k_tot++; k_ok += (kp == sel[i].k); }
        } else { fprintf(stderr, "bad mode\n"); return 1; }
        sum += (double)total; sum2 += (double)total * total;
        free(sel);
    }
    double mean = sum / trials, sd = sqrt(fmax(0, sum2 / trials - mean * mean)), se = sd / sqrt((double)trials);
    int ntgt = !strcmp(mode, "sep") ? L : (!strcmp(mode, "common") ? L : 2 * L - 1);
    printf("{\"mode\":\"%s\",\"L\":%d,\"targets\":%d,\"trials\":%d,\"dpbits\":%d,\"r\":%d,\"randinst\":%d,"
           "\"mean_total_its\":%.1f,\"se\":%.1f,\"k_ok\":%lld,\"k_tot\":%lld,\"aborts\":%lld,\"useless\":%lld,"
           "\"escapes\":%lld,\"verify_fail\":%lld,\"useless_diff_a\":%lld,\"useless_same\":%lld,\"walks\":%lld,\"dp_new\":%lld,\"per_position_mean\":[",
           mode, L, ntgt, trials, DPBITS, R_STEPS, randinst, mean, se, k_ok, k_tot, n_aborts, n_useless, n_escapes, n_verify_fail, n_useless_diff_a, n_useless_same_walk, n_walks, n_dp_new);
    int np = !strcmp(mode, "sep") ? L : ntgt;
    for (int i = 0; i < np; i++) printf("%s%.1f", i ? "," : "", pos_sum[i] / trials);
    printf("]}\n");
    return 0;
}
