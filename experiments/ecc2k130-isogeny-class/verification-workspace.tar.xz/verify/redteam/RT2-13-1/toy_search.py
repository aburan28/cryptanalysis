"""RT2-13-1: search toy Koblitz analogues of ECC2K-130: y^2+xy=x^3+1 over F_{2^m}, m prime,
#E0 = 4*N with N prime, and a small odd prime l | f (t^2-4q=-7f^2), l not dividing #E0.
Prints (l, kronecker(-7,l), k=ord(t/2 mod l)).  run: sage -python toy_search.py"""
from sage.all import Integer, factor, kronecker, prime_range, log, Mod, is_prime
for m in prime_range(23, 70):
    t1 = -1
    tt = [Integer(2), Integer(t1)]
    for _ in range(2, m + 1):
        tt.append(t1 * tt[-1] - 2 * tt[-2])
    t = tt[m]; q = Integer(2) ** m; card = q + 1 - t
    if card % 4 or not is_prime(card // 4):
        continue
    N = card // 4
    D = t * t - 4 * q; f = (-D // 7).isqrt(); assert 7 * f * f == -D
    cand = []
    for l in prime_range(3, 400):
        if f % l == 0 and card % l != 0:
            c = Mod(t, l) / 2
            cand.append((l, kronecker(-7, l), c.multiplicative_order()))
    print(m, 'log2N=%.2f' % float(log(N, 2)), 'f =', factor(f), '| (l,kron,k)', cand, flush=True)
