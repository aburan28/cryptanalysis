"""E0-only params for a larger toy: y^2+xy=x^3+1 over F_{2^41} (#E0 = 4N, N prime).  No instances in the
file (rho_mt -r generates random independent-base instances).  run: sage -python params41.py"""
from sage.all import GF, EllipticCurve, Integer, pari, set_random_seed, Integer
set_random_seed(41)
m = 41; K = GF(2**m, 'z'); E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
card = E0.order(); N = card // 4; assert card == 4 * N and N.is_prime(proof=True)
while True:
    G = 4 * E0.random_point()
    if not G.is_zero(): break
roots = [Integer(r) for r in pari('polrootsmod(x^2+x+2, %d)' % N)]
s = [r for r in roots if E0(G[0]**2, G[1]**2) == r * G]; assert len(s) == 1; s = s[0]
modint = sum(int(c) << i for i, c in enumerate(K.modulus().list()))
open('toy41_params.txt', 'w').write('%d %d 0 1 %d %d %d %d 0\n' % (m, modint, N, s, G[0].to_integer(), G[1].to_integer()))
print('m', m, 'modulus', K.modulus(), 'N', N, 'log2N %.3f' % float(N.log(2)), 's', s, 'ord s', pari('znorder(Mod(%d,%d))' % (s, N)))
