#!/bin/bash
# RT2-13-1: m=37 toy with instances TRANSPORTED from the 74 floor curves of the 73-volcano (toy37_params.txt).
# dpbits=3 (theta=1/8), r=256.  distinct: L instances on L distinct floor curves, each with its own base.
cd /Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-13-1
B=./rho_mt; P=toy37_params.txt
run() { timeout 2400 $B $P "$@" >> runs/m37.jsonl; }
( run sep 1 1000 3 256 201; run sep 8 100 3 256 202 ) &
( run common 8 300 3 256 203; run common 32 150 3 256 204; run common 74 100 3 256 205 ) &
( run distinct 8 300 3 256 206; run distinct 32 150 3 256 207 ) &
( run distinct 74 100 3 256 208 ) &
wait
echo done >> runs/m37.done
