"""RT2-13-1: wider toy search. Koblitz y^2+xy=x^3+a x^2+1 over F_{2^m}, m prime; N = largest prime
factor of #E0 (26..46 bits); odd prime l | f, l not | #E0, l < 3000; k = ord(t/2 mod l).
run: sage -python toy_search2.py"""
from sage.all import Integer, factor, kronecker, prime_range, log, Mod
for m in prime_range(23, 100):
    for a in (0, 1):
        t1 = -1 if a == 0 else 1
        tt = [Integer(2), Integer(t1)]
        for _ in range(2, m + 1):
            tt.append(t1 * tt[-1] - 2 * tt[-2])
        t = tt[m]; q = Integer(2) ** m; card = q + 1 - t
        fac = factor(card); N = max(pp for pp, e in fac)
        lg = float(log(N, 2))
        if not (26 <= lg <= 46):
            continue
        D = t * t - 4 * q; f = (-D // 7).isqrt(); assert 7 * f * f == -D
        cand = []
        for l in prime_range(3, 3000):
            if f % l == 0 and card % l != 0:
                c = Mod(t, l) / 2
                cand.append((l, kronecker(-7, l), c.multiplicative_order()))
        print(m, a, 'log2N=%.2f' % lg, 'cof', card // N, 'f =', factor(f), '| (l,kron,k)', cand, flush=True)
