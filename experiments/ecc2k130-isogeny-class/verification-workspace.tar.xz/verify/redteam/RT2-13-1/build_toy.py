"""RT2-13-1 toy pipeline, part 1 (Sage).
Toy analogue of the ECC2K-130 class: E0: y^2+xy=x^3+1 over F_{2^37} (#E0 = 4*149*N, N = 230603167 prime),
t^2-4q = -7 f^2 with f = 73*2663; 73 is inert in Q(sqrt-7), so the 73-volcano has E0 on the crater and
74 floor curves (two Frobenius orbits of 37).  For each floor orbit we compute ONE F_q-rational ascending
73-isogeny psi0: X0 -> E0 and transport any floor curve X_k via T_k = tau^k o psi0 o sigma^{-k}.
(v2: transport = inverse of the descending isogeny on F_q-points, see below.)
We then plant random DLP instances (P, Q=kP) with INDEPENDENT random base points on every floor curve,
transport them to E0 and check Q' = k P'.  Output: toy_instances.json (for rho_mt.c).
run: sage -python build_toy.py"""
import json, time, random
from sage.all import GF, EllipticCurve, Integer, pari, PolynomialRing, Mod, set_random_seed
set_random_seed(20260924); random.seed(20260924)
m = 37; K = GF(2**m, 'z'); z = K.gen()
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
card = E0.order(); N = Integer(230603167); cof = card // N
assert card == 4 * 149 * N and N.is_prime(proof=True)
t = 2**m + 1 - card
f2 = -(t * t - 2**(m + 2)) // 7; f = f2.isqrt(); assert f * f == f2 and f == 73 * 2663
log = {'m': m, 'modulus': str(K.modulus()), 'card': str(card), 'N': str(N), 't': str(t), 'f': str(f)}
def rnd_N(E):
    while True:
        P = cof * E.random_point()
        if not P.is_zero():
            assert (N * P).is_zero(); return P
G = rnd_N(E0)
tau = lambda P: P.curve()(P[0]**2, P[1]**2)
# tau eigenvalue on the N-subgroup: root of s^2 + s + 2 (tau^2 - t1 tau + 2 with t1 = -1)
roots = [Integer(r) for r in pari('polrootsmod(x^2+x+2, %d)' % N)]
s = [r for r in roots if tau(G) == r * G]; assert len(s) == 1; s = s[0]
assert Mod(s, N).multiplicative_order() == m   # s^m = 1 (pi = tau^m is 1 on E(F_q)); -1 not in <s> (odd order) so class {+-s^j} has 2m elements
log['tau_eigen_s'] = str(s); log["ord_s_modN"] = m
# floor j-invariants: roots of Phi_73(1,Y) mod 2 in F_q
ph = pari('polmodular(73, 0, Mod(1,2))')
R = PolynomialRing(GF(2), 'Y'); Pm = R([int(c.lift()) for c in ph.Vec()][::-1])
facs = [g for g, e in Pm.factor()]; assert [g.degree() for g in facs] == [37, 37]
orbits = {}
for name, g in zip('AB', facs):
    r0 = min((r for r, e in g.change_ring(K).roots()), key=lambda u: u.to_integer())
    orbits[name] = [r0**(2**k) for k in range(m)]
    assert len(set(orbits[name])) == m
alljs = orbits['A'] + orbits['B']; assert len(set(alljs)) == 74 and K(1) not in alljs
# All 74 descending 73-isogenies phi_i: E0 -> E_i (F_q-rational kernels).  Transport E_i -> E0 is the
# inverse of phi_i on F_q-points: ker(phi_i) has no nontrivial F_q-point (73 does not divide #E0(F_q)), so
# phi_i: E0(F_q) -> E_i(F_q) is an injective homomorphism between groups of equal order, hence bijective.
# Inverting it = finding the unique F_q-root of num(x) - x_X den(x) (degree 73) -- no dual isogeny needed
# (Sage has no char-2 dual).  (Sage's isogenies_prime_degree on a floor curve overflowed PARI's stack.)
t0 = time.time(); isos = E0.isogenies_prime_degree(73); dt = time.time() - t0
assert len(isos) == 74
log['descending_isogenies_seconds'] = round(dt, 1)
print('74 descending isogenies in %.1f s' % dt, flush=True)
Rx = PolynomialRing(K, 'X')
def make_transport(phi):
    fx = phi.rational_maps()[0]
    num, den = Rx(fx.numerator().univariate_polynomial()), Rx(fx.denominator().univariate_polynomial())
    def T(Pt):
        cands = []
        for x0, e in (num - Pt[0] * den).roots():
            for y0, e2 in PolynomialRing(K, 'Y')([x0**3 + 1, x0, 1]).roots():   # y^2 + x0 y + (x0^3+1) = 0
                X = E0(x0, y0)
                if phi(X) == Pt: cands.append(X)
        assert len(cands) == 1, len(cands)
        return cands[0]
    return T
jlab = {}
for name in 'AB':
    for k, jj in enumerate(orbits[name]): jlab[jj] = '%s%02d' % (name, k)
inst = []; checks = {'hom_ok': 0, 'dlp_ok': 0, 'tau_ok': 0, 'no_tau_on_floor': 0, 'order_ok': 0, 'card_ok': 0, 'j_in_floor_set': 0}
per_curve = 8
t0 = time.time()
seen = set()
for phi in sorted(isos, key=lambda ph: jlab.get(ph.codomain().j_invariant(), 'Z')):
    Ei = phi.codomain(); jj = Ei.j_invariant()
    checks['j_in_floor_set'] += (jj in jlab); seen.add(jj)
    checks['card_ok'] += (Ei.order() == card)
    if jj**2 != jj: checks['no_tau_on_floor'] += 1          # E_i not defined over F_2: no tau endomorphism
    T = make_transport(phi)
    A_, B_ = rnd_N(Ei), rnd_N(Ei)
    if T(A_ + B_) == T(A_) + T(B_): checks['hom_ok'] += 1
    for r in range(per_curve):
        P = rnd_N(Ei); kk = Integer(random.randrange(1, N)); Q = kk * P
        Pp, Qp = T(P), T(Q)
        ok = (not Pp.is_zero()) and (N * Pp).is_zero()
        checks['order_ok'] += ok
        checks['dlp_ok'] += (Qp == kk * Pp)
        checks['tau_ok'] += (tau(Pp) == s * Pp)
        inst.append({'curve': jlab[jj], 'k': str(kk),
                     'Px': str(Pp[0].to_integer()), 'Py': str(Pp[1].to_integer()),
                     'Qx': str(Qp[0].to_integer()), 'Qy': str(Qp[1].to_integer())})
assert len(seen) == 74
log['transport_seconds_total'] = round(time.time() - t0, 1)
log['checks'] = checks; log['n_instances'] = len(inst)
print(json.dumps(log, indent=1))
assert checks['hom_ok'] == 74 and checks['no_tau_on_floor'] == 74 and checks['card_ok'] == 74 and checks['j_in_floor_set'] == 74
assert checks['dlp_ok'] == checks['order_ok'] == checks['tau_ok'] == len(inst) == 74 * per_curve
modint = sum(int(c) << i for i, c in enumerate(K.modulus().list()))
json.dump({'meta': log, 'modulus_int': str(modint), 'a2': 0, 'a6': 1, 'N': str(N), 's': str(s),
           'Gx': str(G[0].to_integer()), 'Gy': str(G[1].to_integer()), 'instances': inst},
          open('toy_instances.json', 'w'), indent=0)
print('wrote toy_instances.json')
