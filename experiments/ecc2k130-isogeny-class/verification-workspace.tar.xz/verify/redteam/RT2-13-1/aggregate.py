"""RT2-13-1: compare measured multi-target rho costs (runs/*.jsonl from rho_mt.c) with the Kuhn-Struik model
  E[total for m targets] = S1 * sum_{i<m} binom(2i,i)/4^i + m * 2^dpbits,  S1 = sqrt(pi n'/2), n' = (N-1)/(2M)+1.
Also reports the measured amortised gain in bits vs separate single-instance solving.
run: python3 aggregate.py"""
import json, math, glob
P = {'m41': dict(M=41, N=549756390943), 'm37': dict(M=37, N=230603167)}
def csum(m):
    c, t = 1.0, 0.0
    for i in range(m):
        t += c; c *= (2 * i + 1) / (2 * i + 2)
    return t
def cvals(m):
    c, out = 1.0, []
    for i in range(m):
        out.append(c); c *= (2 * i + 1) / (2 * i + 2)
    return out
res = {}
for tag, prm in P.items():
    f = 'runs/%s.jsonl' % tag
    try: rows = [json.loads(l) for l in open(f) if l.strip()]
    except FileNotFoundError: continue
    npr = (prm['N'] - 1) / (2 * prm['M']) + 1
    S1 = math.sqrt(math.pi * npr / 2)
    sep = [r for r in rows if r['mode'] == 'sep' and r['L'] == 1]
    single = sep[0]['mean_total_its'] if sep else None
    out = {'S1_model': S1, 'single_measured': single, 'rows': []}
    for r in sorted(rows, key=lambda r: (r['mode'], r['L'])):
        m = r['targets']; ov = 2 ** r['dpbits']
        pred = S1 * csum(m) + m * ov if r['mode'] != 'sep' else r['L'] * (S1 + ov)
        # points sampled = walk iterations + walk starts (each start is a fresh random point, 2 group ops)
        pts = r['mean_total_its'] + r['walks'] / r['trials']
        pos_pred = [S1 * c + ov for c in cvals(m)]
        pos = r['per_position_mean']
        # per-position check on the first 4 positions and the tail mean
        tail = max(1, m // 4)
        row = {'mode': r['mode'], 'L': r['L'], 'targets': m, 'trials': r['trials'],
               'measured_total': r['mean_total_its'], 'se': r['se'], 'KS_pred_total': round(pred, 1),
               'measured/pred': round(r['mean_total_its'] / pred, 4),
               'walk_starts_per_trial': round(r['walks'] / r['trials'], 1),
               'points_incl_starts/pred': round(pts / pred, 4),
               'z': round((r['mean_total_its'] - pred) / r['se'], 2) if r['se'] > 0 else None,
               'pos_first4_meas': [round(x) for x in pos[:4]], 'pos_first4_pred': [round(x) for x in pos_pred[:4]],
               'pos_last_quarter_meas_mean': round(sum(pos[-tail:]) / tail, 1) if r['mode'] != 'sep' else None,
               'pos_last_quarter_pred_mean': round(sum(pos_pred[-tail:]) / tail, 1) if r['mode'] != 'sep' else None,
               'k_ok': '%d/%d' % (r['k_ok'], r['k_tot']), 'verify_fail': r['verify_fail'], 'aborts': r['aborts'],
               'useless_dup_walks': r['useless']}
        if single and r['mode'] != 'sep':
            row['measured_amortised_gain_bits_vs_single'] = round(math.log2(single) - math.log2(r['mean_total_its'] / r['L']), 3)
            row['claimed_gain_bits_0.5log2L'] = round(0.5 * math.log2(r['L']), 3)
            row['KS_model_gain_bits'] = round(math.log2(S1 + ov) - math.log2(pred / r['L']), 3)
        out['rows'].append(row)
    res[tag] = out
json.dump(res, open('aggregate.json', 'w'), indent=1)
for tag, out in res.items():
    print('==', tag, 'S1_model %.1f single_measured %s' % (out['S1_model'], out['single_measured']))
    for row in out['rows']:
        print(' %-8s L=%-4d tg=%-4d n=%-4d meas=%10.1f +-%8.1f pred=%10.1f ratio=%.3f pts_ratio=%.3f z=%5s gain=%s (claim %s, KS %s) k_ok=%s vf=%d'
              % (row['mode'], row['L'], row['targets'], row['trials'], row['measured_total'], row['se'], row['KS_pred_total'],
                 row['measured/pred'], row['points_incl_starts/pred'], row['z'], row.get('measured_amortised_gain_bits_vs_single'), row.get('claimed_gain_bits_0.5log2L'),
                 row.get('KS_model_gain_bits'), row['k_ok'], row['verify_fail']))
