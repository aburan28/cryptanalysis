"""RT0-8 end-to-end twist attack against a NON-validating x-only ladder oracle, on the real curves.

Run:  export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
      sage -python s2_e2e.py

The only shortcut: the secret k is PLANTED with (k mod P114) < 2^32 so the P114-part DLP can be
finished by an interval BSGS (2^17 group ops) instead of the ~2^53.27-iteration tau'-rho the real
attack would need. Everything else (the oracle, the x-only outputs, sign ambiguities, the E0'
structure, the transport through the 263-isogeny, CRT, the final check against the public key) is
done for real. We never touch the ECC2K-130 challenge key.

Part 1: implementation on E0   (b = 1)       -> twist E0'   = Z/(2*263*P114) x Z/263
Part 2: implementation on A000 (b = b_A000)  -> twist A000' = Z/(2*263^2*P114) (cyclic);
        P114 part transported to E0' by the F_q-rational 263-isogeny, tau' checked on the image.
"""
import json, math, sys, time, random, itertools
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import EllipticCurve, Integer, crt, lcm, set_random_seed, discrete_log
from sage.groups.generic import bsgs

set_random_seed(8120924)
random.seed(8120924)
t0 = time.time()
q, t, N = ecc2k.q, ecc2k.t, ecc2k.N
T = q + 1 + t
P114 = T // (2 * 263 ** 2)
LAM = 11620273277080081443521875815673184      # tau' eigenvalue on E0'[P114] (s1_structure.json C)
K, curves = ecc2k.load(["E0", "A000"])
E0t = EllipticCurve(K, [1, 1, 0, 0, 1])
PLANT = 2 ** 32
out = {}


def ladder(xP, k, b):
    """Lopez-Dahab projective x-only ladder, uses only b (never a2). None = point at infinity."""
    k = int(k)
    if k == 0:
        return None
    X1, Z1 = xP, K(1)
    X2, Z2 = xP ** 4 + b, xP ** 2
    for i in range(k.bit_length() - 2, -1, -1):
        Zs = (X1 * Z2 + X2 * Z1) ** 2
        if (k >> i) & 1:
            X1, Z1 = xP * Zs + (X1 * Z2) * (X2 * Z1), Zs
            X2, Z2 = X2 ** 4 + b * Z2 ** 4, X2 ** 2 * Z2 ** 2
        else:
            X2, Z2 = xP * Zs + (X1 * Z2) * (X2 * Z1), Zs
            X1, Z1 = X1 ** 4 + b * Z1 ** 4, X1 ** 2 * Z1 ** 2
    return None if Z1 == 0 else X1 / Z1


def make_oracle(b, k):
    calls = [0]

    def oracle(x):
        calls[0] += 1
        return ladder(x, k, b)       # NO check that x lies on y^2+xy=x^3+b
    return oracle, calls


def xof(P):
    return None if P.is_zero() else P[0]


def small_log_pm(R, ans, n):
    """all j in [0,n) with x([j]R) == ans (x-only => j and n-j)."""
    sols, Z = [], R.curve()(0)
    for j in range(n):
        if xof(Z) == ans:
            sols.append(j)
        Z += R
    return sols


def log_pm_generic(R, ans, n):
    """x-only answer -> {+-log} via Sage discrete_log (PH) on the lifted point, n = ord(R)."""
    if ans is None:
        return [0]
    S = R.curve().lift_x(ans)
    l1 = Integer(discrete_log(S, R, ord=Integer(n), operation='+'))
    return sorted({int(l1 % n), int((-l1) % n)})


def planted_log_pm(R, ans):
    """P114 part: +-log in [0, 2^32) by BSGS (stand-in for the 2^53.27 tau'-rho)."""
    S = R.curve().lift_x(ans)
    sols = set()
    for SS in (S, -S):
        try:
            l = Integer(bsgs(R, SS, (0, PLANT - 1), operation='+'))
            sols.add(int(l % P114)); sols.add(int((-l) % P114))
        except ValueError:
            pass
    return sorted(sols)


def plant_key():
    k0 = random.randrange(1, PLANT)
    while True:
        u = random.randrange(0, N // P114)
        k = k0 + P114 * u
        if 1 <= k < N:
            return k


def finish(residue_sets, G, Q):
    """CRT every sign combination, enumerate k < N in each class, test [k]G == Q."""
    mods = [m for m, _ in residue_sets]
    M = lcm(mods)
    tested, hits = 0, []
    for combo in itertools.product(*[r for _, r in residue_sets]):
        c = int(crt([Integer(x) for x in combo], [Integer(m) for m in mods]))
        k = c
        while k < N:
            if k > 0:
                tested += 1
                if k * G == Q:
                    hits.append(k)
            k += int(M)
    return M, tested, sorted(set(hits))


# =========================================================== Part 1: E0 implementation
E0 = curves["E0"]
b = K(1)
k_sec = plant_key()
G = 4 * E0.random_point()
assert not G.is_zero() and (N * G).is_zero()
Q = k_sec * G
oracle, calls = make_oracle(b, k_sec)
tA = time.time()
res = []
# (i) order-4 points of E0 have x = 1  ->  k mod 4 up to sign
P4 = E0(1, 0)
assert (4 * P4).is_zero() and not (2 * P4).is_zero()
r4 = small_log_pm(P4, oracle(K(1)), 4)
res.append((4, r4))
# (ii) order-263 point on the twist E0'
cof = T // 263 ** 2
while True:
    R263 = cof * E0t.random_point()
    if not R263.is_zero():
        break
o263 = 263 if (263 * R263).is_zero() else 263 ** 2
assert o263 == 263
ans263 = oracle(xof(R263))
r263 = small_log_pm(R263, ans263, 263)
res.append((263, r263))
# (iii) try hard to find an x giving k mod 263^2: sample 400 random x of E0 u E0' and record the max
#       263-power order ever met (E0 has none; E0' exponent kills 263^2)
max263 = 1
for _ in range(200):
    for Ec, cardc in ((E0t, T),):
        Z = (cardc // 263 ** 2) * Ec.random_point()
        if not Z.is_zero():
            max263 = max(max263, 263 if (263 * Z).is_zero() else 263 ** 2)
# (iv) P114 part on E0'
R114 = (2 * 263 ** 2) * E0t.random_point()
assert not R114.is_zero() and (P114 * R114).is_zero()
assert E0t(R114[0] ** 2, R114[1] ** 2) == LAM * R114          # tau' usable for rho here
ans114 = oracle(xof(R114))
r114 = planted_log_pm(R114, ans114)
res.append((P114, r114))
M, tested, hits = finish(res, G, Q)
out["E0_impl"] = dict(
    k_secret=str(k_sec), oracle_calls=calls[0],
    k_mod4_candidates=r4, k_mod263_candidates=r263, k_modP114_candidates=[str(x) for x in r114],
    max_263_power_order_seen_on_E0t_200_samples=int(max263),
    leak_modulus=str(M), leak_modulus_log2=float(math.log2(M)),
    candidates_tested=tested, hits=[str(h) for h in hits], recovered=bool(hits == [k_sec]),
    k_mod_263sq_obtainable=False, seconds=time.time() - tA)
print("E0_impl", out["E0_impl"])

# =========================================================== Part 2: A000 implementation
A = curves["A000"]
bA = A.a6()
At = EllipticCurve(K, [1, 1, 0, 0, bA])
k2 = plant_key()
GA = 4 * A.random_point()
assert not GA.is_zero() and (N * GA).is_zero()
QA = k2 * GA
oracle2, calls2 = make_oracle(bA, k2)
tB = time.time()
res2 = []
# (i) order-4 point on A000 (2-Sylow of A000 is cyclic Z/4)
while True:
    P4 = N * A.random_point()
    if not (2 * P4).is_zero():
        break
res2.append((4, small_log_pm(P4, oracle2(xof(P4)), 4)))
# (ii) order-263^2 point on A000'
while True:
    R2 = (2 * P114) * At.random_point()
    if not (263 * R2).is_zero():
        break
assert (263 ** 2 * R2).is_zero()
r2632 = log_pm_generic(R2, oracle2(xof(R2)), 263 ** 2)
res2.append((263 ** 2, r2632))
# (iii) P114 part on A000', transported to E0' by the rational 263-isogeny
R114A = (2 * 263 ** 2) * At.random_point()
assert not R114A.is_zero() and (P114 * R114A).is_zero()
ansA = oracle2(xof(R114A))
SA = At.lift_x(ansA)
ker = 263 * R2                                 # the unique F_q-rational subgroup of order 263
tI = time.time()
phi = At.isogeny(ker)
C = phi.codomain()
iso = C.isomorphism_to(E0t)
t_iso = time.time() - tI
psi = lambda P: iso(phi(P))
U, V = psi(R114A), psi(SA)
assert (P114 * U).is_zero() and not U.is_zero()
tau_img = (E0t(U[0] ** 2, U[1] ** 2) == LAM * U) and (E0t(V[0] ** 2, V[1] ** 2) == LAM * V)
# DLP solved on E0' (where tau'+negation rho would run), planted-small stand-in
rT = set()
for VV in (V, -V):
    try:
        l = Integer(bsgs(U, VV, (0, PLANT - 1), operation='+'))
        rT.add(int(l % P114)); rT.add(int((-l) % P114))
    except ValueError:
        pass
rT = sorted(rT)
# same answer directly on A000' (no transport)
rD = planted_log_pm(R114A, ansA)
res2.append((P114, rT))
M2, tested2, hits2 = finish(res2, GA, QA)
out["A000_impl"] = dict(
    k_secret=str(k2), oracle_calls=calls2[0],
    k_mod263sq_candidates=r2632, k_modP114_via_E0t=[str(x) for x in rT],
    k_modP114_direct_on_A000t=[str(x) for x in rD], transport_agrees=bool(rT == rD),
    isogeny_codomain_j=str(C.j_invariant()), codomain_isomorphic_to_E0t=True,
    isogeny_build_seconds=t_iso, tau_prime_acts_by_LAM_on_images=bool(tau_img),
    leak_modulus=str(M2), leak_modulus_log2=float(math.log2(M2)), leak_ge_N=bool(M2 >= N),
    candidates_tested=tested2, hits=[str(h) for h in hits2], recovered=bool(hits2 == [k2]),
    seconds=time.time() - tB)
print("A000_impl", out["A000_impl"])


# =========================================================== Part 3: validation defeats it
def validating_oracle(b, k):
    def o(x):
        if x != 0 and (x + b / x ** 2).trace() != 0:
            raise ValueError("point not on curve")
        return ladder(x, k, b)
    return o


vo = validating_oracle(K(1), k_sec)
rej = 0
for Z in (R263, R114):
    try:
        vo(xof(Z))
    except ValueError:
        rej += 1
acc = 0
for _ in range(20):
    try:
        vo(xof(E0.random_point())); acc += 1
    except ValueError:
        pass
ok_valid = (acc == 20)
out["validation"] = dict(twist_queries_rejected=rej, of=2, honest_queries_accepted=bool(ok_valid),
                         check="Tr(x + b/x^2) == 0: one inversion + one trace")
print("validation", out["validation"])
out["seconds"] = time.time() - t0
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-8-1/s2_e2e.json", "w"), indent=1)
print("done", out["seconds"])
