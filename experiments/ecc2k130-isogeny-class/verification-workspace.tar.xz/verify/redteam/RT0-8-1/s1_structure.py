"""RT0-8 (twist / x-only oracle) -- independent structural checks.

Run:  export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
      sage -python s1_structure.py

Checks
 A  factorisation of the twist order T = q+1+t, primality of P114 (proof=True)
 B  group STRUCTURE of E0'(F_q), E0' = [1,1,0,0,1]: 263-Sylow is (Z/263)^2 (full 263-torsion
    rational, Weil pairing nontrivial) -> exponent 2*263*P114 (NOT 2*263^2*P114)
 C  tau' eigenvalue on E0'[P114], its order; 131 | P114-1
 D  floor twists (all 262): 263-Sylow cyclic of order 263^2 (point of order 263^2),
    2-part Z/2, so E'(F_q) cyclic of order T
 E  x-only Lopez-Dahab ladder uses only b: agrees with Sage on E and on its twist
 F  every x != 0 lies on exactly one of [1,0,0,0,b], [1,1,0,0,b]  (Tr(1)=1, odd degree),
    decided by Tr(x + b/x^2)
 G  rho costs and information-theoretic leak per implementation
"""
import json, math, sys, time, random
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import (EllipticCurve, Integer, is_prime, factor, GF, PolynomialRing, lcm,
                      set_random_seed, pari)

set_random_seed(20260924)
random.seed(20260924)
t0 = time.time()
out = {}
q, t, N = ecc2k.q, ecc2k.t, ecc2k.N
K, curves = ecc2k.load()
lg = lambda x: float(math.log2(x))

# ------------------------------------------------------------------ A
T = q + 1 + t
F = factor(Integer(T))
P114 = T // (2 * 263 ** 2)
assert T == 2 * 263 ** 2 * P114
assert Integer(P114).is_prime(proof=True) and bool(pari(P114).isprime(1))
assert T == 2 * q + 2 - 4 * N
out["A"] = dict(T=str(T), T_factor=str(F), P114=str(P114), P114_log2=lg(P114),
                P114_prime_proof=True, T_log2=lg(T), T_gt_N=bool(T > N),
                P114_minus1_factor=str(factor(Integer(P114 - 1))),
                v131_P114m1=int(Integer(P114 - 1).valuation(131)))
print("A", out["A"])

# ------------------------------------------------------------------ B
E0 = curves["E0"]
E0t = EllipticCurve(K, [1, 1, 0, 0, 1])
card_pari = Integer(pari(E0t).ellcard()) if False else E0t.cardinality(algorithm="pari")
assert card_pari == T
grp = pari(E0t).ellgroup()  # PARI group structure (cyc)
print("PARI ellgroup(E0')", grp)
cof263 = T // 263 ** 2


def pt_order_263(E):
    while True:
        R = cof263 * E.random_point()
        if not R.is_zero():
            if (263 * R).is_zero():
                return R
            # R has order 263^2: return it so caller can see
            return R


# two independent 263-torsion points on E0' with nontrivial Weil pairing
pts = []
max263 = 1
for _ in range(40):
    R = cof263 * E0t.random_point()
    o = 1 if R.is_zero() else (263 if (263 * R).is_zero() else 263 ** 2)
    max263 = max(max263, o)
    if o == 263:
        pts.append(R)
P1 = pts[0]
P2 = next(Rr for Rr in pts[1:] if P1.weil_pairing(Rr, 263) != 1)
wp = P1.weil_pairing(P2, 263)
assert wp != 1 and wp ** 263 == 1
# 263-Sylow = (Z/263)^2 since v_263(T)=2 and E0'[263] is F_q-rational
# exponent check on random points
expo = 2 * 263 * P114
exp_ok = all((expo * E0t.random_point()).is_zero() for _ in range(30))
# exponent is exactly 2*263*P114: find a point of order 2*263*P114 (x != 0 generic)
Rg = E0t.random_point()
ok_full = all(not ((expo // l) * Rg).is_zero() for l in (2, 263, P114))
out["B"] = dict(E0t_card_pari_eq_T=True, pari_ellgroup=str(grp),
                max_263_order_seen_in_40_random=int(max263),
                weil_pairing_263_nontrivial=True,
                sylow263="(Z/263)^2",
                exponent=str(expo), exponent_log2=lg(expo),
                exponent_kills_30_random_points=bool(exp_ok),
                random_point_has_order_exponent=bool(ok_full))
print("B", out["B"])

# ------------------------------------------------------------------ C
R = PolynomialRing(GF(P114), "X"); X = R.gen()
roots = [Integer(r) for r, _ in (X ** 2 - X + 2).roots()]
Pt = (2 * 263 ** 2) * E0t.random_point()
assert not Pt.is_zero() and (P114 * Pt).is_zero()
FrP = E0t(Pt[0] ** 2, Pt[1] ** 2)
lam = [r for r in roots if r * Pt == FrP]
assert len(lam) == 1
lam = lam[0]
ordlam = Integer(GF(P114)(lam).multiplicative_order())
other = [r for r in roots if r != lam][0]
ordother = Integer(GF(P114)(other).multiplicative_order())
# tau'^131 = pi = identity on E0'(F_q): check directly on a point
Z = Pt
for _ in range(131):
    Z = E0t(Z[0] ** 2, Z[1] ** 2)
assert Z == Pt
out["C"] = dict(lambda_tau=str(lam), lambda_order=str(ordlam), other_root_order_log2=lg(ordother),
                tau131_identity_on_point=True,
                matches_proposer=bool(str(lam) == "11620273277080081443521875815673184"))
print("C", out["C"])

# ------------------------------------------------------------------ D  all 262 floor twists
cycl = 0
bad = []
tD = time.time()
for lab in ecc2k.LABELS[1:]:
    b = curves[lab].a6()
    assert curves[lab].a2() == 0
    Et = EllipticCurve(K, [1, 1, 0, 0, b])
    found = False
    for _ in range(6):
        Rr = (2 * P114) * Et.random_point()
        if not (263 * Rr).is_zero():
            assert (263 ** 2 * Rr).is_zero()
            found = True
            break
    # exponent T: point of order T (full cyclic) -- checked via the 263^2 point + Z/2 (unique 2-torsion) + P114
    if found:
        cycl += 1
    else:
        bad.append(lab)
out["D"] = dict(floor_twists_checked=262, with_point_of_order_263sq=cycl, failures=bad,
                seconds=time.time() - tD)
print("D", out["D"])


# ------------------------------------------------------------------ E  x-only ladder (b only)
def ladder(xP, k, b):
    """Lopez-Dahab projective x-only Montgomery ladder for y^2+xy=x^3+a x^2+b.
    Uses only b and x(P); a is never referenced. Returns x([k]P) or None (point at infinity)."""
    k = int(k)
    if k == 0:
        return None
    X1, Z1 = xP, K(1)
    X2, Z2 = xP ** 4 + b, xP ** 2
    for i in range(k.bit_length() - 2, -1, -1):
        if (k >> i) & 1:
            Zs = (X1 * Z2 + X2 * Z1) ** 2
            X1, Z1 = xP * Zs + (X1 * Z2) * (X2 * Z1), Zs
            X2, Z2 = X2 ** 4 + b * Z2 ** 4, X2 ** 2 * Z2 ** 2
        else:
            Zs = (X1 * Z2 + X2 * Z1) ** 2
            X2, Z2 = xP * Zs + (X1 * Z2) * (X2 * Z1), Zs
            X1, Z1 = X1 ** 4 + b * Z1 ** 4, X1 ** 2 * Z1 ** 2
    if Z1 == 0:
        return None
    return X1 / Z1


def sage_x(Pp):
    return None if Pp.is_zero() else Pp[0]


nE = 0
for lab in ["E0", "A000", "A064", "B021"]:
    b = curves[lab].a6()
    for a2 in (0, 1):
        Ec = EllipticCurve(K, [1, a2, 0, 0, b])
        for _ in range(8):
            Pp = Ec.random_point()
            k = random.randrange(1, 2 ** 132)
            assert ladder(Pp[0], k, b) == sage_x(k * Pp), (lab, a2)
            nE += 1
# special x: x=0 (2-torsion) and x=1 on E0 (order-4 points)
b1 = K(1)
for k in range(1, 9):
    assert ladder(K(0), k, b1) == sage_x(k * E0(0, 1))
    assert ladder(K(1), k, b1) == sage_x(k * E0(1, 0))
out["E"] = dict(ladder_vs_sage_random_tests=nE, special_x_tests=16, all_agree=True)
print("E", out["E"])


# ------------------------------------------------------------------ F  twist membership
assert K(1).trace() == 1
nF = 0
for lab in ["E0", "A000", "B130"]:
    b = curves[lab].a6()
    E_ = EllipticCurve(K, [1, 0, 0, 0, b]); Et_ = EllipticCurve(K, [1, 1, 0, 0, b])
    for _ in range(200):
        x = K.random_element()
        if x == 0:
            continue
        on0 = bool(E_.lift_x(x, all=True))
        on1 = bool(Et_.lift_x(x, all=True))
        tr = (x + b / x ** 2).trace()
        assert on0 != on1 and on0 == (tr == 0)
        nF += 1
out["F"] = dict(random_x_tested=nF, each_x_on_exactly_one_twist=True,
                validation_rule="x on [1,0,0,0,b] iff Tr(x + b/x^2) = 0 (x != 0)")
print("F", out["F"])

# ------------------------------------------------------------------ G  costs and leak sizes
pi = math.pi
rho = lambda n, m: 0.5 * (math.log2(pi) + math.log2(n) - math.log2(2 * m))
leak_E0 = lcm([4, 2 * 263 * P114])        # E0 2-Sylow Z/4 ; E0' exponent 2*263*P114
leak_floor = lcm([4, T])                   # floor E 2-Sylow Z/4 ; floor twist cyclic of order T
out["G"] = dict(
    rho_E0_neg_tau_log2=rho(N, 262), rho_generic_neg_log2=rho(N, 2),
    rho_P114_neg_tau_log2=rho(P114, 262), rho_P114_neg_only_log2=rho(P114, 2),
    gain_bits_vs_E0=rho(N, 262) - rho(P114, 262),
    E0_impl_leak_modulus_log2=lg(leak_E0), E0_impl_residual_log2=lg(N) - lg(leak_E0),
    E0_impl_residual_candidates=str((N + leak_E0 - 1) // leak_E0),
    floor_impl_leak_modulus_log2=lg(leak_floor), floor_impl_leak_ge_N=bool(leak_floor > N),
    claimed_small_part_log2=lg(2 * 263 ** 2), actual_E0_small_part_log2=lg(2 * 263))
print("G", out["G"])
out["seconds"] = time.time() - t0
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-8-1/s1_structure.json", "w"), indent=1)
print("done", out["seconds"])
