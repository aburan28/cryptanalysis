"""RT0-8: how the gain depends on the oracle model (numbers only + a blinding check).

Run:  export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
      sage -python s3_models.py

 M1 raw-output oracle (claim's model): the P114 part is solved by tau'-rho on E0'
 M2 hashed-output oracle (ECDH + KDF + key confirmation): only guess-and-check of small-order
    components works; the rest of k is found by an interval (kangaroo) search on the real curve.
    Kangaroo cost uses the textbook van Oorschot-Wiener constant 2*sqrt(W) per coset (analytic).
 M3 scalar blinding k' = k + r*N with fresh r per call: twist-side residues are randomised.
"""
import json, math, sys, random
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import EllipticCurve, Integer, set_random_seed

set_random_seed(3)
random.seed(3)
q, t, N = ecc2k.q, ecc2k.t, ecc2k.N
T = q + 1 + t
P114 = T // (2 * 263 ** 2)
L = lambda x: math.log2(x)
rho = lambda n, m: 0.5 * (L(math.pi) + L(n) - L(2 * m))
base = rho(N, 262)
out = {"baseline_E0_tau_rho_log2": base}

# M1
out["M1_raw_output"] = dict(E0_impl=rho(P114, 262), floor_impl_via_E0t=rho(P114, 262),
                            floor_impl_no_transport_neg_only=rho(P114, 2))
# M2: E0 impl knows k mod 2 and +-k mod 263 (E0' exponent has only 263^1); floor impl +-k mod 263^2
def kang(W, cosets):
    return L(2 * math.sqrt(W)) + L(cosets)          # cosets run independently (upper bound)
W_E0 = N / (2 * 263)
W_fl = N / (2 * 263 ** 2)
out["M2_hashed_output"] = dict(
    E0_impl_known_bits=L(2 * 263), E0_impl_interval_log2=L(W_E0),
    E0_impl_kangaroo_log2_per_coset=kang(W_E0, 1), E0_impl_kangaroo_log2_2cosets=kang(W_E0, 2),
    floor_impl_known_bits=L(2 * 263 ** 2), floor_impl_interval_log2=L(W_fl),
    floor_impl_kangaroo_log2_per_coset=kang(W_fl, 1), floor_impl_kangaroo_log2_2cosets=kang(W_fl, 2),
    confirmations_needed_floor="<= 263 + 263 guesses (PH over 263^2) + 2 for the 2-part")

# M3: blinding. Same query point, two calls, blinded scalars -> different outputs on the twist
K, curves = ecc2k.load(["E0"])
E0t = EllipticCurve(K, [1, 1, 0, 0, 1])
R = (2 * 263 ** 2) * E0t.random_point()
k = random.randrange(1, N)
outs = set()
for _ in range(4):
    r = random.getrandbits(64)
    outs.add((k + r * N) * R)
out["M3_blinding"] = dict(N_mod_P114_nonzero=bool(N % P114 != 0), N_mod_263=int(N % 263),
                          distinct_outputs_for_4_blinded_calls=len(outs))
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT0-8-1/s3_models.json", "w"), indent=1)
print(json.dumps(out, indent=1))
