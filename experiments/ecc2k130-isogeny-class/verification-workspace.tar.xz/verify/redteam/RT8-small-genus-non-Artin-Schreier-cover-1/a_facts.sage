# RT8 re-verification: structure of A = trace-zero part of Res(E0), place counts,
# break-even genera.  Independent re-derivation (does not import proposer code).
import json, math, time
out = {}
q = 2**131
# E0 over F_2: #E0(F_2)=4 -> t1 = 2+1-4 = -1
t1 = -1
R.<T> = ZZ[]
PE0 = T**2 - t1*T + 2
# trace of pi = tau^131 via power sums
s = {0: 2, 1: t1}
for k in range(2, 3000):
    s[k] = t1*s[k-1] - 2*s[k-2]
t = s[131]
out['t'] = str(t)
N = (q + 1 - t) // 4
assert (q + 1 - t) % 4 == 0 and is_prime(N)
out['N'] = str(N)
PRes = T**262 - t*T**131 + q
PA, r = PRes.quo_rem(PE0)
assert r == 0 and PA.degree() == 260
t0 = time.time()
out['PA_irreducible'] = bool(pari(PA).polisirreducible())
out['PA_irred_seconds'] = round(time.time()-t0, 2)
out['PA_at_1_equals_N'] = bool(PA(1) == N)
out['PA_middle_coeff_T130_odd(ordinary)'] = bool(PA[130] % 2 == 1)
# A's Frobenius field: is it Q(zeta_131, sqrt(-7))? check PA(T) = prod_{j=1..130} (T^2 - zeta^j t1 T + 2 zeta^{2j})
# i.e. roots are zeta^j*tau: equivalently PA(T) = Res_z(Phi_131(z), T^2 - t1 z T + 2 z^2)
Phi = cyclotomic_polynomial(131)
U.<x, y> = ZZ[]
res = Phi(y).resultant(x**2 - t1*y*x + 2*y**2, y)
out['PA_equals_prod_over_nontrivial_zeta(T^2 - zeta*t1*T + 2 zeta^2)'] = bool(R(res.univariate_polynomial()) == PA)

# traces of Frobenius^k on A: a_k(A) = sum of roots^k
def aA(k):
    v = -s[k]
    if k % 131 == 0:
        # sum over all 262 roots of T^262 - t T^131 + q of alpha^k = 131 * (pi^m + pibar^m), m=k/131
        m = k // 131
        tm = {0: 2, 1: t}
        a_, b_ = 2, t
        for _ in range(m-1):
            a_, b_ = b_, t*b_ - q*a_
        v += 131 * (b_ if m >= 1 else 2)
    return v
# hypothetical genus-130 curve with Jac ~ A
Ck = {k: 2**k + 1 - aA(k) for k in range(1, 1201)}
out['C_counts_k1_3'] = [int(Ck[1]), int(Ck[2]), int(Ck[3])]
# closed form check: #C(F_{2^k}) = 2(2^k+1) - #E0(F_{2^k}) for 131 !| k
ok = all(Ck[k] == 2*(2**k+1) - (2**k+1-s[k]) for k in range(1, 131))
out['C_count_eq_2(2^k+1)-#E0(F_2^k)_for_k<131'] = ok
places = {}
for d in range(1, 1201):
    tot = sum(moebius(d//e)*Ck[e] for e in divisors(d))
    places[d] = (tot // d, tot % d == 0)
out['places_deg1_6'] = [int(places[d][0]) for d in range(1, 7)]
out['places_all_integral_nonneg_d<=1200'] = all(v[1] and v[0] >= 0 for v in places.values())
out['min_places_d<=1200'] = str(min((v[0], d) for d, v in places.items()))
# Weil-bound slack at k=131: |a_131(A)| vs 2*130*2^65.5
out['log2_|a131(A)|'] = float(RR(abs(aA(131))).log(2))
out['log2_weil_bound_genus130_k131'] = float(RR(260*2**65.5).log(2))

# dimension-count heuristic (as the proposer): log2 E = (3g-3) + (g-130)(g-129)/4 - g(g+1)/4 = 4189.5 - 62 g
out['heuristic_log2_expected'] = {int(g): float((3*g-3) + (g-130)*(g-129)/4 - g*(g+1)/4) for g in (130, 249, 263, 394, 447)}
out['heuristic_closed_form_4189.5-62g_ok'] = all(abs(out['heuristic_log2_expected'][int(g)] - (4189.5-62*g)) < 1e-9 for g in out['heuristic_log2_expected'])

# break-even genus of L_{2^g}[alpha,c] (o(1)=0) vs rho 2^60.81
RHO = float(RR(sqrt(pi*N/(4*131))).log(2))
out['rho_bits_E0'] = RHO
def Lbits(g, a, c):
    lnQ = g*math.log(2)
    return c*lnQ**a*math.log(lnQ)**(1-a)/math.log(2)
H = {}
for name, a, c in [('L(1/2,sqrt2)', .5, math.sqrt(2)), ('L(1/2,1)', .5, 1.0),
                   ('L(1/3,(64/9)^(1/3))', 1/3, (64/9)**(1/3)), ('L(1/3,1)', 1/3, 1.0)]:
    g = 130
    while Lbits(g, a, c) < RHO: g += 1
    H[name] = dict(break_even=g, bits_at={int(gg): round(Lbits(gg, a, c), 2) for gg in (130, 249, 263, 394, 447)})
out['L_break_even'] = H
# kronecker symbols used later
out['kron(-7,131)'] = int(kronecker(-7, 131))
out['weil_max_#J_F2'] = {int(g): float((1+sqrt(2.0))**(2*g)) for g in (2, 3, 4, 5)}
print(json.dumps(out, indent=1, default=str))
json.dump(out, open('a_facts.json', 'w'), indent=1, default=str)
