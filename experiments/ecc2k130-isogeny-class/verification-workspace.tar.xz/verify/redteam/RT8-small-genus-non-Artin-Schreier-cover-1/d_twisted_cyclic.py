"""Cyclic order-131 structure with twisted Frobenius action (m = order of a,
Frobenius acts on <rho> by rho -> rho^a).  An unramified geometric Z/131 cover
C -> D exists with that Frobenius action iff Frobenius on J(D)[131] has an
eigenvalue in {a, a^-1, 2a, 2a^-1} (mod 131).  For A to sit in the Prym, the
Artin L-function reduced mod (1-zeta) forces P_D(zeta_m^i * tau) == 0 mod a
prime over 131 for some i.  dim(Prym) = 130(g_D - 1) must be >= 130*m, so for
g_D = 3 only m in {1, 2} matter; we nevertheless list all roots of P_D mod 131.
Superset of genus-3 L-polys used: all hyperelliptic ones + all Weil-valid
quartic-form L-polys (contains the smooth ones).
"""
import json, importlib.util
spec = importlib.util.spec_from_file_location('b', 'b_genus3_enum.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
p = 131
Ls = set(b.hyp_L) | {L for L in b.quart_L if b.weil_ok(L)}
def PD(L, x):  # P_D(x) = sum L[i] x^(6-i) mod p
    r = 0
    for c in L: r = (r * x + c) % p
    return r
def ordp(a):
    k, x = 1, a % p
    while x != 1: x = x * a % p; k += 1
    return k
# F_{131^2} = F_131[tau]/(tau^2+tau+2)
def mul(u, v):
    a0 = u[0] * v[0]; a1 = u[0] * v[1] + u[1] * v[0]; a2 = u[1] * v[1]
    return ((a0 - 2 * a2) % p, (a1 - a2) % p)
def PD2(L, x):
    r = (0, 0)
    for c in L:
        r = mul(r, x); r = ((r[0] + c) % p, r[1])
    return r
out = dict(n_Lpolys=len(Ls), roots_mod131={}, m_possible={}, tau_conditions={})
mset = {}
for L in sorted(Ls):
    roots = [x for x in range(1, p) if PD(L, x) == 0]
    if roots:
        out['roots_mod131'][str(L)] = roots
        for r in roots:
            # r in {a, a^-1, 2a, 2a^-1}: candidate a's
            for a in {r, pow(r, -1, p), r * pow(2, -1, p) % p, pow(r * pow(2, -1, p) % p, -1, p)}:
                m = ordp(a)
                mset.setdefault(m, set()).add(str(L))
    # necessary tau-condition for m = 1 and m = 2
    t1 = PD2(L, (0, 1)) == (0, 0)
    t2 = PD2(L, (0, p - 1)) == (0, 0)
    if t1 or t2: out['tau_conditions'][str(L)] = dict(P_D_tau_zero=t1, P_D_minus_tau_zero=t2)
out['m_possible'] = {m: len(v) for m, v in sorted(mset.items())}
out['m1_or_m2_possible_Lpolys'] = sorted(mset.get(1, set()) | mset.get(2, set()))
json.dump(out, open('d_twisted_cyclic.json', 'w'), indent=1)
print(json.dumps({k: v for k, v in out.items() if k != 'roots_mod131'}, indent=1))
print('num L with some root mod 131:', len(out['roots_mod131']))
