import json
out = {}
R.<s> = GF(2)[]
f = (s**131 - 1).factor()
out['factor_degrees_of_s^131-1_over_F2'] = sorted([g.degree() for g, e in f])
out['possible_GHS_m_values(F2[sigma]-submodule dims)'] = sorted(set([0, 1, 130, 131]) - {0})
# Kummer family y^131 = f(x): x -> x^131 bijective on F_{2^k} when 130 !| k
out['gcd(131, 2^k-1)=1 for all k<130'] = all(gcd(131, 2**k - 1) == 1 for k in range(1, 130))
out['kummer_genus_4_branch_points'] = (131 - 1) * (4 - 2) // 2
# required #C(F_2) for Jac(C) ~ A is 2; Kummer model has #C(F_2) = #P^1(F_2) = 3
out['required_C_F2_for_JacA'] = 2
out['kummer_C_F2'] = 3
json.dump(out, open('f_misc.json', 'w'), indent=1, default=str); print(out)
