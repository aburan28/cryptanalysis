"""Enumerate ALL genus-3 curves over F_2 (every smooth hyperelliptic model
y^2+h(x)y=f(x), deg h<=4, deg f<=8, and every plane quartic form) and compute
their L-polynomials from N1,N2,N3.

Question tested: an unramified Z/131 cover C -> D (Galois group defined over F_2,
so C has an F_2-automorphism rho of order 131; Riemann-Hurwitz gives genus
g(C) = 1 + 131(g(D)-1) = 263 for g(D)=3) needs 131 | #J(D)(F_2) (geometric
class field theory: Gal = quotient of Pic^0(D)(F_2)).  For such C to contain A
(Frobenius eigenvalues zeta^k*tau), the twisted L-function L(D,chi,T) must have
reciprocal root zeta^k*tau; reducing mod the prime (1-zeta) over 131 gives the
necessary condition  P_D(X) := X^6 L_D(1/X)  vanishes at tau mod 131, i.e.
X^2+X+2 | P_D(X) mod 131 (131 is inert in Q(sqrt-7)).
Quartic smoothness is only checked (in Sage, separately) for survivors; the
filter is sound because every smooth quartic is counted correctly.
"""
import json, itertools, time
import numpy as np

MOD = {1: 0b11, 2: 0b111, 3: 0b1011}   # F_2, F_4=F_2[w]/(w^2+w+1), F_8=F_2[w]/(w^3+w+1)

def gmul(a, b, k):
    m = MOD[k]; r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1; a <<= 1
        if a >> k & 1: a ^= m
    return r

def gpow(a, e, k):
    r = 1
    while e:
        if e & 1: r = gmul(r, a, k)
        a = gmul(a, a, k); e >>= 1
    return r

def ginv(a, k):
    return gpow(a, (1 << k) - 2, k)

def gtr(a, k):
    s, x = 0, a
    for _ in range(k):
        s ^= x; x = gmul(x, x, k)
    return s  # 0 or 1

def peval(coeffs_mask, deg, x, k):
    # polynomial over F_2 given as bitmask, evaluated at x in F_{2^k}
    r = 0
    for i in range(deg, -1, -1):
        r = gmul(r, x, k) ^ ((coeffs_mask >> i) & 1)
    return r

# ---------- F_2[x] polynomial helpers (ints) ----------
def pdeg(a): return a.bit_length() - 1
def pmod(a, b):
    db = pdeg(b)
    while a and pdeg(a) >= db:
        a ^= b << (pdeg(a) - db)
    return a
def pgcd(a, b):
    while b: a, b = b, pmod(a, b)
    return a
def pderiv(a):
    r = 0; i = 1
    while (a >> i):
        if (a >> i) & 1 and i % 2 == 1: r |= 1 << (i - 1)
        i += 1
    return r
def psq(a):
    r = 0; i = 0
    while a >> i:
        if (a >> i) & 1: r |= 1 << (2 * i)
        i += 1
    return r
def pmul(a, b):
    r = 0
    while b:
        if b & 1: r ^= a
        a <<= 1; b >>= 1
    return r

def lpoly(N1, N2, N3, q=2):
    S = [None, N1 - q - 1, N2 - q * q - 1, N3 - q ** 3 - 1]
    a = [1, 0, 0, 0]
    for k in (1, 2, 3):
        acc = sum(S[i] * a[k - i] for i in range(1, k + 1))
        assert acc % k == 0, (N1, N2, N3)
        a[k] = acc // k
    return [1, a[1], a[2], a[3], q * a[2], q * q * a[1], q ** 3]

def PD_at_tau_mod131(L):
    # P_D(X) = sum L[i] X^(6-i); evaluate at tau in F_131[tau]/(tau^2+tau+2)
    p = 131
    def mul(u, v):  # (u0 + u1 tau)(v0 + v1 tau), tau^2 = -tau - 2
        a0 = u[0] * v[0]; a1 = u[0] * v[1] + u[1] * v[0]; a2 = u[1] * v[1]
        return ((a0 - 2 * a2) % p, (a1 - a2) % p)
    r = (0, 0)
    for c in L:  # Horner from X^6 coefficient L[0]
        r = mul(r, (0, 1)); r = ((r[0] + c) % p, r[1] % p)
    return r

def weil_ok(L):
    import cmath
    r = np.roots([L[i] for i in range(7)][::-1])  # roots of L(T), should have |.|=1/sqrt2
    return bool(np.all(np.abs(np.abs(r) - 2 ** -0.5) < 1e-6))

t0 = time.time()
results = {}
# ---------- hyperelliptic ----------
fields = {}
for k in (1, 2, 3):
    fields[k] = list(range(1 << k))
hyp_L = {}
hyp_count = 0
for h in range(1, 1 << 5):
    for f in range(1 << 9):
        # smoothness
        c = psq(pderiv(f)) ^ pmul(psq(pderiv(h)), f)
        if pgcd(h, c) not in (1,):
            if h == 0 or pgcd(h, c) != 1: continue
        h4 = (h >> 4) & 1
        if not h4:
            f7 = (f >> 7) & 1; f8 = (f >> 8) & 1; h3 = (h >> 3) & 1
            if (f7 ^ (h3 & f8)) == 0: continue
        Ns = []
        for k in (1, 2, 3):
            n = 0
            for x in fields[k]:
                hx = peval(h, 4, x, k); fx = peval(f, 8, x, k)
                if hx == 0: n += 1
                else:
                    ihx = ginv(hx, k)
                    n += 2 if gtr(gmul(fx, gmul(ihx, ihx, k), k), k) == 0 else 0
            if h4:
                f8 = (f >> 8) & 1
                n += 2 if gtr(f8, k) == 0 else 0   # h4=1: y^2+y=f8
            else:
                n += 1
            Ns.append(n)
        L = lpoly(*Ns)
        hyp_count += 1
        hyp_L.setdefault(tuple(L), []).append((h, f))
results['hyperelliptic_models_smooth'] = hyp_count
results['hyperelliptic_distinct_L'] = len(hyp_L)
print('hyp done', hyp_count, len(hyp_L), round(time.time() - t0, 1), flush=True)

# ---------- plane quartics (vectorised over all 2^15 forms) ----------
mons = [(i, j, 4 - i - j) for i in range(5) for j in range(5 - i)]
assert len(mons) == 15
def proj_points(k):
    F = range(1 << k)
    pts = [(1, y, z) for y in F for z in F] + [(0, 1, z) for z in F] + [(0, 0, 1)]
    return pts
allc = np.arange(1 << 15, dtype=np.int64)
quartN = {}
for k in (1, 2, 3):
    cnt = np.zeros(1 << 15, dtype=np.int64)
    for P in proj_points(k):
        vals = np.zeros(1 << 15, dtype=np.int64)
        for jm, (a, b, cc) in enumerate(mons):
            mv = gmul(gmul(gpow(P[0], a, k), gpow(P[1], b, k), k), gpow(P[2], cc, k), k)
            if mv:
                vals ^= ((allc >> jm) & 1) * mv
        cnt += (vals == 0)
    quartN[k] = cnt
quart_L = {}
bad_newton = 0
for cmask in range(1, 1 << 15):
    Ns = (int(quartN[1][cmask]), int(quartN[2][cmask]), int(quartN[3][cmask]))
    try:
        L = lpoly(*Ns)
    except AssertionError:
        bad_newton += 1; continue   # impossible for smooth genus-3 curves
    quart_L.setdefault(tuple(L), []).append(cmask)
results['quartic_forms_with_integral_newton'] = sum(len(v) for v in quart_L.values())
results['quartic_forms_nonintegral(singular,excluded)'] = bad_newton
print('quartic counts done', round(time.time() - t0, 1), flush=True)

# ---------- filter ----------
def summarize(Ldict, weil_required):
    J = {}
    surv = []
    for L, reps in Ldict.items():
        if weil_required and not weil_ok(L):
            continue
        j1 = sum(L)
        J[j1] = J.get(j1, 0) + len(reps)
        if j1 % 131 == 0:
            surv.append(dict(L=list(L), J=j1, PD_tau_mod131=PD_at_tau_mod131(L), n_models=len(reps), rep=reps[0]))
    return J, surv
Jh, sh = summarize(hyp_L, True)
results['hyp_all_L_satisfy_weil'] = all(weil_ok(L) for L in hyp_L)
results['hyp_max_#J'] = max(Jh); results['hyp_#J_hist_top'] = sorted(Jh.items())[-8:]
results['hyp_131_divides_#J'] = sh
# for quartics only Weil-valid L are possible for smooth curves
Jq, sq = summarize(quart_L, True)
results['quartic_weil_valid_distinct_L'] = sum(1 for L in quart_L if weil_ok(L))
results['quartic_max_#J(weil-valid)'] = max(Jq); results['quartic_#J_hist_top'] = sorted(Jq.items())[-8:]
results['quartic_131_divides_#J'] = [dict(s, rep=int(s['rep'])) for s in sq]
results['seconds'] = round(time.time() - t0, 1)
json.dump(results, open('b_genus3_enum.json', 'w'), indent=1, default=str)
print(json.dumps({k: v for k, v in results.items()}, indent=1, default=str))
