"""Concrete (non-asymptotic) index-calculus cost model for Jac(C)(F_2), genus g.

Relation search: random combinations reduced to effective degree-g divisors,
kept if b-smooth (all places of degree <= b).  Smoothness counts are EXACT
generating-function counts using the place counts of P^1 over F_2 (number of
irreducible polys I_d) as a proxy for the curve's place counts (Hess/Diem:
divisor smoothness ~ polynomial smoothness); for g=130 we also use the EXACT
place counts a_d of a hypothetical curve with Jac ~ A.
Costs are in "group operations" (one Jacobian addition = 1, generous to the
attacker: a genus-g Jacobian op over F_2 is much dearer than an EC op) and in
"LA ops" = FB^2 * w (sparse Wiedemann/Lanczos, w = mean #factors of a
relation, counted with multiplicity so an upper bound on the true weight).
Variants: no large prime, single large prime (birthday pairing, deg <= L).
Break-even is against rho on E0: 2^60.81.
"""
import math, json, sys

def mobius(n):
    r, m, p = 1, n, 2
    while p * p <= m:
        if m % p == 0:
            m //= p
            if m % p == 0: return 0
            r = -r
        p += 1
    if m > 1: r = -r
    return r

def I(d):
    return sum(mobius(d // e) * 2 ** e for e in range(1, d + 1) if d % e == 0) // d

GMAX = 700
Id = [0] + [I(d) for d in range(1, GMAX + 1)]

def smooth_series(b, gmax, places):
    # S[n] = # effective divisors of degree n composed of places of degree <= b
    S = [0] * (gmax + 1); S[0] = 1
    for d in range(1, b + 1):
        a = places[d]
        if a == 0: continue
        # multiply by (1 - T^d)^(-a): S_new[n] = sum_k C(a+k-1,k) S[n-dk]; do it by
        # repeated "prefix sums with stride d" a times would be slow for big a;
        # use the recurrence of the binomial series instead.
        coef = [1]
        k = 1
        while d * k <= gmax:
            coef.append(coef[-1] * (a + k - 1) // k); k += 1
        new = [0] * (gmax + 1)
        for n in range(gmax + 1):
            if S[n] == 0: continue
            for k2, c in enumerate(coef):
                m = n + d * k2
                if m > gmax: break
                new[m] += S[n] * c
        S = new
    return S

def mean_factors(b, g, places, S):
    # E[#irreducible factors with multiplicity] among b-smooth degree-g divisors
    # = [T^g] S(T) * sum_{d<=b} a_d T^d/(1-T^d)  /  S[g]
    W = [0] * (g + 1)
    for d in range(1, b + 1):
        for m in range(d, g + 1, d):
            W[m] += places[d]
    tot = sum(S[g - m] * W[m] for m in range(1, g + 1))
    return tot / S[g]

def log2(x): return math.log2(x) if x > 0 else float('-inf')

_cache = {}
def series_table(places, gmax, bmax):
    key = (id(places), gmax, bmax)
    if key in _cache: return _cache[key]
    tab = {}
    S = [0] * (gmax + 1); S[0] = 1
    for d in range(1, bmax + 1):
        a = places[d] if d < len(places) else 0
        if a:
            coef = [1]; k = 1
            while d * k <= gmax:
                coef.append(coef[-1] * (a + k - 1) // k); k += 1
            new = [0] * (gmax + 1)
            for n in range(gmax + 1):
                if S[n] == 0: continue
                for k2, c in enumerate(coef):
                    m = n + d * k2
                    if m > gmax: break
                    new[m] += S[n] * c
            S = new
        tab[d] = S
    _cache[key] = tab
    return tab

def cost(g, places, total_divisors_deg_g, bmax=70, lp_extra=(0, 4, 8, 12), gmax=None):
    best = None; rows = []
    tab = series_table(places, gmax or g, min(bmax, g))
    for b in range(8, min(bmax, g) + 1):
        S = tab[b]
        FB = sum(places[1:b + 1])
        pf = S[g] / total_divisors_deg_g
        if pf == 0: continue
        w = mean_factors(b, g, places, S)
        la = log2(FB) * 2 + log2(w)
        for ex in lp_extra:
            L = b + ex
            if ex == 0:
                att = FB / pf
            else:
                if L > g: continue
                NL = sum(places[b + 1:L + 1])
                pp = sum(S[g - e] * places[e] for e in range(b + 1, L + 1)) / total_divisors_deg_g
                # solve f*A + (p*A)^2/(2*NL) = FB
                a_, b_, c_ = pp * pp / (2 * NL), pf, -FB
                att = (-b_ + math.sqrt(b_ * b_ - 4 * a_ * c_)) / (2 * a_)
            tot = max(log2(att), la)
            r = dict(b=b, L=L, log2_FB=round(log2(FB), 2), log2_Psmooth=round(log2(pf), 2),
                     w=round(w, 1), log2_attempts=round(log2(att), 2), log2_LA=round(la, 2),
                     log2_total=round(tot, 2))
            rows.append(r)
            if best is None or tot < best['log2_total']: best = r
    return best, rows

if __name__ == '__main__':
    out = {}
    RHO = 60.809
    genera = [130, 160, 200, 249, 263, 300, 330, 360, 394, 420, 447, 500]
    for g in genera:
        placesP1 = Id[:g + 1] + [0] * 0
        tot = 2 ** g   # #effective degree-g divisors ~ #J * 2^{...}; for P^1-proxy use 2^g monic polys
        best, rows = cost(g, Id, tot, gmax=GMAX)
        out[g] = dict(best=best, best_noLP=min((r for r in rows if r['L'] == r['b']), key=lambda r: r['log2_total']))
        print(g, 'best', best, '\n    noLP', out[g]['best_noLP'], flush=True)
    # exact place counts of a hypothetical genus-130 C with Jac ~ A (J(F_2) has order N)
    q = 2 ** 131
    s = {0: 2, 1: -1}
    for k in range(2, 400): s[k] = -s[k - 1] - 2 * s[k - 2]
    t = s[131]
    def aA(k):
        v = -s[k]
        if k % 131 == 0:
            m = k // 131; a_, b_ = 2, t
            for _ in range(m - 1): a_, b_ = b_, t * b_ - q * a_
            v += 131 * b_
        return v
    Ck = {k: 2 ** k + 1 - aA(k) for k in range(1, 131)}
    pl = [0] + [sum(mobius(d // e) * Ck[e] for e in range(1, d + 1) if d % e == 0) // d for d in range(1, 131)]
    N = (q + 1 - t) // 4
    # number of effective divisors of degree g=130 on C: [T^130] L(T)/((1-T)(1-2T)); use the
    # exact coefficient via the Euler product up to degree 130
    Sfull = smooth_series(130, 130, pl)
    out['A_curve_g130'] = dict(places_1_to_12=pl[1:13], eff_divisors_deg130_log2=round(log2(Sfull[130]), 3),
                               log2_N=round(log2(N), 3))
    best, rows = cost(130, pl, Sfull[130])
    out['A_curve_g130']['best'] = best
    print('A-curve g=130', out['A_curve_g130'], flush=True)
    # concrete break-even genus (P^1 proxy): scan g
    be = {}
    for g in range(250, 701, 10):
        best, rows = cost(g, Id, 2 ** g, gmax=GMAX)
        be[g] = best['log2_total']
        noLP = min((r for r in rows if r['L'] == r['b']), key=lambda r: r['log2_total'])['log2_total']
        print('scan', g, best['log2_total'], noLP, flush=True)
        if best['log2_total'] > RHO + 3 and noLP > RHO + 3: break
    out['scan_best_log2'] = be
    json.dump(out, open('c_ic_cost.json', 'w'), indent=1)
