"""Cost at g=394 (and neighbours) when C carries an F_2-automorphism of order n
(n=131 for the unramified Z/131 family over a genus-4 D) acting on the target
subgroup by a known scalar: factor base and relation count shrink by n
(orbit representatives), LA by n^2.  Same concrete model as c_ic_cost.py."""
import json, math
import importlib.util
spec = importlib.util.spec_from_file_location('c', 'c_ic_cost.py'); c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
out = {}
for g in (263, 300, 350, 370, 380, 390, 394, 420, 447, 525):
    for n in (1, 131):
        best = None
        tab = c.series_table(c.Id, c.GMAX, 70)
        for b in range(8, 71):
            S = tab[b]; FB = sum(c.Id[1:b + 1]); pf = S[g] / 2 ** g
            w = c.mean_factors(b, g, c.Id, S)
            for ex in (0, 4, 8, 12):
                L = b + ex
                if ex == 0: att = FB / pf
                else:
                    NL = sum(c.Id[b + 1:L + 1]); pp = sum(S[g - e] * c.Id[e] for e in range(b + 1, L + 1)) / 2 ** g
                    a_ = pp * pp / (2 * NL / n)   # large primes also reduced to orbits
                    att = (-pf + math.sqrt(pf * pf + 4 * a_ * FB / n)) / (2 * a_)
                    att *= 1  # attempts already count relations modulo orbits
                if ex == 0: att = att / n
                tot = max(math.log2(att), 2 * math.log2(FB / n) + math.log2(w))
                if best is None or tot < best[0]: best = (round(tot, 2), b, L, round(math.log2(att), 2), round(2 * math.log2(FB / n) + math.log2(w), 2))
        out[f'g{g}_n{n}'] = dict(log2_total=best[0], b=best[1], L=best[2], log2_attempts=best[3], log2_LA=best[4])
        print(g, n, out[f'g{g}_n{n}'], flush=True)
json.dump(out, open('c2_autred.json', 'w'), indent=1)
