# Cross-check b_genus3_enum.py against Sage point counting on random samples,
# and independently recompute max #J over all SMOOTH quartics (Sage smoothness).
import json, random, sys
sys.path.insert(0, '.')
import importlib.util
spec = importlib.util.spec_from_file_location('b', 'b_genus3_enum.py')
# re-run cheaply: we only need helper functions + data, so exec the module
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
random.seed(int(20260924))
K = GF(2); P.<x> = K[]
out = {'hyp_checked': 0, 'hyp_mismatch': [], 'quart_checked': 0, 'quart_mismatch': []}
hyp_items = [(L, hf) for L, reps in b.hyp_L.items() for hf in reps]
for L, (h, f) in random.sample(hyp_items, int(60)):
    hp = P([ (h >> i) & 1 for i in range(5)]); fp = P([(f >> i) & 1 for i in range(9)])
    C = HyperellipticCurve(fp, hp)
    assert C.genus() == 3
    Ns = [len(C.change_ring(GF(2**k, 'w')).points()) if False else None for k in (1,2,3)]
    # Sage counts on the smooth model:
    Ns = C.count_points(3)
    Ls = b.lpoly(*Ns)
    out['hyp_checked'] += 1
    if tuple(Ls) != tuple(L): out['hyp_mismatch'].append((h, f, Ns, L))
R3.<X,Y,Z> = K[]
mons = b.mons
def form(cm):
    return sum(X**a*Y**bb*Z**c for j, (a, bb, c) in enumerate(mons) if (cm >> j) & 1)
smooth_J = {}
nsmooth = 0
for L, reps in b.quart_L.items():
    for cm in reps:
        F = form(cm)
        # smooth iff the ideal (F, dF/dX, dF/dY, dF/dZ) has no projective zero
        I = R3.ideal([F, F.derivative(X), F.derivative(Y), F.derivative(Z)])
        if I.dimension() == 0:   # dimension 0 of affine cone => no projective zero
            nsmooth += 1
            smooth_J[sum(L)] = smooth_J.get(sum(L), 0) + 1
            if random.random() < 0.004:
                Cq = Curve(F)
                Ns = [len(Cq.change_ring(GF(2**k, 'w')).rational_points()) for k in (1, 2, 3)]
                out['quart_checked'] += 1
                if tuple(b.lpoly(*Ns)) != tuple(L): out['quart_mismatch'].append((cm, Ns, L))
out['smooth_quartic_forms'] = nsmooth
out['smooth_quartic_max_#J'] = max(smooth_J)
out['smooth_quartic_any_131_divides_#J'] = any(j % 131 == 0 for j in smooth_J)
out['smooth_quartic_#J_values'] = sorted(smooth_J)
print(out)
json.dump(out, open('b_validate.json', 'w'), indent=1, default=str)
