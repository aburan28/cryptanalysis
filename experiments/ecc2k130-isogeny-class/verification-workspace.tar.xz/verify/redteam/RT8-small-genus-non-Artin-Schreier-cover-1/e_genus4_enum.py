"""Genus-4 curves D over F_2: which have 131 | #J(D)(F_2) (needed for an unramified
Z/131 cover C -> D with F_2-rational automorphism rho, g(C)=394), or 131 | P_D(-1)
(twisted m=2 variant, no F_2-automorphism).
Coverage: every hyperelliptic model y^2+h y=f (deg h<=5, deg f<=10) and every
canonical model Q=K=0 in P^3 with Q in {hyperbolic x0x1+x2x3, elliptic
x0x1+x2^2+x2x3+x3^2, cone x0x1+x2^2} (all geometrically irreducible quadrics over
F_2 up to PGL_4(F_2)) and K running over all cubics modulo Q*(linear forms).
L-polys come from N1..N4.  Smoothness of quadric-cubic survivors checked in Sage
separately (the filter is sound: smooth curves are counted correctly).
"""
import json, time, itertools
import numpy as np
MOD = {1: 0b11, 2: 0b111, 3: 0b1011, 4: 0b10011}
def gmul(a, b, k):
    m = MOD[k]; r = 0
    while b:
        if b & 1: r ^= a
        b >>= 1; a <<= 1
        if a >> k & 1: a ^= m
    return r
def gpow(a, e, k):
    r = 1
    while e:
        if e & 1: r = gmul(r, a, k)
        a = gmul(a, a, k); e >>= 1
    return r
def ginv(a, k): return gpow(a, (1 << k) - 2, k)
def gtr(a, k):
    s, x = 0, a
    for _ in range(k): s ^= x; x = gmul(x, x, k)
    return s
def peval(c, deg, x, k):
    r = 0
    for i in range(deg, -1, -1): r = gmul(r, x, k) ^ ((c >> i) & 1)
    return r
def pdeg(a): return a.bit_length() - 1
def pmod(a, b):
    db = pdeg(b)
    while a and pdeg(a) >= db: a ^= b << (pdeg(a) - db)
    return a
def pgcd(a, b):
    while b: a, b = b, pmod(a, b)
    return a
def pderiv(a):
    return sum(1 << (i - 1) for i in range(1, a.bit_length()) if (a >> i) & 1 and i % 2 == 1)
def psq(a): return sum(1 << (2 * i) for i in range(a.bit_length()) if (a >> i) & 1)
def pmul(a, b):
    r = 0
    while b:
        if b & 1: r ^= a
        a <<= 1; b >>= 1
    return r
def lpoly(Ns, g, q=2):
    S = [None] + [Ns[k - 1] - q ** k - 1 for k in range(1, g + 1)]
    a = [1] + [0] * g
    for k in range(1, g + 1):
        acc = sum(S[i] * a[k - i] for i in range(1, k + 1))
        assert acc % k == 0
        a[k] = acc // k
    return a + [q ** (g - i) * a[i] for i in range(g - 1, -1, -1)]
def weil_ok(L):
    r = np.roots(L[::-1]); return bool(np.all(np.abs(np.abs(r) - 2 ** -0.5) < 1e-6))
def PD_mod(L, x, p=131):
    r = 0
    for c in L: r = (r * x + c) % p
    return r

t0 = time.time()
g = 4
res = {}
# ---------- hyperelliptic ----------
hypL = {}
nh = 0
for h in range(1, 1 << 6):
    dh = psq(pderiv(h))
    for f in range(1 << 11):
        c = psq(pderiv(f)) ^ pmul(dh, f)
        if pgcd(h, c) != 1: continue
        h5 = (h >> 5) & 1
        if not h5:
            if (((f >> 9) & 1) ^ (((h >> 4) & 1) & ((f >> 10) & 1))) == 0: continue
        Ns = []
        for k in (1, 2, 3, 4):
            n = 0
            for x in range(1 << k):
                hx = peval(h, 5, x, k); fx = peval(f, 10, x, k)
                if hx == 0: n += 1
                else:
                    ih = ginv(hx, k)
                    n += 2 if gtr(gmul(fx, gmul(ih, ih, k), k), k) == 0 else 0
            n += (2 if gtr((f >> 10) & 1, k) == 0 else 0) if h5 else 1
            Ns.append(n)
        nh += 1
        hypL.setdefault(tuple(lpoly(Ns, g)), []).append((h, f))
res['hyp_smooth_models'] = nh; res['hyp_distinct_L'] = len(hypL)
print('hyp', nh, len(hypL), round(time.time() - t0, 1), flush=True)

# ---------- canonical Q = K = 0 ----------
mons3 = [e for e in itertools.product(range(4), repeat=4) if sum(e) == 3]
assert len(mons3) == 20
def qform(name, P, k):
    x0, x1, x2, x3 = P
    if name == 'hyperbolic': return gmul(x0, x1, k) ^ gmul(x2, x3, k)
    if name == 'elliptic': return gmul(x0, x1, k) ^ gmul(x2, x2, k) ^ gmul(x2, x3, k) ^ gmul(x3, x3, k)
    if name == 'cone': return gmul(x0, x1, k) ^ gmul(x2, x2, k)
def proj3(k):
    F = range(1 << k); pts = []
    for lead in range(4):
        for rest in itertools.product(F, repeat=3 - lead):
            pts.append(tuple([0] * lead + [1] + list(rest)))
    return pts
# cubic monomials modulo Q*linear: Q*x_i are 4 cubics; choose a complement of 16 monomials
# by Gaussian elimination over F_2 on monomial-coefficient vectors.
def mono_idx(e): return mons3.index(e)
def qtimes_lin(name):
    Qm = {'hyperbolic': [(1,1,0,0),(0,0,1,1)], 'elliptic': [(1,1,0,0),(0,0,2,0),(0,0,1,1),(0,0,0,2)],
          'cone': [(1,1,0,0),(0,0,2,0)]}[name]
    vecs = []
    for i in range(4):
        v = 0
        for e in Qm:
            ee = list(e); ee[i] += 1; v ^= 1 << mono_idx(tuple(ee))
        vecs.append(v)
    return vecs
quadL = {}
for name in ('hyperbolic', 'elliptic', 'cone'):
    vecs = qtimes_lin(name)
    # pivot monomials of span(Q*x_i): reduce to echelon form, drop pivots from the cubic basis
    basis = []; piv = []
    for v in vecs:
        for bv, pv in zip(basis, piv):
            if (v >> pv) & 1: v ^= bv
        if v:
            p_ = v.bit_length() - 1
            basis.append(v); piv.append(p_)
    assert len(piv) == 4
    free = [j for j in range(20) if j not in piv]
    assert len(free) == 16
    allc = np.arange(1 << 16, dtype=np.int64)
    Nk = {}
    for k in (1, 2, 3, 4):
        cnt = np.zeros(1 << 16, dtype=np.int64)
        for P in proj3(k):
            if qform(name, P, k) != 0: continue
            vals = np.zeros(1 << 16, dtype=np.int64)
            for jj, j in enumerate(free):
                e = mons3[j]
                mv = 1
                for coord, ex in zip(P, e): mv = gmul(mv, gpow(coord, ex, k), k)
                if mv: vals ^= ((allc >> jj) & 1) * mv
            cnt += (vals == 0)
        Nk[k] = cnt
    for cm in range(1, 1 << 16):
        Ns = [int(Nk[k][cm]) for k in (1, 2, 3, 4)]
        try: L = tuple(lpoly(Ns, g))
        except AssertionError: continue
        quadL.setdefault(L, []).append((name, cm))
    print('quadric', name, round(time.time() - t0, 1), flush=True)
res['canonical_forms_total'] = sum(len(v) for v in quadL.values())

def analyse(Ld, need_weil):
    J = {}; surv1 = []; surv2 = []; nL = 0
    for L, reps in Ld.items():
        if need_weil and not weil_ok(list(L)): continue
        nL += 1
        j1 = sum(L); J[j1] = J.get(j1, 0) + len(reps)
        m1 = PD_mod(L, 1) == 0 or PD_mod(L, 2) == 0
        m2 = PD_mod(L, 130) == 0 or PD_mod(L, 129) == 0
        rec = dict(L=list(L), J=j1, n_models=len(reps), rep=reps[0])
        if m1: surv1.append(rec)
        if m2: surv2.append(rec)
    return nL, J, surv1, surv2
nL, Jh, s1h, s2h = analyse(hypL, False)
res['hyp_all_weil'] = all(weil_ok(list(L)) for L in hypL)
res['hyp_max_#J'] = max(Jh); res['hyp_m1_survivors(131|#J)'] = s1h; res['hyp_m2_survivors'] = len(s2h)
nLq, Jq, s1q, s2q = analyse(quadL, True)
res['canon_weil_valid_L'] = nLq; res['canon_max_#J(weil-valid)'] = max(Jq)
res['canon_m1_survivors(131|#J)'] = s1q; res['canon_m2_survivors'] = len(s2q)
res['seconds'] = round(time.time() - t0, 1)
json.dump(res, open('e_genus4_enum.json', 'w'), indent=1, default=str)
print(json.dumps({k: (v if not isinstance(v, list) or len(v) < 6 else f'{len(v)} items') for k, v in res.items()}, indent=1, default=str))
