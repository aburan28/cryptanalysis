# Validate e_genus4_enum.py point counts against Sage on random samples, and check
# that sampled canonical models are smooth genus-4 curves.
import json, random, importlib.util
spec = importlib.util.spec_from_file_location('e', 'e_genus4_enum.py')
e = importlib.util.module_from_spec(spec); spec.loader.exec_module(e)
random.seed(int(4242))
K = GF(2); P.<x> = K[]
out = dict(hyp_checked=0, hyp_mismatch=[], canon_checked=0, canon_mismatch=[], canon_nonsmooth_skipped=0)
items = [(L, hf) for L, reps in e.hypL.items() for hf in reps]
for L, (h, f) in random.sample(items, int(40)):
    C = HyperellipticCurve(P([(f >> i) & 1 for i in range(11)]), P([(h >> i) & 1 for i in range(6)]))
    assert C.genus() == 4
    Ns = C.count_points(4)
    out['hyp_checked'] += 1
    if tuple(e.lpoly(Ns, 4)) != tuple(L): out['hyp_mismatch'].append((h, f))
R.<x0, x1, x2, x3> = K[]
Qf = {'hyperbolic': x0*x1 + x2*x3, 'elliptic': x0*x1 + x2^2 + x2*x3 + x3^2, 'cone': x0*x1 + x2^2}
free_cache = {}
def free_monos(name):
    vecs = e.qtimes_lin(name); basis = []; piv = []
    for v in vecs:
        for bv, pv in zip(basis, piv):
            if (v >> pv) & 1: v ^= bv
        if v: basis.append(v); piv.append(v.bit_length() - 1)
    return [j for j in range(20) if j not in piv]
cands = [(L, rep) for L, reps in e.quadL.items() if e.weil_ok(list(L)) for rep in reps]
tries = 0
while out['canon_checked'] < 12 and tries < 400:
    tries += 1
    L, (name, cm) = random.choice(cands)
    fr = free_monos(name)
    Kc = sum(prod(v**ex for v, ex in zip((x0, x1, x2, x3), e.mons3[j])) for jj, j in enumerate(fr) if (cm >> jj) & 1)
    I = R.ideal([Qf[name], Kc])
    if I.dimension() != 2: continue          # need a curve (affine cone dim 2)
    J = I + R.ideal(matrix(R, 2, 4, [[g.derivative(v) for v in (x0, x1, x2, x3)] for g in (Qf[name], Kc)]).minors(2))
    if J.dimension() != 0:
        out['canon_nonsmooth_skipped'] += 1; continue
    X = Curve(I.gens(), ProjectiveSpace(3, K, names='x0,x1,x2,x3'))
    if X.genus() != 4 or not X.is_irreducible(): continue
    Ns = [len(X.change_ring(GF(2**k, 'w')).rational_points()) for k in (1, 2, 3, 4)]
    out['canon_checked'] += 1
    if tuple(e.lpoly(Ns, 4)) != tuple(L): out['canon_mismatch'].append((name, cm, Ns, L))
print(out)
json.dump(out, open('e_validate.json', 'w'), indent=1, default=str)
