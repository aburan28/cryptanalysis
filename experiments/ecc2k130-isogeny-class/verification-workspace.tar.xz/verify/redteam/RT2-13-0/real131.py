"""RT2-13 on the real 131-bit class: re-verify cross-curve transport end to end on sample floor curves
with an independent explicit char-2 Velu implementation that counts field operations, check that
planted relations survive, check the Frobenius-conjugate shortcut, and recompute the level-p numbers
that decide whether B2 (conductor p, 263p) instances can join the E0 pool.
run: export TMPDIR=...; sage -python real131.py  -> real131.json"""
import sys, json, time
sys.path.insert(0, '/Volumes/SSD990/ecdlp-hardness-work/ground_truth')
import ecc2k
from sage.all import (EllipticCurve, Integer, Mod, factor, kronecker, set_random_seed, log, GF)
set_random_seed(213131)
K, curves = ecc2k.load()
N, q, t, p = Integer(ecc2k.N), Integer(ecc2k.q), Integer(ecc2k.t), Integer(ecc2k.p)
s_tau = Integer(ecc2k.TAU_EIGEN)
E0 = curves['E0']
out = {}
assert E0.a_invariants() == (1, 0, 0, 0, 1)
assert q + 1 - t == 4 * N

class Cnt:
    def __init__(s): s.M = 0; s.S = 0; s.I = 0; s.A = 0

def velu_x_kernel(Etw, cof):
    """x-coordinates of the 131 representatives of a 263-subgroup of the twist (F_q-rational)."""
    while True:
        R = Etw.random_point()
        P = cof * R
        if not P.is_zero() and (263 * P).is_zero():
            break
    xs = []; A = P
    for i in range(131):
        xs.append(A[0]); A = A + P
    return xs, P

def velu_eval(xs, x, y, c):
    """explicit char-2 Velu (a1=1,a3=0,a4=0): X = x + sum(m + m^2), Y = y + sum(m d (x m + x + y + xQ^2)),
    m = xQ d, d = 1/(x + xQ); batch inversion (Montgomery: 3(n-1) M + 1 I). Counts ops in c."""
    n = len(xs)
    den = [x + xq for xq in xs]; c.A += n
    pref = [den[0]]
    for i in range(1, n):
        pref.append(pref[-1] * den[i]); c.M += 1
    inv = ~pref[-1]; c.I += 1
    d = [None] * n
    for i in range(n - 1, 0, -1):
        d[i] = inv * pref[i - 1]; inv = inv * den[i]; c.M += 2
    d[0] = inv
    X = x; Y = y
    for i, xq in enumerate(xs):
        m = xq * d[i]; c.M += 1
        m2 = m * m; c.S += 1
        X += m + m2; c.A += 2
        xq2 = xq * xq; c.S += 1          # kernel constant (precomputable once per curve)
        Y += m * d[i] * (x * m + x + y + xq2); c.M += 3; c.A += 4
    return X, Y

labels = ['A000', 'B000', 'A077', 'B042']
recs = {}
for lab in labels:
    E = curves[lab]
    a1, a2, a3, a4, a6 = E.a_invariants()
    assert (a1, a2, a3, a4) == (1, 0, 0, 0)
    Etw = EllipticCurve(K, [1, 1, 0, 0, a6])
    ntw = q + 1 + t
    assert ntw.valuation(263) == 2
    cof = ntw // 263**2 * 263          # lands in the unique subgroup of order 263 (Sylow cyclic)
    t1 = time.time()
    xs, Pk = velu_x_kernel(Etw, cof)
    assert len(set(xs)) == 131
    t_kernel = time.time() - t1
    # codomain by explicit Velu: [1, a2, 0, v, a6 + v], v = sum xQ
    v = sum(xs)
    C = EllipticCurve(K, [1, a2, 0, v, a6 + v])
    assert C.j_invariant() == 1, 'codomain not E0'
    iso = C.isomorphism_to(E0)
    # Sage independent construction for comparison
    R = K['x']; X_ = R.gen()
    from sage.all import prod
    kp = prod(X_ - xq for xq in xs)
    psi_sage = E.isogeny(kp)
    Cs = psi_sage.codomain()
    rec = dict(kernel_seconds=round(t_kernel, 3), codomain_j_is_1=True,
               sage_codomain_equals_explicit=bool(Cs.a_invariants() == C.a_invariants()))
    iso_s = Cs.isomorphism_to(E0)
    ok_agree = True; ok_rel = True; ok_order = True; cnts = []
    for trial in range(3):
        P = 4 * E.random_point()
        kk = Integer(K.random_element().to_integer()) % N
        Q = kk * P
        c = Cnt()
        Xp, Yp = velu_eval(xs, P[0], P[1], c)
        cnts.append((c.M, c.S, c.I, c.A))
        Xq, Yq = velu_eval(xs, Q[0], Q[1], Cnt())
        psiP = iso(C(Xp, Yp)); psiQ = iso(C(Xq, Yq))
        ok_agree &= (iso_s(psi_sage(P)) == psiP) or (iso_s(psi_sage(P)) == -psiP)
        ok_rel &= (psiQ == kk * psiP)
        ok_order &= (not psiP.is_zero()) and (N * psiP).is_zero()
    rec.update(explicit_matches_sage_up_to_sign=bool(ok_agree), planted_relation_preserved=bool(ok_rel),
               image_has_order_N=bool(ok_order), ops_per_point_M_S_I_A=cnts[0],
               ops_per_point_excluding_kernel_constants=dict(M=cnts[0][0], S=cnts[0][1] - 131, I=1))
    # cross-curve: two independent bases land on unrelated E0 points (their ratio is an extra unknown)
    recs[lab] = rec
    print(lab, rec, flush=True)
out['transport_checks'] = recs

# Frobenius-conjugate shortcut: A_k(F_q) -> A_0(F_q), (x,y) -> (x^(2^(131-k)), y^(2^(131-k))) is a group iso
E5 = curves['A005']; E0A = curves['A000']
P = 4 * E5.random_point(); kk = Integer(K.random_element().to_integer()) % N; Q = kk * P
def frob_inv(Pt, kidx):
    e = 131 - kidx
    return E0A(Pt[0]**(2**e), Pt[1]**(2**e))
out['frobenius_shortcut_A005_to_A000'] = dict(relation_preserved=bool(frob_inv(Q, 5) == kk * frob_inv(P, 5)),
                                               squarings_per_point=2 * (131 - 5))

# E0 rho baselines and the level-p obstruction numbers
cls = (N - 1) // 262
out['E0_classes'] = str(cls)
c_p = Mod(t, p) / 2
assert c_p**2 == Mod(q, p)
r = c_p.multiplicative_order()
out['level_p'] = dict(kronecker_minus7_p=int(kronecker(-7, p)), h_O_p=str(p - kronecker(-7, p)),
                      p_minus_1=str(factor(p - 1)), ord_t_over_2_mod_p=str(r), log2_r=float(log(r, 2)),
                      r_even=bool(r % 2 == 0),
                      note='E0[p] and the ascending p-kernel of any level-p curve are defined over F_{q^r}; x over F_{q^(r/2)} if r even')
out['kronecker_minus7_263'] = int(kronecker(-7, 263))
json.dump(out, open('real131.json', 'w'), indent=1, default=str)
print(json.dumps(out, indent=1, default=str))
