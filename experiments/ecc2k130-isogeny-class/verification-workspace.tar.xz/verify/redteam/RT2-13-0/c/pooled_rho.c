/* RT2-13 toy: pooled (Kuhn-Struik sequential) multi-target Pollard rho on a binary Koblitz curve
 *   E0: y^2 + x y = x^3 + a2 x^2 + b over F_{2^n}, n <= 63, polynomial basis F_2[z]/(z^n + low(z)),
 * walking on classes {+-tau^i W} (tau = F_2-Frobenius), additive walk with r steps R_j = [c_j]G,
 * Wiener-Zuccherato/BKL look-ahead against fruitless 2-cycles, distinguished points (DP),
 * walks capped at CAPMUL/theta steps (then abandoned; the steps still count as work).
 *
 * Modes
 *   pooled_rho synth <params> <seed> <U> <dbits> <trials>
 *        U uniform random targets T_i = [u_i]G (u_i known only for the final check), solved in
 *        sequence with every earlier DP kept (KS 2001).  One JSON line per trial.
 *   pooled_rho file  <params> <targets> <seed> <dbits>
 *        targets from a file (lines: id x_hex y_hex), solved in file order; prints logs.
 * params file: n, low_hex, a2_hex, b_hex, N, s, Gx_hex, Gy_hex (one per line; N, s decimal)
 * Every recovered log x_T is checked by recomputing [x_T]G == T.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#if defined(__aarch64__)
#include <arm_neon.h>
#endif
typedef uint64_t u64; typedef unsigned __int128 u128;

static int NBITS; static u64 MASK, LOW, A2, B6, NORD, SEIG;
static u64 SPOW[64];                    /* s^i mod N */

static inline u128 clmul(u64 a, u64 b) {
#if defined(__aarch64__) && defined(__ARM_FEATURE_AES)
    return (u128)vmull_p64((poly64_t)a, (poly64_t)b);
#else
    u128 r = 0; for (int i = 0; i < 64; i++) if ((b >> i) & 1) r ^= ((u128)a) << i; return r;
#endif
}
static inline u64 fred(u128 v) {
    u64 lo = (u64)v & MASK; u128 hi = v >> NBITS;
    while (hi) { u128 t = clmul((u64)hi, LOW); lo ^= (u64)t & MASK; hi = t >> NBITS; lo &= MASK; }
    return lo;
}
static inline u64 fmul(u64 a, u64 b) { return fred(clmul(a, b)); }
static inline u64 fsqr(u64 a) { return fred(clmul(a, a)); }
static inline u64 fsqrn(u64 a, int k) { while (k--) a = fsqr(a); return a; }
static u64 finv(u64 a) {                 /* a^(2^n - 2) via Itoh-Tsujii on n-1 */
    int m = NBITS - 1; u64 b = a; int e = 1;          /* b = a^(2^e - 1) */
    int bits[64], nb = 0; for (int t = m; t > 1; t >>= 1) bits[nb++] = t & 1;
    for (int i = nb - 1; i >= 0; i--) {
        b = fmul(fsqrn(b, e), b); e *= 2;
        if (bits[i]) { b = fmul(fsqr(b), a); e += 1; }
    }
    return fsqr(b);
}
static inline u64 mulmod(u64 a, u64 b) { return (u64)(((u128)a * b) % NORD); }
static inline u64 addmod(u64 a, u64 b) { u64 c = a + b; return c >= NORD ? c - NORD : c; }
static u64 powmod(u64 a, u64 e) { u64 r = 1; while (e) { if (e & 1) r = mulmod(r, a); a = mulmod(a, a); e >>= 1; } return r; }
static u64 invmod(u64 a) { return powmod(a, NORD - 2); }

typedef struct { u64 x, y; int inf; } pt;
static pt padd(pt P, pt Q) {
    if (P.inf) return Q; if (Q.inf) return P;
    pt R; R.inf = 0;
    if (P.x == Q.x) {
        if (P.y != Q.y || P.x == 0) { R.inf = 1; R.x = R.y = 0; return R; }   /* P = -Q */
        u64 l = P.x ^ fmul(P.y, finv(P.x));
        R.x = fsqr(l) ^ l ^ A2; R.y = fsqr(P.x) ^ fmul(l ^ 1, R.x); return R;
    }
    u64 l = fmul(P.y ^ Q.y, finv(P.x ^ Q.x));
    R.x = fsqr(l) ^ l ^ P.x ^ Q.x ^ A2; R.y = fmul(l, P.x ^ R.x) ^ R.x ^ P.y; return R;
}
static pt pmul(pt P, u64 k) { pt R = {0, 0, 1}; while (k) { if (k & 1) R = padd(R, P); P = padd(P, P); k >>= 1; } return R; }
static int oncurve(pt P) { if (P.inf) return 1; u64 x = P.x, y = P.y;
    return (fsqr(y) ^ fmul(x, y)) == (fmul(fsqr(x), x) ^ fmul(A2, fsqr(x)) ^ B6); }

/* canonical representative of {+-tau^i P}; returns multiplier (+-s^i mod N) */
static u64 canon(pt *P) {
    u64 x = P->x, best = x; int bi = 0;
    for (int i = 1; i < NBITS; i++) { x = fsqr(x); if (x < best) { best = x; bi = i; } }
    u64 y = fsqrn(P->y, bi); u64 mult = SPOW[bi];
    u64 y2 = y ^ best;                    /* -(x,y) = (x, x+y) */
    if (y2 < y) { y = y2; mult = mult ? NORD - mult : 0; }
    P->x = best; P->y = y; return mult;
}

static u64 rs[2];
static inline u64 rnd(void) { u64 s1 = rs[0]; const u64 s0 = rs[1]; rs[0] = s0; s1 ^= s1 << 23;
    rs[1] = s1 ^ s0 ^ (s1 >> 17) ^ (s0 >> 26); return rs[1] + s0; }
static u64 rndmod(void) { return (u64)(((u128)rnd() * NORD) >> 64); }

#define RSTEPS 1024
static pt Rst[RSTEPS]; static u64 Rc[RSTEPS];
static inline unsigned hsh(u64 x) { return (unsigned)((x * 0x9E3779B97F4A7C15ULL) >> 54) & (RSTEPS - 1); }
static int DBITS;
static inline int isdp(u64 x) { return (((x * 0xC2B2AE3D27D4EB4FULL) >> 40) & ((1ULL << DBITS) - 1)) == 0; }

/* DP hash table */
typedef struct { u64 x, y, a, b; int tid; int used; } ent;
static ent *TAB; static u64 TCAP, TCNT;
static void tab_reset(void) { memset(TAB, 0, sizeof(ent) * TCAP); TCNT = 0; }
static ent *tab_find(u64 x, u64 y, int *found) {
    u64 i = (x * 0xff51afd7ed558ccdULL) & (TCAP - 1);
    while (TAB[i].used) { if (TAB[i].x == x && TAB[i].y == y) { *found = 1; return &TAB[i]; } i = (i + 1) & (TCAP - 1); }
    *found = 0; return &TAB[i];
}

static pt G; static pt GP[64];
#define SSTART 4096
static pt Sst[SSTART]; static u64 Sc[SSTART];
/* random start T + S[i1] + ... + S[i4] (S = 4096 random multiples of G, fresh per trial) */
static pt start_point(pt T, u64 *r) { pt W = T; u64 a = 0;
    for (int k = 0; k < 4; k++) { unsigned i = (unsigned)(rnd() >> 52); W = padd(W, Sst[i]); a = addmod(a, Sc[i]); }
    *r = a; return W; }

#define CAPMUL 40
typedef struct { u64 iters, lookahead, walks, abandoned, selfcoll, crosscoll; } stats;

/* solve target index ti (point T); logs[] holds logs of solved targets. returns log */
static u64 solve_one(pt T, int ti, u64 *logs, stats *st) {
    u64 cap = (u64)CAPMUL << DBITS;
    for (;;) {
        u64 r; pt W = start_point(T, &r);
        if (W.inf) continue;
        u64 a = r, b = 1; u64 m = canon(&W); a = mulmod(a, m); b = mulmod(b, m);
        u64 steps = 0; int bad = 0;
        st->walks++;
        while (!isdp(W.x)) {
            unsigned j = hsh(W.x); pt W1; u64 m1; int tries = 0;
            for (;;) {
                W1 = padd(W, Rst[j]);
                if (W1.inf) { bad = 1; break; }
                m1 = canon(&W1);
                if (hsh(W1.x) != j || ++tries >= RSTEPS) break;
                j = (j + 1) & (RSTEPS - 1); st->lookahead++;
            }
            if (bad) break;
            a = mulmod(addmod(a, Rc[j]), m1); b = mulmod(b, m1); W = W1;
            if (++steps > cap) { bad = 1; break; }
        }
        st->iters += steps;
        if (bad) { st->abandoned++; continue; }
        int found; ent *e = tab_find(W.x, W.y, &found);
        if (!found) { e->used = 1; e->x = W.x; e->y = W.y; e->a = a; e->b = b; e->tid = ti; TCNT++;
            if (TCNT * 2 > TCAP) { fprintf(stderr, "table full\n"); exit(3); } continue; }
        u64 xt;
        if (e->tid == ti) {                /* a + b x = e.a + e.b x */
            if (e->b == b) continue;        /* same trail, useless */
            xt = mulmod((e->a + NORD - a) % NORD, invmod((b + NORD - e->b) % NORD)); st->selfcoll++;
        } else {                            /* e belongs to a solved target: value v = e.a + e.b log */
            u64 v = addmod(e->a, mulmod(e->b, logs[e->tid]));
            xt = mulmod((v + NORD - a) % NORD, invmod(b)); st->crosscoll++;
        }
        pt C = pmul(G, xt);
        if (C.inf || C.x != T.x || C.y != T.y) { fprintf(stderr, "VERIFY FAIL ti=%d\n", ti); exit(4); }
        return xt;
    }
}

static void read_params(const char *fn) {
    FILE *f = fopen(fn, "r"); if (!f) { perror(fn); exit(1); }
    unsigned long long n, low, a2, b6, N, s, gx, gy;
    if (fscanf(f, "%llu %llx %llx %llx %llu %llu %llx %llx", &n, &low, &a2, &b6, &N, &s, &gx, &gy) != 8) { fprintf(stderr, "bad params\n"); exit(1); }
    fclose(f);
    NBITS = (int)n; MASK = (NBITS == 64) ? ~0ULL : ((1ULL << NBITS) - 1); LOW = low; A2 = a2; B6 = b6; NORD = N; SEIG = s;
    G.x = gx; G.y = gy; G.inf = 0;
    if (!oncurve(G)) { fprintf(stderr, "G not on curve\n"); exit(2); }
    if (!pmul(G, NORD).inf) { fprintf(stderr, "G order != N\n"); exit(2); }
    pt tG = {fsqr(G.x), fsqr(G.y), 0}, sG = pmul(G, SEIG);
    if (tG.x != sG.x || tG.y != sG.y) { fprintf(stderr, "tau eigenvalue mismatch\n"); exit(2); }
    SPOW[0] = 1; for (int i = 1; i < 64; i++) SPOW[i] = mulmod(SPOW[i - 1], SEIG);
    if (SPOW[NBITS] != 1) { fprintf(stderr, "s^n != 1\n"); exit(2); }
    GP[0] = G; for (int i = 1; i < 64; i++) GP[i] = padd(GP[i - 1], GP[i - 1]);
}
static void setup_steps(void) { for (int j = 0; j < RSTEPS; j++) { Rc[j] = rndmod(); Rst[j] = pmul(G, Rc[j]); }
    for (int j = 0; j < SSTART; j++) { Sc[j] = rndmod(); Sst[j] = pmul(G, Sc[j]); } }

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage\n"); return 1; }
    TCAP = 1ULL << 24; TAB = malloc(sizeof(ent) * TCAP);
    if (!strcmp(argv[1], "synth")) {
        read_params(argv[2]); u64 seed = strtoull(argv[3], 0, 10); int U = atoi(argv[4]); DBITS = atoi(argv[5]); int trials = atoi(argv[6]);
        rs[0] = seed * 0x9E3779B97F4A7C15ULL + 1; rs[1] = seed ^ 0x1234567887654321ULL; for (int i = 0; i < 20; i++) rnd();
        u64 *logs = malloc(8 * U), *per = malloc(8 * U); pt *T = malloc(sizeof(pt) * U); u64 *u = malloc(8 * U);
        for (int tr = 0; tr < trials; tr++) {
            setup_steps(); tab_reset();
            for (int i = 0; i < U; i++) { do u[i] = rndmod(); while (!u[i]); T[i] = pmul(G, u[i]); }
            stats st = {0}; clock_t c0 = clock();
            for (int i = 0; i < U; i++) { u64 before = st.iters; logs[i] = solve_one(T[i], i, logs, &st); per[i] = st.iters - before;
                if (logs[i] != u[i]) { fprintf(stderr, "log mismatch\n"); return 5; } }
            double sec = (double)(clock() - c0) / CLOCKS_PER_SEC;
            printf("{\"U\":%d,\"dbits\":%d,\"seed\":%llu,\"trial\":%d,\"total\":%llu,\"lookahead\":%llu,\"walks\":%llu,\"abandoned\":%llu,\"selfcoll\":%llu,\"crosscoll\":%llu,\"dps\":%llu,\"cpu_s\":%.3f,\"per\":[",
                   U, DBITS, (unsigned long long)seed, tr, (unsigned long long)st.iters, (unsigned long long)st.lookahead, (unsigned long long)st.walks,
                   (unsigned long long)st.abandoned, (unsigned long long)st.selfcoll, (unsigned long long)st.crosscoll, (unsigned long long)TCNT, sec);
            for (int i = 0; i < U; i++) printf("%s%llu", i ? "," : "", (unsigned long long)per[i]);
            printf("]}\n"); fflush(stdout);
        }
    } else if (!strcmp(argv[1], "file")) {
        read_params(argv[2]); FILE *f = fopen(argv[3], "r"); u64 seed = strtoull(argv[4], 0, 10); DBITS = atoi(argv[5]);
        rs[0] = seed * 0x9E3779B97F4A7C15ULL + 1; rs[1] = seed ^ 0x1234567887654321ULL; for (int i = 0; i < 20; i++) rnd();
        int cap = 4096, U = 0; pt *T = malloc(sizeof(pt) * cap); char (*ids)[64] = malloc(64 * cap);
        unsigned long long x, y; char id[64];
        while (fscanf(f, "%63s %llx %llx", id, &x, &y) == 3) { T[U].x = x; T[U].y = y; T[U].inf = 0;
            if (!oncurve(T[U]) || !pmul(T[U], NORD).inf) { fprintf(stderr, "target %s not in <G>\n", id); return 6; }
            strcpy(ids[U], id); U++; }
        setup_steps(); tab_reset();
        u64 *logs = malloc(8 * U); stats st = {0};
        printf("{\"U\":%d,\"dbits\":%d,\"results\":[", U, DBITS);
        for (int i = 0; i < U; i++) { u64 before = st.iters; logs[i] = solve_one(T[i], i, logs, &st);
            printf("%s{\"id\":\"%s\",\"log\":\"%llu\",\"iters\":%llu}", i ? "," : "", ids[i], (unsigned long long)logs[i], (unsigned long long)(st.iters - before)); }
        printf("],\"total\":%llu,\"walks\":%llu,\"abandoned\":%llu,\"lookahead\":%llu,\"selfcoll\":%llu,\"crosscoll\":%llu}\n", (unsigned long long)st.iters,
               (unsigned long long)st.walks, (unsigned long long)st.abandoned, (unsigned long long)st.lookahead, (unsigned long long)st.selfcoll, (unsigned long long)st.crosscoll);
    }
    return 0;
}
