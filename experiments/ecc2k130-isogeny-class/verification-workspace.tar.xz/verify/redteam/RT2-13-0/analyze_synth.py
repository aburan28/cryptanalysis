"""RT2-13: aggregate the n=41 toy pooled-rho runs (synth/*.jsonl) and compare with Kuhn-Struik.
run: python3 analyze_synth.py -> synth_summary.json"""
import json, glob, math, collections
P = json.load(open('toy_params.json'))
N = int(P['N']); l = (N - 1) // 82
rho1 = math.sqrt(math.pi * l / 2)
def S(U):
    s, term = 0.0, 1.0
    for i in range(U):
        s += term; term *= (2 * i + 1) / (2 * i + 2)
    return s
runs = collections.defaultdict(list)
for fn in glob.glob('synth/*.jsonl'):
    for line in open(fn):
        line = line.strip()
        if line:
            r = json.loads(line); runs[r['U']].append(r)
out = dict(N=N, classes=l, rho1=rho1, dbits=5, per_U={}, note="mean_total counts every visited point (walk steps + walk start points); KS predicts visited points. mean_first/mean_last count steps only.")
first = []
aband = walks = look = iters = 0
for U in sorted(runs):
    R = runs[U]; tot = [r['total'] + r['walks'] for r in R]      # points visited = steps + walk start points
    m = sum(tot) / len(tot); sd = math.sqrt(sum((x - m) ** 2 for x in tot) / (len(tot) - 1)) if len(tot) > 1 else float('nan')
    pred = rho1 * S(U); pred_dp = pred + U * 2 ** 5
    first += [r['per'][0] for r in R]
    for r in R:
        aband += r['abandoned']; walks += r['walks']; look += r['lookahead']; iters += r['total']
    per_mean = [sum(r['per'][i] for r in R) / len(R) for i in range(U)]    # steps only (start points not included)
    steps_only = sum(r['total'] for r in R) / len(R)
    out['per_U'][U] = dict(trials=len(R), mean_steps_only=round(steps_only, 1), mean_total=round(m, 1), se=round(sd / math.sqrt(len(R)), 1),
                           ks_pred=round(pred, 1), ks_plus_dp_pred=round(pred_dp, 1),
                           ratio_measured_over_ks_dp=round(m / pred_dp, 4),
                           z_vs_ks_dp=round((m - pred_dp) / (sd / math.sqrt(len(R))), 2) if len(R) > 1 else None,
                           mean_first=round(per_mean[0], 1), mean_last=round(per_mean[-1], 1),
                           ks_last=round(rho1 * math.comb(2 * (U - 1), U - 1) / 4 ** (U - 1), 1),
                           mean_cpu_s=round(sum(r['cpu_s'] for r in R) / len(R), 3))
    print(U, out['per_U'][U])
mf = sum(first) / len(first); sdf = math.sqrt(sum((x - mf) ** 2 for x in first) / (len(first) - 1))
out['first_instance'] = dict(n=len(first), mean=round(mf, 1), se=round(sdf / math.sqrt(len(first)), 1),
                             ks_E0=round(rho1, 1), ks_E0_plus_dp=round(rho1 + 32, 1))
out['walk_stats'] = dict(iterations=iters, walks=walks, abandoned_walks=aband, lookahead_extra_adds=look,
                         lookahead_fraction=look / iters, visited_over_steps=(iters + walks) / iters)
out['first_instance']['mean_visited_est'] = round(mf * (iters + walks) / iters, 1)
# cross-curve penalty: independent bases -> U = 2L-1 instead of L
pen = {}
for L in (8, 32, 64):
    if L in out['per_U'] and 2 * L - 1 in out['per_U']:
        a = out['per_U'][L]; b = out['per_U'][2 * L - 1]
        rm = b['mean_total'] / a['mean_total']
        rse = rm * math.sqrt((a['se'] / a['mean_total']) ** 2 + (b['se'] / b['mean_total']) ** 2)
        pen[L] = dict(measured_ratio=round(rm, 4), se=round(rse, 4), ks_ratio=round(S(2 * L - 1) / S(L), 4),
                      measured_bits=round(math.log2(rm), 3), ks_bits=round(math.log2(S(2 * L - 1) / S(L)), 3))
out['independent_base_penalty'] = pen
# amortized law: log2(total/L) vs claimed log2(rho1) - 0.5 log2 L
law = {}
for U, d in out['per_U'].items():
    law[U] = dict(measured_amortized_log2=round(math.log2(d['mean_total'] / U), 3),
                  claimed_log2=round(math.log2(rho1) - 0.5 * math.log2(U), 3),
                  excess_bits=round(math.log2(d['mean_total'] / U) - (math.log2(rho1) - 0.5 * math.log2(U)), 3),
                  separate_log2=round(math.log2(rho1), 3))
out['amortized_law'] = law
json.dump(out, open('synth_summary.json', 'w'), indent=1)
print(json.dumps({k: out[k] for k in ('first_instance', 'walk_stats', 'independent_base_penalty', 'amortized_law')}, indent=1))
