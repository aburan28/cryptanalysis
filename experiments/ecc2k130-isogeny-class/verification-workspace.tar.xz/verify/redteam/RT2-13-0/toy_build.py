"""RT2-13 toy, stage 1: build floor curves of the 409-volcano of the n=41 Koblitz toy E0 and their
ascending (transport) isogenies psi_i : E_i -> E0, all defined over F_q, q = 2^41.
E0: y^2+xy=x^3+1 over k41 = F_2[z]/(z^41+z^3+1); t = -2308219, #E0 = 4N, N prime (39 bits),
t^2-4q = -7 f^2, f = 409*1721; pi acts on E0[409] as the scalar c = t/2 mod 409 (order 408), so
E0[409] lies in the quadratic twist of E0 over F_{q^204} and every one of the 410 409-isogenies of
E0 is F_q-rational and descends (kronecker(-7,409) = -1).  The ascending kernel on a floor curve is
the unique pi-eigenline, again x-rational over F_{q^204} on the twist.
run: sage -python toy_build.py   (writes toy_build.json, toy_build.sobj)"""
import json, time, sys
from sage.all import (GF, PolynomialRing, EllipticCurve, Integer, matrix, vector, set_random_seed,
                      save, prod, Mod)
set_random_seed(20260924)
T0 = time.time()
log = {}
R2 = PolynomialRing(GF(2), 'x'); X = R2.gen()
m41 = X**41 + X**3 + 1
k = GF(2**41, 'z', modulus=m41); z = k.gen()
E0 = EllipticCurve(k, [1, 0, 0, 0, 1])
n, ell, kx = 41, 409, 204
def trace_k(kk, t1=-1):
    a, b = Integer(2), Integer(t1)
    for _ in range(kk - 1):
        a, b = b, t1 * b - 2 * a
    return b
t = trace_k(n); q = Integer(2)**n; N = (q + 1 - t) // 4
assert E0.order() == 4 * N and N.is_prime()
c = Mod(t, ell) / 2
assert c.multiplicative_order() == 408 and c**2 == Mod(q, ell)
# big field F = F_{q^204}
F = GF(2**(n * kx), 'w'); w = F.gen()
log['F_modulus_terms'] = int(F.modulus().number_of_terms())
# embedding k -> F: rho = root of m41 in F
t1 = time.time()
e = (2**(n * kx) - 1) // (2**n - 1)
while True:
    g = F.random_element()**e
    conj = [g]
    for i in range(1, n):
        conj.append(conj[-1]**2)
    if conj[1] != g:
        break
PF = PolynomialRing(F, 'Y'); Y = PF.gen()
mu = prod(Y - cj for cj in conj)
mu2 = R2([Integer(int(cf == 1)) if cf in (F(0), F(1)) else None for cf in mu.list()])
assert mu2.degree() == 41 and mu2.is_irreducible()
kp = GF(2**41, 'u', modulus=mu2)
rp = m41.change_ring(kp).roots(multiplicities=False)[0]
rho = rp.polynomial().change_ring(F)(g)
assert rho**41 + rho**3 + 1 == 0
def emb(a):
    return a.polynomial().change_ring(F)(rho)
# section: F-subfield element -> k via linear algebra over GF(2)
def fvec(a):
    L = a.polynomial().list(); L += [0] * (n * kx - len(L)); return vector(GF(2), L)
M = matrix(GF(2), [fvec(rho**i) for i in range(n)])
piv = M.pivots(); Msub = M.matrix_from_columns(piv); Minv = Msub.inverse()
def sec(a):
    v = fvec(a); sol = vector(GF(2), [v[j] for j in piv]) * Minv
    assert sol * M == v, "element not in subfield"
    return k(R2(list(sol)))
aa = k.random_element(); assert sec(emb(aa)) == aa
log['embedding_seconds'] = round(time.time() - t1, 2)
print('embedding done', time.time() - T0, flush=True)
# quadratic twist of E0 over F
while True:
    delta = F.random_element()
    if delta.trace() == 1:
        break
tb = trace_k(n * kx); card_tw = 2**(n * kx) + 1 + tb
assert card_tw.valuation(ell) == 2
cof = card_tw // ell**2
E0t = EllipticCurve(F, [1, delta, 0, 0, 1])
t1 = time.time()
# Sage's random_point and PARI-backed scalar multiplication are very slow over F_{2^8364};
# use an explicit Artin-Schreier solver and plain double-and-add instead.
mF = n * kx
while True:
    tau_ = F.random_element()
    if tau_.trace() == 1:
        break
_tp = [tau_]
for _j in range(1, mF):
    _tp.append(_tp[-1]**2)
_suf = [F(0)] * (mF + 1)
for _j in range(mF - 1, -1, -1):
    _suf[_j] = _suf[_j + 1] + _tp[_j]
def solve_as(cc):                  # u^2 + u = cc, Tr(cc) = 0, even-degree field
    u = F(0); ci = cc
    for i in range(mF - 1):
        u += ci * _suf[i + 1]; ci = ci**2
    assert u**2 + u == cc
    return u
def rpoint(E):
    a1_, a2_, a3_, a4_, a6_ = E.a_invariants()
    assert a1_ == 1 and a3_ == 0
    while True:
        xx = F.random_element()
        if xx == 0:
            continue
        cc = xx + a2_ + a4_ / xx + a6_ / xx**2       # y = x u: u^2 + u = x + a2 + a4/x + a6/x^2
        if cc.trace() != 0:
            continue
        return E(xx, xx * solve_as(cc))
def smul(m_, P_):
    R_ = P_.curve()(0); A_ = P_
    m_ = Integer(m_)
    while m_:
        if m_ & 1:
            R_ = R_ + A_
        A_ = A_ + A_; m_ >>= 1
    return R_
def tors_point(E, cof):
    while True:
        P = smul(cof, rpoint(E))
        if not P.is_zero():
            return P
P = tors_point(E0t, cof); assert smul(ell, P).is_zero()
print('P found', time.time() - T0, flush=True)
xsP = set((i * P)[0] for i in range(1, 205))
while True:
    Q = tors_point(E0t, cof)
    if Q[0] not in xsP:
        break
log['E0_409_basis_seconds'] = round(time.time() - t1, 2)
print('basis', log, flush=True)
def kernel_poly_from(Pk, Ebig):
    xs = []; A = Pk
    for i in range(1, (ell - 1) // 2 + 1):
        xs.append(A[0]); A = A + Pk
    Kbig = prod(Y - xx for xx in xs)
    return PolynomialRing(k, 'x')([sec(cf) for cf in Kbig.list()])
# floor curves from kernels <Q + j P>, j in JS
JS = [0, 1, 2, 3]
curves = []
for jj in JS:
    t1 = time.time()
    Kp = kernel_poly_from(Q + jj * P, E0t)
    phi = E0.isogeny(Kp)
    E1 = phi.codomain()
    j1 = E1.j_invariant()
    rec = dict(kernel='Q+%dP' % jj, a_invs=[hex(Integer(a.to_integer())) for a in E1.a_invariants()],
               j=hex(Integer(j1.to_integer())), j_min_poly_degree=int(j1.minimal_polynomial().degree()),
               order_equals_4N=bool(E1.order() == 4 * N), iso_to_E0=bool(E1.is_isomorphic(E0)))
    # ascending kernel: F_q-structure on E1's twist over F
    a1, a2, a3, a4, a6 = E1.a_invariants()
    E1t = EllipticCurve(F, [emb(a1), emb(a2) + delta, emb(a3), emb(a4), emb(a6)])
    R1 = tors_point(E1t, cof)
    if not smul(ell, R1).is_zero():
        R1 = smul(ell, R1)
    assert not R1.is_zero() and smul(ell, R1).is_zero()
    rec['E1_twist_409_sylow_cyclic_order_409^2'] = bool(not smul(ell, tors_point(E1t, cof)).is_zero())
    print(' ascending kernel point found', time.time() - t1, flush=True)
    K2 = kernel_poly_from(R1, E1t)
    psi0 = E1.isogeny(K2)
    Ctgt = psi0.codomain()
    assert Ctgt.j_invariant() == 1
    iso = Ctgt.isomorphism_to(E0)
    psi = iso * psi0
    # checks: psi o phi = [+-409] on E0, planted relation preserved
    G = 4 * E0.random_point()
    img = psi(phi(G))
    rec['psi_phi_is_pm409'] = bool(img == ell * G or img == -ell * G)
    P1 = 4 * E1.random_point(); kk = Integer(k.random_element().to_integer()) % N
    rec['planted_relation_preserved'] = bool(psi(kk * P1) == kk * psi(P1))
    rec['psi_P_order_N'] = bool((N * psi(P1)).is_zero() and not psi(P1).is_zero())
    rec['build_seconds'] = round(time.time() - t1, 2)
    t2 = time.time()
    for _ in range(20):
        psi(P1)
    rec['sage_eval_seconds'] = round((time.time() - t2) / 20, 5)
    curves.append(dict(rec=rec, E1=E1, psi=psi, kernel_psi=K2))
    print(jj, rec, flush=True)
log['curves'] = [cv['rec'] for cv in curves]
log['total_seconds'] = round(time.time() - T0, 1)
json.dump(log, open('toy_build.json', 'w'), indent=1)
save(dict(E1s=[cv['E1'] for cv in curves], K2s=[cv['kernel_psi'] for cv in curves]), 'toy_build.sobj')
print(json.dumps(log, indent=1))
