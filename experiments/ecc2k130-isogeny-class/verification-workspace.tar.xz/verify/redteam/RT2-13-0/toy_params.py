"""Write params for the n=41 toy E0: y^2+xy=x^3+1 over F_2[z]/(z^41+z^3+1). run: sage -python toy_params.py"""
import json
from sage.all import GF, PolynomialRing, EllipticCurve, Integer, Mod, set_random_seed
set_random_seed(4113)
R = PolynomialRing(GF(2), 'x'); x = R.gen()
k = GF(2**41, 'z', modulus=x**41 + x**3 + 1); z = k.gen()
E0 = EllipticCurve(k, [1, 0, 0, 0, 1])
card = E0.order(); N = card // 4
assert N.is_prime() and card == 4 * N
while True:
    G = 4 * E0.random_point()
    if not G.is_zero(): break
roots = [Integer(r) for r in (R.change_ring(GF(N))([2, 1, 1])).roots(multiplicities=False)]  # s^2+s+2
tG = E0(G[0]**2, G[1]**2)
s = [r for r in roots if r * G == tG]; assert len(s) == 1; s = s[0]
assert Mod(s, N).multiplicative_order() == 41
toint = lambda e: Integer(e.to_integer()) if hasattr(e, 'to_integer') else Integer(e.integer_representation())
open('toy_params.txt', 'w').write('41\n9\n0\n1\n%d\n%d\n%x\n%x\n' % (N, s, toint(G[0]), toint(G[1])))
json.dump(dict(n=41, modulus='z^41+z^3+1', N=str(N), card=str(card), s=str(s), classes=str((N - 1) // 82),
               Gx=hex(toint(G[0])), Gy=hex(toint(G[1]))), open('toy_params.json', 'w'), indent=1)
print(open('toy_params.txt').read())
