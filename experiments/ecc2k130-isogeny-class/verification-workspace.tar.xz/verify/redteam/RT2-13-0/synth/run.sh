#!/bin/bash
# one job: U seed trials -> synth/U<U>_s<seed>.jsonl (dbits 5)
cd /Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-13-0
timeout 2400 ./c/pooled_rho synth toy_params.txt $2 $1 5 $3 > synth/U$1_s$2.jsonl 2> synth/U$1_s$2.err
