import time
from sage.all import GF, PolynomialRing, EllipticCurve, Integer, factor, Mod, ZZ
R = PolynomialRing(GF(2), 'x'); x = R.gen()
m41 = x**41 + x**3 + 1
print('x^41+x^3+1 irreducible:', m41.is_irreducible())
n = 41; ell = 409
# traces of pi^k via Lucas: t_k = t1 t_{k-1} - 2 t_{k-2}
t1 = -1
def trace_k(k):
    a, b = Integer(2), Integer(t1)
    if k == 0: return a
    for _ in range(k - 1):
        a, b = b, t1 * b - 2 * a
    return b
t = trace_k(n); q = Integer(2)**n
print('t', t, '#E', q + 1 - t, factor(q + 1 - t))
c = Mod(t, ell) / 2
print('c', c, 'ord', c.multiplicative_order())
k = 204
tk = trace_k(n * k)
qk = Integer(2)**(n * k)
tw = qk + 1 + tk
print('v_409(#twist over F_q^204)', tw.valuation(ell), 'v_409(#E over F_q^204)', (qk + 1 - tk).valuation(ell))
t0 = time.time()
F = GF(2**(n * k), 'w')
print('big field built', time.time() - t0, F.modulus().number_of_terms())
a = F.random_element(); b = F.random_element()
t0 = time.time()
for _ in range(100): c2 = a * b
print('mul us', (time.time() - t0) / 100 * 1e6)
t0 = time.time()
for _ in range(20): c2 = ~a
print('inv us', (time.time() - t0) / 20 * 1e6)
