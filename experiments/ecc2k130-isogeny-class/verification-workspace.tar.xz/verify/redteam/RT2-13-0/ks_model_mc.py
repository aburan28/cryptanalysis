"""Monte Carlo of the idealised birthday model behind Kuhn-Struik: with T points already stored
(n classes), the next target's walk survives k steps with probability exp(-(T k + k^2/2)/n).
Compares E[T_U]/sqrt(n) with the KS closed form sqrt(pi/2) * sum_{i<U} C(2i,i)/4^i.
run: python3 ks_model_mc.py -> ks_model_mc.json"""
import random, math, json
random.seed(213)
n = 1.0
def S(U):
    s, term = 0.0, 1.0
    for i in range(U):
        s += term; term *= (2 * i + 1) / (2 * i + 2)
    return s
Us = [1, 2, 4, 8, 16, 32, 64, 128, 525]
reps = 40000
acc = {U: 0.0 for U in Us}
for _ in range(reps):
    T = 0.0; done = 0
    for i in range(1, max(Us) + 1):
        u = random.random()
        k = -T + math.sqrt(T * T - 2 * n * math.log(u))
        T += k
        if i in acc:
            acc[i] += T
out = {}
for U in Us:
    mc = acc[U] / reps; ks = math.sqrt(math.pi / 2) * S(U)
    out[U] = dict(mc=round(mc, 4), ks=round(ks, 4), ratio=round(mc / ks, 4), sqrt2U=round(math.sqrt(2 * U), 4))
    print(U, out[U])
json.dump(dict(reps=reps, rows=out), open('ks_model_mc.json', 'w'), indent=1)
