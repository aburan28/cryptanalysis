"""RT2-13: end-to-end cost of pooled multi-target rho over the ECC2K-130 class (analytic, KS 2001).
E_i = rho1 * C(2i,i)/4^i for the i-th unknown (0-indexed), total for U unknowns = rho1 * S(U),
S(U) = 2 Gamma(U+1/2) / (sqrt(pi) Gamma(U)) ~ 2 sqrt(U/pi).  rho1 = sqrt(pi l / 2), l = (N-1)/262.
Unknowns: instances on E0 share E0's base G (1 unknown each); an instance on another curve with its
own base P_i needs log_G(psi(P_i)) once per base plus log_G(psi(Q_ij)) per target.
run: python3 ks_scenarios.py -> ks_scenarios.json"""
import json, math
N = 680564733841876926932320129493409985129
l = (N - 1) // 262
L2 = math.log2
rho1 = math.sqrt(math.pi * l / 2)
rho_neg = math.sqrt(math.pi * N / 4)
def S(U):
    return 2 * math.exp(math.lgamma(U + 0.5) - math.lgamma(U)) / math.sqrt(math.pi)
def S_exact(U):                       # sum_{i<U} C(2i,i)/4^i by recurrence (float)
    s, term = 0.0, 1.0
    for i in range(U):
        s += term; term *= (2 * i + 1) / (2 * i + 2)
    return s
for U in (1, 2, 3, 10, 525, 1000):
    assert abs(S(U) - S_exact(U)) < 1e-9 * S(U)
out = dict(rho1_log2=L2(rho1), rho_floor_native_neg_only_log2=L2(rho_neg), classes_log2=L2(l))
rows = []
def scen(name, L, U, note=''):
    tot = rho1 * S(U)
    claimed_tot = math.sqrt(L) * rho1
    rows.append(dict(scenario=name, instances_L=L, unknowns_U=U, total_log2=round(L2(tot), 3),
                     claimed_total_sqrtL_log2=round(L2(claimed_tot), 3),
                     amortized_per_instance_log2=round(L2(tot / L), 3),
                     claimed_amortized_log2=round(L2(rho1) - 0.5 * L2(L), 3),
                     excess_over_claim_bits=round(L2(tot) - L2(claimed_tot), 3),
                     separate_transported_log2=round(L2(L * rho1), 3),
                     saving_vs_separate_bits=round(L2(L * rho1) - L2(tot), 3),
                     first_instance_log2=round(L2(rho1), 3),
                     marginal_last_log2=round(L2(rho1 * S_exact(U) - rho1 * S_exact(U - 1)) if U > 1 else L2(rho1), 3),
                     note=note))
scen('single instance, any of the 263 curves', 1, 1)
scen('2 instances on E0 (common base G)', 2, 2)
scen('2 instances, E0 + one floor curve (own base)', 2, 3)
scen('2 instances on two floor curves (own bases)', 2, 3, 'G := psi_1(P_1)')
scen('131 instances on E0', 131, 131)
scen('263 instances all on E0 (common base)', 263, 263)
scen('263 instances, one per curve (E0 + 262 floor, independent bases)', 263, 1 + 2 * 262)
scen('262 floor + E0, 10 instances per curve', 2630, 2630 + 262)
scen('1000 instances on E0', 1000, 1000)
out['scenarios'] = rows
# amortized-saving law: claimed -0.5 log2 L vs KS
out['amortized_offset_bits_common_base_largeL'] = L2(2 / math.sqrt(math.pi))
# DP / parallelism side condition: m walks in lockstep; each new unknown waits ~m/theta for DPs
dp = []
U = 525; tot = rho1 * S(U)
for lm in (16, 20, 24):
    for lmem in (30, 34, 38):              # stored DP entries
        theta = 2.0 ** lmem / tot
        over = U * 2.0 ** lm / theta
        dp.append(dict(U=U, log2_parallel_walks=lm, log2_DP_entries=lmem, log2_theta=round(L2(theta), 2),
                       overhead_log2=round(L2(over), 2), total_with_overhead_log2=round(L2(tot + over), 3)))
out['dp_side_conditions_U525'] = dp
json.dump(out, open('ks_scenarios.json', 'w'), indent=1)
for r in rows:
    print(r['scenario'], '| U', r['unknowns_U'], '| total', r['total_log2'], '| claim', r['claimed_total_sqrtL_log2'],
          '| per-inst', r['amortized_per_instance_log2'], '| claim', r['claimed_amortized_log2'], '| excess', r['excess_over_claim_bits'],
          '| separate', r['separate_transported_log2'], '| last', r['marginal_last_log2'])
print('offset', out['amortized_offset_bits_common_base_largeL'])
for d in dp: print(d)
