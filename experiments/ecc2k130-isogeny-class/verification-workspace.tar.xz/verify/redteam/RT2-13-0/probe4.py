import time
from sage.all import GF, EllipticCurve, Integer
F = GF(2**8364, 'w'); m = 8364
while True:
    tau = F.random_element()
    if tau.trace() == 1: break
t0 = time.time()
# precompute tau^(2^j) and suffix sums for solving u^2+u=c in even degree
tp = [tau]
for j in range(1, m): tp.append(tp[-1]**2)
suf = [F(0)] * (m + 1)
for j in range(m - 1, -1, -1): suf[j] = suf[j + 1] + tp[j]
print('precompute', time.time() - t0, flush=True)
def solve_as(c):
    # u = sum_{i=0}^{m-2} c^{2^i} * (sum_{j=i+1}^{m-1} tau^{2^j}); valid when Tr(c)=0
    u = F(0); ci = c
    for i in range(m - 1):
        u += ci * suf[i + 1]; ci = ci**2
    return u
a2 = F.random_element(); E = EllipticCurve(F, [1, a2, 0, 0, 1])
def rpoint(E):
    a1, a2, a3, a4, a6 = E.a_invariants()
    while True:
        x = F.random_element()
        if x == 0: continue
        c = x + a2 + a6 / x**2
        if c.trace() != 0: continue
        u = solve_as(c); y = x * u
        return E(x, y)
t0 = time.time(); P = rpoint(E); print('rpoint', time.time() - t0, flush=True)
t0 = time.time(); Q = P + P; print('dbl', time.time() - t0, flush=True)
t0 = time.time(); R = (Integer(2)**200 + 12345) * P; print('mul 2^200', time.time() - t0, flush=True)
