"""RT2-13: collect the numbers the verdict rests on into rt2_13_summary.json. run: python3 summary.py"""
import json, math
real = json.load(open('real131.json')); ks = json.load(open('ks_scenarios.json'))
syn = json.load(open('synth_summary.json'))
try:
    e2e = json.load(open('toy_e2e.json')); e2e.pop('runs', None)
except FileNotFoundError:
    e2e = None
try:
    tb = json.load(open('toy_build.json'))
except FileNotFoundError:
    tb = None
L2 = math.log2
# toy: independent-base amortized cost (L instances -> U = 2L-1) vs claim
rho1 = syn['rho1']; pu = syn['per_U']
indep = {}
for L, U in ((8, 15), (32, 63), (64, 127)):
    if str(U) in pu:
        m = pu[str(U)]['mean_total']
        indep[L] = dict(U=U, measured_amortized_log2=round(L2(m / L), 3), claimed_log2=round(L2(rho1) - 0.5 * L2(L), 3),
                        excess_bits=round(L2(m / L) - L2(rho1) + 0.5 * L2(L), 3),
                        saving_vs_separate_bits=round(L2(L * rho1) - L2(m), 3), claimed_saving_bits=round(0.5 * L2(L), 3))
# real class: transport cost relative to the pooled rho
tr = real['transport_checks']['A000']['ops_per_point_excluding_kernel_constants']
M_equiv = tr['M'] + 8 + (tr['S'] + 130) * 0  # squarings counted as free in the M-equivalent
out = dict(
    real_class=dict(transport_checked_curves=list(real['transport_checks']),
                    all_transport_checks_pass=all(all(v for k, v in r.items() if isinstance(v, bool)) for r in real['transport_checks'].values()),
                    transport_ops_per_point=tr, transport_M_equiv_per_point_log2=round(L2(M_equiv), 2),
                    transport_all_525_points_log2_M=round(L2(525 * M_equiv), 2),
                    pooled_rho_U525_log2_iterations=[r for r in ks['scenarios'] if r['unknowns_U'] == 525][0]['total_log2'],
                    level_p=real['level_p'], frobenius_shortcut=real['frobenius_shortcut_A005_to_A000']),
    ks_scenarios=ks['scenarios'], dp_side_conditions=ks['dp_side_conditions_U525'],
    toy=dict(params='n=41, E0: y^2+xy=x^3+1, N=%d (39.0 bits), classes %d' % (syn['N'], syn['classes']),
             first_instance=syn['first_instance'], walk_stats=syn['walk_stats'],
             common_base_amortized=syn['amortized_law'], independent_base_penalty=syn['independent_base_penalty'],
             independent_base_amortized=indep, build=tb, e2e=e2e))
json.dump(out, open('rt2_13_summary.json', 'w'), indent=1)
print(json.dumps(out['real_class'], indent=1)); print(json.dumps(indep, indent=1))
