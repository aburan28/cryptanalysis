"""RT2-13 toy, stage 2: end-to-end pooled solve of instances that live on DIFFERENT curves of the
n=41 toy class.  Instances on E0 (base G), on 4 floor curves E_1..E_4 and on 2 Frobenius
conjugates of E_1 (each with its own random base), all transported to E0 (psi_i, plus inverse
Frobenius for the conjugates), then solved by one sequential multi-target rho with negation+tau
(c/pooled_rho file mode).  Planted k's are recovered from log(psi Q)/log(psi P) and checked.
Repeats the pooled solve REPS times with fresh walk randomness to measure the mean cost.
run: sage -python toy_e2e.py -> toy_e2e.json"""
import json, subprocess, time, math
from sage.all import (GF, PolynomialRing, EllipticCurve, Integer, load, set_random_seed, inverse_mod)
set_random_seed(4242)
R2 = PolynomialRing(GF(2), 'x'); X = R2.gen()
k = GF(2**41, 'z', modulus=X**41 + X**3 + 1)
E0 = EllipticCurve(k, [1, 0, 0, 0, 1])
P = json.load(open('toy_params.json'))
N = Integer(P['N'])
G = E0(k.from_integer(int(P['Gx'], 16)), k.from_integer(int(P['Gy'], 16)))
B = load('toy_build.sobj')
E1s = [E.change_ring(k) if E.base_ring() is not k else E for E in B['E1s']]
K2s = B['K2s']
def transport_map(E1, K2):
    psi0 = E1.isogeny(K2.change_ring(k))
    iso = psi0.codomain().isomorphism_to(E0)
    return iso * psi0
psis = [transport_map(E, K) for E, K in zip(E1s, K2s)]
toi = lambda e: int(Integer(e.to_integer()))
curves = [('E0', E0, None, 0)]
for i, (E, ps) in enumerate(zip(E1s, psis)):
    curves.append(('F%d' % (i + 1), E, ps, 0))
# Frobenius conjugates of F1: coefficients squared e times; transport = inverse Frobenius then psi_1
for e in (7, 23):
    Ec = EllipticCurve(k, [a**(2**e) for a in E1s[0].a_invariants()])
    curves.append(('F1^(2^%d)' % e, Ec, psis[0], e))
def to_E0(entry, Pt):
    name, E, ps, e = entry
    if ps is None:
        return Pt
    if e:
        back = 41 - e
        Pt = E1s[0](Pt[0]**(2**back), Pt[1]**(2**back))
    return ps(Pt)
M_PER = 3
lines, planted, meta = [], [], []
for entry in curves:
    name, E, ps, e = entry
    assert E.order() == 4 * N
    if ps is None:
        base = G
    else:
        while True:
            base = 4 * E.random_point()
            if not base.is_zero():
                break
    assert (N * base).is_zero()
    tb = to_E0(entry, base)
    assert not tb.is_zero() and (N * tb).is_zero()
    if ps is not None:
        lines.append('%s:base %x %x' % (name, toi(tb[0]), toi(tb[1])))
    for j in range(M_PER):
        kk = Integer(k.random_element().to_integer()) % N
        Qt = kk * base
        tq = to_E0(entry, Qt)
        assert tq == kk * tb, 'transport broke the relation'
        lines.append('%s:q%d %x %x' % (name, j, toi(tq[0]), toi(tq[1])))
        planted.append((name, j, int(kk)))
    meta.append(dict(curve=name, j=hex(toi(E.j_invariant())), j_degree=int(E.j_invariant().minimal_polynomial().degree()),
                     has_tau=bool(E.j_invariant() in (k(0), k(1))), frob_power=e))
open('toy_e2e_targets.txt', 'w').write('\n'.join(lines) + '\n')
L = len(planted); U = len(lines)
REPS = 40
runs = []
for rep in range(REPS):
    t0 = time.time()
    res = subprocess.run(['./c/pooled_rho', 'file', 'toy_params.txt', 'toy_e2e_targets.txt', str(9000 + rep), '5'],
                         capture_output=True, text=True, timeout=2400)
    assert res.returncode == 0, res.stderr
    r = json.loads(res.stdout)
    logs = {x['id']: Integer(x['log']) for x in r['results']}
    ok = True
    for name, j, kk in planted:
        lq = logs['%s:q%d' % (name, j)]
        lb = Integer(1) if name == 'E0' else logs['%s:base' % name]
        ok &= (lq * inverse_mod(lb, N)) % N == kk
    runs.append(dict(rep=rep, total_steps=r['total'], walks=r['walks'], visited=r['total'] + r['walks'],
                     all_planted_recovered=bool(ok), abandoned=r['abandoned'], wall_s=round(time.time() - t0, 2)))
    print(runs[-1], flush=True)
def S(n):
    s, term = 0.0, 1.0
    for i in range(n):
        s += term; term *= (2 * i + 1) / (2 * i + 2)
    return s
l = (int(N) - 1) // 82; rho1 = math.sqrt(math.pi * l / 2)
vis = [x['visited'] for x in runs]; m = sum(vis) / len(vis)
sd = math.sqrt(sum((v - m) ** 2 for v in vis) / (len(vis) - 1))
out = dict(curves=meta, instances_L=L, unknowns_U=U, reps=REPS,
           all_reps_recovered_all_planted=all(x['all_planted_recovered'] for x in runs),
           mean_visited=round(m, 1), se=round(sd / math.sqrt(REPS), 1),
           ks_pred_U=round(rho1 * S(U) + 32 * U, 1), ks_pred_if_U_equal_L=round(rho1 * S(L) + 32 * L, 1),
           claimed_sqrtL_rho1=round(math.sqrt(L) * rho1, 1), separate_L_rho1=round(L * rho1, 1),
           runs=runs)
json.dump(out, open('toy_e2e.json', 'w'), indent=1)
print(json.dumps({kk: v for kk, v in out.items() if kk != 'runs'}, indent=1))
