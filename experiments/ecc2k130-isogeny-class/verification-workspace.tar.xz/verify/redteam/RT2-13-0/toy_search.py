"""RT2-13 toy search: Koblitz analogues y^2+xy=x^3+a x^2+1 over F_{2^n}, n prime.
Want: N = largest prime of #E (30..50 bits), an odd prime l | f (t^2-4q=-7f^2), l < 3000, l not | #E,
and small k = ord(t/2 mod l) (field of definition of E0[l] over F_q: F_{q^k}).
run: sage -python toy_search.py"""
from sage.all import Integer, factor, kronecker, prime_range, log, Mod
for n in prime_range(29, 90):
    for a in (0, 1):
        t1 = -1 if a == 0 else 1
        tt = [Integer(2), Integer(t1)]
        for _ in range(2, n + 1):
            tt.append(t1 * tt[-1] - 2 * tt[-2])
        t = tt[n]; q = Integer(2) ** n; card = q + 1 - t
        fac = factor(card); N = max(p for p, e in fac)
        lg = float(log(N, 2))
        D = t * t - 4 * q; f = (-D // 7).isqrt(); assert 7 * f * f == -D
        cand = []
        for l in prime_range(3, 3000):
            if f % l == 0 and card % l != 0:
                c = Mod(t, l) / 2
                cand.append((l, kronecker(-7, l), c.multiplicative_order()))
        if 28 <= lg <= 52:
            print(n, a, round(lg, 2), 'cof', card // N, '| f =', factor(f), '| (l,kron,k)', cand, flush=True)
