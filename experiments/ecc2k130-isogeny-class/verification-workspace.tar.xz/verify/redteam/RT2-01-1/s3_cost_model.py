# RT2-01 adversarial check, script 3 (python3 + sympy): refined cost model for the Kani/MITM transport
# of an ECDLP instance from a level-p curve E1 to E0 (Galbraith 2024/924 Thm 1 / Cor 1; dim-2 variant).
#
# Reproduces the proposer's model first (rt4_transport_cost.py) to make sure it is read correctly, then
# changes ONE assumption at a time:
#   (1) working field of an l-step = FULL l-torsion field lcm(k1,k2)   (proposer: max(k1,k2))
#   (2) points pushed per later prime: 4 (dim 2: eigenbasis on the E1 side + gamma'-images on the E0 side)
#       and 8 (dim 4)  (proposer: 2)
#   (3) pushing a point of a later prime l' through an l-step computed by theta/Koizumi-type formulas needs
#       the compositum F_{q^lcm(K_l, K_l')}   (proposer: F_{q^K_l})  -- "compositum" model;
#       the "descended" model instead assumes an F_q-rational representation of every step is available
#       at the same cost C (so pushes happen in F_{q^K_l'})
#   (4) F_{q^k} multiplication: k^1.585 (proposer) or the measured NTL/gf2x ratio (raw/s2_fqk_mul_bench.jsonl)
#   (5) optimal ordering of the primes in the guess tree (exact DP over subsets), not just largest-first
# Then a parameter search (dim 2 and dim 4) for the set minimising the refined cost, and break-even C values.
# All costs are in F_q-multiplications; C (F_{q^k}-mults per l^g unit) is left symbolic (cost is linear in C).
import json, math, itertools, functools, os
from sympy import factorint, primerange, legendre_symbol
from math import gcd, lcm, log2, prod

HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-01-1"
p = 146505763881528721
q = 2 ** 131
tk = [2, -1]
for k in range(2, 132): tk.append(-tk[-1] - 2 * tk[-2])
t = tk[131]
f = math.isqrt((t * t - 4 * q) // -7); assert f * f * -7 == t * t - 4 * q and f == 263 * p
RHO_E0 = 2 ** 63.394          # proposer's E0 rho cost in F_q mults (2^60.809 it x ~6 M), rt3_misc.json
RHO_B2 = 2 ** 66.911          # proposer's native level-p/263p rho cost (2^64.326 it x ~6 M), rt4_transport_cost.json
IT_M = RHO_E0 / 2 ** 60.809   # M per iteration used by the proposer

# ---------------- Elkies table (independent of script 1, cross-checked below) ----------------
def mult_order(a, l):
    o = l - 1
    for r, e in factorint(l - 1).items():
        for _ in range(e):
            if pow(a, o // r, l) == 1: o //= r
            else: break
    return o
def eig(l):
    rts = [x for x in range(l) if (x * x - t * x + q) % l == 0]
    if len(rts) != 2: return None
    k1, k2 = mult_order(rts[0], l), mult_order(rts[1], l)
    K = lcm(k1, k2)
    Kx = None
    for d in sorted(d for d in range(1, K + 1) if K % d == 0):
        a, b = pow(rts[0], d, l), pow(rts[1], d, l)
        if a == b and a in (1, l - 1): Kx = d; break
    return dict(l=l, k=(k1, k2), maxk=max(k1, k2), K=K, Kx=Kx)
ELK = {}
for l in primerange(3, 1200):
    if l in (7, 263) or legendre_symbol((-7) % l, l) != 1: continue
    ELK[l] = eig(l)
s1 = json.load(open(os.path.join(HERE, "raw/s1_params.json")))
for d in s1['elkies_table_first_60']:
    e = ELK[d['l']]; assert e['K'] == d['K_full'] and e['Kx'] == d['K_kummer'] and sorted(e['k']) == sorted(d['k'])
# order of pi on E[3^e] (3 inert): multiplicative order of pi in (O_K / 3^e)^*
def ord_pi_3e(e):
    n = 3 ** e
    def mul(u, v):
        a, b = u; c, d = v
        return ((a * c - 2 * b * d) % n, (a * d + b * c + b * d) % n)
    pi = (((t - f) // 2) % n, f % n); x = (1, 0)
    for k in range(1, 10 ** 5):
        x = mul(x, pi)
        if x == (1, 0): return k
K3 = {e: ord_pi_3e(e) for e in range(1, 6)}

# ---------------- F_{q^k} multiplication cost ----------------
bench = []
bp = os.path.join(HERE, "raw/s2_fqk_mul_bench.jsonl")
for line in open(bp):
    line = line.strip()
    if line.startswith('{'): bench.append(json.loads(line))
bench.sort(key=lambda r: r['k'])
BK = [(log2(r['k']), r['log2_ratio_mulmod']) for r in bench]
def M_kara(k): return k ** 1.585
def M_meas(k):
    x = log2(k)
    if x <= BK[0][0]: return 1.0
    for (x0, y0), (x1, y1) in zip(BK, BK[1:]):
        if x0 <= x <= x1: return 2 ** (y0 + (y1 - y0) * (x - x0) / (x1 - x0))
    x0, y0 = BK[-1]
    return 2 ** (y0 + 1.1 * (x - x0))          # beyond the last measurement: quasi-linear (FFT) slope
MFUN = {'kara': M_kara, 'meas': M_meas}

def c_guess(c):   # proposer's c-part guess count, c = 3^n (checked in s1: 12 for c = 81)
    if c == 1: return 1
    n = 0; cc = c
    while cc % 3 == 0: cc //= 3; n += 1
    assert cc == 1
    return 4 * 3 ** ((n + 1) // 2 - 1)

# ---------------- proposer's model, reproduced ----------------
def proposer_model(primes, c, g, C):
    ls = sorted(primes, reverse=True)
    n3 = 0; cc = c
    while cc > 1: cc //= 3; n3 += 1
    root = 4 * 3 ** ((n3 + 1) // 2 - 1) if c > 1 else 1
    total = 0.0; nodes = root / 2
    for d, l in enumerate(ls):
        nodes *= (l - 1)
        k = ELK[l]['maxk']
        npush = 2 * (len(ls) - d - 1)
        total += nodes * (1 + npush) * C * l ** g * k ** 1.585
    return 2 * total

# ---------------- refined model ----------------
def refined(primes, c, g, C=1.0, field='K', push='compositum', npush=None, mfun='kara', order='dp'):
    """Return (cost, ordering). field: 'K' (full torsion field) or 'Kx' (Kummer field) or 'maxk' (proposer)."""
    M = MFUN[mfun]
    if npush is None: npush = 4 if g == 2 else 8
    S = tuple(sorted(primes))
    Kf = {l: ELK[l][field] for l in S}
    n3 = 0; cc = c
    while cc > 1: cc //= 3; n3 += 1
    root = c_guess(c) / 2
    # c-part at the root: ceil(n3/2) steps of degree 3 on 3^e torsion, field K3[e]; pushes all A-points
    root_cost = 0.0
    e3 = (n3 + 1) // 2
    if e3:
        k3 = K3[e3]
        pf = sum(M(lcm(k3, Kf[l])) if push == 'compositum' else M(Kf[l]) for l in S)
        root_cost = root * e3 * C * 3 ** g * (M(k3) + npush * pf)
    def step(l, prefix, later):
        n = root * prod(x - 1 for x in prefix) * (l - 1)
        pf = sum(M(lcm(Kf[l], Kf[x])) if push == 'compositum' else M(Kf[x]) for x in later)
        return n * C * l ** g * (M(Kf[l]) + npush * pf)
    if order == 'largest_first':
        ords = [tuple(sorted(S, reverse=True))]
        best = None
        for o in ords:
            tot = sum(step(l, o[:i], o[i + 1:]) for i, l in enumerate(o))
            best = (tot, o)
    else:
        full = frozenset(S)
        @functools.lru_cache(None)
        def dp(done):
            if done == full: return (0.0, ())
            res = None
            for l in S:
                if l in done: continue
                later = tuple(x for x in S if x not in done and x != l)
                cst = step(l, tuple(done), later)
                sub = dp(done | {l})
                cand = (cst + sub[0], (l,) + sub[1])
                if res is None or cand[0] < res[0]: res = cand
            return res
        best = dp(frozenset())
    return 2 * (best[0] + root_cost), best[1]      # both halves (F1 and F2bar)

def effective_iters(T):
    return log2((RHO_E0 + T) / IT_M)

out = {'constants': dict(log2_rho_E0_M=log2(RHO_E0), log2_rho_B2_native_M=log2(RHO_B2), M_per_iteration=IT_M,
                         K3_order_pi_mod_3e={str(k): v for k, v in K3.items()}),
       'Mk_measured': [dict(k=r['k'], log2_ratio=r['log2_ratio_mulmod'], log2_kara=round(1.585 * log2(r['k']), 3)) for r in bench]}
CASES = {
    'dim2_c81_A=29.71.137.179': ([29, 71, 137, 179], 81, 2),
    'dim2_c3_A=11.23.79.107.109': ([11, 23, 79, 107, 109], 3, 2),
    'dim4_c1_A=23.37.53.67.137': ([23, 37, 53, 67, 137], 1, 4),
}
rows = {}
for name, (pr, c, g) in CASES.items():
    r = {}
    r['proposer_model_C=9/100/1000'] = [round(log2(proposer_model(pr, c, g, C)), 2) for C in (9, 100, 1000)]
    base = lambda **kw: refined(pr, c, g, C=1.0, **kw)
    variants = {
        'A_proposer_like(maxk,npush2,no-compositum,largest_first)': dict(field='maxk', push='descended', npush=2, order='largest_first'),
        'B_+full_torsion_field': dict(field='K', push='descended', npush=2, order='largest_first'),
        'C_+npush_4or8': dict(field='K', push='descended', order='largest_first'),
        'D_+compositum_pushes': dict(field='K', push='compositum', order='largest_first'),
        'E_+optimal_order(DP)': dict(field='K', push='compositum', order='dp'),
        'F_E_with_Kummer_field': dict(field='Kx', push='compositum', order='dp'),
        'G_descended_rep_optimal_order': dict(field='K', push='descended', order='dp'),
        'H_E_with_measured_Mk': dict(field='K', push='compositum', order='dp', mfun='meas'),
    }
    for vn, kw in variants.items():
        cost, o = base(**kw)
        r[vn] = dict(log2_cost_C1=round(log2(cost), 2), order=list(o),
                     log2_cost_C=[round(log2(cost * C), 2) for C in (9, 100, 1000, 10000)],
                     eff_iters_C=[round(effective_iters(cost * C), 3) for C in (9, 100, 1000, 10000)],
                     breakeven_C_equal_E0_rho=round(RHO_E0 / cost, 1),
                     breakeven_C_no_gain_vs_native=round((RHO_B2 - RHO_E0) / cost, 1))
    rows[name] = r
out['headline_cases'] = rows
print(json.dumps(rows, indent=1))

# ---------------- parameter search: best refined cost over prime sets ----------------
def two_sq(m):
    return all(not (l % 4 == 3 and e % 2) for l, e in factorint(m).items())
def norm_ok(m):
    # m = 2^a * m' with every prime inert in O_K (3,5,6 mod 7) to an even power, 7 allowed, p forbidden
    if m <= 0 or m % p == 0: return False
    for l, e in factorint(m).items():
        if l in (2, 7): continue
        if legendre_symbol((-7) % l, l) == -1 and e % 2: return False
    return True
POOL = [l for l in sorted(ELK) if l <= 400]
def search(g, cs, keep=4000, mfun='kara', field='K'):
    Mf = MFUN[mfun]
    cands = []
    for c in cs:
        lo = math.isqrt(p // c) + 1; hi = 3 * lo
        R = c_guess(c) / 2
        def rec(i, cur, prodv):
            if prodv >= lo:
                if prodv < hi:
                    ph = prod(x - 1 for x in cur)
                    lb = 2 * R * ph * min(x ** g * Mf(ELK[x][field]) for x in cur)
                    cands.append((lb, c, tuple(cur)))
                return
            for j in range(i, len(POOL)):
                l = POOL[j]
                if prodv * l >= hi: break
                if len(cur) >= 8: break
                rec(j + 1, cur + [l], prodv * l)
        rec(0, [], 1)
    cands.sort()
    best = []
    for lb, c, S in cands[:keep]:
        A = prod(S); m = c * A * A - p
        adm = two_sq(m) if g == 4 else norm_ok(m)
        adm_int = (g == 2 and math.isqrt(m) ** 2 == m)
        cost, o = refined(list(S), c, g, C=1.0, field=field, push='compositum', order='dp', mfun=mfun)
        cost_d, o_d = refined(list(S), c, g, C=1.0, field=field, push='descended', order='dp', mfun=mfun)
        best.append(dict(log2_cost_C1_compositum=round(log2(cost), 3), log2_cost_C1_descended=round(log2(cost_d), 3),
                         c=c, primes=list(S), order=list(o), A=A, m=m, admissible=adm, m_is_square=adm_int,
                         log2_guesses=round(log2(c_guess(c) * prod(x - 1 for x in S) / 2), 3), n_candidates=len(cands)))
    best.sort(key=lambda d: d['log2_cost_C1_compositum'])
    return best, len(cands)
search_out = {}
for g, cs in ((2, [3 ** n for n in range(0, 9)]), (4, [1, 3, 9, 27, 81])):
    for mf in ('kara', 'meas'):
        best, ncand = search(g, cs, mfun=mf)
        adm = [b for b in best if b['admissible']]
        bestd = sorted(adm, key=lambda d: d['log2_cost_C1_descended'])
        search_out['g=%d_%s' % (g, mf)] = dict(n_sets_enumerated=ncand, n_evaluated=len(best),
                                               best_admissible_compositum=adm[:5], best_admissible_descended=bestd[:3])
        b0 = adm[0]
        T1 = 2 ** b0['log2_cost_C1_compositum']
        search_out['g=%d_%s' % (g, mf)]['breakeven'] = dict(
            C_transport_equals_E0_rho=round(RHO_E0 / T1, 1),
            C_no_gain_vs_B2_native=round((RHO_B2 - RHO_E0) / T1, 1),
            eff_iters_at_C=[(C, round(effective_iters(T1 * C), 3)) for C in (9, 100, 1000, 10 ** 4, 10 ** 5)])
        print('g=%d %s: sets %d, best admissible (compositum) log2 cost/C = %.2f %s c=%d; breakeven %s' % (
            g, mf, ncand, b0['log2_cost_C1_compositum'], b0['primes'], b0['c'], search_out['g=%d_%s' % (g, mf)]['breakeven']))
out['search'] = search_out
json.dump(out, open(os.path.join(HERE, "raw/s3_cost_model.json"), 'w'), indent=1)
