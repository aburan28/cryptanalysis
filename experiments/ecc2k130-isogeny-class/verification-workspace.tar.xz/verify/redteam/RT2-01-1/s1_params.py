# RT2-01 adversarial check, script 1 (sage -python).
# Independent re-derivation of every number-theoretic ingredient the RT2-01 proposal relies on:
#   - trace / p / Kronecker symbols / class-number counts of levels p and 263p
#   - Elkies primes: eigenvalues of q-Frobenius mod l, their orders k1,k2, the FULL l-torsion field
#     degree lcm(k1,k2) (the proposer used max(k1,k2)), and the Kummer (+-) field degree of a
#     mixed kernel point P1+P2 (smallest k with lambda1^k = lambda2^k = +-1, same sign)
#   - the proposer's two headline parameter sets (dim 4 and dim 2)
#   - the 3-part (3 inert) of the dim-2 set: guess count and E[9] field degree
# Output: raw/s1_params.json
import sys, json, math, itertools
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import (ZZ, GF, Integer, kronecker, is_prime, primes, lcm, gcd, euler_phi, factor,
                      PolynomialRing, Mod, IntegerModRing, QuadraticField, two_squares)

OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-01-1/raw/s1_params.json"
q = ecc2k.q; t = ecc2k.t; N = ecc2k.N; f = ecc2k.f; p = ecc2k.p
res = {}
# ---------- trace re-derivation (Lucas sequence for tau^2 + tau + 2 = 0, t1 = -1) ----------
tk = [2, -1]
for k in range(2, 132):
    tk.append(-tk[-1] - 2 * tk[-2])
assert tk[131] == t
assert t * t - 4 * q == -7 * f * f and f == 263 * p and q + 1 - t == 4 * N
assert ZZ(p).is_prime(proof=True) and ZZ(N).is_prime(proof=True)
res['t'] = str(t); res['p'] = str(p); res['log2_p'] = float(math.log2(p))
res['kron(-7,p)'] = int(kronecker(-7, p)); res['kron(-7,263)'] = int(kronecker(-7, 263))
res['p_mod_7'] = int(p % 7)
# class numbers of the orders (h(O_K)=1, units +-1 for both): h(O_c) = c * prod_{l|c}(1 - (-7/l)/l)
h_p = p - kronecker(-7, p)
h_263p = (263 - kronecker(-7, 263)) * (p - kronecker(-7, p))
res['h_level_p'] = str(h_p); res['h_level_263p'] = str(h_263p)
res['log2_total_B2_curves'] = float(math.log2(h_p + h_263p))
# ---------- Elkies table ----------
def eig_data(l):
    R = PolynomialRing(GF(l), 'X'); X = R.gen()
    rts = [r for r, e in (X**2 - t * X + q).roots()]
    if len(rts) != 2:
        return None
    k = [int(Mod(r, l).multiplicative_order()) for r in rts]
    K = int(lcm(k[0], k[1]))
    # Kummer degree of a mixed point: smallest d with l1^d = l2^d = eps, eps in {+1,-1}
    Kx = None
    for d in sorted(ZZ(K).divisors()):
        a = Mod(rts[0], l) ** d; b = Mod(rts[1], l) ** d
        if a == b and (a == 1 or a == -1):
            Kx = int(d); break
    # tau-eigenvalues (E0 is defined over F_2): roots of X^2 + X + 2; E0[l] lives over F_{2^d0}
    rt2 = [r for r, e in (X**2 + X + 2).roots()]
    d0 = int(lcm([Mod(r, l).multiplicative_order() for r in rt2]))
    return dict(l=int(l), lam=[int(r) for r in rts], k=k, max_k=max(k), K_full=K, K_kummer=Kx,
                E0_torsion_F2_degree=d0, l_mod_4=int(l % 4))
tab = []
for l in primes(3, 20000):
    if l in (7, 263) or kronecker(-7, l) != 1:
        continue
    d = eig_data(l)
    assert d is not None
    tab.append(d)
res['n_elkies_below_20000'] = len(tab)
res['n_elkies_below_4000'] = len([d for d in tab if d['l'] < 4000])
bl = {d['l']: d for d in tab}
res['elkies_table_first_60'] = tab[:60]
res['n_primes_where_lcm_exceeds_max'] = sum(1 for d in tab if d['K_full'] > d['max_k'])
res['first_primes_where_lcm_exceeds_max'] = [(d['l'], d['k'], d['K_full']) for d in tab if d['K_full'] > d['max_k']][:20]
# ---------- proposer dim-4 headline set ----------
S4 = [23, 37, 53, 67, 137]
A4 = int(math.prod(S4)); m4 = A4 * A4 - p
fm4 = factor(m4)
two_sq4 = all(not (l % 4 == 3 and e % 2) for l, e in fm4)
res['dim4'] = dict(primes=S4, A=A4, log2_A=math.log2(A4), A2_gt_p=A4 * A4 > p, m=str(m4),
                   m_factor=str(fm4), m_sum_of_two_squares=bool(two_sq4),
                   two_squares=[int(x) for x in two_squares(m4)] if two_sq4 else None,
                   guesses_phiA_over_2=int(euler_phi(A4) // 2), log2_guesses=math.log2(int(euler_phi(A4) // 2)),
                   per_prime=[dict(l=l, k=bl[l]['k'], K_full=bl[l]['K_full'], K_kummer=bl[l]['K_kummer'], l_mod_4=l % 4) for l in S4],
                   lcm_all_K_full=int(lcm([bl[l]['K_full'] for l in S4])))
# ---------- proposer dim-2 headline set ----------
S2 = [29, 71, 137, 179]; c2 = 81
A2 = int(math.prod(S2)); m2 = c2 * A2 * A2 - p
fm2 = factor(m2)
gamma_deg = 16 * 67 * 631 * 1877 * 5023 * 97 ** 2
split_status = {l: int(kronecker(-7, l)) for l in (2, 3, 67, 631, 1877, 5023, 97)}
# 3-part: pi acting on O_K/9 (3 inert, 3 does not divide f). omega^2 - omega + 2 = 0, pi = (t-f)/2 + f*omega
def mul(u, v, n):   # (a + b w)(c + d w), w^2 = w - 2
    a, b = u; c, d = v
    return ((a * c - 2 * b * d) % n, (a * d + b * c + b * d) % n)
pi9 = (((t - f) // 2) % 9, f % 9)
x = (1, 0); ordpi9 = None
for k in range(1, 100):
    x = mul(x, pi9, 9)
    if x == (1, 0):
        ordpi9 = k; break
units9 = [(a, b) for a in range(9) for b in range(9) if (a * a + a * b + 2 * b * b) % 3 != 0]
normp = [(a, b) for a, b in units9 if (a * a + a * b + 2 * b * b) % 9 == p % 9]
res['dim2'] = dict(primes=S2, c=c2, A=A2, log2_A=math.log2(A2), m=str(m2), m_factor=str(fm2),
                   m_equals_claimed_gamma_degree=(m2 == gamma_deg), kronecker_minus7=split_status,
                   guesses_12_phiA_over_2=int(12 * euler_phi(A2) // 2), log2_guesses=math.log2(int(12 * euler_phi(A2) // 2)),
                   proposer_log2_guesses_phi9A=math.log2(int(euler_phi(9 * A2))),
                   n_units_O_K_mod_9=len(units9), n_units_norm_p_mod_9=len(normp),
                   order_pi_mod_9O_K=ordpi9,
                   per_prime=[dict(l=l, k=bl[l]['k'], K_full=bl[l]['K_full'], K_kummer=bl[l]['K_kummer'], l_mod_4=l % 4) for l in S2],
                   lcm_all_K_full=int(lcm([bl[l]['K_full'] for l in S2] + [ordpi9])))
# ---------- simplest dim-2 Kani: gamma = [n] (no class-number argument needed at all) ----------
res['note_gamma_is_integer'] = ("F: E1 x E0 -> E0 x E1 with kernel {([n]P, phi(P))} needs only M = p + n^2 = c A^2; "
                                "valid for any h(O_K); the h(O_K)=1 argument is only needed for horizontal gamma.")
json.dump(res, open(OUT, 'w'), indent=1, default=str)
print(json.dumps({k: v for k, v in res.items() if k not in ('elkies_table_first_60',)}, indent=1, default=str))
