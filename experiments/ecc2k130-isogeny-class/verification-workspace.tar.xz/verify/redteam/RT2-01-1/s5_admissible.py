# RT2-01 adversarial check, script 5 (python3 + sympy): the dim-2 variant needs gamma: E1 -> E2 of degree
# m = c*A^2 - p to be COMPUTABLE: 2-power part = Frobenius power, 7 = ramified horizontal step, inert primes
# to even powers (= [l]), split primes = horizontal Elkies steps from a level-p curve, which must be computed
# once per instance (kernel = eigenline over F_{q^ord(lambda)}, or Phi_l(j,Y)). So the largest split prime
# in m matters. This script re-runs the refined model (s3) on many more candidate sets and reports the best
# set under max-split-prime bounds, plus the gamma = [x] (m a perfect square) hits of the proposer's rt2b.
# Also prints the per-level cost breakdown of the best set (to check what dominates).
import json, math, os
from math import log2, prod, lcm
HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-01-1"
src = open(os.path.join(HERE, "s3_cost_model.py")).read()
exec(src[:src.index("out = {'constants'")])
from sympy import factorint, legendre_symbol
POOL = [l for l in sorted(ELK) if l <= 400]

def gamma_info(m):
    fm = factorint(m)
    if m % p == 0: return None
    maxsplit = 1; ok = True
    for l, e in fm.items():
        if l in (2, 7): continue
        if legendre_symbol((-7) % l, l) == 1: maxsplit = max(maxsplit, l)
        elif e % 2: ok = False
    return dict(ok=ok, maxsplit=maxsplit, v2=fm.get(2, 0), factor={str(k): v for k, v in fm.items()})

def enum(g, cs, mfun='kara', field='K'):
    Mf = MFUN[mfun]; cands = []
    for c in cs:
        lo = math.isqrt(p // c) + 1; hi = 3 * lo; R = c_guess(c) / 2
        def rec(i, cur, prodv):
            if prodv >= lo:
                if prodv < hi:
                    cands.append((2 * R * prod(x - 1 for x in cur) * min(x ** g * Mf(ELK[x][field]) for x in cur), c, tuple(cur)))
                return
            for j in range(i, len(POOL)):
                l = POOL[j]
                if prodv * l >= hi or len(cur) >= 8: break
                rec(j + 1, cur + [l], prodv * l)
        rec(0, [], 1)
    cands.sort()
    return cands

out = {}
cands = enum(2, [3 ** n for n in range(0, 9)])
rows = []
for lb, c, S in cands[:20000]:
    A = prod(S); m = c * A * A - p
    gi = gamma_info(m)
    if gi is None or not gi['ok']: continue
    cost, o = refined(list(S), c, 2, C=1.0, field='K', push='compositum', order='dp')
    rows.append(dict(log2_cost_C1=round(log2(cost), 3), c=c, primes=list(S), order=list(o), m=m, maxsplit=gi['maxsplit'],
                     frob_power=gi['v2'], m_factor=gi['factor']))
rows.sort(key=lambda r: r['log2_cost_C1'])
out['n_candidates'] = len(cands); out['n_admissible_evaluated'] = len(rows)
for B in (10 ** 3, 10 ** 4, 10 ** 5, 10 ** 6, 10 ** 9, 10 ** 30):
    sel = [r for r in rows if r['maxsplit'] <= B]
    out['best_maxsplit_le_%d' % B] = sel[:3]
    if sel:
        T1 = 2 ** sel[0]['log2_cost_C1']
        print('max split prime <= %.0e: best log2 cost/C = %.2f  (%s c=%d, maxsplit %d)  C for E0-parity %.0f, C for no-gain %.0f' % (
            B, sel[0]['log2_cost_C1'], sel[0]['primes'], sel[0]['c'], sel[0]['maxsplit'], RHO_E0 / T1, (RHO_B2 - RHO_E0) / T1))
    else:
        print('max split prime <= %.0e: none in the top-20000 candidates' % B)

# per-level breakdown of the best B<=1e4 set
best = out['best_maxsplit_le_10000'][0] if out['best_maxsplit_le_10000'] else rows[0]
S = best['primes']; c = best['c']; o = best['order']
Kf = {l: ELK[l]['K'] for l in S}
R = c_guess(c) / 2
bd = []
for i, l in enumerate(o):
    n = R * prod(x - 1 for x in o[:i]) * (l - 1)
    later = o[i + 1:]
    stepc = n * l ** 2 * M_kara(Kf[l]); pushc = n * l ** 2 * 4 * sum(M_kara(lcm(Kf[l], Kf[x])) for x in later)
    bd.append(dict(level=i, l=l, K=Kf[l], log2_nodes=round(log2(n), 2), log2_step_cost=round(log2(2 * stepc), 2),
                   log2_push_cost=round(log2(2 * pushc), 2) if pushc else None,
                   push_fields=[lcm(Kf[l], Kf[x]) for x in later]))
out['breakdown_best'] = dict(set=S, c=c, order=o, levels=bd)
print(json.dumps(out['breakdown_best'], indent=1))

# proposer's gamma = [x] hits (rt2b dim2_best): m = x^2 a perfect square, E2 = E1, no horizontal steps at all
rt2b = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/redteam-2/raw/rt2b_search.json"))
sq = []
for h in rt2b['dim2_best']:
    c = h['c']; S = h['primes']
    n3 = 0; cc = c
    while cc % 3 == 0: cc //= 3; n3 += 1
    if cc != 1:   # refined() models only 3-power c; record and skip
        sq.append(dict(c=c, primes=S, note='c not a power of 3: not modelled')); continue
    cost, o = refined(S, c, 2, C=1.0, field='K', push='compositum', order='dp')
    x = h['x']; assert p + x * x == c * prod(S) ** 2
    sq.append(dict(c=c, primes=S, x=x, log2_cost_C1=round(log2(cost), 3), order=list(o)))
out['gamma_integer_hits_rt2b'] = sq
print(json.dumps(sq, indent=1))
json.dump(out, open(os.path.join(HERE, "raw/s5_admissible.json"), 'w'), indent=1)
