# RT2-01 adversarial check, script 4 (sage -python): toy check of the one new mathematical claim in RT2-01(b):
#   "gamma: E1 -> E2 horizontal (or Frobenius) of degree coprime to the conductor prime => the ascending
#    isogenies phi: E1 -> E0 and phi': E2 -> E0 close a commutative diamond on the unique crater curve E0,
#    i.e. gamma(ker phi) = ker phi', so phi' o gamma = gamma' o phi with gamma' in End(E0)."
# Toy analogue of ECC2K-130: E0: y^2 + xy = x^3 + 1 (the same Koblitz curve, j = 1, O_K = Z[(1+sqrt-7)/2], h = 1)
# over F_{2^n} with conductor f_n of Z[pi_n] divisible by a prime ell that is INERT in O_K (like p = 1.47e17,
# kron(-7,p) = -1). Level-ell curves E1 are reached by the ell+1 descending ell-isogenies from E0.
# Checks, for every level-ell curve E1 and every horizontal ell'-isogeny gamma (ell' split, small):
#   (a) E1 has exactly one F_q-rational ell-isogeny (the ascending one), and it lands on j = 1 with the SAME trace
#   (b) its kernel is the eigenline of pi on E1[ell] with eigenvalue t/2 mod ell
#   (c) E2 = gamma(E1) is again on level ell (exactly one rational ell-isogeny, landing on j = 1)
#   (d) gamma maps ker(phi) onto ker(phi')  (diamond closes on E0)
#   (e) the same for gamma = 2-power Frobenius x -> x^2
import sys, json, time
from cysignals.alarm import alarm, cancel_alarm, AlarmInterrupt
from sage.all import (GF, EllipticCurve, PolynomialRing, ZZ, kronecker, factor, Mod, lcm, set_random_seed, EllipticCurveIsogeny)
set_random_seed(20260924)
OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-01-1/raw/s4_toy_diamond.json"
tk = [2, -1]
for k in range(2, 80): tk.append(-tk[-1] - 2 * tk[-2])

_EMB = {}
def big_field(K, D):
    """GF(2^(n*D)) with a sparse default modulus and an explicit embedding K -> L (avoids pseudo-Conway)."""
    key = (K.order(), D)
    if key not in _EMB:
        n = K.degree()
        L = GF(2 ** (n * D), 'u') if D > 1 else K
        if D > 1:
            r = K.modulus().change_ring(L).roots(multiplicities=False)[0]
            emb = K.hom([r], L)
        else:
            emb = K.hom([K.gen()], K)
        _EMB[key] = (L, emb)
    return _EMB[key]

def base_change(E, L, emb):
    return EllipticCurve(L, [emb(c) for c in E.a_invariants()])

def poly_to(h, L, emb):
    R = PolynomialRing(L, 'x')
    return R([emb(c) for c in h.list()])

def kernel_points(E, h):
    """(L, emb, EL, P): a generator P of the kernel with kernel polynomial h, over the smallest suitable L."""
    K = E.base_field()
    d = max(g.degree() for g, e in h.factor())
    for e in range(1, 64):
        L, emb = big_field(K, d * e)
        rts = poly_to(h, L, emb).roots(multiplicities=False)
        if not rts: continue
        EL = base_change(E, L, emb)
        for x0 in rts:
            pts = EL.lift_x(x0, all=True)
            if pts: return L, emb, EL, pts[0]
    raise RuntimeError("no kernel point")

def check_curve(E1, n, ell, ellp_list, t, q, K):
    r = dict(j=str(E1.j_invariant()))
    assert E1.trace_of_frobenius() == t
    up = E1.isogenies_prime_degree(ell)
    r['a_n_rational_ell_isog'] = len(up)
    phi = up[0]
    r['a_lands_on_j1'] = bool(phi.codomain().j_invariant() == 1 and phi.codomain().trace_of_frobenius() == t)
    # (b) eigenvalue of pi on ker(phi)
    L, emb, EL, P = kernel_points(E1, phi.kernel_polynomial())
    FrP = EL(P[0] ** q, P[1] ** q)
    lam = None
    for a in range(ell):
        if FrP == a * P: lam = a; break
    r['b_eigenvalue'] = lam; r['b_t_over_2_mod_ell'] = int(Mod(t, ell) / 2)
    diam = []
    for lp in ellp_list:
        for gam in E1.isogenies_prime_degree(lp):
            E2 = gam.codomain()
            up2 = E2.isogenies_prime_degree(ell)
            ok_c = (len(up2) == 1 and up2[0].codomain().j_invariant() == 1)
            phip = up2[0]
            # (d) gamma(P) in ker(phi')?  evaluate gamma over the field of P
            gamL = EllipticCurveIsogeny(EL, poly_to(gam.kernel_polynomial(), L, emb))
            E2L = gamL.codomain()
            iso = E2L.isomorphism_to(base_change(E2, L, emb))
            GP = iso(gamL(P))
            hp = phip.kernel_polynomial()
            ok_d = bool(GP != 0 and poly_to(hp, L, emb)(GP[0]) == 0)
            diam.append(dict(ellp=lp, E2_level_ell_and_up_to_j1=bool(ok_c), gamma_kerphi_eq_kerphi_prime=ok_d))
    # (e) Frobenius gamma: E1 -> E1^(2), P -> (x^2, y^2)
    a = E1.a_invariants()
    E1s = EllipticCurve(K, [c ** 2 for c in a])
    up3 = E1s.isogenies_prime_degree(ell)
    FP = EL(P[0] ** 2, P[1] ** 2) if False else None
    E1sL = base_change(E1s, L, emb)
    QP = E1sL(P[0] ** 2, P[1] ** 2)
    ok_e = (len(up3) == 1 and up3[0].codomain().j_invariant() == 1 and
            poly_to(up3[0].kernel_polynomial(), L, emb)(QP[0]) == 0)
    r['e_frobenius_diamond'] = bool(ok_e)
    r['d_horizontal'] = diam

    return r


def run(n, ell, ellp_list):
    t = tk[n]; q = 2 ** n
    K = GF(2 ** n, 'z')
    E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
    assert E0.trace_of_frobenius() == t
    rec = dict(n=n, ell=ell, t=int(t), f=int(ZZ((t * t - 4 * q) // -7).isqrt()), kron_ell=int(kronecker(-7, ell)),
               ellp=ellp_list, curves=[])
    desc = E0.isogenies_prime_degree(ell)
    rec['n_ell_isogenies_from_E0'] = len(desc)
    js = set()
    for idx, psi in enumerate(desc):
        E1 = psi.codomain()
        js.add(E1.j_invariant())
        r = None
        for attempt in range(6):
            try:
                alarm(90)
                r = check_curve(E1, n, ell, ellp_list, t, q, K)
                cancel_alarm()
                r['attempts'] = attempt + 1
                break
            except AlarmInterrupt:
                print('  n=%d curve %d attempt %d timed out, reseeding' % (n, idx, attempt), file=sys.stderr, flush=True)
                set_random_seed(1000 + 17 * attempt + idx)
        assert r is not None
        print('  n=%d curve %d done' % (n, idx), time.strftime('%H:%M:%S'), file=sys.stderr, flush=True)
        rec['curves'].append(r)
    rec['n_distinct_level_ell_j'] = len(js)
    rec['all_ok'] = all(c['a_n_rational_ell_isog'] == 1 and c['a_lands_on_j1'] and c['b_eigenvalue'] == c['b_t_over_2_mod_ell']
                        and c['e_frobenius_diamond'] and all(d['E2_level_ell_and_up_to_j1'] and d['gamma_kerphi_eq_kerphi_prime'] for d in c['d_horizontal'])
                        and len(c['d_horizontal']) > 0 for c in rec['curves'])
    return rec

res = []
for n, ell, lps in ((8, 3, [11]), (6, 5, [11]), (9, 17, [11, 23])):
    t0 = time.time()
    r = run(n, ell, lps)
    r['seconds'] = round(time.time() - t0, 1)
    print(json.dumps({k: v for k, v in r.items() if k != 'curves'}), flush=True)
    res.append(r)
json.dump(res, open(OUT, 'w'), indent=1)
