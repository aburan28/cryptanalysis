# RT2-01 adversarial check, script 6: descended vs compositum costs for the admissible dim-2 sets found by s5
# (gamma computable: largest split prime of m <= 1e5 / 1e6) and break-even C values. Output raw/s6_summary.json
import json, os
from math import log2
HERE = "/Volumes/SSD990/ecdlp-hardness-work/verify/redteam/RT2-01-1"
src = open(os.path.join(HERE, "s3_cost_model.py")).read()
exec(src[:src.index("out = {'constants'")])
s5 = json.load(open(os.path.join(HERE, "raw/s5_admissible.json")))
sets = {'proposer_dim2_c81': ([29, 71, 137, 179], 81, 2, 5023),
        'best_split_le_1e5': tuple(s5['best_maxsplit_le_100000'][0][k] for k in ('primes', 'c')) + (2, s5['best_maxsplit_le_100000'][0]['maxsplit']),
        'best_split_le_1e6': tuple(s5['best_maxsplit_le_1000000'][0][k] for k in ('primes', 'c')) + (2, s5['best_maxsplit_le_1000000'][0]['maxsplit']),
        'proposer_dim4': ([23, 37, 53, 67, 137], 1, 4, None)}
out = {}
for name, (S, c, g, ms) in sets.items():
    row = dict(primes=S, c=c, g=g, max_split_prime_in_gamma=ms)
    for push in ('compositum', 'descended'):
        for mf in ('kara', 'meas'):
            T1, o = refined(S, c, g, C=1.0, field='K', push=push, order='dp', mfun=mf)
            row['%s_%s' % (push, mf)] = dict(log2_cost_over_C=round(log2(T1), 2),
                                             C_at_E0_parity=round(RHO_E0 / T1), C_at_no_gain=round((RHO_B2 - RHO_E0) / T1),
                                             eff_iters_C100_C1000_C10000=[round(log2((RHO_E0 + C * T1) / IT_M), 3) for C in (100, 1000, 10000)])
    out[name] = row
    print(name, json.dumps(row))
json.dump(out, open(os.path.join(HERE, "raw/s6_summary.json"), 'w'), indent=1)
