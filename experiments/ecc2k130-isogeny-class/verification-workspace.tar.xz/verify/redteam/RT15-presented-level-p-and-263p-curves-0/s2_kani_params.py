# RT15 / script 2: concrete Kani/MITM parameters for the ascending p-isogeny E(level p) -> E0, and an
# explicit end-to-end cost model (E0 rho + transport) vs the native negation-only rho on the level-p curve.
#
# Variants (all use only odd M: in char 2, E[2^e] is cyclic, see s1_constants.json):
#   V8  Galbraith 2024 Thm 1 as written: M = 3^n A^2 (A squarefree, Elkies primes), m = M - p = 4 squares,
#       F : E0^4 x E1^4 -> E1^4 x E0^4 (dimension G = 8); shared guess (M2 | M1), no memory.
#   V4  same with m = sum of 2 squares (Galbraith: "in practice one would prefer the two squares version"), G = 4.
#   V4+ V4 with GGR 2025 extensions: inert primes allowed in A (GGR Thm 4.1), and the 7-part fixed up to
#       sign by the self-pairing (GGR Alg. 2/3, m = 7 | Delta(O_K) = -7), i.e. M = 3^n 7^2 A^2.
#   V2  dimension 2 (G = 2): gamma = [x] on E0, M = p + x^2 smooth; M = M1*M2 coprime split, hash-table
#       meet-in-the-middle on invariants of the middle abelian surface (Igusa-type), memory = min side.
#
# Cost model (NOT measured -- no char-2 higher-dimensional isogeny implementation exists to time):
#   one (l,...,l)-step in dimension G over F_{q^k}:  C_step = n^G * l^(G*s)  F_{q^k}-multiplications,
#     n = theta level (odd in char 2: n = 3, and n = 5 for the l = 3 steps), s = 1 ("LR23": O~(l^G)),
#     or s = r/2 with r = 2 (l = 1 mod 4) / r = 4 (l = 3 mod 4) ("LR12"), or the bare floor "ell^G" (n^G := 1);
#   an F_{q^k}-multiplication = k^1.585 F_q-multiplications (Karatsuba); k = degree of the field of E[l^j];
#   guess tree: node at depth d is visited prod_{i<=d} g_i times; each node computes one step and pushes
#     2G basis points per later prime (a push costs one C_step);  both halves (F1 and F2bar) are walked.
#   E0 rho = 2^60.809 iterations x c_it F_q-mults, c_it = 5 (the 5M of Bernstein et al., ECC2K-130 paper,
#     "each iteration costs at most (1/N)(I-3M)+5M+21S+7a"), and c_it = 7 as a sensitivity check.
import sys, json, math, itertools, time
from sage.all import Integer, factor, is_prime, kronecker, two_squares
T0 = time.time()
D = json.load(open("s1_constants.json"))
p = Integer(D["results"]["h(O_p) = p - (-7|p)"]) - 1          # h(O_p) = p + 1
assert is_prime(p) and p == 146505763881528721
SP = {row["l"]: row for row in D["small_primes"]}
NN = 680564733841876926932320129493409985129
LOG2_E0_RHO = 0.5 * math.log2(math.pi * NN / (4 * 131))
LOG2_NEG_RHO = 0.5 * math.log2(math.pi * 680564733841876926932320129493409985129 / 4)

# --- per prime-power data: (guesses at this step, field degree k of the step's torsion)
q_, t_, f_ = 2 ** 131, -22283658519494248867, 38531015900842053623
b_ = f_ if (t_ - f_) % 2 == 0 else -f_
a_ = (t_ - b_) // 2
assert a_ * a_ + a_ * b_ + 2 * b_ * b_ == q_
def _mulw(x, y, n):
    return ((x[0] * y[0] - 2 * x[1] * y[1]) % n, (x[0] * y[1] + x[1] * y[0] + x[1] * y[1]) % n)
def _powpi(e, n):
    res, base = (1, 0), (a_ % n, b_ % n)
    while e:
        if e & 1: res = _mulw(res, base, n)
        base = _mulw(base, base, n); e >>= 1
    return res
_ORD = {}
def ord_full(ell, e):
    """exact order of pi in (O_K/ell^e)^* = degree of the field of definition of E[ell^e]"""
    if (ell, e) in _ORD: return _ORD[(ell, e)]
    k = kronecker(-7, ell)
    o = Integer((ell - 1) ** 2 * ell ** (2 * (e - 1)) if k == 1 else (ell * ell - 1) * ell ** (2 * (e - 1)) if k == -1
                else (ell - 1) * ell ** (2 * e - 1))
    n = ell ** e
    assert _powpi(int(o), n) == (1, 0)
    for (l, _) in factor(o):
        while o % l == 0 and _powpi(int(o // l), n) == (1, 0):
            o //= l
    _ORD[(ell, e)] = int(o)
    return int(o)
K3 = {e: None for e in range(1, 8)}
def steps_for(ell, e, selfpair7=True):
    """list of (ell, branching, k) for the e successive ell-steps of an ell^e-part"""
    out = []
    kind = SP[ell]["kind"] if ell in SP else None
    for j in range(1, e + 1):
        if j == 1:
            if ell == 7 and selfpair7: g = 2                        # GGR self-pairing, T = 2
            elif kind == "elkies": g = ell - 1
            elif kind == "inert": g = ell + 1
            else: g = 2 * ell                                       # ramified 7 without self-pairing
        else:
            g = ell
        k = ord_full(ell, j)
        out.append((ell, g, k))
    return out

def step_cost(ell, G, k, model):
    kar = k ** 1.585
    if model == "ell^G":
        c = ell ** G
    else:
        n = 5 if ell == 3 else 3
        if model == "LR23":
            c = n ** G * ell ** G
        elif model == "LR12":
            r = 2 if ell % 4 == 1 else 4
            c = n ** G * ell ** (G * r / 2)
        else:
            raise ValueError(model)
    return c * kar

def tree_cost(steps, G, model, halve=True):
    """min over orderings (exhaustive for <= 8 steps, else sorted heuristic) of the guess-tree cost"""
    def cost(order):
        tot, nodes = 0.0, (0.5 if halve else 1.0)
        # all steps of the same prime must stay in increasing j order; we treat the list as given
        for d, (ell, g, k) in enumerate(order):
            nodes *= g
            later_primes = len(set(s[0] for s in order[d + 1:]))
            tot += nodes * (1 + PUSH * 2 * G * later_primes) * step_cost(ell, G, k, model)
        return tot, nodes
    best = None
    # group by prime (keep the j-order inside a prime), permute the primes
    groups = {}
    for s in steps: groups.setdefault(s[0], []).append(s)
    keys = list(groups)
    def key(l):
        ell, g, k = groups[l][0]
        c = sum(step_cost(*st[0:1], G, st[2], model) for st in groups[l])
        gg = 1
        for st in groups[l]: gg *= st[1]
        return c * gg / max(gg - 1, 1)
    heur = sorted(keys, key=lambda l: -key(l))
    perms = itertools.permutations(keys) if (EXHAUSTIVE and len(keys) <= 7) else [heur]
    for perm in perms:
        order = [s for l in perm for s in groups[l]]
        c, leaves = cost(order)
        if best is None or c < best[0]:
            best = (c, leaves, [l for l in perm])
    return best

def rho_total(T, c_it):
    return math.log2(2 ** LOG2_E0_RHO + T / c_it)

MODELS = ["ell^G", "LR23", "LR12"]
EXHAUSTIVE = False
PUSH = int(sys.argv[1]) if len(sys.argv) > 1 else 1
TAG = "" if PUSH == 1 else "_nopush"
RESULTS = {"meta": {"log2_E0_rho_its": LOG2_E0_RHO, "log2_negation_rho_its": LOG2_NEG_RHO,
                    "c_it_values": [5, 7], "p": str(p), "log2_sqrt_p": math.log2(p) / 2}}

# ---------------- V8 / V4 / V4+ : M = 3^n [7^2] A^2 ----------------
def pool(allow_inert, kmax):
    out = []
    for l, row in sorted(SP.items()):
        if l in (3, 7): continue
        if row["kind"] == "elkies" or (allow_inert and row["kind"] == "inert"):
            if row["k_full_e1"] <= kmax and l < 700:
                out.append(l)
    return out

def enumerate_A(pl, lo, hi, cap=400000, must=None):
    """squarefree products of primes from pl in [lo, hi)"""
    res = []
    pl = sorted(pl)
    def dfs(i, prod, chosen):
        if len(res) >= cap: return
        if lo <= prod < hi and (must is None or must in chosen):
            res.append((prod, tuple(chosen)))
        for j in range(i, len(pl)):
            np_ = prod * pl[j]
            if np_ >= hi: break
            dfs(j + 1, np_, chosen + [pl[j]])
    dfs(0, 1, [])
    return res

def is_sum_two_squares(m):
    for (l, e) in factor(m):
        if l % 4 == 3 and e % 2: return False
    return True

def run_galbraith(name, G, two_sq, allow_inert, seven, kmax=400, cap=60000):
    pl = pool(allow_inert, kmax)
    rows = {mdl: [] for mdl in MODELS}
    n_cand = 0
    for n in range(0, 7):
        s = 3 ** n * (49 if seven else 1)
        lo = math.isqrt(p // s) + 1
        hi = math.isqrt(3 * p // s) + 1                       # M in (p, ~3p)
        cands = enumerate_A(pl, lo, hi, cap=cap)
        n1, n2 = (n + 1) // 2, n // 2
        s7 = steps_for(7, 1) if seven else []
        s3a = steps_for(3, n1) if n1 else []
        s3b = steps_for(3, n2) if n2 else []
        for A, primes in cands:
            M = s * A * A
            if M <= p: continue
            n_cand += 1
            base = [st for l in primes for st in steps_for(l, 1)]
            st1 = base + s7 + s3a
            st2 = base + s7 + s3b
            for mdl in MODELS:
                c1 = tree_cost(st1, G, mdl)
                c2 = tree_cost(st2, G, mdl)
                rows[mdl].append((c1[0] + c2[0], n, A, primes, M, c1))
    out = {"G": G, "two_squares": two_sq, "inert_allowed": allow_inert, "self_pairing_7": seven,
           "n_candidates": n_cand, "kmax": kmax, "best": {}}
    for mdl in MODELS:
        rows[mdl].sort(key=lambda r: r[0])
        b = None; tested = 0
        for (T, n, A, primes, M, c1) in rows[mdl]:
            m = Integer(M - p); tested += 1
            if two_sq and not is_sum_two_squares(m): continue
            b = {"T": T, "log2_T_Fq_mults": math.log2(T), "n": n, "A_primes": list(primes),
                 "M": str(M), "log2_M": math.log2(M), "m": str(m),
                 "log2_leaves_F1 (#guesses)": math.log2(c1[1]), "order_F1_primes": c1[2],
                 "max_k": max([ord_full(l, 1) for l in primes] + ([ord_full(3, (n + 1) // 2)] if n else []) + ([42] if seven else [])),
                 "rank_among_candidates_before_SOS_filter": tested}
            break
        if b is None: continue
        if two_sq:
            a1, a2 = two_squares(m); b["m_two_squares"] = [str(a1), str(a2)]
            assert a1 * a1 + a2 * a2 == m
        b["log2_T_best_ignoring_SOS"] = math.log2(rows[mdl][0][0])
        b["effective_log2_its_c5"] = rho_total(b["T"], 5)
        b["effective_log2_its_c7"] = rho_total(b["T"], 7)
        b["gain_vs_negation_rho_bits_c5"] = LOG2_NEG_RHO - b["effective_log2_its_c5"]
        b["T"] = "%.4g" % b["T"]
        out["best"][mdl] = b
    RESULTS[name] = out
    print(name, json.dumps(out, indent=None)[:2500], flush=True)

run_galbraith("V8_galbraith_thm1_four_squares_dim8", 8, False, False, False)
run_galbraith("V4_two_squares_dim4", 4, True, False, False)
run_galbraith("V4plus_two_squares_dim4_inert_and_selfpair7", 4, True, True, True)
run_galbraith("V8plus_four_squares_dim8_inert_and_selfpair7", 8, False, True, True)

# ---------------- V2 : M = p + x^2, smooth, coprime split, hash MITM ----------------
import numpy as np
def v2_search(X_half_max, kmax=600, chunk=1 << 23):
    allowed = []                      # (prime, max exponent allowed by kmax)
    for l, row in SP.items():
        if l == 263: continue
        emax = 0
        for e in range(1, 6):
            k = ord_full(l, e) if l ** e < 10 ** 7 else 10 ** 9
            if k <= kmax and (l ** e) < 10 ** 9: emax = e
            else: break
        if emax: allowed.append((l, emax))
    allowed.sort()
    hits = []
    ROOTS = []
    for (l, emax) in allowed:
        ll = 1
        for e in range(1, emax + 1):
            ll *= l
            if ll > 5 * 10 ** 5: break
            r = np.arange(ll, dtype=np.int64)
            ROOTS.append((l, ll, [int(v) for v in r[(4 * r * r + int(p % ll)) % ll == 0]]))
    # x = 2i (M odd). sieve log2 over i in [0, X_half_max)
    for start in range(1, X_half_max, chunk):
        i = np.arange(start, min(start + chunk, X_half_max), dtype=np.int64)
        acc = np.zeros(len(i), dtype=np.float32)
        for (l, ll, roots) in ROOTS:
            lg = math.log2(l)
            for r0 in roots:
                off = (r0 - start) % ll
                acc[off::ll] += lg
        M_log = np.log2(p + 4.0 * i.astype(np.float64) ** 2)
        cand = np.nonzero(acc >= M_log - 0.01)[0]
        for c in cand:
            ii = int(i[c]); M = int(p) + 4 * ii * ii
            fac = factor(Integer(M))
            ok = all(any(l == a and e <= em for a, em in allowed) for l, e in fac)
            if ok: hits.append((2 * ii, M, [(int(l), int(e)) for l, e in fac]))
    return allowed, hits

def v2_cost(fac, model, G=2):
    parts = [steps_for(l, e) for (l, e) in fac]
    best = None
    idx = range(len(parts))
    for mask in range(1, 2 ** len(parts) - 1):
        s1 = [st for j in idx if mask >> j & 1 for st in parts[j]]
        s2 = [st for j in idx if not mask >> j & 1 for st in parts[j]]
        c1 = tree_cost(s1, G, model, halve=True)
        c2 = tree_cost(s2, G, model, halve=False)
        T = c1[0] + c2[0]
        if best is None or T < best[0]:
            M1 = 1
            for j in idx:
                if mask >> j & 1: M1 *= fac[j][0] ** fac[j][1]
            best = (T, c1[1], c2[1], M1)
    return best

t2 = time.time()
allowed, hits = v2_search(X_half_max=1 << 27)          # x < 2^28, M < p + 2^56 < 1.5 p
print("V2 sieve: allowed prime powers", len(allowed), "hits", len(hits), "time", round(time.time() - t2, 1), flush=True)
v2 = {"G": 2, "x_range": "x even, 0 < x < 2^28", "n_smooth_hits": len(hits), "best": {}}
for mdl in MODELS:
    bestrow = None
    for (x, M, fac) in hits:
        if len(fac) > 10: continue
        T, g1, g2, M1 = v2_cost(fac, mdl)
        if bestrow is None or T < bestrow["T"]:
            bestrow = {"T": T, "x": str(x), "M": str(M), "log2_M": math.log2(M), "factorization": fac,
                       "M1": str(M1), "M2": str(M // M1), "log2_leaves_F1": math.log2(g1), "log2_leaves_F2": math.log2(g2),
                       "log2_memory_entries": math.log2(min(g1, g2))}
    b = bestrow
    b["log2_T_Fq_mults"] = math.log2(b["T"])
    b["effective_log2_its_c5"] = rho_total(b["T"], 5)
    b["effective_log2_its_c7"] = rho_total(b["T"], 7)
    b["gain_vs_negation_rho_bits_c5"] = LOG2_NEG_RHO - b["effective_log2_its_c5"]
    b["T"] = "%.4g" % b["T"]
    v2["best"][mdl] = b
    print("V2", mdl, json.dumps(b)[:900], flush=True)
RESULTS["V2_dim2_square_gamma_hashMITM"] = v2

# break-even per-leaf cost: transport budget that still leaves a gain / keeps within 0.1 bit of E0
for c_it in (5, 7):
    RESULTS["meta"]["log2_budget_Fq_mults_for_any_gain_c%d" % c_it] = math.log2((2 ** LOG2_NEG_RHO - 2 ** LOG2_E0_RHO) * c_it)
    RESULTS["meta"]["log2_budget_Fq_mults_within_0.1bit_of_E0_c%d" % c_it] = math.log2((2 ** 0.1 - 1) * 2 ** LOG2_E0_RHO * c_it)
RESULTS["meta"]["elapsed_s"] = round(time.time() - T0, 1)
# exhaustive re-ordering of the reported best parameter sets (<= 7 prime groups): confirm the heuristic order
EXHAUSTIVE = True
for name, blk in RESULTS.items():
    if name == "meta" or "best" not in blk: continue
    for mdl, b in blk["best"].items():
        if "A_primes" in b:
            n = b["n"]; seven = blk["self_pairing_7"]; G = blk["G"]
            base = [st for l in b["A_primes"] for st in steps_for(l, 1)]
            s7 = steps_for(7, 1) if seven else []
            st1 = base + s7 + (steps_for(3, (n + 1) // 2) if n else [])
            st2 = base + s7 + (steps_for(3, n // 2) if n // 2 else [])
            T = tree_cost(st1, G, mdl)[0] + tree_cost(st2, G, mdl)[0]
        else:
            T, _, _, _ = v2_cost(b["factorization"], mdl)
        b["log2_T_exhaustive_order"] = math.log2(T)
        b["leaves_total_log2"] = b.get("log2_leaves_F1 (#guesses)", None)
# per-leaf budgets
RESULTS["meta"]["note_budget"] = "max F_q-mults per transport for (a) any gain over native rho, (b) staying within 0.1 bit of E0 rho"
json.dump(RESULTS, open("s2_kani_params%s.json" % TAG, "w"), indent=1, default=str)
print(json.dumps(RESULTS["meta"], indent=1))
print("DONE")
