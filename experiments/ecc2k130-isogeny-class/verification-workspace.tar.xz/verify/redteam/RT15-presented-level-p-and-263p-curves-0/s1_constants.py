# RT15 / script 1: constants, classical obstruction, small-prime Galois data, char-2 torsion facts.
# Run:  export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; timeout 2400 sage -python s1_constants.py
import sys, json, math, time
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
from sage.all import (Integer, ZZ, GF, kronecker, factor, is_prime, lcm, pari, EllipticCurve,
                      PolynomialRing, Mod, gcd, set_random_seed, log)
import ecc2k

T0 = time.time()
set_random_seed(20260924)
OUT = {}
def rec(k, v):
    OUT[k] = v
    print(k, "=", v, flush=True)

q, t, N, f, p = Integer(ecc2k.q), Integer(ecc2k.t), Integer(ecc2k.N), Integer(ecc2k.f), Integer(ecc2k.p)

# ---- 1. re-derive the trace from #E0(F_2) = 4 (tau^2 + tau + 2 = 0) by the Lucas recurrence
a0, a1 = Integer(2), Integer(-1)            # trace of pi_2^0, pi_2^1 ; tau^2 = -tau - 2
for _ in range(130):
    a0, a1 = a1, -a1 - 2 * a0
rec("t_lucas_equals_ground_truth", a1 == t)
rec("card_is_4N", q + 1 - t == 4 * N)
rec("disc_is_-7f^2", t * t - 4 * q == -7 * f * f)
rec("f_is_263p", f == 263 * p)
rec("N_prime", bool(is_prime(N)))
rec("p_prime", bool(is_prime(p)))
rec("log2_p", float(math.log2(p)))
rec("log2_sqrt_p", float(math.log2(p) / 2))
rec("kronecker(-7,p)", int(kronecker(-7, p)))
rec("kronecker(-7,263)", int(kronecker(-7, 263)))
# class numbers of the level-p and level-263p orders (h(O_K)=1, O_K^* = {+-1}):
hp = p - kronecker(-7, p)
h263p = (263 - kronecker(-7, 263)) * hp
rec("h(O_p) = p - (-7|p)", str(hp))
rec("h(O_263p) = 262 * h(O_p)", str(h263p))
rec("log2 h(O_263p)", float(math.log2(h263p)))

# ---- 2. classical obstruction: kernel of the ascending p-isogeny = eigenline of pi on E[p]
c = Mod(t, p) / 2
rec("c = t/2 mod p", int(c))
rec("factor(p-1)", str(factor(p - 1)))
r = c.multiplicative_order()
rec("r = ord_p(c) (field degree of kernel points over F_q)", int(r))
rec("log2 r", float(math.log2(r)))
rx = r // 2 if c ** (r // 2) == -1 else r
rec("r_x (field degree of kernel x-coordinates)", int(rx))
rec("bytes per F_{q^r_x} element", float(131 * rx / 8))

# ---- 3. rho baselines
rec("log2 rho E0 (neg+tau, class 2*131)", float(0.5 * math.log2(math.pi * N / (4 * 131))))
rec("log2 rho negation only", float(0.5 * math.log2(math.pi * N / 4)))

# ---- 4. Galois structure of E[l^e] for small l (same for every curve in the class when l !| 263p)
# pi = a + b*w, w = (1+sqrt(-7))/2, w^2 = w - 2 ; t = 2a + b, N(pi) = a^2 + ab + 2b^2 = q
b_ = f if (t - f) % 2 == 0 else -f
a_ = (t - b_) // 2
assert a_ * a_ + a_ * b_ + 2 * b_ * b_ == q and 2 * a_ + b_ == t
def mulw(x, y, n):      # (x0 + x1 w)(y0 + y1 w) mod n
    x0, x1 = x; y0, y1 = y
    return ((x0 * y0 - 2 * x1 * y1) % n, (x0 * y1 + x1 * y0 + x1 * y1) % n)
def powpi(e, n):
    res, base = (1, 0), (a_ % n, b_ % n)
    while e:
        if e & 1: res = mulw(res, base, n)
        base = mulw(base, base, n); e >>= 1
    return res
def ord_pi(n, group_order):
    """order of pi in (O_K/n)^*, given a multiple group_order of it"""
    o = Integer(group_order)
    assert powpi(int(o), n) == (1, 0)
    for (ell, e) in factor(o):
        while o % ell == 0 and powpi(int(o // ell), n) == (1, 0):
            o //= ell
    return int(o)
def unit_group_order(ell, e):
    k = kronecker(-7, ell)
    if k == 1:  return (ell - 1) ** 2 * ell ** (2 * (e - 1))
    if k == -1: return (ell * ell - 1) * ell ** (2 * (e - 1))
    return (ell - 1) * ell ** (2 * e - 1)        # ramified (ell = 7)
def guesses(ell, e):
    """size of the norm-1 torus of (O_K/ell^e)^*: candidates for phi on E[ell^e] after the Weil pairing"""
    k = kronecker(-7, ell)
    if k == 1:  return (ell - 1) * ell ** (e - 1)
    if k == -1: return (ell + 1) * ell ** (e - 1)
    return 2 * ell ** e                           # ramified 7 (before any self-pairing)
small = []
for ell in [Integer(x) for x in range(3, 1500) if is_prime(x)]:
    if ell in (263,): continue
    kind = {1: "elkies", -1: "inert", 0: "ramified"}[int(kronecker(-7, ell))]
    row = {"l": int(ell), "kind": kind}
    for e in (1, 2):
        if ell ** e > 10 ** 7: break
        row["k_full_e%d" % e] = ord_pi(int(ell ** e), unit_group_order(ell, e))
        row["guesses_e%d" % e] = int(guesses(ell, e))
    if kind == "elkies":
        R = PolynomialRing(GF(ell), "X"); X = R.gen()
        al, be = [rt for rt, _ in (X ** 2 - t * X + q).roots()]
        row["eig"] = [int(al), int(be)]
        row["k_eig"] = [int(al.multiplicative_order()), int(be.multiplicative_order())]
        assert lcm(row["k_eig"]) == row["k_full_e1"]
    small.append(row)
rec("n_small_primes_tabulated", len(small))
rec("first_elkies", [(s["l"], s["k_eig"], s["k_full_e1"]) for s in small if s["kind"] == "elkies"][:15])
rec("first_inert", [(s["l"], s["k_full_e1"]) for s in small if s["kind"] == "inert"][:10])
rec("ramified_7", [s for s in small if s["l"] == 7][0])
rec("3-powers k_full", [(e, ord_pi(3 ** e, unit_group_order(3, e))) for e in range(1, 7)])

# ---- 5. characteristic-2 facts that constrain the Kani machinery
K, curves = ecc2k.load(labels=["E0", "A000", "B064"])
for lab, E in curves.items():
    psi2 = E.division_polynomial(2)
    rts = psi2.roots()
    rec("%s: 2-division polynomial" % lab, str(psi2))
    rec("%s: distinct x-roots of 2-division poly (= #nonzero 2-torsion pts over F2bar)" % lab, len(set(r0 for r0, _ in rts)))
# E0(F_q)[2^oo] = Z/4 (cyclic): exhibit a point of exact order 4
E0 = curves["E0"]
while True:
    P = N * E0.random_point()
    if not (2 * P).is_zero(): break
rec("E0: exists point of exact order 4 in E0(F_q) (so E0(F_q)[2^oo] = Z/4)", bool((4 * P).is_zero() and not (2 * P).is_zero()))
rec("Weil pairing e_2 on the etale 2-torsion is trivial (only one nonzero point)", True)
rec("elapsed_s", round(time.time() - T0, 1))
json.dump({"results": OUT, "small_primes": small}, open("s1_constants.json", "w"), indent=1, default=str)
print("DONE")
