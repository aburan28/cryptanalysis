# RT15 / script 3: characteristic-2 toy check of the torsion-data part of Galbraith Thm 1 / GGR 2025
# (everything except the higher-dimensional isogeny chain, for which no char-2 implementation exists).
# Toy: Koblitz E0: y^2+xy = x^3+1 over F_{2^37}; t^2-4q = -7 f^2, f = 73*2663; l0 = 73 is inert in Q(sqrt-7),
# i.e. the same situation as p for ECC2K-130 (crater of size 1, E1 = a 73-floor curve).
# Checks:
#  (a) descending 73-isogeny phi: E0 -> E1 (F_q-rational), E1 on the 73-floor, #E1 = #E0
#  (b) for toy-Elkies primes l: phi maps Frobenius eigenpoints to eigenpoints (same eigenvalue);
#      phi(P0) = lam*P1, phi(Q0) = mu*Q1 and the Weil pairing fixes lam*mu: the pairing-consistent candidates
#      form exactly one (Z/l)^* orbit (l-1 of them) and the true (lam,mu) is one of them;
#      every candidate gives a Weil-isotropic dimension-2 Kani kernel {(phi_hat-guess(P), -x P)}: no pruning.
#  (c) GGR self-pairing on E[7] (7 | Delta(O_K) = -7): tau = 2 pi - t; e_7(P, tau P) != 1 on E0 and E1,
#      and phi(tau P0) = a * tau P1 with a^2 fixed by the pairings: only 2 candidates (a, -a).
import json, time, random
T0 = time.time(); set_random_seed(int(20260924)); random.seed(int(20260924))
out = {}
def rec(k, v):
    out[k] = v; print(k, "=", v, flush=True)
m = 37; q = 2^m
t0, t1 = 2, -1
for k in range(1, m): t0, t1 = t1, -t1 - 2*t0
t = t1
f = isqrt((4*q - t^2)//7); assert -7*f^2 == t^2 - 4*q
l0 = 73; assert f % l0 == 0 and kronecker(-7, l0) == -1
rec("t", t); rec("f", str(factor(f)))
K37.<a> = GF(2^m)
E0 = EllipticCurve(K37, [1, 0, 0, 0, 1]); assert E0.order() == q + 1 - t
def tk(k):
    A, B = 2, t
    for _ in range(k - 1): A, B = B, t*B - q*A
    return B if k >= 1 else 2
# ---- (a) descending 73-isogeny, as in the C4 toy: E0[73] lives over F_{q^18}
c = GF(l0)(t)/2; r = c.multiplicative_order(); rec("ord of t/2 mod 73 (field degree of E0[73])", r)
Kr.<z> = GF(2^(m*r))
emb = K37.hom([K37.modulus().change_ring(Kr).roots(multiplicities=False)[0]], Kr); sec = emb.section()
NK = q^r + 1 - tk(r); v = valuation(NK, l0)
E0r = EllipticCurve(Kr, [emb(ai) for ai in E0.a_invariants()])
while True:
    R = (NK // l0^v) * E0r.random_point()
    if R.is_zero(): continue
    while not (l0*R).is_zero(): R = l0*R
    break
RX.<X> = Kr[]
h = prod(X - (k*R)[0] for k in range(1, (l0 - 1)//2 + 1))
h = PolynomialRing(K37, 'X')([sec(co) for co in h.list()])
phi = E0.isogeny(h); E1 = phi.codomain()
rec("j(E1) != 1 and #E1 == #E0", bool(E1.j_invariant() != 1 and E1.order() == E0.order()))
rec("phi degree", int(phi.degree()))
xmap, ymap = phi.rational_maps()
rec("time_after_(a)_s", round(time.time() - T0, 1))

def ext_curve(E, KK, e):
    return EllipticCurve(KK, [e(ai) for ai in E.a_invariants()])
def ev_phi(P, e, EK1):
    """evaluate phi (rational maps over F_q) at a point over an extension KK (embedding e)"""
    x0, y0 = P[0], P[1]
    def evr(rf):
        num = rf.numerator(); den = rf.denominator()
        def evp(pol):
            return sum(e(cf) * x0^i * y0^j for (i, j), cf in pol.dict().items())
        return evp(num) / evp(den)
    return EK1(evr(xmap), evr(ymap))
def frobq(P):
    return P.curve()(P[0]^q, P[1]^q)

# ---- (b) toy-Elkies primes with small eigen-degree
cands = []
for l in primes(5, 200):
    if f % l == 0 or kronecker(-7, l) != 1: continue
    R2.<Y> = GF(l)[]
    al, be = [rr for rr, _ in (Y^2 - t*Y + q).roots()]
    k = lcm(al.multiplicative_order(), be.multiplicative_order())
    cands.append((k, l, int(al), int(be)))
cands.sort()
rec("toy Elkies primes (k, l, alpha, beta), smallest k first", cands[:6])
resb = {}
for (k, l, al, be) in cands[:3]:
    KK = GF(2^(m*k), 'w')
    e = K37.hom([K37.modulus().change_ring(KK).roots(multiplicities=False)[0]], KK)
    EK0 = ext_curve(E0, KK, e); EK1 = ext_curve(E1, KK, e)
    NKk = q^k + 1 - tk(k); vv = valuation(NKk, l)
    def eigpt(EK, lam):
        # random l-torsion point, projected onto the lam-eigenline: (pi - mu)(P) kills the mu-part
        other = be if lam == al else al
        while True:
            P = (NKk // l^vv) * EK.random_point()
            while not P.is_zero() and not (l*P).is_zero(): P = l*P
            if P.is_zero(): continue
            Pe = frobq(P) - other*P
            if not Pe.is_zero():
                assert frobq(Pe) == lam*Pe
                return Pe
    P0, Q0 = eigpt(EK0, al), eigpt(EK0, be)
    P1, Q1 = eigpt(EK1, al), eigpt(EK1, be)
    fP0, fQ0 = ev_phi(P0, e, EK1), ev_phi(Q0, e, EK1)
    ok_eig = (frobq(fP0) == al*fP0) and (frobq(fQ0) == be*fQ0)
    lam = next(i for i in range(1, l) if i*P1 == fP0)
    mu = next(i for i in range(1, l) if i*Q1 == fQ0)
    w0 = P0.weil_pairing(Q0, l); w1 = P1.weil_pairing(Q1, l)
    # lam*mu predicted from pairings alone: e(phi P0, phi Q0) = e(P0,Q0)^deg  =>  w1^(lam mu) = w0^73
    pred = [s for s in range(1, l) if w1^s == w0^l0]
    # all (lam', mu') with lam'*mu' = pred: l-1 candidates; check each gives an isotropic Kani kernel
    # (dimension 2, gamma = [x], M = 73 + x^2 prime to l ... isotropy only needs the pairing relation)
    x = 2
    iso_all = True
    for lp in range(1, l):
        mp = (pred[0] * inverse_mod(lp, l)) % l
        # kernel generators in E0 x E1 [l]:  (guess of phi on P0, Q0) paired as (phi(P), -x P)-type
        g1 = (P0, -x*(lp*P1)); g2 = (Q0, -x*(mp*Q1))
        # product pairing: e(P0,Q0) * e(x lp P1, x mp Q1)  must equal  e(P0,Q0)^(1 + ...) ; test the
        # graph-of-phi kernel {(P, phi(P))} of the l-part of an (73+x^2)-isogeny: e(P,Q)^M = 1 iff consistent
        val = (w0^(x*x)) * (w1^(lp*mp))^(1)
        # isotropy condition for {( [x]P, phi(P) )}: e(xP0,xQ0) * e(phi P0, phi Q0) = w0^(x^2) * w1^(lp*mp) = w0^(x^2+73)
        iso_all &= (val == w0^(x*x + l0))
    resb[str(l)] = {"k": k, "eigenpoints mapped to eigenpoints": bool(ok_eig), "true (lam, mu)": [lam, mu],
                    "lam*mu predicted by pairing": pred, "true lam*mu": (lam*mu) % l,
                    "n pairing-consistent candidates": l - 1,
                    "all candidates give Weil-isotropic kernels (no pruning)": bool(iso_all)}
    print(l, resb[str(l)], flush=True)
rec("(b) Elkies-prime torsion data", resb)

# ---- (c) GGR self-pairing on E[7]
R7.<Y> = GF(7)[]
k7 = None
# degree of the field of E[7]: smallest k with pi^k = 1 on E[7]; test via #E(F_{q^k}) divisible by 49 and full torsion
for k in range(1, 400):
    NKk = q^k + 1 - tk(k)
    if NKk % 49 == 0 and (t^k if False else True):
        # full 7-torsion over F_{q^k} iff pi^k = 1 mod 7 End: check via trace: pi^k = 1 mod 7 <=> tk(k) = 2 mod 7 and q^k = 1 mod 7
        # and pi^k - 1 divisible by 7 in O_K: norm (q^k + 1 - tk(k)) divisible by 49 is necessary; verify by points below
        k7 = k; break
rec("first k with 49 | #E(F_{q^k})", k7)
KK = GF(2^(m*k7), 'u')
e = K37.hom([K37.modulus().change_ring(KK).roots(multiplicities=False)[0]], KK)
EK0 = ext_curve(E0, KK, e); EK1 = ext_curve(E1, KK, e)
NKk = q^k7 + 1 - tk(k7); vv = valuation(NKk, 7)
def tau(P):   # tau = 2 pi - t
    return 2*frobq(P) - t*P
def gen7(EK):
    for _ in range(50):
        P = (NKk // 7^vv) * EK.random_point()
        while not P.is_zero() and not (7*P).is_zero(): P = 7*P
        if P.is_zero(): continue
        if not tau(P).is_zero() and P.weil_pairing(tau(P), 7) != 1:
            return P
    return None
P0 = gen7(EK0); P1 = gen7(EK1)
rec("(c) found P with e_7(P, tau P) != 1 on E0 and on E1", bool(P0 is not None and P1 is not None))
if P0 is not None and P1 is not None:
    T0p = P0.weil_pairing(tau(P0), 7); T1p = P1.weil_pairing(tau(P1), 7)
    fP0 = ev_phi(P0, e, EK1); ftP0 = ev_phi(tau(P0), e, EK1)
    rec("(c) phi commutes with tau on E[7]", bool(ftP0 == tau(fP0)))
    # tau^2 = t^2-4q = -7 f^2 = 0 on E[7], so tau(E[7]) is a line; phi(tau P0) = a * tau P1 for some a
    tP1 = tau(P1)
    a_true = [i for i in range(1, 7) if i*tP1 == ftP0]
    # pairing: e(phi P0, tau phi P0) = e(P0, tau P0)^73 ; phi P0 = a P1 + b tau P1  =>  T1^(a^2) = T0^73
    cand = [i for i in range(1, 7) if T1p^(i*i) == T0p^l0]
    rec("(c) phi(tau P0) = a * tau(P1) with a in", a_true)
    rec("(c) candidates for a from the self-pairing alone (GGR: T = #sqrt(1) mod 7 = 2)", cand)
    rec("(c) true a among candidates", bool(a_true and a_true[0] in cand))
rec("elapsed_s", round(time.time() - T0, 1))
json.dump(out, open("s3_toy_char2.json", "w"), indent=1, default=str)
print("DONE")
