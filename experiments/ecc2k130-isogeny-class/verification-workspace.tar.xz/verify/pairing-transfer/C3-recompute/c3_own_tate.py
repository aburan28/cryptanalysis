#!/usr/bin/env python3
"""
C3 recompute: independent re-derivation of the 263-Tate-pairing claims on all 263
curves of the ECC2K-130 isogeny class, with a code path that shares nothing with
the sweep (no Sage, no PARI, no GF(2^262) pentanomial, no Sage _miller_).

Own implementation, pure python3:
  * F_q = F_2[z]/(z^131+z^13+z^2+z+1), elements = int bitmasks (bit i = z^i).
  * F_{q^2} = F_q[w]/(w^2+w+1) (a tower; irreducible because Tr_{F_q/F_2}(1) = 1).
    Elements are pairs (a0, a1) = a0 + a1*w.  Frobenius x -> x^q is a0+a1w -> (a0+a1) + a1 w.
  * Curves y^2 + x y = x^3 + a2 x^2 + b, affine arithmetic, own Miller loop with the
    divisor D_Q = (Q+R) - (R), own final exponentiation (two ways: generic power by
    (q^2-1)/263 and Norm_{F_q^2/F_q} followed by ^((q-1)/263)).
Only data read from outside: b_int and a2 of every curve from ground_truth.json.
The trace t is recomputed here from the Lucas recurrence; #E(F_q) = 4N is re-proved
per curve with an own point of order N.
"""
import json, os, random, sys, time, hashlib
from multiprocessing import Pool

GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
OUTDIR = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------- F_q
M = 131
MODPOLY = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << M) - 1

def red(r):
    # reduce a polynomial of degree <= 261 mod z^131 + z^13 + z^2 + z + 1
    while r >> M:
        hi = r >> M
        r = (r & MASK) ^ hi ^ (hi << 1) ^ (hi << 2) ^ (hi << 13)
    return r

def clmul(a, b):
    if a == 0 or b == 0:
        return 0
    t = [0] * 16
    t[1] = a
    for i in range(2, 16, 2):
        t[i] = t[i >> 1] << 1
        t[i + 1] = t[i] ^ a
    r = 0
    nb = b.bit_length()
    s = ((nb - 1) // 4) * 4
    while s >= 0:
        r = (r << 4) ^ t[(b >> s) & 15]
        s -= 4
    return r

def fmul(a, b):
    return red(clmul(a, b))

SPREAD = [0] * 256
for _i in range(256):
    v = 0
    for _k in range(8):
        if (_i >> _k) & 1:
            v |= 1 << (2 * _k)
    SPREAD[_i] = v.to_bytes(2, "little")

def fsqr(a):
    bs = a.to_bytes(17, "little")
    return red(int.from_bytes(b"".join(SPREAD[c] for c in bs), "little"))

def finv(a):
    if a == 0:
        raise ZeroDivisionError("inverse of 0 in F_q")
    u, v = a, MODPOLY
    g1, g2 = 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v = v, u
            g1, g2 = g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return red(g1)

def fpow(a, e):
    r = 1
    for bit in bin(e)[2:]:
        r = fsqr(r)
        if bit == "1":
            r = fmul(r, a)
    return r

# trace as a linear functional: Tr(z^i) for each i
def _trace_slow(a):
    s, x = 0, a
    for _ in range(M):
        s ^= x
        x = fsqr(x)
    return s

TRMASK = 0
for _i in range(M):
    tv = _trace_slow(1 << _i)
    assert tv in (0, 1)
    TRMASK |= tv << _i

def ftr(a):
    return bin(a & TRMASK).count("1") & 1

def fhalftrace(c):
    # H(c) = sum_{i=0}^{65} c^(4^i);  H(c)^2 + H(c) = c + Tr(c)  (M odd)
    s, x = 0, c
    for _ in range((M - 1) // 2 + 1):
        s ^= x
        x = fsqr(fsqr(x))
    return s

# ---------------------------------------------------------------- F_{q^2} = F_q(w), w^2 = w + 1
ZERO2 = (0, 0)
ONE2 = (1, 0)

def add2(a, b):
    return (a[0] ^ b[0], a[1] ^ b[1])

def mul2(a, b):
    a0, a1 = a
    b0, b1 = b
    m0 = fmul(a0, b0)
    m1 = fmul(a1, b1)
    m2 = fmul(a0 ^ a1, b0 ^ b1)
    return (m0 ^ m1, m2 ^ m0)

def sqr2(a):
    s1 = fsqr(a[1])
    return (fsqr(a[0]) ^ s1, s1)

def frob2(a):  # a^q
    return (a[0] ^ a[1], a[1])

def norm2(a):  # a * a^q in F_q
    a0, a1 = a
    return fsqr(a0) ^ fmul(a0, a1) ^ fsqr(a1)

def inv2(a):
    n = norm2(a)
    ni = finv(n)
    c = frob2(a)
    return (fmul(c[0], ni), fmul(c[1], ni))

def pow2(a, e):
    r = ONE2
    for bit in bin(e)[2:]:
        r = sqr2(r)
        if bit == "1":
            r = mul2(r, a)
    return r

def iszero2(a):
    return a[0] == 0 and a[1] == 0

# ---------------------------------------------------------------- integers
q = 1 << 131
# trace via Lucas recurrence from #E0(F_2) = 4 (brute force below)
def count_E0_F2():
    pts = 1  # O
    for x in (0, 1):
        for y in (0, 1):
            if (y * y + x * y) % 2 == (x ** 3 + 0 * x * x + 1) % 2:
                pts += 1
    return pts

def lucas_trace(t1, n):
    # t_{k+1} = t1 t_k - 2 t_{k-1}, t_0 = 2
    a, b = 2, t1
    for _ in range(n - 1):
        a, b = b, t1 * b - 2 * a
    return b

def is_probable_prime(n, rounds=40):
    if n < 2:
        return False
    for sp in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % sp == 0:
            return n == sp
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    rng = random.Random(n)
    for _ in range(rounds):
        a = rng.randrange(2, n - 1)
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True

def v_p(n, p):
    k = 0
    while n % p == 0:
        n //= p
        k += 1
    return k

# ---------------------------------------------------------------- curve arithmetic over F_{q^2}
class Curve:
    def __init__(self, a2, b):
        self.a2 = (a2, 0)
        self.b = (b, 0)

    def on(self, P):
        if P is None:
            return True
        x, y = P
        lhs = add2(sqr2(y), mul2(x, y))
        x2 = sqr2(x)
        rhs = add2(add2(mul2(x2, x), mul2(self.a2, x2)), self.b)
        return lhs == rhs

    def neg(self, P):
        if P is None:
            return None
        return (P[0], add2(P[0], P[1]))

    def add(self, P, Q):
        if P is None:
            return Q
        if Q is None:
            return P
        x1, y1 = P
        x2, y2 = Q
        if x1 == x2:
            if add2(y1, y2) == x1:  # Q = -P  (y2 = y1 + x1)
                return None
            # P == Q
            return self.dbl(P)
        lam = mul2(add2(y1, y2), inv2(add2(x1, x2)))
        x3 = add2(add2(add2(add2(sqr2(lam), lam), self.a2), x1), x2)
        y3 = add2(add2(mul2(lam, add2(x1, x3)), x3), y1)
        return (x3, y3)

    def dbl(self, P):
        if P is None:
            return None
        x1, y1 = P
        if iszero2(x1):
            return None
        lam = add2(x1, mul2(y1, inv2(x1)))
        x3 = add2(add2(sqr2(lam), lam), self.a2)
        y3 = add2(add2(mul2(lam, add2(x1, x3)), x3), y1)
        return (x3, y3)

    def mul(self, k, P):
        if k < 0:
            return self.mul(-k, self.neg(P))
        R = None
        for bit in bin(k)[2:] if k else "":
            R = self.dbl(R)
            if bit == "1":
                R = self.add(R, P)
        return R

    # --- random points
    def rand_Fq(self, rng):
        # point of E(F_q): x in F_q^*, y = x z with z^2 + z = x + a2 + b/x^2
        while True:
            x = rng.getrandbits(M)
            if x == 0:
                continue
            c = x ^ self.a2[0] ^ fmul(self.b[0], finv(fsqr(x)))
            if ftr(c):
                continue
            z = fhalftrace(c)
            assert fsqr(z) ^ z == c
            P = ((x, 0), (fmul(x, z), 0))
            assert self.on(P)
            return P

    def rand_Fq2(self, rng):
        while True:
            x = (rng.getrandbits(M), rng.getrandbits(M))
            if iszero2(x):
                continue
            c = add2(add2(x, self.a2), mul2(self.b, inv2(sqr2(x))))
            c0, c1 = c
            if ftr(c1):
                continue
            z1 = fhalftrace(c1)
            rhs0 = c0 ^ fsqr(z1)
            if ftr(rhs0):
                z1 ^= 1
                rhs0 = c0 ^ fsqr(z1)
            assert ftr(rhs0) == 0
            z0 = fhalftrace(rhs0)
            z = (z0, z1)
            assert add2(sqr2(z), z) == c
            P = (x, mul2(x, z))
            assert self.on(P)
            return P

    # --- Miller loop with divisor D = (S1) - (S2), S1 = Q+R, S2 = R
    def miller_ratio(self, n, P, S1, S2):
        """returns f_{n,P}(S1)/f_{n,P}(S2), div f_{n,P} = n(P) - n(O)."""
        fn, fd = ONE2, ONE2
        T = P

        def line_eval(xT, yT, lam, S):
            x, y = S
            return add2(add2(y, yT), mul2(lam, add2(x, xT)))

        def vert_eval(x3, S):
            return add2(S[0], x3)

        for bit in bin(n)[3:]:
            # doubling step
            xT, yT = T
            assert not iszero2(xT)
            lam = add2(xT, mul2(yT, inv2(xT)))
            T2 = self.dbl(T)
            l1, l2 = line_eval(xT, yT, lam, S1), line_eval(xT, yT, lam, S2)
            if T2 is None:
                v1 = v2 = ONE2
            else:
                v1, v2 = vert_eval(T2[0], S1), vert_eval(T2[0], S2)
            fn = mul2(sqr2(fn), mul2(l1, v2))
            fd = mul2(sqr2(fd), mul2(v1, l2))
            T = T2
            if bit == "1":
                xT, yT = T
                xP, yP = P
                if xT == xP:
                    if add2(yT, yP) == xT:  # T = -P : vertical line, result O
                        l1, l2 = vert_eval(xT, S1), vert_eval(xT, S2)
                        v1 = v2 = ONE2
                        Tn = None
                    else:
                        raise RuntimeError("T == P in addition step (n too small?)")
                else:
                    lam = mul2(add2(yT, yP), inv2(add2(xT, xP)))
                    Tn = self.add(T, P)
                    l1, l2 = line_eval(xT, yT, lam, S1), line_eval(xT, yT, lam, S2)
                    v1, v2 = vert_eval(Tn[0], S1), vert_eval(Tn[0], S2)
                fn = mul2(fn, mul2(l1, v2))
                fd = mul2(fd, mul2(v1, l2))
                T = Tn
        assert T is None, "n*P != O"
        if iszero2(fn) or iszero2(fd):
            raise ZeroDivisionError("divisor support hit")
        return mul2(fn, inv2(fd))

# ---------------------------------------------------------------- global constants (recomputed)
E0F2 = count_E0_F2()
T1 = 2 + 1 - E0F2
TRACE = lucas_trace(T1, 131)
CARD = q + 1 - TRACE
N = CARD // 4
ELL = 263
CARD2 = (q + 1 - TRACE) * (q + 1 + TRACE)       # #E(F_{q^2}) = q^2 + 1 - (t^2 - 2q)
assert CARD2 == q * q + 1 - (TRACE * TRACE - 2 * q)
COF2 = CARD2 // ELL ** 2
EXP_FULL = (q * q - 1) // ELL
EXP_FQ = (q - 1) // ELL

def reduced_tate(C, P, Q, rng, n=ELL, tries=6):
    """reduced Tate pairing t_n(P, Q) with P in E[n], computed with D_Q = (Q+R)-(R).
    Computes it with two random R and both final exponentiations; asserts agreement."""
    vals = []
    for _ in range(2):
        for _t in range(tries):
            R = C.rand_Fq2(rng)
            S1 = C.add(Q, R)
            if S1 is None:
                continue
            try:
                f = C.miller_ratio(n, P, S1, R)
            except ZeroDivisionError:
                continue
            break
        else:
            raise RuntimeError("could not find a good R")
        z_full = pow2(f, EXP_FULL)
        z_norm = fpow(norm2(f), EXP_FQ)          # (q^2-1)/n = (q+1) * (q-1)/n since n | q-1
        assert z_full == (z_norm, 0), "final exponentiations disagree"
        vals.append(z_full)
    assert vals[0] == vals[1], "pairing depends on the auxiliary point R"
    z = vals[0]
    assert z[1] == 0, "pairing value not in F_q"
    assert fpow(z[0], n) == 1, "pairing value not in mu_n"
    return z[0]

def dlog_mu(zeta, x, n=ELL):
    acc = 1
    for k in range(n):
        if acc == x:
            return k
        acc = fmul(acc, zeta)
    raise ValueError("not in <zeta>")

def point_hash(P):
    if P is None:
        return "O"
    return hashlib.sha256(repr(P).encode()).hexdigest()[:16]

# ---------------------------------------------------------------- per-curve work
def work(rec):
    t0 = time.time()
    label = rec["label"]
    a2 = int(rec["a2"])
    b = int(rec["b_int"])
    seed = int.from_bytes(hashlib.sha256(("C3-recompute-" + label).encode()).digest()[:8], "big")
    rng = random.Random(seed)
    C = Curve(a2, b)
    out = {"label": label, "seed": seed}

    # (1) #E(F_q) = 4N via an own point of order N
    while True:
        Q0 = C.rand_Fq(rng)
        QN = C.mul(4, Q0)
        if QN is not None:
            break
    assert C.mul(N, QN) is None
    out["order_N_point_found"] = True     # => N | #E(F_q) => #E(F_q) = 4N (unique multiple in Hasse)
    # Q_N in 263 * E(F_q): explicit 263-division
    inv263 = pow(ELL, -1, N)
    Rdiv = C.mul(inv263, QN)
    assert C.mul(ELL, Rdiv) == QN
    out["QN_in_263E_explicit"] = True

    # (2) structure of E(F_{q^2})[263^inf]
    samples = []
    for _ in range(4):
        R = C.rand_Fq2(rng)
        S = C.mul(COF2, R)
        samples.append(S)
    for S in samples:
        assert C.mul(ELL * ELL, S) is None
    big = [S for S in samples if C.mul(ELL, S) is not None]
    res = {}
    if big:
        T = big[0]
        res["structure"] = "Z/263^2 (cyclic)"
        res["witness"] = "point of exact order 263^2"
        P = C.mul(ELL, T)                       # generator of E(F_{q^2})[263], order 263
        assert P is not None and C.mul(ELL, P) is None
        # nondegeneracy control: t(P, T) != 1  (T generates E(F_{q^2})/263E(F_{q^2}))
        tPT = reduced_tate(C, P, T, rng)
        res["t(263T,T)!=1"] = tPT != 1
        zeta = tPT
        # bilinearity self-tests of the own implementation
        res["bilin_t(P,2T)=t^2"] = reduced_tate(C, P, C.dbl(T), rng) == fsqr(tPT)
        res["bilin_t(2P,T)=t^2"] = reduced_tate(C, C.dbl(P), T, rng) == fsqr(tPT)
        k = rng.randrange(2, ELL)
        res["bilin_t(kP,T)=t^k"] = reduced_tate(C, C.mul(k, P), T, rng) == fpow(tPT, k)
        # a generic (not cofactor-cleared) second argument U
        U = C.rand_Fq2(rng)
        tPU = reduced_tate(C, P, U, rng)
        res["t(P,U)_log"] = dlog_mu(zeta, tPU)
        # generator of the 263-torsion used for P-slot tests
        Ps = [P]
    else:
        # all samples killed by 263: expect E[263] = (Z/263)^2 inside E(F_{q^2})
        nz = [S for S in samples if S is not None]
        assert len(nz) >= 2
        P1 = nz[0]
        mults = set()
        acc = None
        for _ in range(ELL):
            acc = C.add(acc, P1)
            mults.add(acc)
        P2 = None
        for S in nz[1:]:
            if S not in mults:
                P2 = S
                break
        assert P2 is not None, "no second independent 263-torsion point found"
        res["structure"] = "(Z/263)^2"
        res["witness"] = "two 263-torsion points, second not a multiple of the first (brute force over 263 multiples)"
        tm = [[reduced_tate(C, Pi, Pj, rng) for Pj in (P1, P2)] for Pi in (P1, P2)]
        zeta = next(v for row in tm for v in row if v != 1)
        L = [[dlog_mu(zeta, v) for v in row] for row in tm]
        det = (L[0][0] * L[1][1] - L[0][1] * L[1][0]) % ELL
        res["tate_matrix_logs(zeta=first nontrivial entry)"] = L
        res["tate_matrix_det_mod_263"] = det
        res["nondegenerate"] = det != 0
        # bilinearity self-tests
        s12 = C.add(P1, P2)
        res["bilin_first_slot"] = reduced_tate(C, s12, P1, rng) == fmul(tm[0][0], tm[1][0])
        res["bilin_second_slot"] = reduced_tate(C, P1, s12, rng) == fmul(tm[0][0], tm[0][1])
        U = C.rand_Fq2(rng)
        T = U
        Ps = [P1, P2]

    # (3) the claim: t(P, Q_N) = 1 and t(P, T + c Q_N) = t(P, T)
    allone = True
    shift_inv = True
    details = []
    for Pp in Ps:
        v = reduced_tate(C, Pp, QN, rng)
        allone &= (v == 1)
        # a second, independent Q_N
        Q0b = C.rand_Fq(rng)
        QNb = C.mul(4, Q0b)
        if QNb is not None:
            assert C.mul(N, QNb) is None
            v2 = reduced_tate(C, Pp, QNb, rng)
            allone &= (v2 == 1)
        tT = reduced_tate(C, Pp, T, rng)
        for _ in range(2):
            c = rng.randrange(1, N)
            cQ = C.mul(c, QN)
            v3 = reduced_tate(C, Pp, cQ, rng)
            allone &= (v3 == 1)
            v4 = reduced_tate(C, Pp, C.add(T, cQ), rng)
            shift_inv &= (v4 == tT)
        details.append({"t(P,T)!=1": tT != 1})
    res["t(P,Q_N)==1 (2 Q_N, 2 c*Q_N per P)"] = allone
    res["t(P,T+c*Q_N)==t(P,T) (2 c per P)"] = shift_inv
    res["per_P"] = details
    out["pairing_263"] = res
    out["seconds"] = round(time.time() - t0, 2)
    return out

def main():
    t_start = time.time()
    gt = json.load(open(GT))
    recs = gt["curves"]
    labels_only = sys.argv[1:]
    if labels_only:
        recs = [r for r in recs if r["label"] in labels_only]

    glob = {}
    glob["E0(F_2)_bruteforce"] = E0F2
    glob["t1"] = T1
    glob["trace_t"] = str(TRACE)
    glob["trace_matches_task"] = TRACE == -22283658519494248867
    glob["N"] = str(N)
    glob["N_matches_task"] = N == 680564733841876926932320129493409985129
    glob["CARD==4N"] = CARD == 4 * N
    glob["N_probable_prime_MR40"] = is_probable_prime(N)
    glob["263_prime"] = is_probable_prime(ELL)
    glob["gcd(N,263)"] = __import__("math").gcd(N, ELL)
    glob["v263(q+1-t)"] = v_p(q + 1 - TRACE, ELL)
    glob["v263(q+1+t)"] = v_p(q + 1 + TRACE, ELL)
    glob["v263(#E(F_q2))"] = v_p(CARD2, ELL)
    glob["q mod 263"] = q % ELL
    glob["(q^2-1) mod 263"] = (q * q - 1) % ELL
    glob["ord_263(2)"] = next(k for k in range(1, ELL) if pow(2, k, ELL) == 1)
    glob["Tr_Fq(1)"] = ftr(1)          # 1 => w^2+w+1 irreducible over F_q
    # Hasse: multiples of N in [q+1-2sqrt q, q+1+2sqrt q]
    import math
    s = math.isqrt(4 * q) + 1
    lo, hi = q + 1 - s, q + 1 + s
    glob["multiples_of_N_in_Hasse"] = [k for k in range(lo // N, hi // N + 2) if lo <= k * N <= hi]
    glob["modulus_int_matches_gt"] = MODPOLY == int(gt["meta"]["modulus_int"])
    # field self-tests
    rng = random.Random(1)
    for _ in range(50):
        a = rng.getrandbits(M) or 1
        bb = rng.getrandbits(M)
        assert fmul(a, finv(a)) == 1
        assert fsqr(a) == fmul(a, a)
        assert fmul(a, bb) == fmul(bb, a)
        A = (rng.getrandbits(M), rng.getrandbits(M))
        B = (rng.getrandbits(M), rng.getrandbits(M))
        assert mul2(A, inv2(A)) == ONE2
        assert sqr2(A) == mul2(A, A)
        assert pow2(A, q) == frob2(A)
        assert pow2(A, q * q) == A
    w = (0, 1)
    assert add2(sqr2(w), w) == ONE2
    assert fpow(2, (1 << M) - 1) == 1  # z^(q-1) = 1  (irreducible-modulus sanity)
    glob["field_selftests"] = "passed"
    print(json.dumps(glob, indent=1), flush=True)

    with Pool(12) as pool:
        results = []
        for r in pool.imap(work, recs):
            pr = r["pairing_263"]
            print(r["label"], pr["structure"],
                  pr.get("t(P,Q_N)==1 (2 Q_N, 2 c*Q_N per P)"),
                  pr.get("t(P,T+c*Q_N)==t(P,T) (2 c per P)"),
                  pr.get("t(263T,T)!=1", pr.get("tate_matrix_det_mod_263")),
                  r["seconds"], flush=True)
            results.append(r)

    summary = {
        "n_curves": len(results),
        "structure_counts": {},
        "all_t(P,Q_N)==1": all(r["pairing_263"]["t(P,Q_N)==1 (2 Q_N, 2 c*Q_N per P)"] for r in results),
        "all_shift_invariant": all(r["pairing_263"]["t(P,T+c*Q_N)==t(P,T) (2 c per P)"] for r in results),
        "all_floor_nondegenerate_t(263T,T)!=1": all(r["pairing_263"].get("t(263T,T)!=1", True) for r in results),
        "all_bilinearity_selftests": all(all(v for k, v in r["pairing_263"].items() if k.startswith("bilin")) for r in results),
        "E0_nondegenerate": [r["pairing_263"].get("nondegenerate") for r in results if r["label"] == "E0"],
        "elapsed_s": round(time.time() - t_start, 1),
    }
    for r in results:
        k = (r["label"] == "E0" and "E0:" or "floor:") + r["pairing_263"]["structure"]
        summary["structure_counts"][k] = summary["structure_counts"].get(k, 0) + 1
    print(json.dumps(summary, indent=1))
    tag = "subset" if labels_only else "all"
    with open(os.path.join(OUTDIR, f"c3_results_{tag}.json"), "w") as fh:
        json.dump({"global": glob, "summary": summary, "curves": results}, fh, indent=1)

if __name__ == "__main__":
    main()
