#!/usr/bin/env python3
"""Cross-check own Tate values against PARI elltatepairing on GF(2^262) built from
PARI ffinit(2,262) (not Sage's default modulus), with F_q(w) -> L given by
z -> r (a root of z^131+z^13+z^2+z+1 in L) and w -> a root of u^2+u+1 in L.
Run with sage -python (uses cypari2 only)."""
import json, os
from cypari2 import Pari
pari = Pari()
pari.allocatemem(2 * 10**9, silent=True)

here = os.path.dirname(os.path.abspath(__file__))
vec = json.load(open(os.path.join(here, "xcheck_vectors.json")))

T = pari("ffinit(2, 262, 'v)")
print("L modulus (PARI ffinit):", T)
g = pari.ffgen(T, "a")
pari("default(parisize, 2000000000)") if False else None
fz = pari("x^131 + x^13 + x^2 + x + 1") * g**0
fw = pari("x^2 + x + 1") * g**0
rz = pari.polrootsmod(fz)
rw = pari.polrootsmod(fw)
print("roots found:", len(rz), len(rw))
r = rz[0]
om = rw[0]
# precompute powers r^i
pw = [g**0]
for i in range(1, 131):
    pw.append(pw[-1] * r)

def emb_fq(n):
    n = int(n)
    s = 0 * g
    i = 0
    while n:
        if n & 1:
            s = s + pw[i]
        n >>= 1
        i += 1
    return s

def emb2(a):
    return emb_fq(a[0]) + emb_fq(a[1]) * om

def embpt(P):
    return pari.List([emb2(P[0]), emb2(P[1])])

# sanity: embedding is a homomorphism on a couple of products (computed with own code)
import sys
sys.path.insert(0, here)
import c3_own_tate as C3
import random
rng = random.Random(5)
for _ in range(5):
    A = (rng.getrandbits(131), rng.getrandbits(131))
    B = (rng.getrandbits(131), rng.getrandbits(131))
    assert emb2(C3.mul2(A, B)) == emb2(A) * emb2(B)
    assert emb2(C3.add2(A, B)) == emb2(A) + emb2(B)
print("embedding homomorphism checks passed")

e = (2**262 - 1) // 263
for v in vec:
    a2 = emb_fq(v["a2"]); b = emb_fq(v["b"])
    E = pari.ellinit([g**0, a2, 0, 0, b])
    P = [emb2([int(t) for t in v["P"][0]]), emb2([int(t) for t in v["P"][1]])]
    res = {}
    for key, name in (("U", "t(P,U)"), ("QN", "t(P,QN)"), ("UcQN", "t(P,U+cQN)")):
        Q = [emb2([int(t) for t in v[key][0]]), emb2([int(t) for t in v[key][1]])]
        assert pari.ellisoncurve(E, P) and pari.ellisoncurve(E, Q)
        tp = pari.elltatepairing(E, P, Q, 263) ** e
        own = emb_fq(v["own_values_Fq_int"][name])
        res[name] = {"pari_is_1": bool(tp == g**0), "equal_own": bool(tp == own),
                     "equal_own_inverse": bool(tp * own == g**0)}
    print(v["label"], json.dumps(res))
