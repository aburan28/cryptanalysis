#!/usr/bin/env python3
"""Dump test vectors (own tower field F_q(w), w^2+w+1=0) with own reduced Tate values,
for a cross-check against PARI on a PARI-ffinit GF(2^262) with an independent embedding."""
import json, random, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import c3_own_tate as C3

gt = json.load(open(C3.GT))
recs = {r["label"]: r for r in gt["curves"]}
out = []
for label in ["E0", "A017", "B101"]:
    r = recs[label]
    C = C3.Curve(int(r["a2"]), int(r["b_int"]))
    rng = random.Random(777 + len(out))
    QN = None
    while QN is None:
        QN = C.mul(4, C.rand_Fq(rng))
    # 263-torsion point P and a generic second argument U
    while True:
        S = C.mul(C3.COF2, C.rand_Fq2(rng))
        if S is not None:
            break
    P = C.mul(C3.ELL, S) if C.mul(C3.ELL, S) is not None else S
    U = C.rand_Fq2(rng)
    c = rng.randrange(1, C3.N)
    UcQ = C.add(U, C.mul(c, QN))
    vals = {
        "t(P,U)": C3.reduced_tate(C, P, U, rng),
        "t(P,QN)": C3.reduced_tate(C, P, QN, rng),
        "t(P,U+cQN)": C3.reduced_tate(C, P, UcQ, rng),
    }
    enc = lambda Pt: [[str(Pt[0][0]), str(Pt[0][1])], [str(Pt[1][0]), str(Pt[1][1])]]
    out.append({"label": label, "a2": int(r["a2"]), "b": r["b_int"],
                "P": enc(P), "QN": enc(QN), "U": enc(U), "UcQN": enc(UcQ),
                "own_values_Fq_int": {k: str(v) for k, v in vals.items()}})
    print(label, {k: (v == 1) for k, v in vals.items()}, vals["t(P,U)"] == vals["t(P,U+cQN)"], flush=True)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "xcheck_vectors.json"), "w"), indent=1)
