# C2 audit: independent re-derivation, in plain python3 (no Sage, no PARI, no ecc2k.py import),
# of  (a) #E(F_q) = 4N for every one of the 263 ground-truth curves [1,a2,0,0,b], and
#     (b) the embedding degree k_E = ord_{#E/4}(q), evaluated per curve from the order
#         derived in (a), with N-1 factored and N proved prime here (Pocklington/Lucas).
#
# Run:  export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
#       timeout 2400 python3 c2_pure_python.py > c2_pure_python.log 2>&1
# Writes c2_pure_python.json next to this script.
#
# Order argument per curve (no point counting): take random P on E(F_q), Q = [4]P.
# If Q != O and [N]Q = O with N prime then ord(Q) = N, so N | #E(F_q).  Hasse:
# |#E - (q+1)| <= 2 sqrt(q).  We check that 4N is the ONLY multiple of N in that interval,
# hence #E = 4N.  Controls: the quadratic twist [1,a2+1,0,0,b] must fail ([N]R != O),
# and must satisfy [q+1+t]R = O; broken arithmetic would not pass both.
import json, math, random, time, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
GT = Path("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json")
T0 = time.time()
out = {"script": "c2_pure_python.py", "tools": "python3 %s only (ints)" % sys.version.split()[0]}

# ---------------------------------------------------------------- field GF(2^131)
n = 131
F = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << n) - 1


def red(r):
    while r >> n:
        h = r >> n
        r = (r & MASK) ^ h ^ (h << 1) ^ (h << 2) ^ (h << 13)
    return r


def mul(a, b):
    if a == 0 or b == 0:
        return 0
    tab = [0] * 16
    tab[1] = a
    for i in range(2, 16, 2):
        tab[i] = tab[i >> 1] << 1
        tab[i + 1] = tab[i] ^ a
    r = 0
    nb = (b.bit_length() + 3) // 4
    for i in range(nb - 1, -1, -1):
        r = (r << 4) ^ tab[(b >> (4 * i)) & 15]
    return red(r)


def sqr(a):
    return mul(a, a)


def inv(a):
    """extended Euclid in F_2[z]"""
    assert a != 0
    u, v = a, F
    g1, g2 = 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v = v, u
            g1, g2 = g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return red(g1)


def frob_pow(a, k):
    for _ in range(k):
        a = sqr(a)
    return a


def trace(c):
    s, x = 0, c
    for _ in range(n):
        s ^= x
        x = sqr(x)
    assert s in (0, 1)
    return s


def half_trace(c):
    s, x = 0, c
    for _ in range((n - 1) // 2 + 1):
        s ^= x
        x = sqr(sqr(x))
    return s


# field self-checks: modulus irreducible (Rabin: n prime, z^(2^n) = z and f has no root in F_2)
z = 2
assert frob_pow(z, n) == z
assert (F & 1) == 1 and bin(F).count("1") % 2 == 1          # f(0)=1, f(1)=1 (odd #terms)
rng = random.Random(20260923)
for _ in range(50):
    a, b, c = rng.getrandbits(n), rng.getrandbits(n), rng.getrandbits(n)
    assert mul(a, b) == mul(b, a) and mul(a, mul(b, c)) == mul(mul(a, b), c)
    assert mul(a, b ^ c) == mul(a, b) ^ mul(a, c)
    if a:
        assert mul(a, inv(a)) == 1
out["field"] = {"modulus": "z^131+z^13+z^2+z+1", "modulus_int": str(F),
                "irreducible_rabin": True, "ring_axiom_spotchecks": 50}

# ---------------------------------------------------------------- curve y^2+xy = x^3+a2 x^2+b
O = None


def on_curve(P, a2, b):
    if P is O:
        return True
    x, y = P
    return sqr(y) ^ mul(x, y) == mul(sqr(x), x) ^ (mul(a2, sqr(x)) if a2 else 0) ^ b


def add(P, Q, a2):
    if P is O:
        return Q
    if Q is O:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y1 == y2:
            return dbl(P, a2)
        return O                                # Q = -P  (y2 = x1 + y1)
    lam = mul(y1 ^ y2, inv(x1 ^ x2))
    x3 = sqr(lam) ^ lam ^ x1 ^ x2 ^ a2
    y3 = mul(lam, x1 ^ x3) ^ x3 ^ y1
    return (x3, y3)


def dbl(P, a2):
    if P is O:
        return O
    x1, y1 = P
    if x1 == 0:
        return O
    lam = x1 ^ mul(y1, inv(x1))
    x3 = sqr(lam) ^ lam ^ a2
    y3 = sqr(x1) ^ mul(lam, x3) ^ x3
    return (x3, y3)


def smul(k, P, a2):
    R = O
    for bit in bin(k)[2:]:
        R = dbl(R, a2)
        if bit == "1":
            R = add(R, P, a2)
    return R


def random_point(a2, b, rng):
    while True:
        x = rng.getrandbits(n)
        if x == 0:
            continue
        c = x ^ a2 ^ mul(b, inv(sqr(x)))
        if trace(c):
            continue
        zz = half_trace(c)
        assert sqr(zz) ^ zz == c
        P = (x, mul(x, zz))
        assert on_curve(P, a2, b)
        return P


# ---------------------------------------------------------------- integers
def is_sprp(nn, a):
    d, s = nn - 1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    x = pow(a, d, nn)
    if x in (1, nn - 1):
        return True
    for _ in range(s - 1):
        x = x * x % nn
        if x == nn - 1:
            return True
    return False


SMALLP = [p for p in range(2, 1000) if all(p % d for d in range(2, int(p**0.5) + 1))]
MR13 = SMALLP[:13]                   # 2..41: deterministic for n < 3317044064679887385961981
MR13_BOUND = 3317044064679887385961981


def proven_prime_small(m):
    """rigorous for m < 3.317e24 (Sorenson-Webster 2015); trial division below 10^6."""
    if m < 2:
        return False
    if m < 10**12:
        return all(m % d for d in range(2, int(math.isqrt(m)) + 1))
    for pp in SMALLP:
        if m % pp == 0:
            return m == pp
    if not all(is_sprp(m, a) for a in MR13):
        return False                      # certainly composite
    assert m < MR13_BOUND, "probable prime too large for a deterministic-MR proof"
    return True


def pollard_brent(m, seed):
    if m % 2 == 0:
        return 2
    r_ = random.Random(seed)
    y, c, mm = r_.randrange(1, m), r_.randrange(1, m), 128
    g, rr, qq = 1, 1, 1
    while g == 1:
        x = y
        for _ in range(rr):
            y = (y * y + c) % m
        k = 0
        while k < rr and g == 1:
            ys = y
            for _ in range(min(mm, rr - k)):
                y = (y * y + c) % m
                qq = qq * abs(x - y) % m
            g = math.gcd(qq, m)
            k += mm
        rr *= 2
    if g == m:
        while True:
            ys = (ys * ys + c) % m
            g = math.gcd(abs(x - ys), m)
            if g > 1:
                break
    return g


def factor(m):
    """full factorisation with every prime factor PROVEN (small-prime proofs only)."""
    fac = {}
    for pp in range(2, 10**5):
        while m % pp == 0:
            fac[pp] = fac.get(pp, 0) + 1
            m //= pp
        if m == 1:
            break
    stack = [m] if m > 1 else []
    seed = 1
    while stack:
        u = stack.pop()
        if proven_prime_small(u):
            fac[u] = fac.get(u, 0) + 1
            continue
        d = pollard_brent(u, seed); seed += 1
        if d in (1, u):
            stack.append(u); continue
        stack += [d, u // d]
    return sorted(fac.items())


def lucas_prime_proof(m, fac):
    """Lucas/Pocklington: m prime iff exists a with a^(m-1)=1 and a^((m-1)/r) != 1 for all r | m-1."""
    for a in range(2, 200):
        if pow(a, m - 1, m) != 1:
            return None
        if all(pow(a, (m - 1) // r, m) != 1 for r, _ in fac):
            return a
    return None


def order_mod(g, m, fac):
    """multiplicative order of g mod prime m, fac = factorisation of m-1."""
    k = m - 1
    for r, e in fac:
        for _ in range(e):
            if pow(g, k // r, m) == 1:
                k //= r
            else:
                break
    assert pow(g, k, m) == 1
    kf = [(r, e) for r, e in fac if k % r == 0]
    for r, _ in kf:
        assert pow(g, k // r, m) != 1, "not minimal"
    return k


# ---------------------------------------------------------------- global constants (re-derived)
q = 1 << n
# #E0(F_2): brute force over F_2 for y^2+xy = x^3+1
cnt = 1 + sum(1 for x in (0, 1) for y in (0, 1) if (y * y + x * y - x**3 - 1) % 2 == 0)
t1 = 2 + 1 - cnt
tk_prev, tk = 2, t1
for _ in range(n - 1):
    tk_prev, tk = tk, t1 * tk - 2 * tk_prev
t = tk
CARD = q + 1 - t
TW = q + 1 + t
assert CARD % 4 == 0
N = CARD // 4
facNm1 = factor(N - 1)
assert math.prod(r**e for r, e in facNm1) == N - 1
witness = lucas_prime_proof(N, facNm1)
assert witness is not None, "N not proved prime"
# Hasse window and uniqueness of 4N
s = math.isqrt(q)                      # floor(sqrt q); 2 sqrt q <= 2(s+1)
lo, hi = q + 1 - 2 * (s + 1), q + 1 + 2 * (s + 1)
mults = [m * N for m in range(lo // N, hi // N + 2) if lo <= m * N <= hi]
assert mults == [CARD], mults
k = order_mod(q % N, N, facNm1)
k2 = order_mod(2, N, facNm1)
assert k == k2 // math.gcd(k2, n)
out["global"] = {
    "E0_F2_points": cnt, "t": str(t), "card_4N": str(CARD), "N": str(N), "N_bits": N.bit_length(),
    "N_log2": round(math.log2(N), 4), "twist_card": str(TW),
    "N_minus_1_factorization": [[str(r), e] for r, e in facNm1],
    "N_minus_1_factor_proofs": "trial division (<10^12) or deterministic MR bases 2..41 (<3.317e24)",
    "N_prime_lucas_witness": witness,
    "hasse_multiples_of_N": [str(v) for v in mults],
    "gcd_N_twist": math.gcd(N, TW),
    "k_ord_N_q": str(k), "k_bits": k.bit_length(), "k_log2": round(math.log2(k), 4),
    "(N-1)/k": (N - 1) // k, "ord_N_2": str(k2), "ord_N_2/k": k2 // k,
    "gcd(ord_N_2,131)": math.gcd(k2, n),
    "N_divides_q-1": (q - 1) % N == 0,
}
print("global:", json.dumps(out["global"], indent=1), flush=True)

# ---------------------------------------------------------------- per curve
gt = json.loads(GT.read_text())
assert int(gt["meta"]["modulus_int"]) == F
curves = gt["curves"]
assert len(curves) == 263
seen_j = set()
per = {}
for idx, rec in enumerate(curves):
    lab = rec["label"]
    a2 = int(rec["a2"]); b = int(rec["b_int"]); j = int(rec["j_int"])
    assert a2 in (0, 1) and 0 < b < (1 << n) and b.bit_length() <= n
    assert mul(b, j) == 1                               # j = 1/b for y^2+xy=x^3+a2x^2+b
    seen_j.add(j)
    rr = random.Random(1000003 * idx + 7)
    tries = 0
    while True:
        tries += 1
        P = random_point(a2, b, rr)
        Q = smul(4, P, a2)
        if Q is not O:
            break
        assert tries < 10
    NQ = smul(N, Q, a2)
    assert NQ is O, lab
    # consistency: [N+1]Q = Q,  [N-1]Q = -Q
    assert smul(N + 1, Q, a2) == Q
    Qm = smul(N - 1, Q, a2)
    assert Qm == (Q[0], Q[0] ^ Q[1])
    # => N | #E ; Hasse uniqueness => #E = 4N
    cardE = CARD
    NE = cardE // 4
    # exact order of P (divides 4N)
    ordP = None
    for d in (1, 2, 4, N, 2 * N, 4 * N):
        if smul(d, P, a2) is O:
            ordP = d; break
    # twist controls
    a2t = a2 ^ 1
    R = random_point(a2t, b, rr)
    tw_N_R_is_O = smul(N, R, a2t) is O
    tw_4N_R_is_O = smul(4 * N, R, a2t) is O
    tw_TW_R_is_O = smul(TW, R, a2t) is O
    assert (not tw_N_R_is_O) and (not tw_4N_R_is_O) and tw_TW_R_is_O, lab
    # embedding degree of the prime-order subgroup, per curve
    kE = order_mod(q % NE, NE, facNm1) if NE == N else None
    per[lab] = {
        "a2": a2, "Q_ne_O": True, "N_Q_is_O": True, "ord_P": "4N" if ordP == 4 * N else
        ("2N" if ordP == 2 * N else ("N" if ordP == N else str(ordP))),
        "card_derived": str(cardE), "N_E": str(NE), "k_E": str(kE),
        "twist_[N]R_is_O": tw_N_R_is_O, "twist_[4N]R_is_O": tw_4N_R_is_O,
        "twist_[q+1+t]R_is_O": tw_TW_R_is_O,
        "gt_order_pari_matches": int(rec["order_pari"]) == cardE,
        "gt_twist_order_pari_matches": int(rec["twist_order_pari"]) == TW,
    }
    if idx < 3 or idx % 40 == 0 or idx == 262:
        print(lab, per[lab]["ord_P"], "k_E bits", int(kE).bit_length(), "%.1fs" % (time.time() - T0), flush=True)

ks = {v["k_E"] for v in per.values()}
out["per_curve_summary"] = {
    "n_curves": len(per), "distinct_j": len(seen_j),
    "all_N_divides_card_by_point": all(v["N_Q_is_O"] for v in per.values()),
    "distinct_k_E": sorted(ks),
    "all_equal": len(ks) == 1,
    "ord_P_histogram": {o: sum(1 for v in per.values() if v["ord_P"] == o) for o in {v["ord_P"] for v in per.values()}},
    "a2_histogram": {str(a): sum(1 for v in per.values() if v["a2"] == a) for a in (0, 1)},
    "all_gt_order_pari_match": all(v["gt_order_pari_matches"] for v in per.values()),
    "all_gt_twist_order_pari_match": all(v["gt_twist_order_pari_matches"] for v in per.values()),
    "all_twist_controls_pass": all((not v["twist_[N]R_is_O"]) and v["twist_[q+1+t]R_is_O"] for v in per.values()),
}
out["per_curve"] = per
out["elapsed_s"] = round(time.time() - T0, 1)
(HERE / "c2_pure_python.json").write_text(json.dumps(out, indent=1))
print(json.dumps(out["per_curve_summary"], indent=1))
print("done %.1fs" % (time.time() - T0))
