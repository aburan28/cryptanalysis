# writes c2_gp_ellcard.gp: standalone PARI/GP (no Sage) point count of all 263 ground-truth curves
import json
gt = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
rows = ", ".join('["%s",%s,%s]' % (c["label"], c["a2"], c["b_int"]) for c in gt["curves"])
src = r'''\\ standalone gp: ellcard over F_2[z]/(z^131+z^13+z^2+z+1), a2 and b from ground_truth.json
default(parisize, 10^9);
g = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
q = 2^131;
el(n) = subst(Pol(binary(n)), 'x, g) + 0*g;
C = [%s];
Nref = 680564733841876926932320129493409985129;
ks = List(); cards = List(); bad = 0;
{
for (i = 1, #C,
  lab = C[i][1]; a2 = C[i][2]; b = el(C[i][3]);
  E = ellinit([1, a2, 0, 0, b], g);
  c = ellcard(E);
  Et = ellinit([1, 1 - a2, 0, 0, b], g);
  ct = ellcard(Et);
  if (c + ct != 2*q + 2, bad++);
  if (c %% 4 != 0, bad++);
  NE = c / 4;
  if (!isprime(NE), bad++);
  k = znorder(Mod(q, NE));
  listput(ks, k); listput(cards, c);
  if (i <= 3 || i %% 40 == 0 || i == #C, print(lab, " #E=", c, " #Et=", ct, " N_E prime=", isprime(NE), " k=", k, " grp=", ellgroup(E)));
);
}
print("n=", #C, " distinct #E: ", Set(Vec(cards)), " distinct k: ", Set(Vec(ks)), " bad=", bad);
print("NE==Nref for all: ", Set(Vec(cards)) == [4*Nref]);
print("k == (N-1)/3144: ", Set(Vec(ks)) == [(Nref-1)/3144]);
print("ord_N(2) = ", znorder(Mod(2, Nref)));
\q
''' % rows
open("c2_gp_ellcard.gp", "w").write(src)
