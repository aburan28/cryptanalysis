T = ffinit(2,262,'w); w = ffgen(T,'w);
fq = x^131+x^13+x^2+x+1;
rr = polrootsmod(fq, w); print(#rr);
r = rr[1]; print(subst(fq,x,r)==0);
q=2^131; t=-22283658519494248867; QL=2^262; CL=(q+1-t)*(q+1+t);
E=ellinit([1,0,0,0,w^5+1]); 
s=getabstime(); c=ellcard(E); print(c==CL, " ", c==(QL+1-(t^2-2*q)), " time ", getabstime()-s);
E0=ellinit([1,0,0,0,1+0*w]); s=getabstime(); c0=ellcard(E0); print("E0 card ", c0==CL, " time ", getabstime()-s);
s=getabstime(); g=ellgroup(E0); print(factor(g[1]), " | ", factor(g[2]), " time ", getabstime()-s);
