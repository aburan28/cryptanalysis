import time, random
src = open('c2_own_arith.py').read()
g = {'M':131, 'F':(1<<131)|(1<<13)|(1<<2)|(1<<1)|1}
exec(src[src.index('def clmul'):src.index('# ---- 1.')], g)
exec(src[src.index('def ec_add'):src.index('def on_curve')], g)
a=random.getrandbits(131); b=random.getrandbits(131)
t=time.process_time()
for _ in range(200): g['mul'](a,b)
print('mul us', (time.process_time()-t)/200*1e6)
t=time.process_time()
for _ in range(50): g['inv'](a)
print('inv us', (time.process_time()-t)/50*1e6)
