\\ standalone gp (not Sage's libpari): point count sample curves with ellcard, then k = znorder(Mod(q, #E/4))
default(parisize, 10^9);
read("labels_sample.gp");
P = Mod(1,2)*(x^131+x^13+x^2+x+1);
z = ffgen(P, 'z);
el(n) = subst(Pol(binary(n)), 'x, z) + 0*z;
q = 2^131;
Nref = 680564733841876926932320129493409985129;
{
for(i=1, #LAB,
  b = el(BINT[i]); a2 = el(A2[i]);
  E = ellinit([1, a2, 0, 0, b]);
  tt = getabstime();
  c = ellcard(E);
  Et = ellinit([1, a2+1, 0, 0, b]);
  ct = ellcard(Et);
  NE = c/4;
  k = if(denominator(NE)==1 && isprime(NE), znorder(Mod(q, NE)), -1);
  printf("%s card=%d card_mod4=%d NE==Nref:%d NEprime:%d k=%d twist=%d card+twist==2q+2:%d ms=%d\n",
     LAB[i], c, c%4, NE==Nref, isprime(NE), k, ct, c+ct==2*q+2, getabstime()-tt);
);
}
print("N-1 factor (gp): ", factor(Nref-1));
print("znorder(Mod(2,N)) = ", znorder(Mod(2,Nref)));
print("znorder(Mod(q,N)) = ", znorder(Mod(q,Nref)));
print("isprime(N,2) [APRCL] = ", isprime(Nref,2));
