#!/usr/bin/env python3
# C2 recompute: independent of Sage/PARI entirely (plain python3 ints only).
#  1. own GF(2)[z] arithmetic; Rabin irreducibility test of f = z^131+z^13+z^2+z+1.
#  2. own primality proof of N: verify the claimed factorisation of N-1 by product, prove each
#     factor prime (deterministic Miller-Rabin, all factors < 3.3e24), then Lucas test for N.
#  3. q = 2^131 derived here; Hasse bound => 4N is the unique multiple of N in [q+1-2sqrt q, q+1+2sqrt q].
#  4. For EVERY curve in ground_truth.json (b_int, a2 read straight from JSON), own affine
#     arithmetic on y^2+xy = x^3+a2 x^2+b: 3 random points P each with Q=[4]P != O and [N]Q = O
#     => Q has order N => N | #E => #E = 4N (step 3). Also [4N]P = O and [2N]P != O on at least one P.
#  5. k = ord_N(q) computed two ways: (a) via ord_N(2) (own descent) divided by gcd(.,131);
#     (b) direct minimality check q^k = 1 and q^(k/r) != 1 for every prime r | k.
#  6. compare with per_curve.json (all 263 labels) and per_curve_meta.json.
import json, random, math, sys, time
from functools import reduce

T0 = time.time()
GT = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json'))
PC = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/pairing-transfer/per_curve.json'))
PCM = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/pairing-transfer/per_curve_meta.json'))
OUT = {}

M = 131
F = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
assert F == int(GT['meta']['modulus_int'])

def clmul_slow(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a <<= 1
        b >>= 1
    return r

def clmul(a, b):
    # 4-bit window carry-less multiply
    tab = [0] * 16
    tab[1] = a
    for i in range(2, 16):
        tab[i] = (tab[i >> 1] << 1) if not (i & 1) else (tab[i - 1] ^ a)
    r = 0
    sh = 0
    while b:
        r ^= tab[b & 15] << sh
        b >>= 4
        sh += 4
    return r

SPREAD = [0] * 256
for _i in range(256):
    _v = 0
    for _j in range(8):
        if (_i >> _j) & 1:
            _v |= 1 << (2 * _j)
    SPREAD[_i] = _v

def pmod_generic(a, f):
    df = f.bit_length() - 1
    while a.bit_length() - 1 >= df:
        a ^= f << (a.bit_length() - 1 - df)
    return a

MASK = (1 << 131) - 1
def pmod(a, f=None):
    if f is not None and f != F:
        return pmod_generic(a, f)
    while a >> 131:
        h = a >> 131
        a = (a & MASK) ^ h ^ (h << 1) ^ (h << 2) ^ (h << 13)
    return a

def mul(a, b):
    return pmod(clmul(a, b))

def sqr(a):
    r = 0
    sh = 0
    while a:
        r |= SPREAD[a & 255] << sh
        a >>= 8
        sh += 16
    return pmod(r)

def pgcd(a, b):
    while b:
        a, b = b, pmod(a, b)
    return a

def inv(a):
    # extended Euclid in GF(2)[z]
    assert a != 0
    r0, r1, s0, s1 = F, a, 0, 1
    while r1:
        # quotient
        qq = 0
        r = r0
        d1 = r1.bit_length() - 1
        while r and r.bit_length() - 1 >= d1:
            sh = r.bit_length() - 1 - d1
            qq ^= 1 << sh
            r ^= r1 << sh
        r0, r1 = r1, r
        s0, s1 = s1, s0 ^ clmul(qq, s1)
    assert r0 == 1
    return pmod(s0)

_r = random.Random(7)
for _ in range(300):
    _a, _b = _r.getrandbits(131), _r.getrandbits(131)
    assert mul(_a, _b) == pmod_generic(clmul_slow(_a, _b), F)
    assert sqr(_a) == pmod_generic(clmul_slow(_a, _a), F)
    if _a:
        assert mul(_a, inv(_a)) == 1
OUT['fast_arith_selftest'] = 300

# ---- 1. Rabin irreducibility (degree 131 is prime): z^(2^131) = z mod F and gcd(z^2 - z, F) = 1
x = 2
for _ in range(M):
    x = sqr(x)
rabin1 = (x == 2)
rabin2 = (pgcd(F, pmod((1 << 2) ^ 2)) == 1)
assert rabin1 and rabin2
OUT['field_irreducible_rabin'] = True

# ---- 2. primality of N (own proof)
N = int(GT['meta']['N'])
q = 1 << M
assert q == int(GT['meta']['q'])

def mr(n, bases):
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41):
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    for a in bases:
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True

MR_BASES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]  # deterministic for n < 3.3e24
MR_BOUND = 3317044064679887385961981

# factor N-1 myself: trial division up to 10^6, then the remaining cofactor must split
def trial(n, B):
    fac = {}
    for p in [2] + list(range(3, B, 2)):
        if p * p > n:
            break
        while n % p == 0:
            fac[p] = fac.get(p, 0) + 1
            n //= p
    return fac, n

def pollard_rho(n):
    if n % 2 == 0:
        return 2
    rnd = random.Random(12345)
    while True:
        c = rnd.randrange(1, n)
        f = lambda v: (v * v + c) % n
        xx, yy, d = 2, 2, 1
        while d == 1:
            xx = f(xx); yy = f(f(yy)); d = math.gcd(abs(xx - yy), n)
        if d != n:
            return d

def full_factor(n):
    fac, rest = trial(n, 10**6)
    stack = [rest] if rest > 1 else []
    while stack:
        m = stack.pop()
        if m < MR_BOUND and mr(m, MR_BASES):
            fac[m] = fac.get(m, 0) + 1
            continue
        assert m < MR_BOUND ** 2, "cofactor too large for this simple factoriser"
        d = pollard_rho(m)
        stack += [d, m // d]
    return dict(sorted(fac.items()))

t_f = time.time()
FN1 = full_factor(N - 1)
OUT['N_minus_1_factorization_own'] = {str(k): v for k, v in FN1.items()}
OUT['N_minus_1_factor_seconds'] = round(time.time() - t_f, 2)
assert reduce(lambda a, kv: a * kv[0] ** kv[1], FN1.items(), 1) == N - 1
assert all(r < MR_BOUND and mr(r, MR_BASES) for r in FN1)
# Lucas: find a with a^(N-1)=1, a^((N-1)/r) != 1 for all r => N prime (and a is a primitive root)
lucas_base = None
for a in range(2, 200):
    if pow(a, N - 1, N) != 1:
        break
    if all(pow(a, (N - 1) // r, N) != 1 for r in FN1):
        lucas_base = a
        break
assert lucas_base is not None
OUT['N_prime_lucas_base'] = lucas_base
OUT['N_log2'] = round(math.log2(N), 4)

# ---- 3. Hasse uniqueness
s2 = math.isqrt(4 * q)  # floor(2 sqrt q); interval [q+1-s2-1, q+1+s2+1] is a safe superset
lo, hi = q + 1 - s2 - 1, q + 1 + s2 + 1
mults = [m for m in range(lo // N, hi // N + 2) if lo <= m * N <= hi]
assert mults == [4], mults
OUT['hasse_unique_multiple_of_N'] = mults

# ---- 5. embedding degree k = ord_N(q), two routes
def order_mod(g, n, fac):
    o = n - 1
    for r, e in fac.items():
        for _ in range(e):
            if pow(g, o // r, n) == 1:
                o //= r
            else:
                break
    return o

ord2 = order_mod(2, N, FN1)
assert pow(2, ord2, N) == 1
k_a = ord2 // math.gcd(ord2, M)
# route (b): generic verification of minimality of k_a for q directly
fac_k = {}
kk = k_a
for r in FN1:
    while kk % r == 0:
        fac_k[r] = fac_k.get(r, 0) + 1
        kk //= r
assert kk == 1
q_modN = q % N
min_ok = pow(q_modN, k_a, N) == 1 and all(pow(q_modN, k_a // r, N) != 1 for r in fac_k)
assert min_ok
# route (c): independent descent directly on q
k_c = order_mod(q_modN, N, FN1)
assert k_c == k_a
K = k_a
OUT['ord_N_2'] = str(ord2)
OUT['embedding_degree_k'] = str(K)
OUT['k_bits'] = K.bit_length()
OUT['k_log2'] = round(math.log2(K), 4)
OUT['(N-1)/k'] = (N - 1) // K
OUT['k_factorization'] = {str(r): e for r, e in fac_k.items()}
# explicit: no small embedding degree
_v, _hit = 1, None
for _i in range(1, 10**6 + 1):
    _v = _v * q_modN % N
    if _v == 1:
        _hit = _i; break
OUT['min_k_leq_10^6_with_q^k=1_mod_N'] = _hit

# ---- 4. elliptic curve arithmetic
def ec_add(P, Q, a2):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y2 == x1 ^ y1:  # Q = -P
            return None
        # P == Q: doubling
        if x1 == 0:
            return None
        lam = x1 ^ mul(y1, inv(x1))
        x3 = sqr(lam) ^ lam ^ a2
        y3 = sqr(x1) ^ mul(lam, x3) ^ x3
        return (x3, y3)
    lam = mul(y1 ^ y2, inv(x1 ^ x2))
    x3 = sqr(lam) ^ lam ^ x1 ^ x2 ^ a2
    y3 = mul(lam, x1 ^ x3) ^ x3 ^ y1
    return (x3, y3)

def ec_mul(k, P, a2):
    R = None
    for bit in bin(k)[2:]:
        R = ec_add(R, R, a2)
        if bit == '1':
            R = ec_add(R, P, a2)
    return R

def on_curve(P, a2, b):
    if P is None:
        return True
    x_, y_ = P
    return sqr(y_) ^ mul(x_, y_) == mul(sqr(x_), x_) ^ mul(a2, sqr(x_)) ^ b

def trace(c):
    t_ = c; s = c
    for _ in range(M - 1):
        s = sqr(s); t_ ^= s
    assert t_ in (0, 1)
    return t_

def halftrace(c):
    h = c; s = c
    for _ in range((M - 1) // 2):
        s = sqr(sqr(s)); h ^= s
    return h

def rand_point(rng, a2, b):
    while True:
        x_ = rng.getrandbits(M)
        if x_ == 0:
            continue
        # y = x w, w^2 + w = x + a2 + b/x^2
        c = x_ ^ a2 ^ mul(b, inv(sqr(x_)))
        if trace(c):
            continue
        w = halftrace(c)
        assert sqr(w) ^ w == c
        P = (x_, mul(x_, w))
        assert on_curve(P, a2, b)
        return P

# x-only Montgomery ladder (Lopez-Dahab) on y^2+xy=x^3+a2x^2+b; returns (X,Z) of [k]P, Z==0 <=> O
def ladder(k, xP, b):
    assert k >= 1 and xP != 0
    X1, Z1 = xP, 1                      # [1]P
    X2, Z2 = sqr(sqr(xP)) ^ b, sqr(xP)  # [2]P
    for bit in bin(k)[3:]:
        if bit == '1':
            # R1 = R1+R2 (diff P), R2 = 2 R2
            A_ = mul(X1, Z2); B_ = mul(X2, Z1)
            Z1n = sqr(A_ ^ B_); X1n = mul(xP, Z1n) ^ mul(A_, B_)
            X2s, Z2s = sqr(X2), sqr(Z2)
            X2n = sqr(X2s) ^ mul(b, sqr(Z2s)); Z2n = mul(X2s, Z2s)
            X1, Z1, X2, Z2 = X1n, Z1n, X2n, Z2n
        else:
            A_ = mul(X1, Z2); B_ = mul(X2, Z1)
            Z2n = sqr(A_ ^ B_); X2n = mul(xP, Z2n) ^ mul(A_, B_)
            X1s, Z1s = sqr(X1), sqr(Z1)
            X1n = sqr(X1s) ^ mul(b, sqr(Z1s)); Z1n = mul(X1s, Z1s)
            X1, Z1, X2, Z2 = X1n, Z1n, X2n, Z2n
    return X1, Z1

def is_O(k, P, b):
    return ladder(k, P[0], b)[1] == 0

a2map = {0: 0, 1: 1}
rng = random.Random(20260923_2)

# ladder validation against the affine double-and-add on E0 and on A000 (random k, both small and full size)
_val = 0
for lab_ in ('E0', 'A000', 'B077'):
    rec_ = next(r for r in GT['curves'] if r['label'] == lab_)
    b_ = int(rec_['b_int']); a2_ = a2map[int(rec_['a2'])]
    for kk_ in [1, 2, 3, 4, 5, 7, 8, 12] + [rng.randrange(1, 1 << 40) for _ in range(3)] + [rng.randrange(1, 4 * N) for _ in range(2)]:
        P_ = rand_point(rng, a2_, b_)
        R_ = ec_mul(kk_, P_, a2_)
        X_, Z_ = ladder(kk_, P_[0], b_)
        if R_ is None:
            assert Z_ == 0
        else:
            assert Z_ != 0 and mul(X_, inv(Z_)) == R_[0]
        _val += 1
OUT['ladder_vs_affine_checks'] = _val

# negative control: on the quadratic twist [1,a2+1,0,0,b] (order q+1+t, N does not divide it),
# [4N]P must NOT be O and [N][4]P must NOT be O
TW = int(GT['meta']['twist_card'])
assert TW % N != 0 and TW == 2 * q + 2 - 4 * N
negctl = 0
for lab_ in ('E0', 'A000', 'A064', 'B000', 'B130'):
    rec_ = next(r for r in GT['curves'] if r['label'] == lab_)
    b_ = int(rec_['b_int']); a2t = a2map[int(rec_['a2'])] ^ 1
    P_ = rand_point(rng, a2t, b_)
    assert not is_O(4 * N, P_, b_)
    Q_ = ec_mul(4, P_, a2t)
    assert Q_ is not None and not is_O(N, Q_, b_)
    assert is_O(TW, P_, b_)  # twist order kills it
    negctl += 1
OUT['twist_negative_controls_passed'] = negctl

per = {}
t_c = time.time()
for rec in GT['curves']:
    lab = rec['label']
    b = int(rec['b_int']); a2 = a2map[int(rec['a2'])]
    assert b != 0
    assert mul(b, int(rec['j_int'])) == 1  # j = 1/b
    # point 1: exact order 4N:  [4]P != O, [2N]P != O, [4N]P = O
    P = rand_point(rng, a2, b)
    four = ec_mul(4, P, a2)
    exact4N = (four is not None) and (not is_O(2 * N, P, b)) and is_O(4 * N, P, b)
    # point 2: Q = [4]P' != O and [N]Q = O
    P2 = rand_point(rng, a2, b)
    Q2 = ec_mul(4, P2, a2)
    q4ok = (Q2 is not None) and is_O(N, Q2, b)
    assert exact4N or q4ok
    card = 4 * N  # N | #E (from either point) and Hasse uniqueness
    NE = card // 4
    assert NE == N
    kE = order_mod(q % NE, NE, FN1)
    per[lab] = {'P_order_exactly_4N': exact4N, 'Q=4P_order_N': q4ok,
                'card_proved': str(card), 'k': str(kE),
                'matches_gt_order_pari': int(rec['order_pari']) == card,
                'matches_sweep_N': PC[lab]['N'] == str(NE),
                'matches_sweep_k': PC[lab]['embedding_degree_N'] == str(kE)}
OUT['curve_loop_seconds'] = round(time.time() - t_c, 1)
OUT['n_curves'] = len(per)
OUT['labels_equal_sweep'] = sorted(per) == sorted(PC)
OUT['n_P_order_exactly_4N'] = sum(v['P_order_exactly_4N'] for v in per.values())
OUT['n_Q_order_N'] = sum(v['Q=4P_order_N'] for v in per.values())
OUT['all_k_equal_mine'] = len({v['k'] for v in per.values()}) == 1 and per['E0']['k'] == str(K)
OUT['all_match_gt_order_pari'] = all(v['matches_gt_order_pari'] for v in per.values())
OUT['all_match_sweep_N'] = all(v['matches_sweep_N'] for v in per.values())
OUT['all_match_sweep_k'] = all(v['matches_sweep_k'] for v in per.values())
OUT['sweep_distinct_k_values'] = sorted({v['embedding_degree_N'] for v in PC.values()})
OUT['sweep_meta_all_equal_flag'] = PCM.get('all_embedding_degrees_equal')
OUT['sweep_ord_N_2_values'] = sorted({v.get('ord_N_2') for v in PC.values()})
OUT['sweep_N-1_factorization_values'] = sorted({v.get('N_minus_1_factorization') for v in PC.values()})
OUT['elapsed_s'] = round(time.time() - T0, 1)
json.dump({'summary': OUT, 'per_curve': per},
          open('/Volumes/SSD990/ecdlp-hardness-work/verify/pairing-transfer/C2-recompute/c2_own_arith.json', 'w'), indent=1)
print(json.dumps(OUT, indent=1))
