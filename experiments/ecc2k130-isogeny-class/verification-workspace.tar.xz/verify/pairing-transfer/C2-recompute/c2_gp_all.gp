\\ standalone gp 2.17.3: ellcard on ALL 263 curves (a2 as in ground truth), k = znorder(Mod(q,#E/4)) per curve
default(parisize, 10^9);
read("labels_all.gp");
P = Mod(1,2)*(x^131+x^13+x^2+x+1);
z = ffgen(P, 'z);
el(n) = subst(Pol(binary(n)), 'x, z) + 0*z;
q = 2^131;
Nref = 680564733841876926932320129493409985129;
Kset = Set(); Cset = Set(); bad = 0; distinctb = Set();
{
for(i=1, #LAB,
  b = el(BINT[i]); a2 = el(A2[i]);
  distinctb = setunion(distinctb, [BINT[i]]);
  E = ellinit([1, a2, 0, 0, b]);
  c = ellcard(E);
  NE = c/4;
  if(denominator(NE)!=1 || !isprime(NE), bad++; print("BAD ", LAB[i]); next);
  k = znorder(Mod(q, NE));
  Kset = setunion(Kset, [k]); Cset = setunion(Cset, [c]);
  if(i%50==0, print(i, " done"));
);
}
print("n_curves=", #LAB, " distinct_b=", #distinctb, " bad=", bad);
print("distinct cards: ", Cset);
print("distinct k: ", Kset);
print("k==znorder(q mod Nref): ", Kset == [znorder(Mod(q,Nref))]);
