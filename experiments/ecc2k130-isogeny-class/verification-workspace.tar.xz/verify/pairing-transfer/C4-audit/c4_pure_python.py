# C4 audit: pure-Python (no Sage, no PARI) re-derivation of the twist-order claims.
#   export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; python3 c4_pure_python.py [all|sample]
# Uses only ground_truth.json for the b-coefficients of the 263 curves (b_int).
# Own F_(2^131) arithmetic in the ECC2K polynomial basis z^131+z^13+z^2+z+1, own group law on
# y^2 + xy = x^3 + a2 x^2 + b, own Miller loop / reduced Tate pairing (k = 1, divisor (R+S)-(S)).
import json, math, random, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
GT = json.loads(Path("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json").read_text())
M = 131
MASK = (1 << M) - 1
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
assert str(MOD) == GT["meta"]["modulus_int"]
q = 1 << M
out = {"script": "c4_pure_python.py"}

# ---------------- integers: trace, twist order, factorisation, primality, orders ----------------
a, b_ = 2, -1                       # t_0, t_1 for tau^2 + tau + 2 = 0 (#E0(F_2) = 4)
for _ in range(2, M + 1):
    a, b_ = b_, -b_ - 2 * a
t = b_
TW = q + 1 + t
CARD = q + 1 - t
assert str(t) == GT["meta"]["t"] and str(TW) == GT["meta"]["twist_card"]
N = CARD // 4
assert CARD % 4 == 0
r = 19678316408850118605767852657510239


def trial_is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    d = 3
    while d * d <= n:
        if n % d == 0:
            return False
        d += 2
    return True


def trial_factor(n, bound):
    fac = {}
    d = 2
    while d <= bound and d * d <= n:
        while n % d == 0:
            fac[d] = fac.get(d, 0) + 1
            n //= d
        d += 1 if d == 2 else 2
    return fac, n


# factor TW by trial division of the small part
facTW, rest = trial_factor(TW, 10**4)
out["TW"] = str(TW)
out["TW_small_factors"] = {str(k): v for k, v in facTW.items()}
out["TW_cofactor"] = str(rest)
assert facTW == {2: 1, 263: 2} and rest == r and TW == 2 * 263**2 * r

# factor r-1: trial division to 6e7 then check the cofactor
t0 = time.time()
facr, rest_r = trial_factor(r - 1, 60_000_000)
out["r_minus_1_trial_division_s"] = round(time.time() - t0, 1)
facr[rest_r] = facr.get(rest_r, 0) + 1
t0 = time.time()
for p_ in facr:
    assert trial_is_prime(p_), p_                 # 784596642205391 < 2^50: trial division to 2.8e7
out["r_minus_1_factor_primality_trial_s"] = round(time.time() - t0, 1)
prod = 1
for p_, e in facr.items():
    prod *= p_**e
assert prod == r - 1
out["r_minus_1_factorisation"] = [[str(p_), e] for p_, e in sorted(facr.items())]

# Pocklington / Lehmer n-1 proof that r is prime (F = r-1 fully factored, all factors proven prime)
witness = {}
for p_ in facr:
    for base in range(2, 200):
        if pow(base, r - 1, r) != 1:
            raise AssertionError("r composite (Fermat witness %d)" % base)
        if math.gcd(pow(base, (r - 1) // p_, r) - 1, r) == 1:
            witness[str(p_)] = base
            break
    else:
        raise AssertionError("no Pocklington witness for %d" % p_)
out["r_prime_pocklington_witnesses"] = witness
out["r_log2"] = round(math.log2(r), 4)


def order_mod(g, n, fac_nm1):
    """order of g mod prime n from factorisation of n-1, with minimality check"""
    k = n - 1
    for p_, e in fac_nm1.items():
        for _ in range(e):
            if pow(g, k // p_, n) == 1:
                k //= p_
            else:
                break
    assert pow(g, k, n) == 1
    return k


k_q = order_mod(q % r, r, facr)
k_2 = order_mod(2, r, facr)
# minimality of k_q: q^(k/p) != 1 for every prime p | k
for p_ in facr:
    if k_q % p_ == 0:
        assert pow(q, k_q // p_, r) != 1
out["ord_r_q"] = str(k_q)
out["ord_r_q_bit_length"] = k_q.bit_length()
out["ord_r_q_log2"] = round(math.log2(k_q), 4)
out["(r-1)/ord_r_q"] = (r - 1) // k_q
out["ord_r_2"] = str(k_2)
out["ord_r_2 == 131*ord_r_q"] = (k_2 == 131 * k_q)
assert (r - 1) % k_q == 0 and (r - 1) // k_q == 786 and k_2 == 131 * k_q


def naive_order(g, n):
    x, i = g % n, 1
    while x != 1:
        x = x * g % n
        i += 1
    return i


out["ord_263_q"] = naive_order(q, 263)
out["ord_263^2_q"] = naive_order(q, 263**2)
out["ord_263_2"] = naive_order(2, 263)
out["ord_263^2_2"] = naive_order(2, 263**2)
out["v263(4N)"] = 0 if (4 * N) % 263 else 1
out["4N mod 263"] = (4 * N) % 263
out["gcd(N,TW)"] = math.gcd(N, TW)
out["gcd(4N,TW)"] = math.gcd(4 * N, TW)
assert out["ord_263_q"] == 1 and out["ord_263^2_q"] == 263 and out["gcd(N,TW)"] == 1
# Hasse interval: unique multiple of M0 = 263*r (and of 263^2*r) in [q+1-2sqrt q, q+1+2sqrt q]
lo = q + 1 - 2 * math.isqrt(q) - 2
hi = q + 1 + 2 * math.isqrt(q) + 2
def multiples_in(Mx):
    return [m * Mx for m in range(-(-lo // Mx), hi // Mx + 1)]
out["multiples_of_263r_in_Hasse"] = [str(v) for v in multiples_in(263 * r)]
out["multiples_of_263^2r_in_Hasse"] = [str(v) for v in multiples_in(263**2 * r)]
out["multiples_of_N_in_Hasse"] = [str(v) for v in multiples_in(N)]
assert multiples_in(263 * r) == [TW] and multiples_in(263**2 * r) == [TW] and multiples_in(N) == [CARD]
print(json.dumps(out, indent=1), flush=True)


# ---------------- field F_(2^131) ----------------
def fred(x):
    while x >> M:
        h = x >> M
        x = (x & MASK) ^ h ^ (h << 1) ^ (h << 2) ^ (h << 13)
    return x


def fmul(x, y):
    acc = 0
    while y:
        if y & 1:
            acc ^= x
        x <<= 1
        y >>= 1
    return fred(acc)


def fsq(x):
    return fmul(x, x)


def finv(x):
    # extended Euclid over F_2[z]
    assert x
    u, v, g1, g2 = x, MOD, 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v, g1, g2 = v, u, g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return fred(g1)


def fpow(x, e):
    res = 1
    while e:
        if e & 1:
            res = fmul(res, x)
        x = fsq(x)
        e >>= 1
    return res


def trace(c):
    s, x = 0, c
    for _ in range(M):
        s ^= x
        x = fsq(x)
    assert s in (0, 1)
    return s


def halftrace(c):
    s, x = 0, c
    for _ in range((M - 1) // 2 + 1):
        s ^= x
        x = fsq(fsq(x))
    return s


# field sanity: z^(2^131) = z, inverse
assert fpow(2, q) == 2
_x = 0x1234567890ABCDEF1234567890ABCDEF1
assert fmul(_x, finv(_x)) == 1


# ---------------- curve y^2 + xy = x^3 + a2 x^2 + b ----------------
class Curve:
    def __init__(self, a2, b):
        self.a2, self.b = a2, b

    def on(self, P):
        if P is None:
            return True
        x, y = P
        return fsq(y) ^ fmul(x, y) == fmul(fsq(x), x) ^ fmul(self.a2, fsq(x)) ^ self.b

    def neg(self, P):
        return None if P is None else (P[0], P[0] ^ P[1])

    def add(self, P, Q):
        if P is None:
            return Q
        if Q is None:
            return P
        x1, y1 = P
        x2, y2 = Q
        if x1 == x2:
            if y1 ^ y2 == x1:          # Q = -P (includes 2-torsion x1 = 0, y1 = y2)
                return None
            return self.dbl(P)
        lam = fmul(y1 ^ y2, finv(x1 ^ x2))
        x3 = fsq(lam) ^ lam ^ x1 ^ x2 ^ self.a2
        y3 = fmul(lam, x1 ^ x3) ^ x3 ^ y1
        return (x3, y3)

    def dbl(self, P):
        if P is None:
            return None
        x1, y1 = P
        if x1 == 0:
            return None
        lam = x1 ^ fmul(y1, finv(x1))
        x3 = fsq(lam) ^ lam ^ self.a2
        y3 = fsq(x1) ^ fmul(lam ^ 1, x3)
        return (x3, y3)

    def mul(self, k, P):
        if k < 0:
            return self.mul(-k, self.neg(P))
        R = None
        for bit in bin(k)[2:] if k else "":
            R = self.dbl(R)
            if bit == "1":
                R = self.add(R, P)
        return R

    def random_point(self, rng):
        while True:
            x = rng.getrandbits(M)
            if x == 0:
                continue
            c = x ^ self.a2 ^ fmul(self.b, finv(fsq(x)))
            if trace(c):
                continue
            zz = halftrace(c)
            assert fsq(zz) ^ zz == c
            P = (x, fmul(x, zz))
            if rng.getrandbits(1):
                P = self.neg(P)
            assert self.on(P)
            return P


# ---------------- Tate pairing, n = 263, k = 1 ----------------
ELL = 263
EXP = (q - 1) // ELL
assert (q - 1) % ELL == 0


def line_eval(C, V, W, Pt):
    """value at Pt of the normalised line through V and W (tangent if V == W), divided by the
    vertical through V+W.  Returns (num, den)."""
    xP, yP = Pt
    x1, y1 = V
    if V == W:
        lam = x1 ^ fmul(y1, finv(x1))
    else:
        x2, y2 = W
        if x1 == x2:                      # W = -V: vertical line x + x1, and V+W = O
            return (xP ^ x1, 1)
        lam = fmul(y1 ^ y2, finv(x1 ^ x2))
    num = yP ^ y1 ^ fmul(lam, xP ^ x1)
    S3 = C.add(V, W)
    den = 1 if S3 is None else (xP ^ S3[0])
    return (num, den)


def miller(C, P, n, Pt):
    f_num, f_den = 1, 1
    V = P
    for bit in bin(n)[3:]:
        a1, d1 = line_eval(C, V, V, Pt)
        f_num = fmul(fsq(f_num), a1)
        f_den = fmul(fsq(f_den), d1)
        V = C.dbl(V)
        if bit == "1":
            a1, d1 = line_eval(C, V, P, Pt)
            f_num = fmul(f_num, a1)
            f_den = fmul(f_den, d1)
            V = C.add(V, P)
    assert V is None                      # n P = O
    return f_num, f_den


def tate(C, P, R, rng):
    """reduced Tate pairing t_263(P, R) in mu_263 subset F_q^*, divisor D_R = (R+S) - (S)."""
    while True:
        S = C.random_point(rng)
        RS = C.add(R, S)
        if RS is None:
            continue
        try:
            n1, d1 = miller(C, P, ELL, RS)
            n2, d2 = miller(C, P, ELL, S)
        except AssertionError:
            continue
        if 0 in (n1, d1, n2, d2):
            continue
        val = fmul(fmul(n1, d2), finv(fmul(d1, n2)))
        return fpow(val, EXP)


# ---------------- per-curve twist checks ----------------
mode = sys.argv[1] if len(sys.argv) > 1 else "all"
curves = GT["curves"]
if mode == "sample":
    curves = [c for c in curves if c["label"] in ("E0", "A000", "B000", "A064", "B130")]
rng = random.Random(20260923)
per = {}
pair_rows = []
T0 = time.time()
for cv in curves:
    lab = cv["label"]
    b = int(cv["b_int"])
    assert int(cv["a2"]) == 0
    E = Curve(0, b)
    Et = Curve(1, b)                         # quadratic twist (Tr(1) = 1 since 131 odd)
    row = {}
    # E itself: point with [4N]P = O and [4]P != O  -> #E = 4N (unique multiple of N in Hasse) -> no 263-torsion
    while True:
        P = E.random_point(rng)
        P4 = E.mul(4, P)
        if P4 is not None:
            break
    assert E.mul(N, P4) is None
    row["E_4N_point_check"] = True
    # twist: [TW]R = O; [2*263^2]R has order r (r | ord R)
    Rt = Et.random_point(rng)
    assert Et.mul(TW, Rt) is None
    Rr = Et.mul(2 * 263**2, Rt)
    assert Rr is not None and Et.mul(r, Rr) is None
    row["twist_TW_kills_point"] = True
    row["twist_r_divides_point_order"] = True
    # 263-part
    if lab == "E0":
        # (Z/263)^2: all 263-power points have exponent 263; exhibit two independent ones
        pts = []
        while len(pts) < 2:
            T = Et.mul(2 * r, Et.random_point(rng))
            if T is None:
                continue
            assert Et.mul(263, T) is None
            if not pts:
                pts.append(T)
            else:
                mults, X = set(), None
                for i in range(263):
                    mults.add(X)
                    X = Et.add(X, pts[0])
                if T not in mults:
                    pts.append(T)
        row["twist_263_part"] = "(Z/263)^2 (two independent order-263 points; no order-263^2 point in samples)"
        row["twist_order_proved"] = "263*r | ord-lcm -> unique multiple of 263r in Hasse = TW"
        # extra: is there any point of order 263^2? sample 20 points
        for _ in range(20):
            T = Et.mul(2 * r, Et.random_point(rng))
            assert T is None or Et.mul(263, T) is None
        P263, Rpair = pts[0], pts[1]
    else:
        tries = 0
        while True:
            tries += 1
            T = Et.mul(2 * r, Et.random_point(rng))
            if T is not None and Et.mul(263, T) is not None:
                break
            assert tries < 30
        assert Et.mul(263**2, T) is None
        row["twist_263_part"] = "Z/263^2 (point of exact order 263^2)"
        row["twist_order_proved"] = "263^2*r | #E' -> unique multiple in Hasse = TW"
        P263, Rpair = Et.mul(263, T), T
    per[lab] = row
    # planted toy DLP on the order-263 subgroup via own Tate pairing (selected curves only)
    if lab in ("E0", "A000", "B000", "A064", "B130"):
        t_PR = tate(Et, P263, Rpair, rng)
        assert t_PR != 1 and fpow(t_PR, ELL) == 1
        secret = rng.randrange(1, ELL)
        Qd = Et.mul(secret, P263)
        t_QR = tate(Et, Qd, Rpair, rng)
        x, z = 0, 1
        while z != t_QR:
            z = fmul(z, t_PR)
            x += 1
            assert x < ELL
        # degeneracy check on floor twists: P263 lies in 263*E'(F_q), so t(P263, P263) = 1
        t_PP = tate(Et, P263, P263, rng)
        # consistency across different random S
        t_PR2 = tate(Et, P263, Rpair, rng)
        prow = {"curve_twist": lab + "'", "planted": secret, "recovered": x, "ok": x == secret,
                "t(P,R)!=1": True, "t(P,P)==1": t_PP == 1, "t(P,R) independent of S": t_PR2 == t_PR}
        assert x == secret and t_PR2 == t_PR
        if lab != "E0":
            assert t_PP == 1
        pair_rows.append(prow)
        print("pairing", prow, flush=True)
    if len(per) % 25 == 0 or lab in ("E0", "A000", "B000"):
        print(lab, row, round(time.time() - T0, 1), "s", flush=True)

out["mode"] = mode
out["n_curves_checked"] = len(per)
out["per_curve_all_passed"] = all(v["twist_TW_kills_point"] and v["twist_r_divides_point_order"] for v in per.values())
out["twist_263_structures"] = {s: sum(1 for v in per.values() if v["twist_263_part"] == s)
                               for s in set(v["twist_263_part"] for v in per.values())}
out["planted_263_dlp_own_tate"] = pair_rows
out["elapsed_s"] = round(time.time() - T0, 1)
(HERE / f"c4_pure_python_{mode}.json").write_text(json.dumps({"summary": out, "per_curve": per}, indent=1))
print(json.dumps({k: v for k, v in out.items() if k not in ()}, indent=1))
