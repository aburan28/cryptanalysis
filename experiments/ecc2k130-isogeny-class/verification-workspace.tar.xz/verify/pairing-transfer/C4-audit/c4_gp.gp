\\ C4 audit (independent of the sweep's Sage code and of ground_truth.json)
default(parisize, 10^8);
q = 2^131;
\\ trace via Lucas recurrence for tau^2 + tau + 2 = 0 (#E0(F_2)=4 => t1=-1)
tt = vector(132); t0 = 2; t1 = -1; a=t0; b=t1; for(i=2,131, c = -b - 2*a; a=b; b=c); t = b;
print("t = ", t);
\\ independent point count with PARI on the ECC2K modulus
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
E0 = ellinit([1,0,0,0,1], z);
c = ellcard(E0); print("ellcard(E0) = ", c, "  == q+1-t: ", c == q+1-t);
E0t = ellinit([1,1,0,0,1], z);
ct = ellcard(E0t); print("ellcard(E0') = ", ct, "  == q+1+t: ", ct == q+1+t);
N = c/4; print("N = ", N, " isprime ", isprime(N));
TW = q+1+t; print("TW = ", TW);
F = factor(TW); print("factor(TW) = ", F);
r = 19678316408850118605767852657510239;
print("TW == 2*263^2*r: ", TW == 2*263^2*r);
print("isprime(r) (APRCL/ECPP proof): ", isprime(r, 2), "  log2 r = ", log(r)/log(2));
cert = primecert(r); print("primecertisvalid(r): ", primecertisvalid(cert));
kq = znorder(Mod(2,r)^131); k2 = znorder(Mod(2,r));
print("ord_r(q) = ", kq, "  bits ", #binary(kq), " log2 ", log(kq)/log(2));
print("(r-1)/ord_r(q) = ", (r-1)/kq, "  factor(786)=", factor(786));
print("ord_r(2) = ", k2, "  == 131*ord_r(q): ", k2 == 131*kq);
print("factor(r-1) = ", factor(r-1));
print("ord_263(q) = ", znorder(Mod(2,263)^131), "  ord_263^2(q) = ", znorder(Mod(2,263^2)^131));
print("ord_263(2) = ", znorder(Mod(2,263)), "  ord_263^2(2) = ", znorder(Mod(2,263^2)));
print("q mod 263 = ", q%263, "  q mod 263^2 = ", q % 263^2, "  v263(q-1) = ", valuation(q-1,263));
print("v_263(4N) = ", valuation(4*N,263), "  v_263(TW) = ", valuation(TW,263));
print("gcd(N,TW) = ", gcd(N,TW), "  gcd(4N,TW) = ", gcd(4*N,TW));
print("N == r? ", N==r);
\\ group structure of the twist E0' over F_q
print("ellgroup(E0') = ", ellgroup(E0t));
print("ellgroup(E0)  = ", ellgroup(E0));
\\ ord over F_(q^2): embedding degree of r over F_(q^2)
print("ord_r(q^2) = ", znorder(Mod(2,r)^262));
\\ smallest k such that r | q^k-1 by brute force up to 10^6 (sanity)
m = Mod(1,r); Q = Mod(2,r)^131; hit=0; for(i=1,10^6, m*=Q; if(m==1, hit=i; break)); print("brute scan hit in 1..10^6: ", hit);
