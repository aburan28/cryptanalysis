#!/usr/bin/env python3
"""C5 independent recompute (pure python3, no Sage/PARI, no reuse of sweep scripts).

Claim C5: anomalous attacks (Smart/Semaev/Satoh-Araki) and supersingular MOV do not
apply to any of the 263 curves: #E = 4N != q, t != 1, N odd, 2-part of #E is 4,
all curves ordinary (t odd, j != 0).

Independent code paths used here:
  * t from pi = tau^131 computed in the ring Z[tau], tau^2 = -tau - 2 (NOT the Lucas
    recurrence); #E0(F_2) by brute-force enumeration of F_2 points.
  * own F_{2^131} arithmetic (polynomial basis, own reduction/EEA inverse/half-trace),
    own irreducibility test of the modulus (Rabin).
  * own Miller-Rabin for N.
  * for every one of the 263 curves in ground_truth.json: own parse, j*b == 1 check,
    j != 0, random-point order proof of #E = 4N (point of exact order 4N), explicit
    rational 2-torsion point (0, sqrt(b)) (=> ordinary in char 2), twist point killed by
    q+1+t.
  * bounded embedding-degree scan q^k mod N for k <= KMAX.
"""
import json, random, sys, time, math, hashlib

T0 = time.time()
GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
OUT = "/Volumes/SSD990/ecdlp-hardness-work/verify/pairing-transfer/C5-recompute/c5_recompute.json"
rng = random.Random(20260923 + 5)
res = {"script": __file__, "checks": {}}
chk = res["checks"]

def ok(name, cond, val=None):
    chk[name] = {"pass": bool(cond)} if val is None else {"pass": bool(cond), "value": val}
    print(("PASS " if cond else "FAIL ") + name + ("" if val is None else "  " + str(val)))
    if not cond:
        json.dump(res, open(OUT, "w"), indent=1)
        sys.exit(1)

# ---------------------------------------------------------------- integers
m = 131
q = 1 << m

# brute-force #E0(F_2): y^2 + xy = x^3 + 1 over F_2 (+ point at infinity)
cnt = 1
for x in (0, 1):
    for y in (0, 1):
        if ((y * y + x * y) - (x ** 3 + 1)) % 2 == 0:
            cnt += 1
ok("E0(F_2) brute-force count == 4", cnt == 4, cnt)
t1 = 2 + 1 - cnt  # trace over F_2
ok("t1 == -1 (tau^2 + tau + 2 = 0)", t1 == -1, t1)

# pi = tau^131 in Z[tau] with tau^2 = t1*tau - 2  (elements a + b*tau)
def zmul(u, v):
    a, b = u; c, d = v
    # (a + b tau)(c + d tau) = ac + (ad+bc) tau + bd tau^2, tau^2 = t1 tau - 2
    return (a * c - 2 * b * d, a * d + b * c + t1 * b * d)
def zpow(u, e):
    r = (1, 0)
    while e:
        if e & 1: r = zmul(r, u)
        u = zmul(u, u); e >>= 1
    return r
pa, pb = zpow((0, 1), m)
tr = 2 * pa + t1 * pb           # Tr(a + b tau) = 2a + b*Tr(tau), Tr(tau) = t1
nm = pa * pa + t1 * pa * pb + 2 * pb * pb  # Norm(a + b tau), N(tau)=2, Tr(tau)=t1
ok("Norm(tau^131) == 2^131", nm == q)
t = tr
ok("t from Z[tau] power == -22283658519494248867", t == -22283658519494248867, str(t))
card = q + 1 - t
twist = q + 1 + t
N = 680564733841876926932320129493409985129
ok("#E0 = q+1-t == 4*N", card == 4 * N, str(card))

def mr(n, rounds=64):
    if n < 2: return False
    for sp in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % sp == 0: return n == sp
    d, s = n - 1, 0
    while d % 2 == 0: d //= 2; s += 1
    for _ in range(rounds):
        a = rng.randrange(2, n - 1)
        x = pow(a, d, n)
        if x in (1, n - 1): continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1: break
        else:
            return False
    return True
ok("N prime (own Miller-Rabin, 64 random bases)", mr(N))
ok("log2(N)", True, round(math.log2(N), 4))

# anomalous / characteristic checks
ok("t odd (t mod 2 == 1)", t % 2 == 1, t % 2)
ok("t != 1 (not anomalous: #E != q)", t != 1)
ok("#E != q", card != q)
ok("twist #E' != q", twist != q)
ok("N odd, gcd(N,2) == 1", N % 2 == 1 and math.gcd(N, 2) == 1)
ok("gcd(N, q) == 1", math.gcd(N, q) == 1)
v2 = 0; c = card
while c % 2 == 0: c //= 2; v2 += 1
ok("v2(#E) == 2 (2-part of #E is 4)", v2 == 2 and c == N, 2 ** v2)
vt = 0; c = twist
while c % 2 == 0: c //= 2; vt += 1
ok("v2(#E twist)", True, vt)
# #E(F_2^k) for small extension degrees k of F_q: anomalous over F_{q^k} would need
# #E(F_{q^k}) divisible by... (only the 2-part matters; N odd so irrelevant) - record t_k parity
# supersingular in char 2 <=> t == 0 mod 2
ok("not supersingular: t mod 2 != 0", t % 2 != 0)

# Hasse interval uniqueness of 4N among multiples of N
s = math.isqrt(4 * q)  # floor(2 sqrt q)
lo, hi = q + 1 - s - 1, q + 1 + s + 1
mults = [k for k in range(lo // N, hi // N + 2) if lo <= k * N <= hi]
ok("4 is the only k with k*N in Hasse interval", mults == [4], mults)

# supersingular MOV bound: embedding degree <= 4 in char 2; scan much further
KMAX = 2_000_000
qN = q % N
x = 1; hitk = None
for k in range(1, KMAX + 1):
    x = x * qN % N
    if x == 1:
        hitk = k; break
ok(f"q^k != 1 mod N for all 1 <= k <= {KMAX}", hitk is None, hitk)
# same for base 2 (F_2-subfield view): 2^k != 1 mod N for k <= KMAX
x = 1; hit2 = None
for k in range(1, KMAX + 1):
    x = 2 * x % N
    if x == 1:
        hit2 = k; break
ok(f"2^k != 1 mod N for all 1 <= k <= {KMAX}", hit2 is None, hit2)

# ---------------------------------------------------------------- field F_2^131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
ok("modulus_int matches ground truth", str(MOD) == json.load(open(GT))["meta"]["modulus_int"], str(MOD))
MASK = (1 << m) - 1

def red(r):
    while r >> m:
        h = r >> m
        r = (r & MASK) ^ h ^ (h << 1) ^ (h << 2) ^ (h << 13)
    return r

def clmul(a, b):
    # 4-bit windowed carry-less multiply
    T = [0] * 16
    for k in range(1, 16):
        v = 0
        for i in range(4):
            if (k >> i) & 1: v ^= a << i
        T[k] = v
    r = 0
    nb = (b.bit_length() + 3) // 4
    for i in range(nb - 1, -1, -1):
        r = (r << 4) ^ T[(b >> (4 * i)) & 15]
    return r

def fmul(a, b): return red(clmul(a, b))
def fsq(a):
    # squaring = spread bits
    r = 0; i = 0
    while a:
        if a & 1: r |= 1 << (2 * i)
        a >>= 1; i += 1
    return red(r)
def finv(a):
    assert a
    u, v, g1, g2 = a, MOD, 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v, g1, g2 = v, u, g2, g1; j = -j
        u ^= v << j; g1 ^= g2 << j
    return red(g1)
def fpow2k(a, k):
    for _ in range(k): a = fsq(a)
    return a
def ftrace(a):
    s = a; x = a
    for _ in range(m - 1):
        x = fsq(x); s ^= x
    assert s in (0, 1)
    return s
def fhalftrace(a):
    s = a; x = a
    for _ in range((m - 1) // 2):
        x = fsq(fsq(x)); s ^= x
    return s

# Rabin irreducibility for prime degree 131: x^(2^131) == x mod f and gcd(x^2 - x, f) = 1
X = 2
ok("Rabin: z^(2^131) == z mod f", fpow2k(X, m) == X)
def pgcd(a, b):
    while b:
        while a and a.bit_length() >= b.bit_length():
            a ^= b << (a.bit_length() - b.bit_length())
        a, b = b, a
    return a
ok("Rabin: gcd(z^2 + z, f) == 1", pgcd(MOD, 0b110) == 1)
ok("Tr(1) == 1 (so twist is a2 -> a2+1)", ftrace(1) == 1)
for _ in range(5):
    a = rng.getrandbits(m); b = rng.getrandbits(m)
    assert fmul(a, b) == fmul(b, a) and (a == 0 or fmul(a, finv(a)) == 1)
ok("field self-test (commutativity, inverses) on random elements", True)

# ---------------------------------------------------------------- curve arithmetic
# y^2 + x y = x^3 + a2 x^2 + b ; None = point at infinity
def on_curve(P, a2, b):
    if P is None: return True
    x, y = P
    lhs = fsq(y) ^ fmul(x, y)
    x2 = fsq(x)
    rhs = fmul(x2, x) ^ (x2 if a2 else 0) ^ b
    return lhs == rhs
def padd(P, Q, a2):
    if P is None: return Q
    if Q is None: return P
    x1, y1 = P; x2, y2 = Q
    if x1 == x2:
        if y1 ^ y2 == x1:  # Q = -P  (-P = (x, x+y))
            return None
        return pdbl(P, a2)
    lam = fmul(y1 ^ y2, finv(x1 ^ x2))
    x3 = fsq(lam) ^ lam ^ x1 ^ x2 ^ (1 if a2 else 0)
    y3 = fmul(lam, x1 ^ x3) ^ x3 ^ y1
    return (x3, y3)
def pdbl(P, a2):
    if P is None: return None
    x1, y1 = P
    if x1 == 0: return None
    lam = x1 ^ fmul(y1, finv(x1))
    x3 = fsq(lam) ^ lam ^ (1 if a2 else 0)
    y3 = fsq(x1) ^ fmul(lam ^ 1, x3)
    return (x3, y3)
def pmul(k, P, a2):
    R = None
    for bit in bin(k)[2:]:
        R = pdbl(R, a2)
        if bit == '1': R = padd(R, P, a2)
    return R
def rand_point(a2, b):
    while True:
        x = rng.getrandbits(m)
        if x == 0: continue
        c = x ^ (1 if a2 else 0) ^ fmul(b, finv(fsq(x)))
        if ftrace(c): continue
        z = fhalftrace(c)
        assert fsq(z) ^ z == c
        y = fmul(x, z)
        P = (x, y)
        assert on_curve(P, a2, b)
        return P

# sanity: E0, the Certicom-style check of group law on a random point
gt = json.load(open(GT))
meta = gt["meta"]
ok("meta t/N/card agree with own values",
   int(meta["t"]) == t and int(meta["N"]) == N and int(meta["card"]) == card and int(meta["twist_card"]) == twist)

curves = gt["curves"]
ok("ground truth has 263 curves", len(curves) == 263, len(curves))
labels = [c["label"] for c in curves]
ok("labels unique", len(set(labels)) == 263)
jset = set()
per = []
tc = time.time()
for idx, cv in enumerate(curves):
    j = int(cv["j_int"]); b = int(cv["b_int"]); a2 = int(cv["a2"])
    rec = {"label": cv["label"]}
    assert 0 <= j < q and 0 < b < q, cv["label"]
    assert j != 0, cv["label"]
    assert fmul(j, b) == 1, cv["label"]          # j = 1/b
    assert a2 in (0, 1)
    jset.add(j)
    # explicit F_q-rational 2-torsion point (0, sqrt b): exists only if ordinary in char 2
    T2 = (0, fpow2k(b, m - 1))
    assert on_curve(T2, a2, b) and T2 is not None and pdbl(T2, a2) is None
    # point of exact order 4N on E (=> E(F_q) cyclic of order 4N given Hasse uniqueness)
    for attempt in range(8):
        P = rand_point(a2, b)
        Q4 = pmul(4, P, a2)
        if Q4 is None: continue
        QN = pmul(N, P, a2)          # order-dividing-4 part
        if pmul(2, QN, a2) is None:  # [2N]P = O -> try another point
            continue
        assert on_curve(QN, a2, b)
        assert pmul(N, Q4, a2) is None           # [4N]P = O
        assert pmul(4, QN, a2) is None           # [N]P has order exactly 4
        break
    else:
        raise AssertionError("no point of order 4N found for " + cv["label"])
    # twist a2+1: random point killed by q+1+t
    Pt = rand_point(a2 ^ 1, b)
    assert pmul(twist, Pt, a2 ^ 1) is None
    assert pmul(card, Pt, a2 ^ 1) is not None   # and not by q+1-t
    per.append({"label": cv["label"], "a2": a2, "j_nonzero": True, "jb_eq_1": True,
                "rational_2torsion": True, "point_of_order_4N": True, "twist_killed_by_q+1+t": True})
    if idx % 50 == 0:
        print(f"  {idx:3d} {cv['label']}  ok  ({time.time()-tc:.1f}s)", flush=True)

ok("all 263: j != 0, j*b == 1 in own field arithmetic", True)
ok("all 263 j distinct", len(jset) == 263)
ok("all 263: rational 2-torsion point (0, sqrt b) exists => ordinary", True)
ok("all 263: point of exact order 4N => #E(F_q) = 4N (cyclic), 2-part = Z/4", True)
ok("all 263: twist point killed by q+1+t, not by q+1-t", True)
ok("a2 values", True, sorted(set(int(c["a2"]) for c in curves)))

res["numbers"] = {"t": str(t), "card": str(card), "twist": str(twist), "N": str(N),
                  "v2_card": v2, "v2_twist": vt, "pi_in_Z[tau]": [str(pa), str(pb)],
                  "KMAX": KMAX}
res["per_curve"] = per
res["elapsed_s"] = round(time.time() - T0, 1)
json.dump(res, open(OUT, "w"), indent=1)
print("elapsed", res["elapsed_s"], "s")
