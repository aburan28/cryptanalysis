#!/usr/bin/env python3
"""Own reduced Tate pairing of order 263 on the quadratic twists E' = [1,1,0,0,b]
of E0, A000, B000 over F_q, q = 2^131, polynomial basis z^131+z^13+z^2+z+1.
Pure python3 (own field arithmetic, own Miller loop), not the sweep's code.
Checks: 263-Sylow structure of E'(F_q), non-degeneracy, bilinearity, and solves
planted toy DLPs in the 263-part via Pohlig-Hellman + pairing into mu_263 in F_q^*.
Also checks that E (a2=0) has no F_q-point of order 263.
"""
import json, random, sys, time

random.seed(4242)
M = 131
MODP = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
q = 1 << M
t = -22283658519494248867
TW = q + 1 + t
r = 19678316408850118605767852657510239
N = (q + 1 - t) // 4
assert TW == 2 * 263 ** 2 * r

def red(x):
    while x >> M:
        h = x >> M
        x = (x & ((1 << M) - 1)) ^ h ^ (h << 1) ^ (h << 2) ^ (h << 13)
    return x

def fmul(a, b):
    if bin(a).count("1") < bin(b).count("1"):
        a, b = b, a
    acc = 0
    i = 0
    while b:
        if b & 1:
            acc ^= a << i
        b >>= 1
        i += 1
    return red(acc)

def fsq(a):
    return fmul(a, a)

def finv(a):
    assert a
    u, v, g1, g2 = a, MODP, 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v, g1, g2 = v, u, g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return red(g1)

def fpow(a, e):
    res = 1
    while e:
        if e & 1:
            res = fmul(res, a)
        a = fsq(a)
        e >>= 1
    return res

def ftrace(a):
    s, x = 0, a
    for _ in range(M):
        s ^= x
        x = fsq(x)
    return s

def fhalftrace(c):
    s, x = 0, c
    for _ in range((M + 1) // 2):
        s ^= x
        x = fsq(fsq(x))
    return s

class Curve:
    def __init__(self, a2, b):
        self.a2, self.b = a2, b

    def on(self, P):
        if P is None:
            return True
        x, y = P
        return fsq(y) ^ fmul(x, y) == fmul(fsq(x), x) ^ fmul(self.a2, fsq(x)) ^ self.b

    def lift(self, x):
        if x == 0:
            return None
        rhs = fmul(fsq(x), x) ^ fmul(self.a2, fsq(x)) ^ self.b
        c = fmul(rhs, finv(fsq(x)))
        if ftrace(c):
            return None
        zz = fhalftrace(c)
        assert fsq(zz) ^ zz == c
        return (x, fmul(x, zz))

    def rand(self):
        while True:
            P = self.lift(random.getrandbits(M))
            if P is not None:
                assert self.on(P)
                return P

    def neg(self, P):
        return None if P is None else (P[0], P[0] ^ P[1])

    def add(self, P, Q):
        if P is None:
            return Q
        if Q is None:
            return P
        x1, y1 = P
        x2, y2 = Q
        if x1 == x2:
            if y1 == y2:
                return self.dbl(P)
            return None
        lam = fmul(y1 ^ y2, finv(x1 ^ x2))
        x3 = fsq(lam) ^ lam ^ x1 ^ x2 ^ self.a2
        return (x3, fmul(lam, x1 ^ x3) ^ x3 ^ y1)

    def dbl(self, P):
        if P is None or P[0] == 0:
            return None
        x, y = P
        lam = x ^ fmul(y, finv(x))
        x3 = fsq(lam) ^ lam ^ self.a2
        return (x3, fsq(x) ^ fmul(lam ^ 1, x3))

    def mul(self, k, P):
        if k < 0:
            return self.mul(-k, self.neg(P))
        R = None
        for bit in bin(k)[2:]:
            R = self.dbl(R)
            if bit == '1':
                R = self.add(R, P)
        return R

    # line through T and X (tangent if equal) evaluated at point S, and resulting sum
    def line(self, T, X, S):
        x1, y1 = T
        xs, ys = S
        if T == X:
            if x1 == 0:
                return xs ^ x1, None  # vertical, 2T = O
            lam = x1 ^ fmul(y1, finv(x1))
        else:
            x2, y2 = X
            if x1 == x2:
                return xs ^ x1, None  # vertical, T + X = O
            lam = fmul(y1 ^ y2, finv(x1 ^ x2))
        return ys ^ y1 ^ fmul(lam, xs ^ x1), self.add(T, X)

    def miller(self, n, X, S):
        """f_{n,X}(S) as (num, den) with Miller's normalized functions."""
        num, den = 1, 1
        T = X
        for bit in bin(n)[3:]:
            l, T2 = self.line(T, T, S)
            num = fmul(fsq(num), l)
            den = fsq(den)
            if T2 is not None:
                den = fmul(den, S[0] ^ T2[0])
            T = T2
            if bit == '1':
                l, T2 = self.line(T, X, S)
                num = fmul(num, l)
                if T2 is not None:
                    den = fmul(den, S[0] ^ T2[0])
                T = T2
        assert T is None, "X does not have order dividing n"
        return num, den

    def tate(self, n, X, S, U=None):
        """reduced Tate pairing t_n(X, S) = f_{n,X}((S+U)-(U))^((q-1)/n)."""
        assert (q - 1) % n == 0
        for _ in range(20):
            if U is None:
                U_ = self.rand()
            else:
                U_ = U
            SU = self.add(S, U_)
            try:
                a1, b1 = self.miller(n, X, SU)
                a2, b2 = self.miller(n, X, U_)
                if 0 in (a1, b1, a2, b2):
                    raise ZeroDivisionError
                val = fmul(fmul(a1, b2), finv(fmul(b1, a2)))
                return fpow(val, (q - 1) // n)
            except (ZeroDivisionError, AssertionError, TypeError):
                if U is not None:
                    raise
        raise RuntimeError("no good auxiliary point")

def dlog_mu(g, h, n):
    x = 1
    for k in range(n):
        if x == h:
            return k
        x = fmul(x, g)
    return None

gt = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json'))
bmap = {c['label']: int(c['b_int']) for c in gt['curves']}

out = {}
for label in ["E0", "A000", "B000", "A077", "B130"]:
    T0 = time.time()
    b = bmap[label]
    Et = Curve(1, b)   # twist
    E = Curve(0, b)    # the curve itself
    rec = {"b_int": str(b)}
    # sanity: group orders
    R = Et.rand()
    rec["twist_[TW]R==O"] = Et.mul(TW, R) is None
    rec["twist_[TW/r]R!=O"] = Et.mul(TW // r, R) is not None
    RE = E.rand()
    rec["E_[4N]R==O"] = E.mul(4 * N, RE) is None
    # E has no F_q-point of order 263: 263 does not divide 4N (checked) -> [4N/..] n/a;
    rec["263_divides_4N"] = (4 * N) % 263 == 0
    # 263-Sylow of twist: exponent = max order of [2r]R over several R
    maxord = 1
    gens = []
    for _ in range(4):
        P = Et.mul(2 * r, Et.rand())
        if P is None:
            o = 1
        elif Et.mul(263, P) is None:
            o = 263
        else:
            assert Et.mul(263 ** 2, P) is None
            o = 263 ** 2
        gens.append((o, P))
        maxord = max(maxord, o)
    rec["sylow263_exponent"] = maxord
    # rank: if exponent 263 and v_263 = 2 -> (Z/263)^2 ; check two points independent via pairing
    n = 263
    if maxord == 263:
        rec["sylow263_structure"] = "(Z/263)^2 (exponent 263, order 263^2)"
        G = [P for o, P in gens if o == 263][0]
        # find S with t(G,S) != 1
        while True:
            S = Et.rand()
            e = Et.tate(n, G, S)
            if e != 1:
                break
        rec["t263(G,S)^263==1"] = fpow(e, 263) == 1
        rec["t263(G,S)!=1"] = e != 1
        rec["bilinear_t(2G,S)==t(G,S)^2"] = Et.tate(n, Et.dbl(G), S) == fsq(e)
        S2 = Et.rand()
        rec["bilinear_t(G,S+S2)==t(G,S)t(G,S2)"] = Et.tate(n, G, Et.add(S, S2)) == fmul(e, Et.tate(n, G, S2))
        trials = []
        for _ in range(3):
            k = random.randrange(263)
            Q = Et.mul(k, G)
            kk = dlog_mu(e, Et.tate(n, Q, S), 263) if Q is not None else 0
            trials.append({"planted": k, "recovered": kk, "ok": k == kk})
        rec["planted_dlp"] = trials
    else:
        rec["sylow263_structure"] = "Z/263^2 (cyclic: point of order 263^2 exists, v_263 = 2)"
        G = [P for o, P in gens if o == 263 ** 2][0]
        G1 = Et.mul(263, G)  # generator of E'(F_q)[263]
        e = Et.tate(n, G1, G)   # t(263G, G)
        rec["t263(263G,G)!=1"] = e != 1
        rec["t263(263G,G)^263==1"] = fpow(e, 263) == 1
        rec["t263(263G,263G)==1 (263G in 263E)"] = Et.tate(n, G1, G1) == 1
        rec["bilinear_t(263G,2G)==t^2"] = Et.tate(n, G1, Et.dbl(G)) == fsq(e)
        trials = []
        for _ in range(3):
            k = random.randrange(263 ** 2)
            Q = Et.mul(k, G)
            k0 = dlog_mu(e, Et.tate(n, G1, Q), 263)
            Q1 = Et.add(Q, Et.neg(Et.mul(k0, G)))  # = [263 k1] G in E'[263]
            k1 = 0 if Q1 is None else dlog_mu(e, Et.tate(n, Q1, G), 263)
            kk = k0 + 263 * k1
            trials.append({"planted": k, "recovered": kk, "ok": k == kk})
        rec["planted_dlp"] = trials
        # a direct order-263^2 pairing would need mu_{263^2} in F_q^*: impossible, (q-1) % 263^2
        rec["(q-1)%263^2"] = (q - 1) % 263 ** 2
    rec["seconds"] = round(time.time() - T0, 1)
    out[label] = rec
    print(label, json.dumps(rec), flush=True)

json.dump(out, open('own_tate_263.json', 'w'), indent=1)
