#!/usr/bin/env python3
"""Independent recompute of claim C4 (pairing-transfer sweep).

Pure python3 only: own Lucas recurrence, own Miller-Rabin, own Pollard-rho
(Brent) factoring, own Pocklington/Lucas primality proofs, own multiplicative
order routine, own F_2^131 arithmetic and elliptic-curve scalar multiplication.
No PARI, no Sage, no sweep scripts.
"""
import json, math, random, sys, time

random.seed(20260923)
q = 1 << 131

# ---------- 1. trace via Lucas recurrence (t_0 = 2, t_1 = -1, x^2 + x + 2) -------
# #E0(F_2) = 4 by brute force below -> t1 = 2 + 1 - 4 = -1
def count_F2(a2, b):
    n = 1  # point at infinity
    for x in (0, 1):
        for y in (0, 1):
            if (y * y + x * y + x ** 3 + a2 * x * x + b) % 2 == 0:
                n += 1
    return n

n_E0_F2 = count_F2(0, 1)
t1 = 2 + 1 - n_E0_F2
tprev, tcur = 2, t1
for _ in range(130):
    tprev, tcur = tcur, t1 * tcur - 2 * tprev
t = tcur
order_E = q + 1 - t
twist = q + 1 + t

# ---------- 2. primality tools ----------------------------------------------------
SMALL = [p for p in range(2, 5000) if all(p % d for d in range(2, int(p ** 0.5) + 1))]

def mr(n, rounds=40):
    if n < 2:
        return False
    for p in SMALL[:60]:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    bases = SMALL[:20] + [random.randrange(2, n - 1) for _ in range(rounds)]
    for a in bases:
        a %= n
        if a in (0, 1, n - 1):
            continue
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True

def brent(n):
    if n % 2 == 0:
        return 2
    while True:
        y, c, m = random.randrange(1, n), random.randrange(1, n), 256
        g, r_, qq = 1, 1, 1
        while g == 1:
            x = y
            for _ in range(r_):
                y = (y * y + c) % n
            k = 0
            while k < r_ and g == 1:
                ys = y
                for _ in range(min(m, r_ - k)):
                    y = (y * y + c) % n
                    qq = qq * abs(x - y) % n
                g = math.gcd(qq, n)
                k += m
            r_ *= 2
        if g == n:
            g = 1
            while g == 1:
                ys = (ys * ys + c) % n
                g = math.gcd(abs(x - ys), n)
        if g != n:
            return g

def factor(n, out=None):
    if out is None:
        out = {}
    for p in SMALL:
        while n % p == 0:
            out[p] = out.get(p, 0) + 1
            n //= p
    if n == 1:
        return out
    stack = [n]
    while stack:
        m = stack.pop()
        if m == 1:
            continue
        if mr(m):
            out[m] = out.get(m, 0) + 1
            continue
        d = brent(m)
        stack += [d, m // d]
    return dict(sorted(out.items()))

# Pocklington-style proof (Lucas test with full factorisation of n-1), recursive.
proof_log = []

def prove_prime(n, depth=0):
    if n < SMALL[-1] ** 2:
        ok = n > 1 and all(n % p for p in SMALL if p * p <= n)
        proof_log.append({"n": str(n), "method": "trial division", "ok": ok})
        return ok
    if not mr(n):
        return False
    F = factor(n - 1)
    for p in F:
        if p > SMALL[-1] and not prove_prime(p, depth + 1):
            return False
    # find a witness a with a^(n-1)=1 and a^((n-1)/p) != 1 for every p | n-1
    witnesses = {}
    for p in F:
        for a in range(2, 1000):
            if pow(a, n - 1, n) != 1:
                return False
            if pow(a, (n - 1) // p, n) != 1:
                witnesses[str(p)] = a
                break
        else:
            return False
    proof_log.append({"n": str(n), "method": "Lucas n-1 (full factorisation)",
                      "n_minus_1": {str(k): v for k, v in F.items()},
                      "witness_per_prime": witnesses, "ok": True})
    return True

def mult_order(a, n, phi_fact):
    """order of a mod n given factorisation of the group exponent phi (dict)."""
    phi = 1
    for p, e in phi_fact.items():
        phi *= p ** e
    assert pow(a, phi, n) == 1
    o = phi
    for p, e in phi_fact.items():
        for _ in range(e):
            if pow(a, o // p, n) == 1:
                o //= p
            else:
                break
    return o

def v(p, n):
    k = 0
    while n % p == 0:
        n //= p
        k += 1
    return k

res = {}
res["n_E0_F2_bruteforce"] = n_E0_F2
res["t"] = str(t)
res["order_E"] = str(order_E)
res["twist_order"] = str(twist)

T0 = time.time()
tw_fact = factor(twist)
res["twist_factorisation_own_rho"] = {str(k): e for k, e in tw_fact.items()}
res["time_factor_twist_s"] = round(time.time() - T0, 2)

r_claim = 19678316408850118605767852657510239
res["twist_eq_2_263sq_r"] = (twist == 2 * 263 ** 2 * r_claim)
r = twist // (2 * 263 ** 2)
res["r"] = str(r)
res["r_bits_log2"] = math.log2(r)
res["r_bitlength"] = r.bit_length()

T0 = time.time()
res["r_prime_proved"] = prove_prime(r)
res["time_prove_r_s"] = round(time.time() - T0, 2)

rm1 = factor(r - 1)
res["r_minus_1_factorisation"] = {str(k): e for k, e in rm1.items()}
ord_r_2 = mult_order(2, r, rm1)
ord_r_q = mult_order(pow(2, 131, r), r, rm1)
res["ord_r_2"] = str(ord_r_2)
res["ord_r_q"] = str(ord_r_q)
res["ord_r_q_bitlength"] = ord_r_q.bit_length()
res["ord_r_q_log2"] = math.log2(ord_r_q)
res["(r-1)/ord_r_q"] = str((r - 1) // ord_r_q) if (r - 1) % ord_r_q == 0 else "not integer"
res["ord_r_q_eq_claim"] = (ord_r_q == 25036025965458166165099049182583)
res["ord_r_q_eq_(r-1)/786"] = ((r - 1) % 786 == 0 and ord_r_q == (r - 1) // 786)
res["ord_r_2_eq_131_ord_r_q"] = (ord_r_2 == 131 * ord_r_q)
# direct brute-force-free check: q^k mod r for k = claimed order and its maximal divisors
k = ord_r_q
res["q^ord mod r == 1"] = pow(q, k, r) == 1
res["q^(ord/p) mod r != 1 for all p|ord"] = all(pow(q, k // p, r) != 1 for p in factor(k))

# 263-part
res["ord_263_2"] = mult_order(2, 263, {2: 1, 131: 1})
res["ord_263_q"] = mult_order(q % 263, 263, {2: 1, 131: 1})
res["q_mod_263"] = q % 263
res["ord_263sq_q"] = mult_order(q % 263 ** 2, 263 ** 2, {2: 1, 131: 1, 263: 1})
res["q_mod_263sq"] = q % (263 ** 2)
res["v_263(q-1)"] = v(263, q - 1)
res["v_263(twist)"] = v(263, twist)
res["v_263(4N)"] = v(263, order_E)

N = order_E // 4
res["N"] = str(N)
res["N_prime_mr"] = mr(N)
res["gcd(N,twist)"] = str(math.gcd(N, twist))
res["gcd(orderE,twist)"] = str(math.gcd(order_E, twist))
res["N_eq_r"] = N == r
res["ord_N_q_is_large"] = None  # filled below
Nm1 = factor(N - 1)
ordNq = mult_order(q % N, N, Nm1)
res["ord_N_q_log2"] = math.log2(ordNq)

# ---------- 3. F_2^131 arithmetic; check twist group order on points ----------
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
M = 131

def fmul(a, b):
    r_ = 0
    while b:
        if b & 1:
            r_ ^= a
        b >>= 1
        a <<= 1
        if a >> M:
            a ^= MOD
    return r_

def fsq(a):
    return fmul(a, a)

def finv(a):
    # a^(2^131 - 2)
    return fpow(a, (1 << M) - 2)

def fpow(a, e):
    r_ = 1
    while e:
        if e & 1:
            r_ = fmul(r_, a)
        a = fsq(a)
        e >>= 1
    return r_

def ftrace(a):
    s, x = 0, a
    for _ in range(M):
        s ^= x
        x = fsq(x)
    return s

def fhalftrace(c):
    s, x = 0, c
    for _ in range((M - 1) // 2 + 1):
        s ^= x
        x = fsq(fsq(x))
    return s

# curve y^2 + x y = x^3 + a2 x^2 + b
def lift_x(x, a2, b):
    if x == 0:
        return None
    rhs = fmul(fmul(x, x), x) ^ fmul(a2, fmul(x, x)) ^ b
    c = fmul(rhs, finv(fsq(x)))  # z^2 + z = c, y = x z
    if ftrace(c) != 1 and ftrace(c) != 0:
        raise RuntimeError
    if ftrace(c) == 1:
        return None
    z = fhalftrace(c)
    assert fsq(z) ^ z == c
    y = fmul(x, z)
    return (x, y)

def on_curve(P, a2, b):
    x, y = P
    return fsq(y) ^ fmul(x, y) == fmul(fsq(x), x) ^ fmul(a2, fsq(x)) ^ b

def add(P, Q, a2):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y1 == y2:
            return dbl(P, a2)
        return None  # Q = -P  (-P = (x, x+y))
    lam = fmul(y1 ^ y2, finv(x1 ^ x2))
    x3 = fsq(lam) ^ lam ^ x1 ^ x2 ^ a2
    y3 = fmul(lam, x1 ^ x3) ^ x3 ^ y1
    return (x3, y3)

def dbl(P, a2):
    if P is None:
        return None
    x, y = P
    if x == 0:
        return None
    lam = x ^ fmul(y, finv(x))
    x3 = fsq(lam) ^ lam ^ a2
    y3 = fsq(x) ^ fmul(lam ^ 1, x3)
    return (x3, y3)

def smul(k, P, a2):
    R = None
    for bit in bin(k)[2:]:
        R = dbl(R, a2)
        if bit == '1':
            R = add(R, P, a2)
    return R

def rand_point(a2, b):
    while True:
        x = random.getrandbits(M)
        P = lift_x(x, a2, b)
        if P is not None:
            assert on_curve(P, a2, b)
            return P

T0 = time.time()
pt = {}
# E0 (a2=0,b=1) and twist E0' (a2=1,b=1)
for name, a2, b in [("E0", 0, 1), ("E0_twist", 1, 1)]:
    rec = []
    for i in range(3):
        P = rand_point(a2, b)
        d = {}
        d["[4N]P==O"] = smul(order_E, P, a2) is None
        d["[q+1+t]P==O"] = smul(twist, P, a2) is None
        d["[(q+1+t)/r]P!=O"] = smul(twist // r, P, a2) is not None
        # 263-part structure: exponent of 263-Sylow, from [2r * 263]P
        Q = smul(2 * r, P, a2)
        Q263 = smul(263, Q, a2)
        d["[2r*263]P==O"] = Q263 is None
        d["[N]([4]P)==O"] = smul(N, smul(4, P, a2), a2) is None
        rec.append(d)
    pt[name] = rec
res["point_checks"] = pt
res["time_point_checks_s"] = round(time.time() - T0, 2)

# 263-rank of E0'(F_q): all points of 263-power order killed by 263 => (Z/263)^k with k<=2.
res["proof_log"] = proof_log
json.dump(res, open(sys.argv[1] if len(sys.argv) > 1 else "c4_recompute.json", "w"), indent=1, default=str)
for k_, v_ in res.items():
    if k_ != "proof_log":
        print(k_, "=", v_)
print("proof_log entries:", len(proof_log))
