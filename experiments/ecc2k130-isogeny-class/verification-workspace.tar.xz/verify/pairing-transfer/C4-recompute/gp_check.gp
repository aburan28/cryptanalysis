q=2^131; t=-22283658519494248867;
\\ recompute t via polynomial resultant-free route: t = trace of tau^131 where tau root of x^2+x+2
tt = trace(Mod(x,x^2+x+2)^131); print("t_from_minpoly_power=",tt, " eq=", tt==t);
T=q+1+t; print("twist=",T); print("factor(twist)=",factor(T));
r=19678316408850118605767852657510239; print("T==2*263^2*r:", T==2*263^2*r, " isprime(r):", isprime(r), " log2 r:", log(r)/log(2));
o2=znorder(Mod(2,r)); oq=znorder(Mod(2,r)^131); print("ord_r(2)=",o2," ord_r(q)=",oq, " (r-1)/oq=",(r-1)/oq, " o2/oq=",o2/oq, " bits(oq)=",#binary(oq));
print("ord_263(q)=",znorder(Mod(2,263)^131)," ord_263^2(q)=",znorder(Mod(2,263^2)^131));
N=(q+1-t)/4; print("isprime(N)=",isprime(N)," v263(4N)=",valuation(4*N,263)," gcd(N,T)=",gcd(N,T));
print("embedding degree of N: log2 ord_N(q)=", log(znorder(Mod(q,N)))/log(2));
print("primecert(r) valid:", primecertisvalid(primecert(r)));
