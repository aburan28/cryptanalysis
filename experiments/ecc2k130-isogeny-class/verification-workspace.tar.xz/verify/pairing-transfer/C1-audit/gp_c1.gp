\\ gp check of C1 (run: gp -q gp_c1.gp)
q = 2^131;
t1 = -1; a = 2; b = t1; for(i=1,130, c = t1*b - 2*a; a = b; b = c); t = b;
N = (q+1-t)/4;
print("t = ", t);
print("N = ", N, "  isprime(N) proven: ", isprime(N, 1) != 0);
F = factor(N-1); print("factor(N-1) = ", F);
print("all factors proven prime: ", vecmin(apply(r->isprime(r,1)!=0, F[,1]~)));
k = znorder(Mod(2,N)^131); print("k = znorder(Mod(2,N)^131) = ", k);
print("k == stated: ", k == 216464610000596986937760855436835237);
print("(N-1)/k = ", (N-1)/k, "  factor: ", factor((N-1)/k));
d = znorder(Mod(2,N)); print("ord_N(2) = ", d, "  == 131*k: ", d == 131*k, "  (N-1)/ord_N(2) = ", (N-1)/d);
print("Mod(2,N)^(131k)==1: ", Mod(2,N)^(131*k) == 1);
Fk = factor(131*k)[,1]; for(i=1,#Fk, r=Fk[i]; print("  r=",r,": Mod(2,N)^(131k/r) != 1: ", Mod(2,N)^(131*k/r) != 1));
print("bitlength k = ", #binary(k), "  log2 k = ", log(k)/log(2), "  log2(131k) = ", log(131*k)/log(2));
c = primecert(N); print("primecert(N) valid: ", primecertisvalid(c));
quit
