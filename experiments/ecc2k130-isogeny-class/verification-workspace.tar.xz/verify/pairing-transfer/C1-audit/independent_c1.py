# Independent audit of claim C1 (embedding degree of the order-N subgroup of ECC2K-130's isogeny class).
# Pure Python 3 standard library only: no Sage, no PARI, no sympy, no import of the ground-truth module.
#   export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp
#   python3 independent_c1.py  -> independent_c1.json next to this file
import json, math, random, time
from pathlib import Path

T0 = time.time()
HERE = Path(__file__).resolve().parent
out = {}

# ---------------------------------------------------------------- 1. N from scratch
# E0: y^2 + x*y = x^3 + 1 over F_2: count points by brute force.
cnt = 1  # point at infinity
for x in (0, 1):
    for y in (0, 1):
        if (y * y + x * y + x ** 3 + 1) % 2 == 0:
            cnt += 1
t1 = 2 + 1 - cnt
# Lucas: t_n = t1*t_{n-1} - 2*t_{n-2}, t_0 = 2
a, b = 2, t1
for _ in range(130):
    a, b = b, t1 * b - 2 * a
t = b
q = 2 ** 131
card = q + 1 - t
assert card % 4 == 0
N = card // 4
out["E0_F2_points"] = cnt
out["t"] = str(t)
out["N"] = str(N)
assert N == 680564733841876926932320129493409985129, "N differs from the stated value"
assert t == -22283658519494248867


# ---------------------------------------------------------------- 2. own factoring
def mr(n, bases=(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41)):
    if n < 2:
        return False
    for p in bases:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for a_ in bases:
        x = pow(a_, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def brent(n, seed):
    rng = random.Random(seed)
    if n % 2 == 0:
        return 2
    while True:
        y, c, m = rng.randrange(1, n), rng.randrange(1, n), 128
        g, r, qq = 1, 1, 1
        while g == 1:
            x = y
            for _ in range(r):
                y = (y * y + c) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(m, r - k)):
                    y = (y * y + c) % n
                    qq = qq * abs(x - y) % n
                g = math.gcd(qq, n)
                k += m
            r *= 2
        if g == n:
            g = 1
            while g == 1:
                ys = (ys * ys + c) % n
                g = math.gcd(abs(x - ys), n)
        if g != n:
            return g


def factor(n, seed=1):
    fac = {}
    for p in range(2, 20000):
        while n % p == 0:
            fac[p] = fac.get(p, 0) + 1
            n //= p
    stack = [n] if n > 1 else []
    while stack:
        m = stack.pop()
        if mr(m):
            fac[m] = fac.get(m, 0) + 1
            continue
        d = brent(m, seed)
        seed += 1
        stack += [d, m // d]
    return dict(sorted(fac.items()))


# ---------------------------------------------------------------- 3. own primality proofs (Lucas / Pratt, recursive)
proof_log = {}


def prove_prime(n, depth=0):
    """Return True only if n is PROVEN prime: trial division for n < 2^40, otherwise the Lucas test
    (a^(n-1)=1, a^((n-1)/r) != 1 for every prime r | n-1) with every r proven recursively."""
    if n < 2:
        return False
    if n < 2 ** 40:
        if n < 4:
            return True
        if n % 2 == 0:
            return False
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        proof_log[str(n)] = "trial division to sqrt"
        return True
    f = factor(n - 1)
    for r in f:
        if not prove_prime(r, depth + 1):
            return False
    for a_ in range(2, 1000):
        if pow(a_, n - 1, n) != 1:
            return False  # composite (Fermat witness)
        if all(pow(a_, (n - 1) // r, n) != 1 for r in f):
            proof_log[str(n)] = {"lucas_witness": a_, "n_minus_1": {str(r): e for r, e in f.items()}}
            return True
    raise RuntimeError("no Lucas witness found for %d" % n)


# ---------------------------------------------------------------- 4. factor N-1 and prove everything
fN = factor(N - 1)
prod = 1
for r, e in fN.items():
    prod *= r ** e
assert prod == N - 1
out["N_minus_1_factorization"] = [[str(r), e] for r, e in fN.items()]
stated = {2: 3, 3: 1, 11: 1, 109: 1, 131: 1, 263: 1, 32326729: 1, 21234899465981031419669: 1}
out["factorization_equals_stated"] = (fN == stated)
out["stated_product_equals_N_minus_1"] = (math.prod(r ** e for r, e in stated.items()) == N - 1)
for r in fN:
    assert prove_prime(r), r
out["all_N_minus_1_factors_proven_prime"] = True
assert prove_prime(N)
out["N_proven_prime_by_Lucas"] = True
out["primality_certificates"] = proof_log


# ---------------------------------------------------------------- 5. orders
def order(g, n, fac):
    k = n - 1
    for r, e in fac.items():
        for _ in range(e):
            if k % r == 0 and pow(g, k // r, n) == 1:
                k //= r
            else:
                break
    return k


def check_exact_order(g, n, k):
    """k is the exact order of g mod n: g^k=1 and g^(k/r) != 1 for every prime r|k (factor k independently)."""
    if pow(g, k, n) != 1:
        return False
    fk = factor(k, seed=777)
    return all(pow(g, k // r, n) != 1 for r in fk), fk


qN = pow(2, 131, N)
k = order(qN, N, fN)
ok_k, fk = check_exact_order(qN, N, k)
d2 = order(2, N, fN)
ok_d2, fd2 = check_exact_order(2, N, d2)
assert ok_k and ok_d2
K_STATED = 216464610000596986937760855436835237
out["k_ord_N(2^131)"] = str(k)
out["k_equals_stated"] = (k == K_STATED)
out["k_factorization"] = {str(r): e for r, e in fk.items()}
out["k_bit_length"] = k.bit_length()
out["log2_k"] = math.log2(k)
out["(N-1)/k"] = str((N - 1) // k)
out["(N-1) % k"] = str((N - 1) % k)
out["3144_factorization"] = {str(r): e for r, e in factor(3144).items()}
out["ord_N(2)"] = str(d2)
out["ord_N(2)_factorization"] = {str(r): e for r, e in fd2.items()}
out["ord_N(2)_equals_131k"] = (d2 == 131 * k)
out["(N-1)/ord_N(2)"] = str((N - 1) // d2)
out["log2(131k) = log2 of bit-length of an F_(q^k) element"] = math.log2(131 * k)

# explicit checks suggested in the task, done here in plain python
out["2^(131k) == 1 mod N"] = pow(2, 131 * k, N) == 1
out["2^(131k/r) != 1 mod N for each prime r | 131k"] = {
    str(r): pow(2, 131 * k // r, N) != 1 for r in factor(131 * k, seed=99)}
out["q^(k/r) != 1 mod N for each prime r | k"] = {str(r): pow(q, k // r, N) != 1 for r in fk}

# ---------------------------------------------------------------- 6. minimal field containing mu_N in char 2
# mu_N subset F_(2^m) <=> N | 2^m - 1 <=> ord_N(2) | m.  Smallest m = ord_N(2).
# F_(q^j) contains mu_N <=> ord_N(2) | 131 j.  If ord_N(2) = 131 k then smallest j = k and m = 131 k.
min_m = d2
out["smallest_m_with_mu_N_in_F_2^m"] = str(min_m)
out["smallest_m_equals_131k"] = (min_m == 131 * k)
# Hitt-style shortcut would need ord_N(2) < 131*k i.e. gcd(ord_N(2),131)=1
out["gcd(ord_N(2),131)"] = math.gcd(d2, 131)

# Balasubramanian-Koblitz precondition: N does not divide q-1 (then E[N] subset E(F_(q^k)) iff N | q^k - 1)
out["N_divides_q-1"] = ((q - 1) % N == 0)
out["N_divides_q+1"] = ((q + 1) % N == 0)
out["N^2_divides_#E(F_q)"] = (card % (N * N) == 0)
# sanity: no small j has q^j = 1 mod N (brute scan, redundant)
x = 1
hit = None
for j in range(1, 200001):
    x = x * qN % N
    if x == 1:
        hit = j
        break
out["brute_scan_q^j=1_mod_N_for_j<=200000"] = hit

# every isogenous curve (all 263 in the class and in fact the whole F_q-isogeny class) has #E = q+1-t = 4N
# (Tate), so the order-N subgroup and k are identical for all of them.  N appears once in #E: v_N(4N) = 1.
out["elapsed_s"] = round(time.time() - T0, 2)
(HERE / "independent_c1.json").write_text(json.dumps(out, indent=1))
print(json.dumps({k_: v for k_, v in out.items() if k_ != "primality_certificates"}, indent=1))
