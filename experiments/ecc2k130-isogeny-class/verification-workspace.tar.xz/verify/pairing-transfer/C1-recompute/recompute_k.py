#!/usr/bin/env python3
"""Independent recomputation of the embedding degree of the ECC2K-130 order-N subgroup.

Pure Python 3, no Sage / PARI / sympy.  Own code for:
  * trace via the Lucas recurrence of tau^2 + tau + 2 = 0 (t1 = -1),
  * factorization of N-1 (trial division + Pollard-Brent rho),
  * primality proofs by recursive Pocklington / Pratt-Lucas certificates
    (each certificate is re-verified by a separate checker),
  * multiplicative orders from the factorization (generic descent),
  * a second, structurally different order computation that only uses
    the claimed k and the claimed factorization (direct power checks).
"""
import json, math, random, sys, time

random.seed(20260923)

# ---------------------------------------------------------------- curve data
q = 1 << 131
# #E0(F_2) = 4 = 2 + 1 - t1  ->  t1 = -1 ;  t_{n+1} = t1*t_n - 2*t_{n-1}, t_0 = 2
t_prev, t_cur = 2, -1
for _ in range(130):
    t_prev, t_cur = t_cur, -t_cur - 2 * t_prev
t = t_cur
card = q + 1 - t
assert card % 4 == 0
N = card // 4

# --------------------------------------------------------------- primality
SMALL_PRIMES = []
def _sieve(B):
    s = bytearray([1]) * (B + 1); s[0] = s[1] = 0
    for i in range(2, int(B ** 0.5) + 1):
        if s[i]:
            s[i * i::i] = bytearray(len(s[i * i::i]))
    return [i for i in range(B + 1) if s[i]]
SMALL_PRIMES = _sieve(200000)
SMALL_SET = set(SMALL_PRIMES)

def is_probable_prime(n, rounds=40):
    if n < 2:
        return False
    for p in SMALL_PRIMES[:60]:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    # deterministic bases for n < 3.3e24, plus random ones above
    bases = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]
    bases += [random.randrange(2, n - 1) for _ in range(rounds)]
    for a in bases:
        a %= n
        if a in (0, 1, n - 1):
            continue
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True

def pollard_brent(n):
    if n % 2 == 0:
        return 2
    while True:
        y, c, m = random.randrange(1, n), random.randrange(1, n), 256
        g = r = qq = 1
        while g == 1:
            x = y
            for _ in range(r):
                y = (y * y + c) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(m, r - k)):
                    y = (y * y + c) % n
                    qq = qq * abs(x - y) % n
                g = math.gcd(qq, n)
                k += m
            r <<= 1
        if g == n:
            g = 1
            while g == 1:
                ys = (ys * ys + c) % n
                g = math.gcd(abs(x - ys), n)
        if g != n:
            return g

def factor(n):
    """Return dict prime->exponent (primes only probable here; proved later)."""
    f = {}
    for p in SMALL_PRIMES:
        if p * p > n:
            break
        while n % p == 0:
            f[p] = f.get(p, 0) + 1
            n //= p
    stack = [n] if n > 1 else []
    while stack:
        m = stack.pop()
        if m == 1:
            continue
        if is_probable_prime(m):
            f[m] = f.get(m, 0) + 1
            continue
        d = pollard_brent(m)
        stack += [d, m // d]
    return dict(sorted(f.items()))

# Pocklington (Brillhart-Lehmer-Selfridge simple form): if n-1 = F*R with
# F > sqrt(n), all prime factors of F known and proved, and for each prime
# r | F there is a with a^(n-1) = 1 and gcd(a^((n-1)/r) - 1, n) = 1, then n is prime.
def prove_prime(n, cache):
    """Build a certificate tree for n.  Returns certificate dict."""
    if n in cache:
        return cache[n]
    if n < 200000 * 200000:
        # trial division is a proof for n < (sieve bound)^2
        assert n >= 2
        for p in SMALL_PRIMES:
            if p * p > n:
                break
            if n % p == 0:
                raise ValueError(f"{n} composite (divisible by {p})")
        cert = {"n": n, "method": "trial_division"}
        cache[n] = cert
        return cert
    if not is_probable_prime(n):
        raise ValueError(f"{n} is not prime")
    fac = factor(n - 1)
    # use the fully factored part; everything is factored fully here
    F = 1
    for r, e in fac.items():
        F *= r ** e
    assert F == n - 1
    witnesses = {}
    for r in fac:
        for a in range(2, 10000):
            if pow(a, n - 1, n) != 1:
                raise ValueError(f"Fermat fails for {n}")
            if math.gcd(pow(a, (n - 1) // r, n) - 1, n) == 1:
                witnesses[r] = a
                break
        else:
            raise ValueError(f"no witness for r={r}")
    subs = {r: prove_prime(r, cache) for r in fac}
    cert = {"n": n, "method": "pocklington_full", "n_minus_1": {str(r): e for r, e in fac.items()},
            "witness": {str(r): a for r, a in witnesses.items()}, "sub": [str(r) for r in fac]}
    cache[n] = cert
    return cert

def check_cert(n, cache, seen=None):
    """Independent re-check of a certificate (does not trust the builder)."""
    if seen is None:
        seen = {}
    if n in seen:
        return seen[n]
    c = cache[n]
    ok = False
    if c["method"] == "trial_division":
        ok = n >= 2 and n < 200000 ** 2 and all(n % p for p in SMALL_PRIMES if p * p <= n)
    else:
        fac = {int(r): e for r, e in c["n_minus_1"].items()}
        prod = 1
        for r, e in fac.items():
            prod *= r ** e
        F = prod
        ok = (F == n - 1) and F * F > n
        for r in fac:
            a = c["witness"][str(r)]
            ok = ok and pow(a, n - 1, n) == 1 and math.gcd(pow(a, (n - 1) // r, n) - 1, n) == 1
            ok = ok and check_cert(r, cache, seen)
    seen[n] = ok
    return ok

# --------------------------------------------------------------- orders
def mult_order(a, n, fac_nm1):
    """Order of a mod prime n, given the factorization of n-1 (descent)."""
    o = n - 1
    for r, e in fac_nm1.items():
        for _ in range(e):
            if pow(a, o // r, n) == 1:
                o //= r
            else:
                break
    return o

def prime_divisors(m, fac_nm1):
    return [r for r in fac_nm1 if m % r == 0]

# --------------------------------------------------------------- run
out = {}
T0 = time.time()
out["t"] = str(t)
out["N"] = str(N)
out["N_log2"] = math.log2(N)
out["t_matches_task"] = (t == -22283658519494248867)
out["N_matches_task"] = (N == 680564733841876926932320129493409985129)

cache = {}
cN = prove_prime(N, cache)
out["N_prime_proved"] = check_cert(N, cache)

fac = factor(N - 1)
out["N_minus_1_factorization"] = {str(r): e for r, e in fac.items()}
prod = 1
for r, e in fac.items():
    prod *= r ** e
out["factorization_product_ok"] = (prod == N - 1)
for r in fac:
    prove_prime(r, cache)
out["all_factors_proved_prime"] = all(check_cert(r, cache) for r in fac)

claimed_fac = {2: 3, 3: 1, 11: 1, 109: 1, 131: 1, 263: 1, 32326729: 1, 21234899465981031419669: 1}
out["factorization_equals_claim"] = (fac == claimed_fac)

# Method 1: descent for ord_N(2) and ord_N(2^131)
o2 = mult_order(2, N, fac)
Q = pow(2, 131, N)
k1 = mult_order(Q, N, fac)
out["ord_N_2"] = str(o2)
out["(N-1)/ord_N(2)"] = str((N - 1) // o2) + ("" if (N - 1) % o2 == 0 else " (NOT integral)")
out["k_descent"] = str(k1)
out["(N-1)/k"] = str((N - 1) // k1) + ("" if (N - 1) % k1 == 0 else " (NOT integral)")
out["k_from_ord2_formula"] = str(o2 // math.gcd(o2, 131))

# Method 2: direct verification of the claimed k with power checks (no descent)
k_claim = 216464610000596986937760855436835237
assert k_claim * 3144 == N - 1
fac_k = {}
m = k_claim
for r, e in fac.items():
    while m % r == 0:
        fac_k[r] = fac_k.get(r, 0) + 1; m //= r
assert m == 1
out["k_claim_factorization"] = {str(r): e for r, e in fac_k.items()}
c_one = pow(Q, k_claim, N) == 1
c_nontriv = {str(r): pow(Q, k_claim // r, N) != 1 for r in fac_k}
out["Q^k == 1"] = c_one
out["Q^(k/r) != 1 for all r|k"] = c_nontriv
out["k_claim_is_order"] = c_one and all(c_nontriv.values())

# ord_N(2) = 131*k claim, direct
ok131 = 131 * k_claim
fac_ok = dict(fac_k); fac_ok[131] = fac_ok.get(131, 0) + 1
c2 = pow(2, ok131, N) == 1 and all(pow(2, ok131 // r, N) != 1 for r in fac_ok)
out["ord_N(2)==131k_direct"] = c2

# Method 3: brute check of all divisors of N-1 smaller than k: none has Q^d == 1.
divs = [1]
for r, e in fac.items():
    divs = [d * r ** i for d in divs for i in range(e + 1)]
divs.sort()
out["num_divisors_N_minus_1"] = len(divs)
smaller_hits = [d for d in divs if d < k_claim and pow(Q, d, N) == 1]
out["divisors_d<k_with_Q^d=1"] = [str(d) for d in smaller_hits]
smaller_hits2 = [d for d in divs if d < ok131 and pow(2, d, N) == 1]
out["divisors_d<131k_with_2^d=1"] = [str(d) for d in smaller_hits2]
# also no m < 131k with 2^m = 1 mod N that is not a divisor of N-1: order divides any such m,
# and order of 2 divides N-1 (Fermat), so the divisor check is exhaustive.

out["k_bits"] = k_claim.bit_length()
out["k_log2"] = math.log2(k_claim)
out["log2(131*k)_bits_of_F_q^k_elements"] = math.log2(131 * k_claim)
out["N_minus_1_over_ord2"] = (N - 1) // o2
out["3144 == 24*131"] = (3144 == 24 * 131)
# Also check that q^k - 1 divisible-by-N characterisation: smallest k with q^k = 1 mod N
out["q_mod_N_equals_Q"] = (q % N == Q)
# sanity: N does not divide q-1 (so the MOV/Frey-Rueck condition is the standard one)
out["N_divides_q-1"] = ((q - 1) % N == 0)
out["N_eq_char"] = (N == 2)
out["elapsed_s"] = time.time() - T0

certfile = "/Volumes/SSD990/ecdlp-hardness-work/verify/pairing-transfer/C1-recompute/certificates.json"
json.dump({str(n): c for n, c in cache.items()}, open(certfile, "w"), indent=1)
json.dump(out, open("/Volumes/SSD990/ecdlp-hardness-work/verify/pairing-transfer/C1-recompute/result.json", "w"), indent=1)
print(json.dumps(out, indent=1))
