"""
C1 audit (independent of Sage/PARI and of transport.py): pure-python3 GF(2^131) arithmetic.

Inputs (read directly as JSON, no loader):
  ground_truth/ground_truth.json          -> b_int per label (a2 = 0 curves [1,0,0,0,b])
  transport-263/kernels_all.json          -> 131 hex x-coordinates per floor label (bit i = z^i)
  transport-263/raw/shard_*.json          -> recorded v_int (only compared, never used as input)

Checks per floor curve E = [1,0,0,0,b]:
  K1  131 distinct nonzero x in F_q
  K2  every x lifts to the twist E' = [1,1,0,0,b] over F_q (Tr(x+1+b/x^2)=0) and NOT to E (Tr(x+b/x^2)=1)
  K3  lift P from xs[0] on E'; {x(kP) : k=1..131} == set(xs) and [263]P = O  (so xs = x(<P>\\O)/+-, #<P> = 263)
  K4  E'(F_q) 263-Sylow is cyclic of order 263^2 (point of order 263^2 found), so <P> is the unique
      F_q-rational 263-subgroup of E' (and hence the unique Galois-stable one of E)
  J1  v = XOR(xs); b + v + v^2 == 1 ; also Delta/j of [1,0,0,v,b+v] via generic b2,b4,b6,b8 formulas
  J2  textbook Velu (Washington Thm 12.16, with y_Q) on the twist E' with the rational kernel <P>:
      codomain a-invariants computed from t_Q, u_Q with integer coefficients reduced mod 2; must equal [1,1,0,v,b+v]
  M1  textbook Velu map on E' (uses y_Q) sends random R in E'(F_q) onto [1,1,0,v,b+v]; after (X,Y)->(X,Y+v) onto
      the twist of E0, [1,1,0,0,1]
  M2  x-only char-2 Velu map on E (as in the claim) sends random R in E(F_q) onto [1,0,0,v,b+v]; after
      (X,Y)->(X,Y+v) onto E0: y^2+xy=x^3+1; homomorphism phi(R1+R2)=phi(R1)+phi(R2); phi(2R)=2phi(R);
      R4=[4]R has [N]R4=O on E and phi(R4) != O, [N]phi(R4) = O on E0
  C0  recorded v_int (shards) == my v
Writes results_pure.json.
"""
import json, glob, os, random, sys, time, hashlib

W = "/Volumes/SSD990/ecdlp-hardness-work"
OUT = os.path.join(W, "verify/transport-263/C1-audit/results_pure.json")
M = 131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << 131) - 1
N = 680564733841876926932320129493409985129
q = 1 << 131
t = -22283658519494248867
CARD = q + 1 - t
TW = q + 1 + t
assert CARD == 4 * N
L = 263


# ---------------------------------------------------------------- field
def red(r):
    while r >> 131:
        hi = r >> 131
        r = (r & MASK) ^ hi ^ (hi << 1) ^ (hi << 2) ^ (hi << 13)
    return r


def mul(a, b):
    if a.bit_length() < b.bit_length():
        a, b = b, a
    r = 0
    while b:
        if b & 1:
            r ^= a
        a <<= 1
        b >>= 1
    return red(r)


def sq(a):
    return mul(a, a)


def inv(a):
    assert a != 0
    u, v, g1, g2 = a, MOD, 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v, g1, g2 = v, u, g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return red(g1)


def div(a, b):
    return mul(a, inv(b))


# trace: linear, Tr(z^i) precomputed by 130 squarings
def _tr_slow(c):
    s, u = c, c
    for _ in range(130):
        u = sq(u)
        s ^= u
    assert s in (0, 1)
    return s


TRMASK = 0
for i in range(131):
    if _tr_slow(1 << i):
        TRMASK |= 1 << i


def tr(c):
    return bin(c & TRMASK).count("1") & 1


def half_trace(c):
    s, u = c, c
    for _ in range(65):
        u = sq(sq(u))
        s ^= u
    return s


# ---------------------------------------------------------------- curve y^2 + xy = x^3 + a2 x^2 + a4 x + a6 (a1=1,a3=0)
class Curve:
    def __init__(self, a2, a4, a6):
        self.a2, self.a4, self.a6 = a2, a4, a6

    def on(self, P):
        if P is None:
            return True
        x, y = P
        return sq(y) ^ mul(x, y) == mul(sq(x), x) ^ mul(self.a2, sq(x)) ^ mul(self.a4, x) ^ self.a6

    def neg(self, P):
        return None if P is None else (P[0], P[0] ^ P[1])

    def add(self, P, Q):
        if P is None:
            return Q
        if Q is None:
            return P
        x1, y1 = P
        x2, y2 = Q
        if x1 == x2:
            if y2 == x1 ^ y1:
                return None
            return self.dbl(P)
        lam = div(y1 ^ y2, x1 ^ x2)
        x3 = sq(lam) ^ lam ^ x1 ^ x2 ^ self.a2
        y3 = mul(lam, x1 ^ x3) ^ x3 ^ y1
        return (x3, y3)

    def dbl(self, P):
        if P is None:
            return None
        x1, y1 = P
        if x1 == 0:
            return None
        # general a4: lambda = (3x^2 + 2a2 x + a4 - y)/(2y + x) = (x^2 + a4 + y)/x
        lam = div(sq(x1) ^ self.a4 ^ y1, x1)
        x3 = sq(lam) ^ lam ^ self.a2
        y3 = mul(lam, x1 ^ x3) ^ x3 ^ y1
        return (x3, y3)

    def mul(self, k, P):
        if k < 0:
            return self.mul(-k, self.neg(P))
        R = None
        for bit in bin(k)[2:]:
            R = self.dbl(R)
            if bit == "1":
                R = self.add(R, P)
        return R

    def lift(self, x, pick=0):
        """point with abscissa x (x != 0), or None if not F_q-rational. (a4 must be 0 here)"""
        assert self.a4 == 0
        c = x ^ self.a2 ^ mul(self.a6, sq(inv(x)))
        if tr(c):
            return None
        w = half_trace(c)
        assert sq(w) ^ w == c
        if pick:
            w ^= 1
        return (x, mul(x, w))

    def random_point(self, rng):
        while True:
            x = rng.getrandbits(131)
            if x == 0:
                continue
            if self.a4 == 0:
                P = self.lift(x, rng.getrandbits(1))
            else:
                raise NotImplementedError
            if P is not None:
                assert self.on(P)
                return P


# ---------------------------------------------------------------- Velu maps
def velu_x_only(xs, v, x, y):
    """claim's char-2 formula on E (a1=1,a3=0,a4=0): returns (X, Y) on [1,a2,0,v,b+v]"""
    X, Y = x, y
    for xq in xs:
        e = inv(x ^ xq)
        a = mul(xq, e)
        X ^= a ^ sq(a)
        e2 = sq(e)
        Y ^= mul(mul(sq(xq), x), mul(e2, e)) ^ mul(mul(xq, x ^ y ^ sq(xq)), e2)
    return X, Y


def velu_textbook(a, S, x, y):
    """Washington, Elliptic Curves (2nd ed.) Thm 12.16 (Velu), odd kernel, S = one of each +-Q, with y_Q.
    a = (a1,a2,a3,a4,a6) as field elements. Integer coefficients reduced mod 2 by hand:
      g^x_Q = 3x_Q^2 + 2a2 x_Q + a4 - a1 y_Q  ->  x_Q^2 + a4 + a1 y_Q
      g^y_Q = -2y_Q - a1 x_Q - a3            ->  a1 x_Q + a3
      t_Q   = 2 g^x_Q - a1 g^y_Q             ->  a1 g^y_Q
      u_Q   = (g^y_Q)^2
      X = x + sum [ t_Q/(x-x_Q) + u_Q/(x-x_Q)^2 ]
      Y = y - sum [ u_Q (2y + a1 x + a3)/(x-x_Q)^3 + t_Q (a1(x-x_Q) + y - y_Q)/(x-x_Q)^2 + (a1 u_Q - g^x_Q g^y_Q)/(x-x_Q)^2 ]
    returns (X, Y) and codomain (A1..A6):  A4 = a4 - 5 t, A6 = a6 - (a1^2+4a2) t - 7 w,  w = sum (u_Q + x_Q t_Q)
      -> A4 = a4 + t,  A6 = a6 + a1^2 t + w (char 2)"""
    a1, a2, a3, a4, a6 = a
    tsum, wsum = 0, 0
    X, Y = x, y
    for (xq, yq) in S:
        gx = sq(xq) ^ a4 ^ mul(a1, yq)
        gy = mul(a1, xq) ^ a3
        tq = mul(a1, gy)
        uq = sq(gy)
        tsum ^= tq
        wsum ^= uq ^ mul(xq, tq)
        if x is not None:
            d = x ^ xq
            e = inv(d)
            e2 = sq(e)
            X ^= mul(tq, e) ^ mul(uq, e2)
            term = mul(uq, mul(mul(a1, x) ^ a3, mul(e2, e)))            # 2y term vanishes
            term ^= mul(tq, mul(mul(a1, d) ^ y ^ yq, e2))
            term ^= mul(mul(a1, uq) ^ mul(gx, gy), e2)
            Y ^= term
    A = (a1, a2, a3, a4 ^ tsum, a6 ^ mul(sq(a1), tsum) ^ wsum)
    return (None if x is None else (X, Y)), A


def j_inv(a):
    """j via generic b2,b4,b6,b8,c4,Delta with integer coeffs reduced mod 2"""
    a1, a2, a3, a4, a6 = a
    b2 = sq(a1)                                   # a1^2 + 4a2
    b4 = mul(a1, a3)                              # 2a4 + a1a3
    b6 = sq(a3)                                   # a3^2 + 4a6
    b8 = mul(sq(a1), a6) ^ mul(mul(a1, a3), a4) ^ mul(a2, sq(a3)) ^ sq(a4)   # a1^2a6+4a2a6-a1a3a4+a2a3^2-a4^2
    c4 = sq(b2)                                   # b2^2 - 24 b4
    D = mul(sq(b2), b8) ^ mul(b6, b6) ^ mul(mul(b2, b4), b6)   # -b2^2b8 - 8b4^3 - 27b6^2 + 9b2b4b6
    # 8 b4^3 vanishes; 27 b6^2 -> b6^2; 9 b2 b4 b6 -> b2 b4 b6
    return (div(mul(sq(c4), c4), D) if D else None), D


