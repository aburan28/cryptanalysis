default(parisize, 2^28);
g = ffgen(Mod(1,2)*(z^131+z^13+z^2+z+1), 'a);
toff(n) = if(n==0, 0*g, subst(Pol(binary(n),'X), 'X, g));
E0 = ellinit([1,0,0,0,1], g);
\r data_neg.gp
ev(F, P) = my(f=F[1], gg=F[2], hh=F[3], xv=P[1], yv=P[2], hv = subst(hh,'x,xv)); [subst(f,'x,xv)/hv^2, substvec(gg,['x,'y],[xv,yv])/hv^3];
{
for(i=1,#D,
  my(lab=D[i][1], b=toff(D[i][2]), xs=apply(toff, D[i][3]), E, h, v, res, C, P1, P2, ok);
  E = ellinit([1,0,0,0,b], g); h = prod(k=1,#xs,'x - xs[k]); v = vecsum(xs);
  res = iferr(ellisogeny(E, h), err, [err]);
  if(#res == 1, print(lab, " ellisogeny error: ", res[1]); next);
  C = ellinit(res[1], g);
  P1 = random(E); 
  ok = iferr(ellisoncurve(C, ev(res[2], P1)), err, "err");
  print(lab, " codomain==[1,0,0,v,b+v]: ", res[1]==[1,0,0,v,b+v], "  j==1: ", C.j==1, "  image on codomain: ", ok);
);
}
