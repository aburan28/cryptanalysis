"""Re-run Sage's E.isogeny(kernel_poly) (check=True -> is_kernel_polynomial validation) on a sample of labels,
building the field and curves myself (no ecc2k loader, no transport.py)."""
import json, sys, time
from sage.all import GF, PolynomialRing, EllipticCurve, prod
W = "/Volumes/SSD990/ecdlp-hardness-work"
R2 = PolynomialRing(GF(2), "Z"); Z = R2.gen()
K = GF(2**131, "z", modulus=Z**131 + Z**13 + Z**2 + Z + 1)
gt = json.load(open(W + "/ground_truth/ground_truth.json"))
B = {c["label"]: int(c["b_int"]) for c in gt["curves"]}
kers = json.load(open(W + "/transport-263/kernels_all.json"))
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
RX = PolynomialRing(K, "X")
out = {}
for lab in sys.argv[1].split(","):
    b = K.from_integer(B[lab])
    xs = [K.from_integer(int(h, 16)) for h in kers[lab]]
    v = sum(xs)
    E = EllipticCurve(K, [1, 0, 0, 0, b])
    h = prod(RX.gen() - u for u in xs)
    c = time.time()
    phi = E.isogeny(h)          # check=True by default
    C = phi.codomain()
    isos = [tuple(i.tuple()) for i in C.isomorphisms(E0)]
    P = 4 * E.random_point()
    Q = phi(P)
    Qe = E0(Q[0], Q[1] + v)
    r = {"deg": int(phi.degree()), "codomain_eq": list(C.a_invariants()) == [1, 0, 0, v, b + v],
         "j1": C.j_invariant() == 1, "isos_contain_1_0_0_v": (1, 0, 0, v) in isos, "n_isos": len(isos),
         "img_order_N": (not Qe.is_zero()) and (680564733841876926932320129493409985129 * Qe).is_zero(),
         "sec": round(time.time() - c, 1)}
    out[lab] = {k: (bool(x) if not isinstance(x, (int, float)) else x) for k, x in r.items()}
    print(lab, out[lab], flush=True)
json.dump(out, open(W + "/verify/transport-263/C1-audit/results_sage_sample.json", "w"), indent=1)
