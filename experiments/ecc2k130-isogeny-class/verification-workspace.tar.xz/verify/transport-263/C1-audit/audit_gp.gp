\\ C1 audit with standalone PARI/GP (homebrew gp 2.17.3; Sage's cypari is 2.17.1 and is not used)
\\ For each floor curve: PARI ellisogeny(E, prod(X - x_Q)) with the stored kernel x's;
\\  - codomain a-invariants == [1,0,0,v,b+v], v = sum x_Q ; ellj(codomain) == 1
\\  - ellchangecurve(codomain, [1,0,0,v]) == E0 = [1,0,0,0,1]
\\  - PARI's rational map at R (point chosen by my pure-python code) lands on the codomain, and after
\\    ellchangepoint(.,[1,0,0,v]) equals my pure-python x-only Velu image of R (bitmask ints compared)
\\  - N * image = 0 on E0, image != 0; homomorphism at a gp-random pair of points
\\  - ellcard(E) == 4N (PARI point counting, independent of the ground-truth build)
default(parisize, 2^28);
g = ffgen(Mod(1,2)*(z^131+z^13+z^2+z+1), 'a);
toff(n) = if(n==0, 0*g, subst(Pol(binary(n),'X), 'X, g));
fftoi(e) = my(P = lift(e.pol)); if(type(P)=="t_INT", P, subst(P, variable(P), 2));
N = 680564733841876926932320129493409985129;
E0 = ellinit([1,0,0,0,1], g);
if(ellcard(E0) != 4*N, error("E0 card"));
\r data.gp
ev(F, P) = my(f=F[1], gg=F[2], hh=F[3], xv=P[1], yv=P[2], hv = subst(hh,'x,xv)); [subst(f,'x,xv)/hv^2, substvec(gg,['x,'y],[xv,yv])/hv^3];
nok = vector(9);
T0 = getabstime();
{
for(i = 1, #D,
  my(lab=D[i][1], b=toff(D[i][2]), xs=apply(toff, D[i][3]), R=apply(toff, D[i][4]), img=D[i][5], vpy=D[i][6]);
  my(E = ellinit([1,0,0,0,b], g), h = prod(k=1,#xs, 'x - xs[k]), v = vecsum(xs));
  my(res = ellisogeny(E, h), A = res[1], C, C2, im, im0, c1, c2, c3, c4, c5, c6, c7, c8, c9);
  C = ellinit(A, g);
  c1 = (A == [1,0,0,v,b+v]);
  c2 = (C.j == 1);
  C2 = ellchangecurve(C, [1,0,0,v]);
  c3 = (vector(5,k,C2[k]) == [1,0,0,0,1]);
  c4 = (fftoi(v) == vpy);
  if(!ellisoncurve(E, R), error("R not on E " lab));
  im = ev(res[2], R);
  c5 = ellisoncurve(C, im);
  im0 = ellchangepoint(im, [1,0,0,v]);
  c6 = ellisoncurve(E0, im0) && ([fftoi(im0[1]), fftoi(im0[2])] == img);
  c7 = (ellmul(E0, im0, N) == [0]) && (im0 != [0]);
  my(P1 = random(E), P2 = random(E), a1, a2, a12);
  a1 = ellchangepoint(ev(res[2], P1), [1,0,0,v]); a2 = ellchangepoint(ev(res[2], P2), [1,0,0,v]);
  a12 = ellchangepoint(ev(res[2], elladd(E, P1, P2)), [1,0,0,v]);
  c8 = (elladd(E0, a1, a2) == a12);
  c9 = (ellcard(E) == 4*N);
  my(cs = [c1,c2,c3,c4,c5,c6,c7,c8,c9]);
  for(k=1,9, if(cs[k], nok[k]++));
  print(lab, " ", cs, " ", (getabstime()-T0)\1000, "s");
);
print("TOTAL curves=", #D, " counts [codomain==[1,0,0,v,b+v], j==1, change[1,0,0,v]->E0, v==python v, img on codomain, img==python img, N*img=0, hom, ellcard==4N] = ", nok);
}
