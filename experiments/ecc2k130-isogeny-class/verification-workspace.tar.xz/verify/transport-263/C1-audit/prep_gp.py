"""Write data.gp for the standalone-gp check: per floor label, b, the 131 kernel x's (kernels_all.json),
a random point R on E (own pure-python lift) and its image under my own pure-python x-only Velu + (X,Y+v)."""
import json, os, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gf2131 import *
W = "/Volumes/SSD990/ecdlp-hardness-work"
gt = json.load(open(os.path.join(W, "ground_truth/ground_truth.json")))
kers = json.load(open(os.path.join(W, "transport-263/kernels_all.json")))
rows = []
for c in gt["curves"]:
    lab = c["label"]
    if lab == "E0":
        continue
    b = int(c["b_int"])
    xs = [int(h, 16) for h in kers[lab]]
    v = 0
    for u in xs:
        v ^= u
    E = Curve(0, 0, b)
    rng = random.Random("C1-audit-gp:" + lab)
    R = E.mul(4, E.random_point(rng))
    X, Y = velu_x_only(xs, v, R[0], R[1])
    rows.append('["%s",%d,[%s],[%d,%d],[%d,%d],%d]' % (lab, b, ",".join(str(u) for u in xs), R[0], R[1], X, Y ^ v, v))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data.gp"), "w").write("D=[" + ",\\\n".join(rows) + "];\n")
print(len(rows))
