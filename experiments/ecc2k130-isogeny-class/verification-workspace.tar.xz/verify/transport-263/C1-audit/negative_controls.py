"""Negative controls: the checks used in audit_pure.py / audit_gp.gp must FAIL on corrupted inputs.
 (a) flip one bit of one kernel x of A000 -> b+v+v^2 != 1, K3 subgroup check fails, M2 images off-curve
 (b) A000's kernel with A001's b -> b+v+v^2 != 1
 (c) a random 131-subset structure: x's of a random point's multiples on the twist of the WRONG curve
Also writes data_neg.gp for the gp run on (a),(b)."""
import json, os, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gf2131 import *
W = "/Volumes/SSD990/ecdlp-hardness-work"
gt = json.load(open(os.path.join(W, "ground_truth/ground_truth.json")))
B = {c["label"]: int(c["b_int"]) for c in gt["curves"]}
kers = json.load(open(os.path.join(W, "transport-263/kernels_all.json")))

def checks(b, xs, rng):
    v = 0
    for u in xs:
        v ^= u
    Et = Curve(1, 0, b)
    P = Et.lift(xs[0])
    if P is None:
        k3 = False
    else:
        S, R_ = set(), None
        for k in range(1, 132):
            R_ = Et.add(R_, P); S.add(R_[0] if R_ else None)
        k3 = S == set(xs) and Et.mul(263, P) is None
    E = Curve(0, 0, b)
    C = Curve(0, v, b ^ v)
    R = E.random_point(rng)
    X, Y = velu_x_only(xs, v, R[0], R[1])
    return {"J1": (b ^ v ^ sq(v)) == 1, "K3": k3, "M2_on_codomain": C.on((X, Y)), "M2_on_E0": E0c.on((X, Y ^ v))}

E0c = Curve(0, 0, 1)
rng = random.Random(7)
xs = [int(h, 16) for h in kers["A000"]]
print("control (genuine A000):", checks(B["A000"], xs, rng))
bad = list(xs); bad[5] ^= 1 << 77
print("(a) one bit flipped   :", checks(B["A000"], bad, rng))
print("(b) A000 kernel, A001 b:", checks(B["A001"], xs, rng))
bad2 = list(xs); bad2[0] = xs[0] ^ 1
print("(a') xs[0] perturbed   :", checks(B["A000"], bad2, rng))
rows = []
for lab, b, X in [("NEG_bitflip", B["A000"], bad), ("NEG_wrongb", B["A001"], xs)]:
    rows.append('["%s",%d,[%s]]' % (lab, b, ",".join(str(u) for u in X)))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data_neg.gp"), "w").write("D=[" + ",\\\n".join(rows) + "];\n")
