"""Pure-Python GF(2^131) = F_2[z]/(z^131+z^13+z^2+z+1), elements are int bitmasks (bit i = z^i).
Written from scratch for the C2 recompute (no Sage/NTL/PARI in the arithmetic path)."""
M = 131
POLY = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << M) - 1

# byte -> bit-spread (interleave zeros) table for squaring
_SPREAD = []
for _b in range(256):
    s = 0
    for _i in range(8):
        if (_b >> _i) & 1:
            s |= 1 << (2 * _i)
    _SPREAD.append(s)


def red(r):
    """reduce a polynomial of degree < 2*131 modulo POLY"""
    while r >> M:
        hi = r >> M
        r = (r & MASK) ^ hi ^ (hi << 1) ^ (hi << 2) ^ (hi << 13)
    return r


def mul(a, b):
    # carry-less multiply with a 4-bit window table
    t1 = a; t2 = a << 1; t4 = a << 2; t8 = a << 3
    tab = [0, t1, t2, t2 ^ t1, t4, t4 ^ t1, t4 ^ t2, t4 ^ t2 ^ t1,
           t8, t8 ^ t1, t8 ^ t2, t8 ^ t2 ^ t1, t8 ^ t4, t8 ^ t4 ^ t1, t8 ^ t4 ^ t2, t8 ^ t4 ^ t2 ^ t1]
    r = 0
    sh = (b.bit_length() + 3) & ~3
    while sh > 0:
        sh -= 4
        r = (r << 4) ^ tab[(b >> sh) & 15]
    return red(r)


def sqr(a):
    r = 0
    i = 0
    while a:
        r |= _SPREAD[a & 255] << (16 * i)
        a >>= 8
        i += 1
    return red(r)


def inv(a):
    """binary extended Euclid (Hankerson-Menezes-Vanstone Alg. 2.48)"""
    if a == 0:
        raise ZeroDivisionError
    u, v, g1, g2 = a, POLY, 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v, g1, g2 = v, u, g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return g1


def power(a, e):
    r = 1
    for bit in bin(e)[2:]:
        r = sqr(r)
        if bit == '1':
            r = mul(r, a)
    return r


def _trace_def(a):
    s, u = a, a
    for _ in range(M - 1):
        u = sqr(u)
        s ^= u
    return s  # must be 0 or 1


TRMASK = 0
for _i in range(M):
    _t = _trace_def(1 << _i)
    assert _t in (0, 1)
    if _t:
        TRMASK |= 1 << _i


def tr(a):
    return bin(a & TRMASK).count('1') & 1


def half_trace(c):
    """h = sum_{i=0}^{65} c^(4^i); h^2 + h = c + Tr(c) (m odd)"""
    h, u = c, c
    for _ in range((M - 1) // 2):
        u = sqr(sqr(u))
        h ^= u
    return h
