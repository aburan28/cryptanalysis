"""C2 recompute: planted-scalar / homomorphism / order / toy-DLP checks for the 262 ascending
263-isogenies E -> E0, with my own GF(2^131) + EC code (no Sage, no PARI, none of the sweep's scripts).

Inputs read (data only): ground_truth.json (b, a2 per label), transport-263/kernels_all.json (x_Q lists).
Two independent evaluations of the isogeny x-map:
  (A) Velu partial-fraction sums  X = x + sum(a + a^2), a = x_Q/(x+x_Q)
  (B) kernel polynomial h(X) = prod(X + x_Q) expanded to coefficients, T = 1 + x h'(x)/h(x), X = x + T + T^2
Y-map (Velu, char 2, normalized with (X,Y) -> (X, Y + v)):
  Y = y + v + sum[x_Q^2 x/(x+x_Q)^3 + x_Q (x + y + x_Q^2)/(x+x_Q)^2]
"""
import json, sys, time, random, os
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from f2m import mul, sqr, inv, tr, power
from ec2 import on_curve, neg, add, dbl, smul, smul_naf, x_ladder, lift_x, random_point

GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
KER = "/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"
q = 2 ** 131
t0, t1 = 2, -1
for _ in range(130):
    t0, t1 = t1, -t1 - 2 * t0
TR = t1
N = (q + 1 - TR) // 4
L = 263
SEEDTAG = "C2-recompute-2026-09-23"


def batch_inv(ds):
    m = len(ds)
    pref = [0] * m
    acc = 1
    for i in range(m):
        acc = mul(acc, ds[i]) if i else ds[0]
        pref[i] = acc
    iv = inv(acc)
    out = [0] * m
    for i in range(m - 1, 0, -1):
        out[i] = mul(iv, pref[i - 1])
        iv = mul(iv, ds[i])
    out[0] = iv
    return out


class Iso:
    def __init__(self, xs, b):
        self.xs = xs
        self.sq = [sqr(u) for u in xs]
        v = 0
        for u in xs:
            v ^= u
        self.v = v
        self.b = b
        # kernel polynomial coefficients (low -> high), h = prod (X + x_Q)
        h = [1]
        for u in xs:
            nh = [0] * (len(h) + 1)
            for i, c in enumerate(h):
                nh[i + 1] ^= c
                nh[i] ^= mul(c, u)
            h = nh
        self.h = h
        # formal derivative in char 2: coefficient of X^(i-1) is i*c_i = c_i for odd i
        self.hd = [h[i] if i % 2 == 1 else 0 for i in range(1, len(h))]

    @staticmethod
    def horner(poly, x):
        r = 0
        for c in reversed(poly):
            r = mul(r, x) ^ c
        return r

    def X_polyroute(self, x):
        hx = self.horner(self.h, x)
        hdx = self.horner(self.hd, x)
        T = 1 ^ mul(x, mul(hdx, inv(hx)))
        return x ^ T ^ sqr(T)

    def eval(self, P):
        if P is None:
            return None
        x, y = P
        es = batch_inv([x ^ u for u in self.xs])
        X, Y = x, y
        xy = x ^ y
        for u, u2, e in zip(self.xs, self.sq, es):
            a = mul(u, e)            # x_Q/(x+x_Q)
            X ^= a ^ sqr(a)
            e2 = sqr(e)
            e3 = mul(e2, e)
            Y ^= mul(mul(u2, x), e3) ^ mul(mul(u, xy ^ u2), e2)
        return (X, Y ^ self.v)


def exact_order_4N(P, a2):
    return smul(4 * N, P, a2) is None and smul(2 * N, P, a2) is not None and smul(4, P, a2) is not None


def bsgs(Qb, T, bound_bits=24):
    m = 1 << (bound_bits // 2)
    table = {}
    cur = None
    for j in range(m):
        table.setdefault(cur, j)
        cur = add(cur, Qb, 0)
    G = neg(smul(m, Qb, 0))
    cur = T
    for i in range(m):
        if cur in table:
            return i * m + table[cur]
        cur = add(cur, G, 0)
    return None


def run(args):
    label, b, a2, xs, planted_k_sweep = args
    t_start = time.process_time()
    rec = {"label": label}
    rng = random.Random("%s:%s" % (SEEDTAG, label))
    assert a2 == 0
    # ---- kernel checks (own code)
    rec["n_xs"] = len(xs)
    rec["xs_distinct_nonzero"] = len(set(xs)) == 131 and 0 not in xs
    iso = Iso(xs, b)
    rec["codomain_b_is_1"] = (b ^ iso.v ^ sqr(iso.v)) == 1
    rec["kernel_pts_not_rational_on_E"] = all(lift_x(u, 0, b) is None for u in xs)
    Q0 = lift_x(xs[0], 1, b)             # on the twist y^2+xy = x^3+x^2+b
    ok = Q0 is not None
    if ok:
        mult, R = [], Q0
        for i in range(131):
            mult.append(R)
            R = add(R, Q0, 1)            # R = (i+2) Q0
        # R = 132 Q0 ; 263 Q0 = O  <=>  132 Q0 = -131 Q0
        ok = (set(P[0] for P in mult) == set(xs)) and R == neg(mult[-1]) and all(on_curve(P, 1, b) for P in mult)
    rec["kernel_is_263_subgroup_on_twist"] = bool(ok)
    rec["h_degree"] = len(iso.h) - 1
    # ---- points on E
    while True:
        P = random_point(rng, 0, b)
        if exact_order_4N(P, 0):
            break
    rec["found_point_order_4N_on_E"] = True
    R = smul(4, P, 0)
    rec["R_order_N"] = R is not None and smul(N, R, 0) is None
    phR = iso.eval(R)
    rec["phiR_on_E0"] = on_curve(phR, 0, 1)
    rec["phiR_nonzero"] = phR is not None
    rec["N_phiR_zero"] = smul(N, phR, 0) is None and smul_naf(N, phR, 0) is None
    rec["X_routes_agree_R"] = phR[0] == iso.X_polyroute(R[0])
    # ---- planted scalars: my random k, the sweep's stored planted_k (on my own R), and edge scalars
    ks = [rng.randrange(2, N - 1), rng.randrange(2, N - 1), planted_k_sweep, 2, 3, N - 1, N - 2, (1 << 128) + 12345]
    planted = []
    for k in ks:
        S = smul(k, R, 0)
        phS = iso.eval(S)
        kphR = smul(k, phR, 0)
        kphR2 = smul_naf(k, phR, 0)
        xl = x_ladder(k, phR[0], 1)
        planted.append(bool(on_curve(phS, 0, 1) and phS == kphR == kphR2 and xl == phS[0]
                            and iso.X_polyroute(S[0]) == phS[0]))
    rec["planted_ks"] = [str(k) for k in ks]
    rec["planted_results"] = planted
    rec["planted_all_ok"] = all(planted)
    # negative control: a wrong scalar must fail
    S = smul(ks[0], R, 0)
    rec["negative_control_k_plus_1_fails"] = iso.eval(S) != smul(ks[0] + 1, phR, 0)
    # ---- homomorphism on the full group E(F_q) and order 4N preservation
    hom = []
    for _ in range(3):
        U1, U2 = random_point(rng, 0, b), random_point(rng, 0, b)
        hom.append(iso.eval(add(U1, U2, 0)) == add(iso.eval(U1), iso.eval(U2), 0))
        hom.append(iso.eval(dbl(U1, 0)) == dbl(iso.eval(U1), 0))
        hom.append(iso.eval(neg(U2)) == neg(iso.eval(U2)))
    rec["hom_full_group_checks"] = hom
    rec["hom_full_group_ok"] = all(hom)
    phP = iso.eval(P)
    rec["phiP_order_4N_on_E0"] = bool(on_curve(phP, 0, 1) and exact_order_4N(phP, 0))
    # 2-torsion point (0, sqrt b) -> (0, 1)
    T2 = (0, power(b, 2 ** 130))
    rec["two_torsion_ok"] = on_curve(T2, 0, b) and iso.eval(T2) == (0, 1)
    # a second independent order-4N point (different from P) also preserved
    while True:
        P2 = random_point(rng, 0, b)
        if exact_order_4N(P2, 0):
            break
    rec["phiP2_order_4N_on_E0"] = exact_order_4N(iso.eval(P2), 0)
    # ---- toy DLP: k < 2^24 planted on E, recovered on E0 by my BSGS
    ksm = rng.randrange(1, 1 << 24)
    Ss = smul(ksm, R, 0)
    krec = bsgs(phR, iso.eval(Ss))
    rec["toy_k"] = ksm
    rec["toy_k_recovered"] = krec
    rec["toy_dlp_ok"] = krec == ksm
    rec["cpu_seconds"] = round(time.process_time() - t_start, 2)
    rec["all_ok"] = all([rec["xs_distinct_nonzero"], rec["codomain_b_is_1"], rec["kernel_pts_not_rational_on_E"],
                         rec["kernel_is_263_subgroup_on_twist"], rec["h_degree"] == 131, rec["R_order_N"],
                         rec["phiR_on_E0"], rec["phiR_nonzero"], rec["N_phiR_zero"], rec["X_routes_agree_R"],
                         rec["planted_all_ok"], rec["negative_control_k_plus_1_fails"], rec["hom_full_group_ok"],
                         rec["phiP_order_4N_on_E0"], rec["two_torsion_ok"], rec["phiP2_order_4N_on_E0"],
                         rec["toy_dlp_ok"]])
    return rec


def main():
    nproc = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    only = sys.argv[2].split(",") if len(sys.argv) > 2 else None
    gt = json.load(open(GT))
    curves = gt["curves"]
    if isinstance(curves, list):
        curves = {c["label"]: c for c in curves}
    kers = json.load(open(KER))
    pc = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/per_curve.json"))
    labels = [l for l in curves if l != "E0"]
    if only:
        labels = [l for l in labels if l in only]
    jobs = []
    for l in labels:
        c = curves[l]
        jobs.append((l, int(c["b_int"]), int(c["a2"]), [int(h, 16) for h in kers[l]], int(pc[l]["planted_k"])))
    print("labels:", len(jobs), "N =", N, flush=True)
    t = time.time()
    out = {}
    with Pool(nproc) as pool:
        for rec in pool.imap_unordered(run, jobs):
            out[rec["label"]] = rec
            print("%s all_ok=%s planted=%s hom=%s toy=%s/%s cpu=%.1fs [%d/%d, %.0fs]" % (
                rec["label"], rec["all_ok"], rec["planted_results"], rec["hom_full_group_ok"], rec["toy_k_recovered"],
                rec["toy_k"], rec["cpu_seconds"], len(out), len(jobs), time.time() - t), flush=True)
    name = "results.json" if not only else "results_subset.json"
    json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), name), "w"), indent=1, sort_keys=True)
    keys = ["xs_distinct_nonzero", "codomain_b_is_1", "kernel_pts_not_rational_on_E", "kernel_is_263_subgroup_on_twist",
            "R_order_N", "phiR_on_E0", "phiR_nonzero", "N_phiR_zero", "X_routes_agree_R", "planted_all_ok",
            "negative_control_k_plus_1_fails", "hom_full_group_ok", "phiP_order_4N_on_E0", "two_torsion_ok",
            "phiP2_order_4N_on_E0", "toy_dlp_ok", "all_ok"]
    summ = {k: sum(bool(r[k]) for r in out.values()) for k in keys}
    summ["n"] = len(out)
    summ["wall_seconds"] = round(time.time() - t, 1)
    summ["n_distinct_toy_k"] = len(set(r["toy_k"] for r in out.values()))
    print(json.dumps(summ, indent=1))
    json.dump(summ, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), name.replace("results", "summary")), "w"), indent=1)


if __name__ == "__main__":
    main()
