"""Own affine / x-only arithmetic on y^2 + x y = x^3 + a2 x^2 + b over GF(2^131).  O = None."""
from f2m import mul, sqr, inv, tr, half_trace


def on_curve(P, a2, b):
    if P is None:
        return True
    x, y = P
    lhs = sqr(y) ^ mul(x, y)
    x2 = sqr(x)
    rhs = mul(x2, x) ^ (x2 if a2 else 0) ^ b
    return lhs == rhs


def neg(P):
    return None if P is None else (P[0], P[0] ^ P[1])


def dbl(P, a2):
    if P is None:
        return None
    x, y = P
    if x == 0:
        return None
    lam = x ^ mul(y, inv(x))
    x3 = sqr(lam) ^ lam ^ a2
    y3 = sqr(x) ^ mul(lam, x3) ^ x3
    return (x3, y3)


def add(P, Q, a2):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y1 == y2:
            return dbl(P, a2)
        return None
    lam = mul(y1 ^ y2, inv(x1 ^ x2))
    x3 = sqr(lam) ^ lam ^ x1 ^ x2 ^ a2
    y3 = mul(lam, x1 ^ x3) ^ x3 ^ y1
    return (x3, y3)


def smul(k, P, a2):
    """left-to-right double-and-add; k any integer"""
    if k < 0:
        return smul(-k, neg(P), a2)
    R = None
    for bit in bin(k)[2:]:
        R = dbl(R, a2)
        if bit == '1':
            R = add(R, P, a2)
    return R


def smul_naf(k, P, a2):
    """second, independent scalar-mult path: signed NAF, right-to-left"""
    if k < 0:
        return smul_naf(-k, neg(P), a2)
    R, T = None, P
    while k:
        if k & 1:
            d = 2 - (k & 3)  # +1 or -1
            k -= d
            R = add(R, T if d == 1 else neg(T), a2)
        k >>= 1
        T = dbl(T, a2)
    return R


def x_ladder(k, x, b):
    """Lopez-Dahab x-only Montgomery ladder: returns x([k]P) or None for O; needs x(P) != 0, k >= 1"""
    X1, Z1 = x, 1
    X2, Z2 = sqr(sqr(x)) ^ b, sqr(x)
    for bit in bin(k)[3:]:
        if bit == '1':
            # (P1,P2) -> (P1+P2, 2 P2)
            t1 = mul(X1, Z2); t2 = mul(X2, Z1)
            Z1n = sqr(t1 ^ t2); X1n = mul(x, Z1n) ^ mul(t1, t2)
            X2s, Z2s = sqr(X2), sqr(Z2)
            X2n = sqr(X2s) ^ mul(b, sqr(Z2s)); Z2n = mul(X2s, Z2s)
            X1, Z1, X2, Z2 = X1n, Z1n, X2n, Z2n
        else:
            t1 = mul(X1, Z2); t2 = mul(X2, Z1)
            Z2n = sqr(t1 ^ t2); X2n = mul(x, Z2n) ^ mul(t1, t2)
            X1s, Z1s = sqr(X1), sqr(Z1)
            X1n = sqr(X1s) ^ mul(b, sqr(Z1s)); Z1n = mul(X1s, Z1s)
            X1, Z1, X2, Z2 = X1n, Z1n, X2n, Z2n
    if Z1 == 0:
        return None
    return mul(X1, inv(Z1))


def lift_x(x, a2, b):
    """a point with this x, or None if not F_q-rational (x != 0)"""
    c = x ^ a2 ^ mul(b, sqr(inv(x)))
    if tr(c):
        return None
    z = half_trace(c)
    return (x, mul(x, z))


def random_point(rng, a2, b):
    while True:
        x = rng.getrandbits(131)
        if x == 0:
            continue
        P = lift_x(x, a2, b)
        if P is None:
            continue
        if rng.getrandbits(1):
            P = neg(P)
        return P
