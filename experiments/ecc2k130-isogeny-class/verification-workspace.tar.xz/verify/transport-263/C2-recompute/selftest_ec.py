"""sanity checks of my EC code on E0: y^2+xy=x^3+1 (a2=0,b=1): orders, tau eigenvalue, NAF vs binary vs ladder"""
import random, json, time
from ec2 import *
from f2m import sqr

q = 2 ** 131
# trace via Lucas recurrence with t1 = -1 (#E0(F_2)=4)
t0, t1 = 2, -1
for _ in range(130):
    t0, t1 = t1, -t1 - 2 * t0  # t_{k+1} = t1*t_k - 2 t_{k-1} with t1=-1
t = t1
card = q + 1 - t
assert card % 4 == 0
N = card // 4
print("t =", t)
print("N =", N)
assert t == -22283658519494248867 and N == 680564733841876926932320129493409985129
# tau eigenvalues: roots of s^2+s+2 mod N
import sys
def sqrt_mod(a, p):
    # Tonelli-Shanks
    assert pow(a, (p - 1) // 2, p) == 1
    Q, S = p - 1, 0
    while Q % 2 == 0: Q //= 2; S += 1
    z = 2
    while pow(z, (p - 1) // 2, p) != p - 1: z += 1
    Mx, c, tt, R = S, pow(z, Q, p), pow(a, Q, p), pow(a, (Q + 1) // 2, p)
    while tt != 1:
        i, t2 = 0, tt
        while t2 != 1: t2 = t2 * t2 % p; i += 1
        bb = pow(c, 1 << (Mx - i - 1), p)
        Mx, c, tt, R = i, bb * bb % p, tt * bb * bb % p, R * bb % p
    return R
r = sqrt_mod((-7) % N, N)
inv2 = pow(2, -1, N)
s_roots = sorted({(-1 + r) * inv2 % N, (-1 - r) * inv2 % N})
print("roots of s^2+s+2 mod N:", s_roots)
rng = random.Random("C2-recompute:selftest")
a2, b = 0, 1
hits = {}
for it in range(4):
    P = random_point(rng, a2, b)
    assert on_curve(P, a2, b)
    assert smul(4 * N, P, a2) is None
    R = smul(4, P, a2)
    assert R is not None and smul(N, R, a2) is None and smul_naf(N, R, a2) is None
    tauR = (sqr(R[0]), sqr(R[1]))
    which = [s for s in s_roots if smul(s, R, a2) == tauR]
    assert len(which) == 1
    hits[which[0]] = hits.get(which[0], 0) + 1
    k = rng.randrange(1, N)
    A = smul(k, R, a2); B = smul_naf(k, R, a2)
    assert A == B and on_curve(A, a2, b)
    assert x_ladder(k, R[0], b) == A[0]
    # (k1+k2)R == k1 R + k2 R
    k1, k2 = rng.randrange(N), rng.randrange(N)
    assert add(smul(k1, R, a2), smul(k2, R, a2), a2) == smul((k1 + k2) % N, R, a2)
print("tau eigenvalue on N-subgroup (my computation):", hits)
print("selftest OK")
