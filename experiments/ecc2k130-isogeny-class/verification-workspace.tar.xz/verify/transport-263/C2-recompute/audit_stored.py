"""Audit the sweep's stored C2 fields (data only)."""
import json, glob
N = 680564733841876926932320129493409985129
pc = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/per_curve.json"))
floor = [l for l in pc if l != "E0"]
print("per_curve labels:", len(pc), "floor:", len(floor))
for key in ["planted_check_ok", "hom_full_group_ok", "toy_dlp_recovered_on_E0", "transport_ok"]:
    print(key, sum(pc[l].get(key) is True for l in floor))
ks = [int(pc[l]["planted_k"]) for l in floor]
print("planted_k distinct:", len(set(ks)), "in [2,N-2]:", all(2 <= k <= N - 2 for k in ks), "min bits", min(k.bit_length() for k in ks))
raw = {}
for f in sorted(glob.glob("/Volumes/SSD990/ecdlp-hardness-work/transport-263/raw/shard_*.json")):
    d = json.load(open(f))
    for l, r in d.items():
        raw.setdefault(l, []).append((f.split("/")[-1], r))
print("raw labels:", len(raw), "labels with >1 record:", sum(len(v) > 1 for v in raw.values()))
last = {l: v[-1][1] for l, v in raw.items()}
fl = [l for l in last if l != "E0"]
print("raw floor labels", len(fl))
for key in ["planted_check_ok", "phiR_nonzero", "phiR_order_N", "phiS_eq_k_phiR", "sage_agrees_explicit", "hom_full_group_ok",
            "order_4N_preserved", "toy_dlp_recovered_on_E0"]:
    print("raw", key, sum(last[l].get(key) is True for l in fl))
tk = [last[l]["toy_dlp_k_small"] for l in fl]
print("toy k: distinct", len(set(tk)), "min", min(tk), "max", max(tk), "< 2^24", all(0 <= x < 2**24 for x in tk), "zero/one count", sum(x in (0, 1) for x in tk))
# per_curve planted_k equals the raw one?
print("planted_k per_curve == raw:", all(pc[l]["planted_k"] == last[l]["planted_k"] for l in fl))
# records disagree between duplicate shards?
for l, v in raw.items():
    if len(v) > 1:
        vals = set(json.dumps({k: r.get(k) for k in ["planted_check_ok", "hom_full_group_ok", "toy_dlp_recovered_on_E0"]}) for _, r in v)
        if len(vals) > 1:
            print("DISAGREE", l, [(f, r.get("planted_check_ok"), r.get("toy_dlp_recovered_on_E0")) for f, r in v])
