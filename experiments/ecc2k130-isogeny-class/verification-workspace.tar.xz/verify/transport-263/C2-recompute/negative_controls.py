"""Negative controls: show the checks in c2_recompute.py can fail when the transport is wrong."""
import json, random, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c2_recompute import Iso, N, bsgs, GT, KER
from ec2 import on_curve, smul, random_point, add, lift_x, neg
from f2m import sqr

gt = {c["label"]: c for c in json.load(open(GT))["curves"]}
kers = json.load(open(KER))
rng = random.Random("C2-negative-controls")
res = {}
for lab, other in [("A000", "A001"), ("A077", "B077"), ("B042", "A042")]:
    b = int(gt[lab]["b_int"])
    xs = [int(h, 16) for h in kers[lab]]
    R = smul(4, random_point(rng, 0, b), 0)
    k = rng.randrange(2, N - 1)
    S = smul(k, R, 0)
    r = {}
    # (1) kernel of a different curve
    iso_w = Iso([int(h, 16) for h in kers[other]], b)
    r["wrong_curve_kernel_codomain_b_is_1"] = (b ^ iso_w.v ^ sqr(iso_w.v)) == 1
    r["wrong_curve_kernel_lifts_on_twist"] = lift_x(iso_w.xs[0], 1, b) is not None
    pR = iso_w.eval(R)
    r["wrong_curve_kernel_phiR_on_E0"] = on_curve(pR, 0, 1)
    # (2) one kernel x replaced by a random element
    xs2 = list(xs); xs2[7] = rng.getrandbits(131)
    iso_p = Iso(xs2, b)
    pR, pS = iso_p.eval(R), iso_p.eval(S)
    r["perturbed_kernel_phiR_on_E0"] = on_curve(pR, 0, 1)
    r["perturbed_kernel_planted_ok"] = pS == smul(k, pR, 0)
    # (3) kernel with one x dropped (130 points)
    iso_d = Iso(xs[:-1], b)
    pR, pS = iso_d.eval(R), iso_d.eval(S)
    r["dropped_kernel_phiR_on_E0"] = on_curve(pR, 0, 1)
    r["dropped_kernel_planted_ok"] = pS == smul(k, pR, 0)
    # (4) correct kernel but Y without the +v translation
    iso = Iso(xs, b)
    pR = iso.eval(R)
    r["correct_phiR_on_E0"] = on_curve(pR, 0, 1)
    r["no_v_shift_on_E0"] = on_curve((pR[0], pR[1] ^ iso.v), 0, 1)
    # (5) correct kernel but Y replaced by the other root (Y + X) = -phi(R): planted must fail for generic k
    fake = lambda P: neg(iso.eval(P)) if (P[0] & 1) else iso.eval(P)   # sign flip depending on a bit of x
    fR, fS = fake(R), fake(S)
    r["sign_flip_map_planted_ok"] = fS == smul(k, fR, 0)
    # (6) BSGS negative: target outside [0, 2^24)
    kbig = (1 << 24) + 5
    r["bsgs_out_of_range_returns"] = bsgs(pR, smul(kbig, pR, 0))
    res[lab] = r
print(json.dumps(res, indent=1))
json.dump(res, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "negative_controls.json"), "w"), indent=1)
