\\ Independent PARI/gp (homebrew 2.17.3, not Sage's cypari2) cross-check of claim C1.
\\ Reads gp_input.gp written by verify_c1.py: [label, b, v_python, xs(131), Px, Py, phiPx, phiPy, x0].
default(parisize, "1G");
read("gp_input.gp");
g = ffgen(Mod(1,2)*(a^131+a^13+a^2+a+1), 'a);
elt(n) = my(w=binary(n), s=0*g); for(i=1,#w, s = s*g + w[i]); s;
toint(e) = my(P = lift(e.pol)); if(type(P)=="t_INT", P, subst(P, variable(P), 2));
E0 = ellinit([1,0,0,0,1], g);
cnt = vector(9); names = ["ker_codomain_eq_[1,0,0,v,b+v]","ker_codomain_j_is_1","ker_image_eq_python","iso_[1,0,0,v]_maps_E0_to_codomain","image_translated_on_E0","v_sum_roots_eq_python","gen_twist_order_263","gen_twist_codomain_j_is_1","b_plus_v_plus_v2_is_1"];
out = "gp_results.txt"; write(out, "label ", names);
t0 = getwalltime();
{
for(k=1, #DATA,
  my(D=DATA[k], lab=D[1], b=elt(D[2]), vpy=elt(D[3]), xs=apply(elt, D[4]), Px=elt(D[5]), Py=elt(D[6]),
     fx=elt(D[7]), fy=elt(D[8]), x0=elt(D[9]), E, ker, r, ai, h, X, Y, v, C0, Pe, res=vector(9), Et, y0s, P0, r2);
  E = ellinit([1,0,0,0,b], g);
  ker = prod(i=1, #xs, 'x - xs[i]);
  v = -polcoef(ker, 130, 'x);              \\ sum of roots from the kernel polynomial
  res[6] = (v == vpy) && (#xs == 131);
  res[9] = (b + v + v^2 == 1);
  r = ellisogeny(E, ker); ai = r[1];
  res[1] = (ai == [1, 0, 0, v, b + v]);
  res[2] = (ellinit(ai, g).j == 1);
  h = subst(r[2][3], 'x, Px);
  X = subst(r[2][1], 'x, Px) / h^2;
  Y = subst(subst(r[2][2], 'y, Py), 'x, Px) / h^3;
  res[3] = (X == fx) && (Y == fy);
  C0 = ellchangecurve(E0, [1, 0, 0, v]);
  res[4] = (vector(5, i, C0[i]) == ai);
  Pe = ellchangepointinv([X, Y], [1, 0, 0, v]);
  res[5] = ellisoncurve(E0, Pe) && (Pe[2] == Y + v) && (Pe[1] == X);
  Et = ellinit([1,1,0,0,b], g);
  y0s = ellordinate(Et, x0);
  if(#y0s > 0,
    P0 = [x0, y0s[1]];
    res[7] = (ellmul(Et, P0, 263) == [0]) && (ellmul(Et, P0, 1) != [0]);
    r2 = ellisogeny(Et, P0, 1);
    res[8] = (ellinit(r2, g).j == 1));
  for(i=1, 9, cnt[i] += (res[i] != 0));
  write(out, lab, " ", res);
  if(k % 50 == 0, print(lab, " ", k, " done ", getwalltime() - t0, " ms"));
);
}
print("counts out of ", #DATA, ":");
for(i=1, 9, print("  ", names[i], " = ", cnt[i]));
print("wall ms ", getwalltime() - t0);
