"""Stand-alone GF(2^131) and binary-curve arithmetic in plain Python ints.

Written from scratch for the C1 re-check; uses no Sage, NTL or PARI.
Field: F_2[z]/(z^131 + z^13 + z^2 + z + 1); an element is an int whose bit i
is the coefficient of z^i.
Curves: y^2 + a1 x y + a3 y = x^3 + a2 x^2 + a4 x + a6 with a1 = 1, a3 = 0,
stored as (a2, a4, a6). Points are (x, y) tuples, None = point at infinity.
"""

DEG = 131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << DEG) - 1


def red(r):
    # z^131 = z^13 + z^2 + z + 1
    while r >> DEG:
        h = r >> DEG
        r = (r & MASK) ^ h ^ (h << 1) ^ (h << 2) ^ (h << 13)
    return r


def clmul(a, b):
    # carry-less product via a 4-bit window table of a
    t = [0] * 16
    t[1] = a
    for i in range(2, 16, 2):
        t[i] = t[i >> 1] << 1
        t[i + 1] = t[i] ^ a
    r = 0
    nb = (b.bit_length() + 3) // 4
    for k in range(nb - 1, -1, -1):
        r = (r << 4) ^ t[(b >> (4 * k)) & 15]
    return r


def mul(a, b):
    return red(clmul(a, b))


_SPREAD = []
for _v in range(256):
    _s = 0
    for _i in range(8):
        if (_v >> _i) & 1:
            _s |= 1 << (2 * _i)
    _SPREAD.append(_s)


def sqr(a):
    r = 0
    k = 0
    while a:
        r |= _SPREAD[a & 255] << (16 * k)
        a >>= 8
        k += 1
    return red(r)


def inv(a):
    # extended Euclid in F_2[z]
    if a == 0:
        raise ZeroDivisionError
    u, v = a, MOD
    g1, g2 = 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v = v, u
            g1, g2 = g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return red(g1)


def power(a, e):
    r = 1
    while e:
        if e & 1:
            r = mul(r, a)
        a = sqr(a)
        e >>= 1
    return r


def trace_slow(a):
    s = a
    acc = a
    for _ in range(DEG - 1):
        s = sqr(s)
        acc ^= s
    assert acc in (0, 1)
    return acc


# Tr is F_2-linear: Tr(a) = parity(a & TRMASK)
TRMASK = 0
for _i in range(DEG):
    if trace_slow(1 << _i):
        TRMASK |= 1 << _i


def tr(a):
    return bin(a & TRMASK).count("1") & 1


def halftrace(c):
    # for odd degree: H(c) = sum_{i=0}^{(m-1)/2} c^(4^i); H(c)^2 + H(c) = c + Tr(c)
    h = c
    s = c
    for _ in range((DEG - 1) // 2):
        s = sqr(sqr(s))
        h ^= s
    return h


# ---------------- curves (a1 = 1, a3 = 0) ----------------

def on_curve(C, P):
    if P is None:
        return True
    a2, a4, a6 = C
    x, y = P
    lhs = sqr(y) ^ mul(x, y)
    x2 = sqr(x)
    rhs = mul(x2, x) ^ mul(a2, x2) ^ mul(a4, x) ^ a6
    return lhs == rhs


def neg(P):
    if P is None:
        return None
    return (P[0], P[1] ^ P[0])


def add(C, P, Q):
    a2, a4, a6 = C
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y1 ^ y2 == x1:  # Q = -P (covers the 2-torsion x = 0 case)
            return None
        # doubling: lambda = (x1^2 + a4 + y1)/x1
        lam = mul(sqr(x1) ^ a4 ^ y1, inv(x1))
    else:
        lam = mul(y1 ^ y2, inv(x1 ^ x2))
    x3 = sqr(lam) ^ lam ^ a2 ^ x1 ^ x2
    nu = y1 ^ mul(lam, x1)
    y3 = mul(lam ^ 1, x3) ^ nu
    return (x3, y3)


def smul(C, k, P):
    if k < 0:
        return smul(C, -k, neg(P))
    R = None
    Q = P
    while k:
        if k & 1:
            R = add(C, R, Q)
        Q = add(C, Q, Q)
        k >>= 1
    return R


def lift_x(C, x):
    """Return a point with this x on C over F_q, or None if x lifts only on the twist."""
    a2, a4, a6 = C
    if x == 0:
        return (0, power(a6, 1 << (DEG - 1)))  # y^2 = a6
    # y = x w:  w^2 + w = x + a2 + a4/x + a6/x^2
    ix = inv(x)
    c = x ^ a2 ^ mul(a4, ix) ^ mul(a6, sqr(ix))
    if tr(c):
        return None
    w = halftrace(c)
    return (x, mul(x, w))


def random_point(C, rng):
    while True:
        x = rng.getrandbits(DEG)
        P = lift_x(C, x)
        if P is not None:
            if rng.getrandbits(1):
                P = neg(P)
            return P


def j_invariant(C):
    # a1 = 1, a3 = 0: b2 = 1, b4 = 0 (char 2), b6 = 0, b8 = a6 + a4^2, Delta = b8, c4 = 1
    a2, a4, a6 = C
    delta = a6 ^ sqr(a4)
    return inv(delta)
