"""Negative controls: the checks in verify_c1.py must FAIL on corrupted inputs."""
import json, random, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gf2m import *
gt = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
recs = {c["label"]: c for c in gt["curves"]}
kers = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"))
rng = random.Random(7)
def vsum(xs):
    v = 0
    for x in xs: v ^= x
    return v
def gen_ok(b, xs):
    Et = (1, 0, b); P0 = lift_x(Et, xs[0])
    if P0 is None: return False
    seen = set(); Q = P0
    for k in range(1, 263):
        if Q is None: return False
        if k <= 131: seen.add(Q[0])
        Q = add(Et, Q, P0)
    return Q is None and seen == set(xs)
res = {}
bA = int(recs["A000"]["b_int"]); xsA = [int(h, 16) for h in kers["A000"]]
xsB = [int(h, 16) for h in kers["A001"]]
res["true_A000_relation"] = (bA ^ vsum(xsA) ^ sqr(vsum(xsA))) == 1
res["true_A000_gen"] = gen_ok(bA, xsA)
res["wrong_kernel(A001)_on_A000_relation"] = (bA ^ vsum(xsB) ^ sqr(vsum(xsB))) == 1
res["wrong_kernel(A001)_on_A000_gen"] = gen_ok(bA, xsB)
bad = list(xsA); bad[5] ^= 1 << 17
res["bitflip_relation"] = (bA ^ vsum(bad) ^ sqr(vsum(bad))) == 1
res["bitflip_gen"] = gen_ok(bA, bad)
# relation fails for the other curves' b: count how many of the 262 b's satisfy with A000's v
vA = vsum(xsA)
res["n_curves_whose_b_satisfies_with_A000_v"] = sum(1 for l, r in recs.items() if l != "E0" and (int(r["b_int"]) ^ vA ^ sqr(vA)) == 1)
# untranslated image is NOT on E0
E = (0, 0, bA); P = random_point(E, rng)
X = P[0]; Y = P[1]
ds = [X ^ xq for xq in xsA]
from functools import reduce
Xi = X; Yi = Y
for xq in xsA:
    e = inv(X ^ xq); e2 = sqr(e); xq2 = sqr(xq)
    Xi ^= mul(xq, e) ^ mul(xq2, e2)
    Yi ^= mul(mul(xq2, X), mul(e2, e)) ^ mul(xq, e) ^ mul(mul(xq, Y), e2) ^ mul(xq2 ^ mul(xq2, xq), e2)
res["image_on_C"] = on_curve((0, vA, bA ^ vA), (Xi, Yi))
res["untranslated_image_on_E0"] = on_curve((0, 0, 1), (Xi, Yi))
res["translated_image_on_E0"] = on_curve((0, 0, 1), (Xi, Yi ^ vA))
print(json.dumps(res, indent=1))
