"""Independent re-check of claim C1 (transport-263 sweep), plain python3 only.

Uses gf2m.py (own GF(2^131) + binary-curve code, no Sage/NTL/PARI).
Inputs read: ground_truth.json (b, j, a2, labels), kernels_all.json (131 kernel x per label),
repo selection-20260921.json (Certicom generator, to validate the arithmetic), and the sweep's
raw/shard_*.json only to COMPARE its v / codomain numbers against ours at the end.
Outputs: results_c1.json and gp_input.gp (for the separate homebrew-gp cross-check).
"""
import json, glob, random, time, hashlib, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from gf2m import *  # noqa

GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
KER = "/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"
SHARDS = "/Volumes/SSD990/ecdlp-hardness-work/transport-263/raw/shard_*.json"
SEL = ("/Volumes/SSD990/cryptanalysis/.claude/worktrees/ecc2k-130-volcano-descent-49e6d4/"
       "ecc2k130/metal/selection-20260921.json")

q = 1 << 131
t = -22283658519494248867
N = 680564733841876926932320129493409985129
CARD = q + 1 - t
TWIST = q + 1 + t
S_TAU = 196511074115861092422032515080945363956

out = {"checks": {}, "per_curve": {}}
T0 = time.time()

# ---------- 0. validate the arithmetic itself ----------
assert MOD == 2722258935367507707706996859454145699847
assert CARD == 4 * N
rng = random.Random(20260923)
for _ in range(200):
    a = rng.getrandbits(131); b = rng.getrandbits(131); c = rng.getrandbits(131)
    assert mul(a, b) == mul(b, a)
    assert mul(a, b ^ c) == mul(a, b) ^ mul(a, c)
    assert mul(mul(a, b), c) == mul(a, mul(b, c))
    assert sqr(a) == mul(a, a)
    if a:
        assert mul(a, inv(a)) == 1
    # Frobenius has order 131 on F_q
assert power(2, 1 << 131) == 2  # z^(2^131) = z
assert tr(1) == 1
# irreducibility of the modulus: z^(2^131) = z and gcd(z^(2^1)-z, f) trivial (131 prime)
# f(0) = 1 and f(1) = 1 (five terms), so f has no F_2 root; with z^(2^131) = z and 131 prime,
# every irreducible factor has degree 131, i.e. f is irreducible.
assert bin(MOD).count("1") % 2 == 1 and MOD & 1
out["checks"]["field_axioms_random_200"] = True

sel = json.load(open(SEL))["domain"]
assert sel["polynomial"] == "z^131+z^13+z^2+z+1"
E0 = (0, 0, 1)
G = (int(sel["generatorPolynomial"][0], 16), int(sel["generatorPolynomial"][1], 16))
assert on_curve(E0, G)
assert smul(E0, N, G) is None and G is not None
tauG = (sqr(G[0]), sqr(G[1]))
assert tauG == smul(E0, S_TAU, G)
assert int(sel["frobeniusEigenvalue"]) == S_TAU
out["checks"]["certicom_G_on_E0_order_N_tau_eigen"] = True
# #E0(F_q) = 4N sanity with a random point
Pr = random_point(E0, rng)
assert smul(E0, CARD, Pr) is None
out["checks"]["E0_random_point_killed_by_4N"] = True
print("arithmetic validated", round(time.time() - T0, 2), "s", flush=True)

# ---------- load data ----------
gt = json.load(open(GT))
recs = {c["label"]: c for c in gt["curves"]}
assert int(gt["meta"]["modulus_int"]) == MOD
kers = json.load(open(KER))
floor = [c["label"] for c in gt["curves"] if c["label"] != "E0"]
assert len(floor) == 262 and set(kers.keys()) == set(floor), "label sets differ"
out["checks"]["kernel_labels_equal_ground_truth_floor_labels"] = True

v263 = 0
tmp = TWIST
while tmp % 263 == 0:
    tmp //= 263; v263 += 1
assert v263 == 2
out["checks"]["v263_twist_card"] = v263

shard = {}
for f in glob.glob(SHARDS):
    for k, v in json.load(open(f)).items():
        shard[k] = v

def batch_inv(vals):
    pre = [1] * (len(vals) + 1)
    for i, a in enumerate(vals):
        pre[i + 1] = mul(pre[i], a)
    iv = inv(pre[-1])
    res = [0] * len(vals)
    for i in range(len(vals) - 1, -1, -1):
        res[i] = mul(iv, pre[i])
        iv = mul(iv, vals[i])
    return res

def velu_eval(xs, P):
    """Velu image of P on E=[1,0,0,0,b] (a2=a4=0) under the isogeny with kernel x-set xs.
    char 2, a1=1: v_Q = x_Q, u_Q = x_Q^2, w = 0;
    X = x + sum x_Q e + x_Q^2 e^2,
    Y = y + sum x_Q^2 x e^3 + x_Q e + x_Q y e^2 + (x_Q^2 + x_Q^3) e^2,  e = 1/(x + x_Q)."""
    if P is None:
        return None
    x, y = P
    ds = [x ^ xq for xq in xs]
    if 0 in ds:
        return None  # P in kernel
    es = batch_inv(ds)
    X = x; Y = y
    for xq, e in zip(xs, es):
        e2 = sqr(e); e3 = mul(e2, e); xq2 = sqr(xq)
        X ^= mul(xq, e) ^ mul(xq2, e2)
        Y ^= mul(mul(xq2, x), e3) ^ mul(xq, e) ^ mul(mul(xq, y), e2) ^ mul(xq2 ^ mul(xq2, xq), e2)
    return (X, Y)

gp_lines = []
fails = []
agg = {k: 0 for k in [
    "b_times_j_is_1", "a2_is_0", "kernel_131_distinct_nonzero", "b_plus_v_plus_v2_is_1",
    "kernel_x_not_liftable_on_E", "kernel_generated_by_one_twist_point_order_263",
    "twist_card_kills_random_point", "twist_263_sylow_cyclic_order_263sq",
    "kernel_is_the_unique_Fq_rational_263_subgroup", "codomain_j_is_1_from_a4_a6",
    "images_on_codomain", "translated_images_on_E0", "homomorphism_phi_P_plus_R",
    "E_point_order_4N", "image_order_4N", "phi_kP_eq_k_phiP",
    "v_equals_sweep_v_int", "codomain_equals_sweep_sage_codomain"]}

for idx, lab in enumerate(floor):
    r = recs[lab]
    b = int(r["b_int"]); j = int(r["j_int"]); a2 = int(r["a2"])
    xs = [int(h, 16) for h in kers[lab]]
    pc = {}
    pc["b_times_j_is_1"] = mul(b, j) == 1
    pc["a2_is_0"] = a2 == 0
    pc["kernel_131_distinct_nonzero"] = (len(xs) == 131 and len(set(xs)) == 131 and 0 not in xs
                                        and all(x < (1 << 131) for x in xs))
    v = 0
    for x in xs:
        v ^= x
    pc["b_plus_v_plus_v2_is_1"] = (b ^ v ^ sqr(v)) == 1
    E = (0, 0, b)
    Et = (1, 0, b)
    # kernel points are not F_q-points of E (263 does not divide 4N) but lift on the twist
    pc["kernel_x_not_liftable_on_E"] = all(lift_x(E, x) is None for x in xs)
    P0 = lift_x(Et, xs[0])
    ok = P0 is not None and on_curve(Et, P0)
    xset = set(xs)
    if ok:
        seen = set(); Q = P0
        for k in range(1, 263):
            if Q is None:
                ok = False; break
            if k <= 131:
                seen.add(Q[0])
            Q = add(Et, Q, P0)
        ok = ok and Q is None and seen == xset
    pc["kernel_generated_by_one_twist_point_order_263"] = ok
    # twist group: order TWIST, cyclic 263-Sylow of order 263^2, unique rational 263-subgroup = kernel
    # (a random R has [TWIST/263]R = O with prob. ~1/263, so retry up to 20 times)
    kill_ok = True
    for tries_R in range(1, 21):
        R = random_point(Et, rng)
        kill_ok = kill_ok and smul(Et, TWIST, R) is None
        S1 = smul(Et, TWIST // (263 * 263), R)
        S2 = smul(Et, 263, S1)  # = [TWIST/263] R
        if S2 is not None:
            break
    pc["twist_card_kills_random_point"] = kill_ok
    tries_R_rec = tries_R
    pc["twist_263_sylow_cyclic_order_263sq"] = S2 is not None and smul(Et, 263, S2) is None
    pc["kernel_is_the_unique_Fq_rational_263_subgroup"] = S2 is not None and S2[0] in xset
    # codomain from Velu: [1, 0, 0, v, b+v]; j = 1/(a6 + a4^2)
    C = (0, v, b ^ v)
    pc["codomain_j_is_1_from_a4_a6"] = j_invariant(C) == 1
    # point images
    # E(F_q) = Z/4 x Z/N (one point of order 2), so a random point has order 4N w.p. ~1/2: retry
    for tries_P in range(1, 41):
        P = random_point(E, rng)
        ordP = smul(E, CARD, P) is None and smul(E, 2 * N, P) is not None and smul(E, 4, P) is not None
        if ordP:
            break
    Rr = random_point(E, rng)
    pc["E_point_order_4N"] = ordP
    fP = velu_eval(xs, P); fR = velu_eval(xs, Rr); fPR = velu_eval(xs, add(E, P, Rr))
    pc["images_on_codomain"] = on_curve(C, fP) and on_curve(C, fR) and on_curve(C, fPR)
    tr_ = lambda Z: None if Z is None else (Z[0], Z[1] ^ v)
    gP, gR, gPR = tr_(fP), tr_(fR), tr_(fPR)
    pc["translated_images_on_E0"] = on_curve(E0, gP) and on_curve(E0, gR) and on_curve(E0, gPR)
    pc["homomorphism_phi_P_plus_R"] = add(E0, gP, gR) == gPR
    pc["image_order_4N"] = (smul(E0, CARD, gP) is None and smul(E0, 2 * N, gP) is not None
                           and smul(E0, 4, gP) is not None)
    k = rng.randrange(1, N)
    pc["phi_kP_eq_k_phiP"] = tr_(velu_eval(xs, smul(E, k, P))) == smul(E0, k, gP)
    sw = shard.get(lab, {})
    pc["v_equals_sweep_v_int"] = sw.get("v_int") == str(v)
    pc["codomain_equals_sweep_sage_codomain"] = sw.get("sage_codomain_a1a2a3a4a6") == ["1", "0", "0", str(v), str(b ^ v)]
    for kk, val in pc.items():
        if val:
            agg[kk] += 1
    if not all(pc.values()):
        fails.append((lab, [kk for kk, val in pc.items() if not val]))
    pc["v_int"] = str(v)
    pc["tries_R_twist"] = tries_R_rec
    pc["tries_P_order_4N"] = tries_P
    pc["P"] = [str(P[0]), str(P[1])]
    pc["phiP_on_codomain"] = [str(fP[0]), str(fP[1])]
    out["per_curve"][lab] = pc
    gp_lines.append('[%s, %d, %d, %s, %d, %d, %d, %d, %d]' % (
        '"%s"' % lab, b, v, "[" + ",".join(str(x) for x in xs) + "]",
        P[0], P[1], fP[0], fP[1], P0[0] if P0 else 0))
    if idx % 26 == 0:
        print(lab, "done", round(time.time() - T0, 1), "s", flush=True)

out["aggregate_counts_out_of_262"] = agg
out["fails"] = fails
out["seconds"] = round(time.time() - T0, 1)
json.dump(out, open(os.path.join(HERE, "results_c1.json"), "w"), indent=1)
with open(os.path.join(HERE, "gp_input.gp"), "w") as fh:
    fh.write("DATA = [\\\n" + ",\\\n".join(gp_lines) + "];\n")
print(json.dumps(agg, indent=1))
print("fails:", fails)
print("total", out["seconds"], "s")
