# compare the F_q-roots of the 263-division polynomial (divpol_<label>.out) with kernels_all.json and the PARI twist route
import json, glob
W = "/Volumes/SSD990/ecdlp-hardness-work"
kall = json.load(open(W + "/transport-263/kernels_all.json"))
tw = {}
for line in open("indep_twist_1_263.out"):
    f = line.rstrip("\n").split("|")
    if f[0] != "E0":
        tw[f[0]] = sorted(int(u) for u in f[9].strip("[]").split(","))
out = {}
for fn in sorted(glob.glob("divpol_*.out")):
    f = open(fn).read().strip().split("|")
    lab, deg, nroots, ndist = f[0], int(f[1]), int(f[2]), int(f[3])
    xs = sorted(int(u) for u in f[4].strip("[]").split(",")) if f[4] != "big" else None
    out[lab] = {"divpol_degree": deg, "n_Fq_roots": nroots, "n_distinct": ndist,
                "roots_equal_kernels_all": xs == sorted(int(h, 16) for h in kall[lab]) if xs else None,
                "roots_equal_pari_twist_route": xs == tw[lab] if xs else None,
                "divpol_ms": int(f[5]), "roots_ms": int(f[6])}
print(json.dumps(out, indent=1))
json.dump(out, open("compare_divpol.json", "w"), indent=1)
