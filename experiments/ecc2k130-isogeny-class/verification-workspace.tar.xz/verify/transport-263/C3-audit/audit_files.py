"""C3 audit, part 1: consistency of the transport-263 output files (plain python3, no Sage).

Checks
  * every floor label has exactly one record across raw/shard_*.json (incl. resume shards), no dup conflicts
  * every record has all 11 kernel component flags present and True, kernel_poly_degree == 131
  * kernels_all.json == union of raw/kernels_*.json, 262 labels x 131 distinct nonzero x < 2^131
  * per_curve.json kernel_ok True for all 262
  * the Frobenius relation of stored kernels: kernel(next(X)) = {x^2 : x in kernel(X)} (own GF(2^131) arithmetic)
  * the Tr claim recomputed with own arithmetic: Tr(x + b/x^2) = 1 for every stored kernel x (so x is not the
    abscissa of an F_q-point of E: y = x z, z^2 + z = x + b/x^2)
Writes audit_files.json next to this script.
"""
import json, glob, os, sys

W = "/Volumes/SSD990/ecdlp-hardness-work"
TR = W + "/transport-263"
HERE = os.path.dirname(os.path.abspath(__file__))
GT = json.load(open(W + "/ground_truth/ground_truth.json"))
MOD = int(GT["meta"]["modulus_int"])
assert MOD == (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
recs_by_label = {c["label"]: c for c in GT["curves"]}
floor = [c["label"] for c in GT["curves"] if c["label"] != "E0"]
assert len(floor) == 262


# ---------------- own GF(2^131) arithmetic on bitmask integers
def gmul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        b >>= 1
        a <<= 1
        if a >> 131:
            a ^= MOD
    return r


def gsq(a):
    return gmul(a, a)


def ginv(a):
    """inverse by the extended Euclidean algorithm in GF(2)[z] (bitmask polynomials)"""
    assert a
    r0, r1, s0, s1 = MOD, a, 0, 1
    while r1:
        while r0 and r0.bit_length() >= r1.bit_length():
            sh = r0.bit_length() - r1.bit_length()
            r0 ^= r1 << sh
            s0 ^= s1 << sh
        r0, r1, s0, s1 = r1, r0, s1, s0
    assert r0 == 1
    # reduce s0 mod MOD
    while s0.bit_length() > 131:
        s0 ^= MOD << (s0.bit_length() - 132)
    return s0


def gtrace_slow(a):
    s, u = a, a
    for _ in range(130):
        u = gsq(u)
        s ^= u
    assert s in (0, 1)
    return s


TRMASK = sum(gtrace_slow(1 << i) << i for i in range(131))   # Tr is F_2-linear: Tr(c) = <c, TRMASK>


def gtrace(a):
    return bin(a & TRMASK).count("1") & 1


# sanity of own arithmetic: trace(1) = 1 (131 odd), inverse works
assert gtrace(1) == 1
import random as _r
for _ in range(200):
    _u = _r.getrandbits(131) or 1
    assert gmul(ginv(_u), _u) == 1 and gtrace(_u) == gtrace_slow(_u)
assert gmul(ginv(0x1234567), 0x1234567) == 1

KFLAGS = ["twist_Q_order_263sq", "kernel_gen_order_263", "kernel_gen_matches_sage_mult", "kernel_xs_distinct_131",
          "kernel_pts_not_Fq_rational_on_E", "E_Fq_has_no_263_torsion", "fq2_sylow_cyclic_order_263sq",
          "fq2_kernel_galois_stable_frob_eq_minus", "fq2_kernel_y_not_in_Fq", "fq2_kernel_x_in_Fq",
          "fq2_kernel_poly_equals_twist_kernel_poly"]
out = {}

# ---------------- shard records
seen = {}
dups = []
for fn in sorted(glob.glob(TR + "/raw/shard_*.json")):
    d = json.load(open(fn))
    for lab, r in d.items():
        if lab in seen:
            dups.append((lab, seen[lab][0], os.path.basename(fn), seen[lab][1] == r))
        seen[lab] = (os.path.basename(fn), r)
out["n_labels_in_shards"] = len(seen)
out["duplicates"] = dups
out["missing_labels"] = [l for l in floor if l not in seen]
out["extra_labels"] = [l for l in seen if l not in floor]
bad = {}
for lab in floor:
    r = seen[lab][1]
    miss = [k for k in KFLAGS if k not in r]
    false = [k for k in KFLAGS if k in r and r[k] is not True]
    if miss or false or r.get("kernel_poly_degree") != 131 or r.get("kernel_ok") is not True:
        bad[lab] = {"missing": miss, "false": false, "deg": r.get("kernel_poly_degree"), "kernel_ok": r.get("kernel_ok")}
out["records_with_missing_or_false_kernel_flags"] = bad
out["records_per_file"] = {}
for fn in sorted(glob.glob(TR + "/raw/shard_*.json")):
    out["records_per_file"][os.path.basename(fn)] = len(json.load(open(fn)))

# ---------------- kernels
kall = json.load(open(TR + "/kernels_all.json"))
kraw = {}
for fn in sorted(glob.glob(TR + "/raw/kernels_*.json")):
    kraw.update(json.load(open(fn)))
out["kernels_all_labels"] = len(kall)
out["kernels_all_equals_raw_union"] = all(kall[l] == kraw[l] for l in floor) and set(kall) == set(floor)
kset = {}
kbad = []
for lab in floor:
    xs = [int(h, 16) for h in kall[lab]]
    if len(xs) != 131 or len(set(xs)) != 131 or any(x == 0 or x >> 131 for x in xs):
        kbad.append(lab)
    kset[lab] = set(xs)
out["kernels_bad_shape"] = kbad
# pairwise-disjointness across curves is not required, but record overlaps of whole sets
out["kernels_distinct_sets"] = len({frozenset(s) for s in kset.values()})

# ---------------- per_curve.json
pc = json.load(open(TR + "/per_curve.json"))
out["per_curve_kernel_ok_true"] = sum(1 for l in floor if pc[l]["kernel_ok"] is True)


# ---------------- Frobenius relation with own arithmetic
def nxt(lab):
    o, k = lab[0], int(lab[1:])
    return "%s%03d" % (o, (k + 1) % 131)


frob_bad = [lab for lab in floor if {gsq(x) for x in kset[lab]} != kset[nxt(lab)]]
out["frobenius_relation_own_arith_bad"] = frob_bad

# ---------------- Tr claim, own arithmetic, all 262 x 131 abscissae
tr_counts = {0: 0, 1: 0}
tw_counts = {0: 0, 1: 0}
for lab in floor:
    b = int(recs_by_label[lab]["b_int"])
    # b = 1/j check
    assert gmul(b, int(recs_by_label[lab]["j_int"])) == 1
    for x in kset[lab]:
        c = x ^ gmul(b, gsq(ginv(x)))          # x + b/x^2  (E : a2 = 0)
        tr_counts[gtrace(c)] += 1
        tw_counts[gtrace(c ^ 1)] += 1          # x + 1 + b/x^2  (twist, a2 = 1)
out["Tr_E_counts_over_all_262x131"] = tr_counts
out["Tr_twist_counts_over_all_262x131"] = tw_counts

json.dump(out, open(HERE + "/audit_files.json", "w"), indent=1)
print(json.dumps(out, indent=1))
