# compare standalone-PARI results (indep_twist_1_263.out) with ground truth constants and transport-263 kernels_all.json
import json
W = "/Volumes/SSD990/ecdlp-hardness-work"
GT = json.load(open(W + "/ground_truth/ground_truth.json"))
CARD, TW = int(GT["meta"]["card"]), int(GT["meta"]["twist_card"])
q, t = 2**131, int(GT["meta"]["t"])
assert CARD == q + 1 - t and TW == q + 1 + t
kall = json.load(open(W + "/transport-263/kernels_all.json"))
def v(n, p=263):
    k = 0
    while n % p == 0:
        n //= p; k += 1
    return k
res = {"floor_ok": 0, "floor_bad": [], "E0": None, "kernel_set_match": 0, "kernel_set_mismatch": [],
       "twist_structures_263part": {}, "max_ms": 0}
for line in open("indep_twist_1_263.out"):
    f = line.rstrip("\n").split("|")
    lab, cE, cT = f[0], int(f[1]), int(f[2])
    G = [int(u) for u in f[3].strip("[]").split(",")]
    ordQ, ok263, nE, nT = int(f[5]), int(f[6]), int(f[7]), int(f[8])
    xs = [int(u) for u in f[9].strip("[]").split(",")] if f[9] != "[]" else []
    res["max_ms"] = max(res["max_ms"], int(f[10]))
    struct = "Z/263^%d" % v(G[0]) + (" x Z/263^%d" % v(G[1]) if len(G) > 1 else "")
    if lab == "E0":
        res["E0"] = {"card": cE == CARD, "twist_card": cT == TW, "twist_group": G, "twist_263_part": struct}
        continue
    res["twist_structures_263part"][struct] = res["twist_structures_263part"].get(struct, 0) + 1
    ok = (cE == CARD and cT == TW and (len(G) == 1 or v(G[1]) == 0) and v(G[0]) == 2 and ordQ == 263**2
          and ok263 == 1 and nE == 0 and nT == 262 and len(set(xs)) == 131)
    if ok:
        res["floor_ok"] += 1
    else:
        res["floor_bad"].append(lab)
    mine = sorted(xs)
    theirs = sorted(int(h, 16) for h in kall[lab])
    if mine == theirs:
        res["kernel_set_match"] += 1
    else:
        res["kernel_set_mismatch"].append(lab)
res["twist_group_cyclic_count"] = None
print(json.dumps(res, indent=1))
json.dump(res, open("compare_twist.json", "w"), indent=1)
