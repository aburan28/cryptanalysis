# compare the PARI F_{q^2}-route kernels (fq2_lite_2_263.out, and fq2_full_*.out if present) with the PARI twist-route
# kernels (indep_twist_1_263.out) and with transport-263 kernels_all.json
import json, glob
W = "/Volumes/SSD990/ecdlp-hardness-work"
kall = json.load(open(W + "/transport-263/kernels_all.json"))
tw = {}
for line in open("indep_twist_1_263.out"):
    f = line.rstrip("\n").split("|")
    if f[0] != "E0":
        tw[f[0]] = [int(u) for u in f[9].strip("[]").split(",")]
out = {}
for fn in sorted(glob.glob("fq2_*_*.out")):
    r = {"n": 0, "ok": 0, "bad": [], "match_twist_route": 0, "match_kernels_all": 0, "groups": {}}
    for line in open(fn):
        f = line.rstrip("\n").split("|")
        lab = f[0]
        if lab == "E0":
            r["E0_group_Fq2"] = f[2]
            continue
        r["n"] += 1
        G = f[2]
        r["groups"][G if len(G) < 30 else ("cyclic" if "," not in G else G)] = r["groups"].get(G if len(G) < 30 else ("cyclic" if "," not in G else G), 0) + 1
        ordQ, frob, xin, ynot = int(f[3]), int(f[4]), int(f[5]), int(f[6])
        xs = [int(u) for u in f[7].strip("[]").split(",")]
        ok = ordQ == 263**2 and frob == 1 and xin == 1 and ynot == 1 and len(set(xs)) == 131
        r["ok"] += ok
        if not ok:
            r["bad"].append(lab)
        r["match_twist_route"] += sorted(xs) == sorted(tw[lab])
        r["match_kernels_all"] += sorted(xs) == sorted(int(h, 16) for h in kall[lab])
    out[fn] = r
print(json.dumps(out, indent=1))
json.dump(out, open("compare_fq2.json", "w"), indent=1)
