# writes curves_input.gp: LABS (strings) and BS (b as integer bitmask) for E0 + 262 floor curves, from ground_truth.json
import json
GT = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
labs = [c["label"] for c in GT["curves"]]
bs = [c["b_int"] for c in GT["curves"]]
with open("curves_input.gp", "w") as fh:
    fh.write("LABS = [%s];\n" % ",".join('"%s"' % l for l in labs))
    fh.write("BS = [%s];\n" % ",".join(bs))
print(len(labs))
