I0=1;I1=263;
\\ C3 audit, part 2 (standalone PARI/gp 2.17.1, no Sage, no transport-263 code):
\\ for E0 and all 262 floor curves E = [1,0,0,0,b] (b from ground_truth.json via curves_input.gp):
\\   ellcard(E), ellcard(E'), ellgroup(E') for the twist E' = [1,1,0,0,b]  -> 263-part structure
\\   kernel = <P>, P = (#E'/263) U for random U on E'; x(kP), k = 1..131, as bitmask integers
\\   ellorder of a point Q = (#E'/263^2) U' with 263 Q != 0 (witness of order 263^2)
\\   ellordinate counts: kernel abscissae give 0 F_q-points on E and 2 on E' each
\\ Usage: gp -q indep_twist.gp  with I0, I1 set on the command line via  echo 'I0=..;I1=..;' | cat - indep_twist.gp | gp -q
default(parisize, 400000000);
read("curves_input.gp");
a = ffgen(Mod(1,2)*(z^131+z^13+z^2+z+1), 'a);
fe(n) = subst(Pol(binary(n),'y), 'y, a) + 0*a;
toint(u) = my(p = (u+0*a).pol); if(type(p)=="t_POL", subst(lift(p*Mod(1,2)), variable(p), 2), lift(Mod(p,2)));
if(type(I0)!="t_INT", I0 = 1); if(type(I1)!="t_INT", I1 = #LABS);
setrand(20260924 + I0);
out = Str("indep_twist_", I0, "_", I1, ".out");
{
for(i = I0, I1,
  my(t0 = getabstime(), b = fe(BS[i]), E, Et, cE, cT, G, GE, v1, v2, P, U, Q, ordQ, xs, nE, nT, ok263, pts);
  E = ellinit([1,0,0,0,b], a);
  Et = ellinit([1,1,0,0,b], a);
  cE = ellcard(E); cT = ellcard(Et);
  G = ellgroup(Et); GE = ellgroup(E);
  v1 = valuation(G[1], 263); v2 = if(#G > 1, valuation(G[2], 263), 0);
  if(v2 == 0 && v1 >= 1,
    P = [0]; until(P != [0], U = random(Et); P = ellmul(Et, U, cT/263));
    ok263 = (ellmul(Et, P, 263) == [0]) && ellisoncurve(Et, P);
    Q = [0]; until(ellmul(Et, Q, 263) != [0], Q = ellmul(Et, random(Et), cT/263^2));
    ordQ = ellorder(Et, Q);
    pts = vector(131, k, ellmul(Et, P, k));
    xs = vecsort(vector(131, k, toint(pts[k][1])));
    nE = sum(k = 1, 131, #ellordinate(E, pts[k][1]));
    nT = sum(k = 1, 131, #ellordinate(Et, pts[k][1]));
  ,
    ok263 = -1; ordQ = -1; xs = []; nE = -1; nT = -1);
  write(out, LABS[i], "|", cE, "|", cT, "|", G, "|", GE, "|", ordQ, "|", ok263, "|", nE, "|", nT, "|", xs, "|", getabstime() - t0);
);
}
quit;
