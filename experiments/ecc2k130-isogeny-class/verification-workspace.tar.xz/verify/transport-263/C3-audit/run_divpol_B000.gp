IDX=[133];
\\ C3 audit, part 3 (standalone PARI/gp): the Galois-stable 263-subgroups straight from the 263-division polynomial.
\\ Frobenius pi on E[263] has char poly X^2 - tX + q = (X+1)^2 mod 263, so a pi-stable line is contained in ker(pi+1),
\\ whose abscissae lie in F_q; E(F_q) has no 263-torsion, so the F_q-roots of f_263 (deg (263^2-1)/2 = 34584) are
\\ exactly the x(P), P in ker(pi+1)\O. #roots = 131 <=> ker(pi+1) is a line <=> exactly one Galois-stable subgroup,
\\ and then prod(X - root) is its kernel polynomial.  No twist, no random points, no group orders are used.
default(parisize, 2000000000);
read("curves_input.gp");
a = ffgen(Mod(1,2)*(z^131+z^13+z^2+z+1), 'a);
fe(n) = subst(Pol(binary(n),'y), 'y, a) + 0*a;
toint(u) = my(p = (u+0*a).pol); if(type(p)=="t_POL", subst(lift(p*Mod(1,2)), variable(p), 2), lift(Mod(p,2)));
{
for(j = 1, #IDX,
  my(i = IDX[j], t0 = getabstime(), b = fe(BS[i]), E, psi, t1, r, t2, g, xs);
  E = ellinit([1,0,0,0,b], a);
  psi = elldivpol(E, 263, 'x);
  t1 = getabstime();
  r = polrootsmod(psi);
  t2 = getabstime();
  xs = vecsort(vector(#r, k, toint(r[k])));
  write(Str("divpol_", LABS[i], ".out"), LABS[i], "|", poldegree(psi), "|", #r, "|", #Set(xs), "|", if(#xs <= 200, xs, "big"), "|", t1 - t0, "|", t2 - t1);
  print(LABS[i], " deg=", poldegree(psi), " nroots=", #r, " divpol_ms=", t1 - t0, " roots_ms=", t2 - t1);
);
}
quit;
