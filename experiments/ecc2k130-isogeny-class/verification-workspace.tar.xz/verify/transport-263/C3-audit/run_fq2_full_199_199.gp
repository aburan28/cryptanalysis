I0=199;I1=199;FULL=1;
\\ C3 audit, part 4 (standalone PARI/gp): the F_{q^2} route re-implemented in PARI (own embedding via ffembed).
\\ For each curve E = [1,0,0,0,b]: ellcard/ellgroup of E over F_{q^2}; Q = (#E(F_q^2)/263^2) U with 263Q != 0; P = 263Q;
\\ checks Frob_q(P) = -P, x(kP) in F_q, y(P) not in F_q; abscissae mapped back to F_q as bitmask integers.
default(parisize, 800000000);
read("curves_input.gp");
a = ffgen(Mod(1,2)*(z^131+z^13+z^2+z+1), 'a);
g2 = ffgen(2^262, 'g);
m = ffembed(a, g2); mi = ffinvmap(m);
fe(n) = subst(Pol(binary(n),'y), 'y, a) + 0*a;
toint(u) = my(p = (u+0*a).pol); if(type(p)=="t_POL", subst(lift(p*Mod(1,2)), variable(p), 2), lift(Mod(p,2)));
Q2 = 2^131;
fr(P) = [P[1]^Q2, P[2]^Q2];
setrand(777 + I0);
CT2 = 2722258935367507707729280517973639940516 * 2722258935367507707684713200934651442782;  \\ #E(F_q) * #E'(F_q) = #E(F_{q^2})
if(type(FULL) != "t_INT", FULL = 0);
\\ embedding sanity
{ for(k=1,10, my(u = random(a), w = random(a)); if(ffmap(m, u*w) != ffmap(m,u)*ffmap(m,w) || ffmap(m,u+w) != ffmap(m,u)+ffmap(m,w) || ffmap(mi, ffmap(m,u)) != u, error("embedding"))); }
{
for(i = I0, I1,
  my(t0 = getabstime(), b = fe(BS[i]), E2, c2, G2, Q, P, xs, frobok, xin, ynot, v1, v2);
  E2 = ellinit([1,0,0,0,ffmap(m, b)], g2);
  c2 = if(FULL, ellcard(E2), CT2);
  G2 = if(FULL, ellgroup(E2), [c2]);
  v1 = valuation(G2[1], 263); v2 = if(#G2 > 1, valuation(G2[2], 263), 0);
  if(!FULL && i == 1, error("lite mode: run on floor curves only (I0 >= 2)"));
  if(v2 == 0,
    Q = [0]; until(ellmul(E2, Q, 263) != [0], Q = ellmul(E2, random(E2), c2/263^2));
    if(ellmul(E2, Q, 263^2) != [0], error("Q not killed by 263^2"));
    P = ellmul(E2, Q, 263);
    frobok = (fr(P) == ellneg(E2, P));
    ynot = (P[2]^Q2 != P[2]);
    xs = vector(131, k, ellmul(E2, P, k)[1]);
    xin = prod(k = 1, 131, xs[k]^Q2 == xs[k]);
    xs = vecsort(vector(131, k, toint(ffmap(mi, xs[k]))));
  , frobok = -1; ynot = -1; xin = -1; xs = []);
  write(Str("fq2_", if(FULL,"full_","lite_"), I0, "_", I1, ".out"), LABS[i], "|", c2, "|", G2, "|", if(v2 == 0, if(FULL, ellorder(E2, Q), \
    if(ellmul(E2, Q, 263) != [0] && ellmul(E2, Q, 263^2) == [0], 263^2, -2)), -1), "|", frobok, "|", xin, "|", ynot, "|", xs, "|", getabstime() - t0);
);
}
quit;
