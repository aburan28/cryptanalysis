/*
 * C4-recompute: independent C implementation of the floor -> E0 263-isogeny transport
 * for the ECC2K-130 isogeny class, with operation counters and CPU timing.
 *
 * Field: F_2[z]/(z^131 + z^13 + z^2 + z + 1), elements = 3 x uint64 (bit i = z^i).
 * Multiplication uses ARM PMULL (vmull_p64); inversion is Itoh-Tsujii (8 M + 130 S).
 * Curves: y^2 + x y = x^3 + a2 x^2 + b (affine).
 *
 * Transport (own derivation of Velu in char 2, a1=1, a3=a4=0):
 *   kernel half-set S = {k G : k = 1..131}, x_k = x(kG), T = sum x_k
 *   e = 1/(x + x_k), w = x_k e
 *   X = x + sum (w + w^2)
 *   Y = y + sum [ w + w^2 (w + x_k) + w e y ]           (y_Q terms cancel in char 2)
 *   codomain y^2 + xy = x^3 + T x + (b + T); map y -> y + T gives y^2+xy = x^3 + (b+T+T^2)
 *   so the image on E0 is (X, Y + T) iff b + T + T^2 = 1.
 *
 * Usage: ./transport_c4 input.txt selftest|run [n_eval_reps] [seed]
 */
#include <arm_neon.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct { uint64_t w[3]; } fe;

/* ---------------- counters ---------------- */
static uint64_t cM, cS, cI, cA;
static volatile uint64_t sink;
static int counting = 1;
#define CNT(c) do { if (counting) (c)++; } while (0)

/* ---------------- raw field arithmetic ---------------- */
static inline void clmul64(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    poly128_t p = vmull_p64((poly64_t)a, (poly64_t)b);
    uint64x2_t v = vreinterpretq_u64_p128(p);
    *lo = vgetq_lane_u64(v, 0);
    *hi = vgetq_lane_u64(v, 1);
}

static inline void xor_shifted(uint64_t *r, uint64_t W, int off) {
    int wi = off >> 6, bi = off & 63;
    r[wi] ^= W << bi;
    if (bi) r[wi + 1] ^= W >> (64 - bi);
}

/* reduce r[0..5] (degree <= 261) mod z^131 + z^13 + z^2 + z + 1 */
static inline void reduce(uint64_t *r, fe *out) {
    uint64_t W;
    /* r[5] is always 0 for products of reduced elements (deg <= 260) */
    W = r[4]; r[4] = 0;
    xor_shifted(r, W, 125); xor_shifted(r, W, 126); xor_shifted(r, W, 127); xor_shifted(r, W, 138);
    W = r[3]; r[3] = 0;
    xor_shifted(r, W, 61); xor_shifted(r, W, 62); xor_shifted(r, W, 63); xor_shifted(r, W, 74);
    W = r[2] >> 3; r[2] &= 7;
    r[0] ^= W; xor_shifted(r, W, 1); xor_shifted(r, W, 2); xor_shifted(r, W, 13);
    out->w[0] = r[0]; out->w[1] = r[1]; out->w[2] = r[2];
}

static inline void mul_raw(fe *o, const fe *a, const fe *b) {
    uint64_t r[6] = {0, 0, 0, 0, 0, 0}, lo, hi;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            clmul64(a->w[i], b->w[j], &lo, &hi);
            r[i + j] ^= lo; r[i + j + 1] ^= hi;
        }
    reduce(r, o);
}
static inline void sqr_raw(fe *o, const fe *a) {
    uint64_t r[6] = {0, 0, 0, 0, 0, 0};
    for (int i = 0; i < 3; i++) clmul64(a->w[i], a->w[i], &r[2 * i], &r[2 * i + 1]);
    reduce(r, o);
}
static inline void add_raw(fe *o, const fe *a, const fe *b) {
    o->w[0] = a->w[0] ^ b->w[0]; o->w[1] = a->w[1] ^ b->w[1]; o->w[2] = a->w[2] ^ b->w[2];
}
static inline int fe_eq(const fe *a, const fe *b) {
    return a->w[0] == b->w[0] && a->w[1] == b->w[1] && a->w[2] == b->w[2];
}
static inline int fe_is0(const fe *a) { return !(a->w[0] | a->w[1] | a->w[2]); }
static inline int fe_is1(const fe *a) { return a->w[0] == 1 && !a->w[1] && !a->w[2]; }

/* Itoh-Tsujii: a^(2^131-2); chain 1,2,4,8,16,32,64,128,130 -> 8 M + 130 S */
static int it_M, it_S;
static void inv_raw(fe *o, const fe *a) {
    /* b_k = a^(2^k - 1); b_{j+k} = b_j^(2^k) * b_k */
    fe b2, bk, t;
    it_M = it_S = 0;
    sqr_raw(&t, a); it_S++; mul_raw(&b2, &t, a); it_M++;          /* b2 */
    bk = b2;
    for (int k = 2; k <= 64; k *= 2) {                              /* b4, b8, ..., b128 */
        t = bk;
        for (int s = 0; s < k; s++) { sqr_raw(&t, &t); it_S++; }
        mul_raw(&bk, &t, &bk); it_M++;
    }
    t = bk;                                                          /* b130 = b128^(2^2) * b2 */
    for (int s = 0; s < 2; s++) { sqr_raw(&t, &t); it_S++; }
    mul_raw(&bk, &t, &b2); it_M++;
    sqr_raw(o, &bk); it_S++;                                         /* a^(2^131 - 2) = a^-1 */
}

/* counted wrappers */
static inline void fmul(fe *o, const fe *a, const fe *b) { CNT(cM); mul_raw(o, a, b); }
static inline void fsqr(fe *o, const fe *a) { CNT(cS); sqr_raw(o, a); }
static inline void fadd(fe *o, const fe *a, const fe *b) { CNT(cA); add_raw(o, a, b); }
static inline void finv(fe *o, const fe *a) { CNT(cI); inv_raw(o, a); }

/* trace: linear functional, computed with an uncounted precomputed mask */
static fe trmask;
static void init_trace(void) {
    memset(&trmask, 0, sizeof trmask);
    for (int i = 0; i < 131; i++) {
        fe e = {{0, 0, 0}}, s, acc = {{0, 0, 0}};
        e.w[i >> 6] = 1ULL << (i & 63);
        s = e;
        for (int k = 0; k < 131; k++) { add_raw(&acc, &acc, &s); sqr_raw(&s, &s); }
        /* acc must be 0 or 1 */
        if (!(fe_is0(&acc) || fe_is1(&acc))) { fprintf(stderr, "trace not in F2\n"); exit(1); }
        if (fe_is1(&acc)) trmask.w[i >> 6] |= 1ULL << (i & 63);
    }
}
static inline int trace(const fe *a) {
    uint64_t v = (a->w[0] & trmask.w[0]) ^ (a->w[1] & trmask.w[1]) ^ (a->w[2] & trmask.w[2]);
    return __builtin_parityll(v);
}
/* half-trace, m odd: H(c) = sum_{i=0}^{65} c^(4^i); H^2 + H = c + Tr(c). 130 S + 65 A */
static void halftrace(fe *o, const fe *c) {
    fe acc = *c, s = *c;
    for (int i = 1; i <= 65; i++) { fsqr(&s, &s); fsqr(&s, &s); fadd(&acc, &acc, &s); }
    *o = acc;
}

/* ---------------- RNG ---------------- */
static uint64_t rs = 88172645463325252ULL;
static uint64_t rnd64(void) { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static void fe_rand(fe *a) { a->w[0] = rnd64(); a->w[1] = rnd64(); a->w[2] = rnd64() & 7; }

/* ---------------- curve ---------------- */
typedef struct { fe x, y; int inf; } pt;
typedef struct { fe a2, b; } curve;

static int on_curve(const curve *E, const pt *P) {
    if (P->inf) return 1;
    int sv = counting; counting = 0;
    fe l, r, t, x2;
    sqr_raw(&l, &P->y); mul_raw(&t, &P->x, &P->y); add_raw(&l, &l, &t);
    sqr_raw(&x2, &P->x); mul_raw(&r, &x2, &P->x);
    mul_raw(&t, &x2, &E->a2); add_raw(&r, &r, &t); add_raw(&r, &r, &E->b);
    counting = sv;
    return fe_eq(&l, &r);
}

static pt pt_dbl(const curve *E, const pt *P) {
    pt R; R.inf = 0;
    if (P->inf || fe_is0(&P->x)) { R.inf = 1; return R; }
    fe ix, l, x2, t;
    finv(&ix, &P->x);
    fmul(&l, &P->y, &ix); fadd(&l, &l, &P->x);          /* lambda = x + y/x */
    fsqr(&t, &l); fadd(&t, &t, &l); fadd(&R.x, &t, &E->a2); /* x3 = l^2 + l + a2 */
    fsqr(&x2, &P->x);
    fe one = {{1, 0, 0}}, l1;
    fadd(&l1, &l, &one);
    fmul(&t, &l1, &R.x); fadd(&R.y, &x2, &t);          /* y3 = x^2 + (l+1) x3 */
    return R;
}

static pt pt_add(const curve *E, const pt *P, const pt *Q) {
    if (P->inf) return *Q;
    if (Q->inf) return *P;
    if (fe_eq(&P->x, &Q->x)) {
        if (fe_eq(&P->y, &Q->y)) return pt_dbl(E, P);
        pt R; R.inf = 1; return R;   /* Q = -P */
    }
    pt R; R.inf = 0;
    fe dx, dy, idx, l, t;
    fadd(&dx, &P->x, &Q->x); fadd(&dy, &P->y, &Q->y);
    finv(&idx, &dx);
    fmul(&l, &dy, &idx);
    fsqr(&t, &l); fadd(&t, &t, &l); fadd(&t, &t, &dx); fadd(&R.x, &t, &E->a2);
    fadd(&t, &P->x, &R.x); fmul(&t, &t, &l); fadd(&t, &t, &R.x); fadd(&R.y, &t, &P->y);
    return R;
}

static pt pt_neg(const pt *P) { pt R = *P; if (!P->inf) add_raw(&R.y, &P->y, &P->x); return R; }

/* scalar as 4 x uint64 little endian */
typedef struct { uint64_t w[4]; } sc;
static int sc_bits(const sc *k) { for (int i = 255; i >= 0; i--) if ((k->w[i >> 6] >> (i & 63)) & 1) return i + 1; return 0; }
static pt pt_mul(const curve *E, const sc *k, const pt *P) {
    pt R; R.inf = 1;
    for (int i = sc_bits(k) - 1; i >= 0; i--) {
        R = pt_dbl(E, &R);
        if ((k->w[i >> 6] >> (i & 63)) & 1) R = pt_add(E, &R, P);
    }
    return R;
}
static int pt_eq(const pt *P, const pt *Q) {
    if (P->inf || Q->inf) return P->inf == Q->inf;
    return fe_eq(&P->x, &Q->x) && fe_eq(&P->y, &Q->y);
}

/* random affine point: need u^2 + u = c = (x^3 + a2 x^2 + b)/x^2 = x + a2 + b/x^2 */
static pt pt_random(const curve *E) {
    for (;;) {
        pt P; P.inf = 0;
        fe x, x2, ix2, c, u;
        fe_rand(&x);
        if (fe_is0(&x)) continue;
        fsqr(&x2, &x); finv(&ix2, &x2); fmul(&c, &E->b, &ix2);
        fadd(&c, &c, &x); fadd(&c, &c, &E->a2);
        if (trace(&c)) continue;
        halftrace(&u, &c);
        if (rnd64() & 1) { fe one = {{1, 0, 0}}; fadd(&u, &u, &one); }
        P.x = x; fmul(&P.y, &x, &u);
        return P;
    }
}

/* ---------------- hex parsing ---------------- */
static void hex_to_words(const char *h, uint64_t *w, int nw) {
    memset(w, 0, 8 * nw);
    int L = strlen(h), bit = 0;
    for (int i = L - 1; i >= 0; i--, bit += 4) {
        char c = h[i]; int v;
        if (c >= '0' && c <= '9') v = c - '0'; else if (c >= 'a' && c <= 'f') v = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') v = c - 'A' + 10; else { bit -= 4; continue; }
        if (bit / 64 < nw) w[bit / 64] |= (uint64_t)v << (bit % 64);
    }
}
static void fe_print(FILE *f, const fe *a) { fprintf(f, "%01llx%016llx%016llx", (unsigned long long)a->w[2], (unsigned long long)a->w[1], (unsigned long long)a->w[0]); }

/* ---------------- CPU time ---------------- */
static double cpu_now(void) {
    struct timespec ts; clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
    return ts.tv_sec + 1e-9 * ts.tv_nsec;
}

/* ---------------- transport ---------------- */
#define NK 131
typedef struct { fe xs[NK]; fe T; int ok; } kernel;

static sc NN, COF, S263, S4;

/* Build the kernel of the unique F_q-rational (as a group) 263-isogeny E_b -> E0
 * from scratch: random point on the twist y^2+xy = x^3+x^2+b, times (q+1+t)/263^2,
 * times 263 if needed; the result G (order 263) generates the kernel.
 * The twist isomorphism (x,y)->(x,y+s x), s^2+s=1, preserves x, so x(kG) on the twist
 * are the kernel x-coordinates on E_b.  Returns the number of point attempts. */
static int build_kernel(const fe *b, kernel *K) {
    curve Et; memset(&Et, 0, sizeof Et); Et.a2.w[0] = 1; Et.b = *b;
    int attempts = 0;
    pt G;
    for (;;) {
        attempts++;
        pt P = pt_random(&Et);
        pt R = pt_mul(&Et, &COF, &P);          /* order | 263^2 */
        if (R.inf) continue;
        pt R2 = pt_mul(&Et, &S263, &R);
        if (R2.inf) { G = R; break; }          /* R has order 263 */
        G = R2;                                 /* R had order 263^2 */
        break;
    }
    /* sanity (uncounted): 263 G = O */
    int sv = counting; counting = 0;
    pt chk = pt_mul(&Et, &S263, &G);
    counting = sv;
    if (!chk.inf || G.inf) { K->ok = 0; return attempts; }
    pt Pk = G;
    K->xs[0] = G.x;
    pt G2 = pt_dbl(&Et, &G);
    Pk = G2; K->xs[1] = G2.x;
    for (int k = 2; k < NK; k++) { Pk = pt_add(&Et, &Pk, &G); K->xs[k] = Pk.x; }
    fe T = {{0, 0, 0}};
    for (int k = 0; k < NK; k++) fadd(&T, &T, &K->xs[k]);
    K->T = T;
    K->ok = 1;
    return attempts;
}

/* factored evaluation: 390 M + 1 I (batch inversion) + 131*(3 M + 1 S) + 1 M */
static pt eval_fact(const kernel *K, const pt *P) {
    fe d[NK], c[NK], e[NK], inv, t;
    for (int i = 0; i < NK; i++) fadd(&d[i], &P->x, &K->xs[i]);
    c[0] = d[0];
    for (int i = 1; i < NK; i++) fmul(&c[i], &c[i - 1], &d[i]);
    finv(&inv, &c[NK - 1]);
    for (int i = NK - 1; i >= 1; i--) { fmul(&e[i], &inv, &c[i - 1]); fmul(&inv, &inv, &d[i]); }
    e[0] = inv;
    fe Sw = {{0, 0, 0}}, Sw2 = {{0, 0, 0}}, Sa = {{0, 0, 0}}, Sb = {{0, 0, 0}};
    for (int i = 0; i < NK; i++) {
        fe w, w2, s, a, bb;
        fmul(&w, &K->xs[i], &e[i]);
        fsqr(&w2, &w);
        fadd(&s, &K->xs[i], &w);
        fmul(&a, &w2, &s);
        fmul(&bb, &w, &e[i]);
        fadd(&Sw, &Sw, &w); fadd(&Sw2, &Sw2, &w2); fadd(&Sa, &Sa, &a); fadd(&Sb, &Sb, &bb);
    }
    pt R; R.inf = 0;
    fadd(&t, &P->x, &Sw); fadd(&R.x, &t, &Sw2);
    fe yb; fmul(&yb, &P->y, &Sb);
    fadd(&t, &P->y, &Sw); fadd(&t, &t, &Sa); fadd(&t, &t, &yb); fadd(&R.y, &t, &K->T);
    return R;
}

/* naive evaluation: per term 4 M + 1 S (w, w^2(w+x), w e, (w e) y) -> 390 + 524 = 914 M */
static pt eval_naive(const kernel *K, const pt *P) {
    fe d[NK], c[NK], e[NK], inv, t;
    for (int i = 0; i < NK; i++) fadd(&d[i], &P->x, &K->xs[i]);
    c[0] = d[0];
    for (int i = 1; i < NK; i++) fmul(&c[i], &c[i - 1], &d[i]);
    finv(&inv, &c[NK - 1]);
    for (int i = NK - 1; i >= 1; i--) { fmul(&e[i], &inv, &c[i - 1]); fmul(&inv, &inv, &d[i]); }
    e[0] = inv;
    fe SX = {{0, 0, 0}}, SY = {{0, 0, 0}};
    for (int i = 0; i < NK; i++) {
        fe w, w2, s, a, we, wey;
        fmul(&w, &K->xs[i], &e[i]);
        fsqr(&w2, &w);
        fadd(&SX, &SX, &w); fadd(&SX, &SX, &w2);
        fadd(&s, &K->xs[i], &w);
        fmul(&a, &w2, &s);
        fmul(&we, &w, &e[i]);
        fmul(&wey, &we, &P->y);
        fadd(&SY, &SY, &w); fadd(&SY, &SY, &a); fadd(&SY, &SY, &wey);
    }
    pt R; R.inf = 0;
    fadd(&R.x, &P->x, &SX);
    fadd(&t, &P->y, &SY); fadd(&R.y, &t, &K->T);
    return R;
}

static void snap(uint64_t *o) { o[0] = cM; o[1] = cS; o[2] = cI; o[3] = cA; }
static void diff(uint64_t *o, const uint64_t *a) { o[0] = cM - a[0]; o[1] = cS - a[1]; o[2] = cI - a[2]; o[3] = cA - a[3]; }

static void sc_from_u64(sc *k, uint64_t a, uint64_t b) { memset(k, 0, sizeof *k); k->w[0] = a; k->w[1] = b; }
static void sc_rand_modN(sc *k) {
    /* random 128-bit (< 2^128 < N) nonzero */
    sc_from_u64(k, rnd64(), rnd64() >> 1);
    if (!k->w[0] && !k->w[1]) k->w[0] = 1;
}

/* microbenchmarks */
static double bench_M(long n) { fe a, b; fe_rand(&a); fe_rand(&b); double t0 = cpu_now(); for (long i = 0; i < n; i++) mul_raw(&a, &a, &b); double t1 = cpu_now(); if (fe_is0(&a)) printf("#"); return (t1 - t0) / n; }
static double bench_S(long n) { fe a; fe_rand(&a); double t0 = cpu_now(); for (long i = 0; i < n; i++) sqr_raw(&a, &a); double t1 = cpu_now(); if (fe_is0(&a)) printf("#"); return (t1 - t0) / n; }
static double bench_I(long n) { fe a; fe_rand(&a); double t0 = cpu_now(); for (long i = 0; i < n; i++) { inv_raw(&a, &a); a.w[0] ^= 2; } double t1 = cpu_now(); if (fe_is0(&a)) printf("#"); return (t1 - t0) / n; }

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage\n"); return 1; }
    int reps = argc > 3 ? atoi(argv[3]) : 200;
    if (argc > 4) rs = strtoull(argv[4], 0, 10) | 1;
    init_trace();
    FILE *f = fopen(argv[1], "r");
    char buf[512];
    fscanf(f, "%511s", buf); hex_to_words(buf, NN.w, 4);
    fscanf(f, "%511s", buf); hex_to_words(buf, COF.w, 4);
    sc_from_u64(&S263, 263, 0); sc_from_u64(&S4, 4, 0);
    int ncurves; fscanf(f, "%d", &ncurves);

    if (!strcmp(argv[2], "selftest")) {
        /* print random a, b, a*b, a^2, a^-1, halftrace data for external checking */
        for (int i = 0; i < 200; i++) {
            fe a, b, p, s, iv;
            fe_rand(&a); fe_rand(&b);
            if (i == 0) { memset(&a, 0, sizeof a); a.w[2] = 4; a.w[0] = 1; }       /* z^130 + 1 */
            if (i == 1) { memset(&a, 0xff, sizeof a); a.w[2] = 7; b = a; }         /* all ones */
            mul_raw(&p, &a, &b); sqr_raw(&s, &a);
            if (fe_is0(&a)) continue;
            inv_raw(&iv, &a);
            fe_print(stdout, &a); printf(" "); fe_print(stdout, &b); printf(" ");
            fe_print(stdout, &p); printf(" "); fe_print(stdout, &s); printf(" "); fe_print(stdout, &iv);
            printf(" %d\n", trace(&a));
        }
        fprintf(stderr, "itoh-tsujii chain: M=%d S=%d\n", it_M, it_S);
        return 0;
    }

    if (!strcmp(argv[2], "dump")) {   /* print kernel x-coordinates for the first `reps` floor curves */
        int done = 0;
        for (int ci = 0; ci < ncurves && done < reps; ci++) {
            char lab[64]; fscanf(f, "%63s %511s", lab, buf);
            if (!strcmp(lab, "E0")) continue;
            fe b; hex_to_words(buf, b.w, 3);
            kernel K; build_kernel(&b, &K);
            printf("%s %s", lab, buf);
            for (int k = 0; k < NK; k++) { printf(" "); fe_print(stdout, &K.xs[k]); }
            printf("\n"); done++;
        }
        return 0;
    }
    double tM = 1e9, tS = 1e9, tI = 1e9;
    for (int r = 0; r < 5; r++) {
        double v;
        if ((v = bench_M(2000000)) < tM) tM = v;
        if ((v = bench_S(2000000)) < tS) tS = v;
        if ((v = bench_I(100000)) < tI) tI = v;
    }
    /* E0 affine addition timing (proxy for one rho step's core) */
    curve E0; memset(&E0, 0, sizeof E0); E0.b.w[0] = 1;
    double tAdd = 1e9;
    {
        pt P = pt_random(&E0), Q = pt_random(&E0);
        for (int r = 0; r < 5; r++) {
            double t0 = cpu_now();
            for (int i = 0; i < 200000; i++) { P = pt_add(&E0, &P, &Q); }
            double v = (cpu_now() - t0) / 200000;
            if (v < tAdd) tAdd = v;
        }
    }
    printf("{\"calib\":{\"M_s\":%.4e,\"S_s\":%.4e,\"I_s\":%.4e,\"E0_affine_add_s\":%.4e,\"IT_M\":%d,\"IT_S\":%d}}\n", tM, tS, tI, tAdd, it_M, it_S);
    fflush(stdout);

    for (int ci = 0; ci < ncurves; ci++) {
        char lab[64];
        fscanf(f, "%63s %511s", lab, buf);
        curve E; memset(&E, 0, sizeof E); hex_to_words(buf, E.b.w, 3);
        if (!strcmp(lab, "E0")) continue;
        uint64_t s0[4], ob[4], oe[4], on[4];
        kernel K;
        /* ---- build (counted, timed) ---- */
        snap(s0);
        double tb0 = cpu_now();
        int attempts = build_kernel(&E.b, &K);
        double tb = cpu_now() - tb0;
        diff(ob, s0);
        /* repeat build a few times for timing min (uncounted) */
        counting = 0;
        double tbmin = tb;
        for (int r = 0; r < 5; r++) { kernel K2; double t0 = cpu_now(); build_kernel(&E.b, &K2); double v = cpu_now() - t0; if (v < tbmin) tbmin = v;
            /* kernel x-set must be the same (unique rational 263-subgroup): compare sum and product */
            if (!fe_eq(&K2.T, &K.T)) { fprintf(stderr, "%s kernel not unique?!\n", lab); } }
        counting = 1;
        /* codomain check b + T + T^2 == 1 */
        fe T2, cod; sqr_raw(&T2, &K.T); add_raw(&cod, &E.b, &K.T); add_raw(&cod, &cod, &T2);
        int cod_is_E0 = fe_is1(&cod);
        /* ---- points on E in the N-subgroup ---- */
        counting = 0;
        pt P = pt_random(&E); P = pt_mul(&E, &S4, &P);
        pt P2 = pt_random(&E); P2 = pt_mul(&E, &S4, &P2);
        pt NP = pt_mul(&E, &NN, &P);
        int P_orderN = NP.inf && !P.inf;
        sc k; sc_rand_modN(&k);
        pt Q = pt_mul(&E, &k, &P);
        pt PP2 = pt_add(&E, &P, &P2);
        counting = 1;
        /* ---- eval counted ---- */
        snap(s0); pt fP = eval_fact(&K, &P); diff(oe, s0);
        snap(s0); pt fPn = eval_naive(&K, &P); diff(on, s0);
        counting = 0;
        pt fQ = eval_fact(&K, &Q), fP2 = eval_fact(&K, &P2), fPP2 = eval_fact(&K, &PP2);
        pt kfP = pt_mul(&E0, &k, &fP);
        pt sum = pt_add(&E0, &fP, &fP2);
        pt NfP = pt_mul(&E0, &NN, &fP);
        int ok_on = on_curve(&E0, &fP) && on_curve(&E0, &fQ) && on_curve(&E0, &fP2) && on_curve(&E0, &fPP2);
        int ok_same = pt_eq(&fP, &fPn);
        int ok_dlp = pt_eq(&fQ, &kfP);
        int ok_hom = pt_eq(&sum, &fPP2);
        int ok_ord = NfP.inf && !fP.inf;
        /* negative controls: (a) perturb one kernel x -> image should leave E0;
                              (b) evaluate a point of the WRONG curve (E0 point) -> DLP relation should fail */
        kernel Kbad = K; Kbad.xs[17].w[0] ^= 1;
        pt fbad = eval_fact(&Kbad, &P);
        int neg_a_detected = !on_curve(&E0, &fbad);
        /* (c) drop the y-term (wrong Y formula) */
        pt fwrongY = fP; add_raw(&fwrongY.y, &fwrongY.y, &K.T);   /* forget the y -> y + T isomorphism */
        int neg_c_detected = !on_curve(&E0, &fwrongY);
        /* ---- eval timing ---- */
        double temin = 1e9;
        for (int r = 0; r < 3; r++) {
            double t0 = cpu_now();
            for (int i = 0; i < reps; i++) { pt z = eval_fact(&K, &P); sink ^= z.x.w[0] ^ z.y.w[1]; }
            double v = (cpu_now() - t0) / reps;
            if (v < temin) temin = v;
        }
        counting = 1;
        printf("{\"label\":\"%s\",\"attempts\":%d,\"build\":{\"M\":%llu,\"S\":%llu,\"I\":%llu,\"A\":%llu},"
               "\"eval_fact\":{\"M\":%llu,\"S\":%llu,\"I\":%llu,\"A\":%llu},"
               "\"eval_naive\":{\"M\":%llu,\"S\":%llu,\"I\":%llu,\"A\":%llu},"
               "\"build_s_first\":%.4e,\"build_s_min\":%.4e,\"eval_s_min\":%.4e,"
               "\"kernel_ok\":%d,\"codomain_is_E0\":%d,\"P_order_N\":%d,\"image_on_E0\":%d,\"fact_eq_naive\":%d,"
               "\"dlp_preserved\":%d,\"hom\":%d,\"image_order_N\":%d,\"neg_perturbed_kernel_detected\":%d,\"neg_no_iso_detected\":%d}\n",
               lab, attempts,
               (unsigned long long)ob[0], (unsigned long long)ob[1], (unsigned long long)ob[2], (unsigned long long)ob[3],
               (unsigned long long)oe[0], (unsigned long long)oe[1], (unsigned long long)oe[2], (unsigned long long)oe[3],
               (unsigned long long)on[0], (unsigned long long)on[1], (unsigned long long)on[2], (unsigned long long)on[3],
               tb, tbmin, temin, K.ok, cod_is_E0, P_orderN, ok_on, ok_same, ok_dlp, ok_hom, ok_ord, neg_a_detected, neg_c_detected);
        fflush(stdout);
    }
    return 0;
}
