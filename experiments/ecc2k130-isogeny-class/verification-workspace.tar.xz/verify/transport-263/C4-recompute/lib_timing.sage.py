# Library cross-check (order of magnitude only; the machine is heavily loaded):
#  - Sage EllipticCurveIsogeny from the kernel polynomial prod (X - x_k) (x_k from the C code)
#  - PARI ellisogeny from the same kernel polynomial
#  - the closed-form char-2 Velu map used in the C code agrees with Sage's isogeny (up to the
#    F_q-isomorphism of the codomain onto E0 and the automorphism -1).
import json, os, sys, time
from sage.all import prod, GF, PolynomialRing, EllipticCurve, EllipticCurveIsogeny, pari, set_random_seed, cputime
HERE = os.path.dirname(os.path.abspath(__file__))
set_random_seed(4)
R2 = PolynomialRing(GF(2), "z"); z = R2.gen()
K = GF(2 ** 131, "z", modulus=z ** 131 + z ** 13 + z ** 2 + z + 1)
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
n = int(sys.argv[1]) if len(sys.argv) > 1 else 2
res = []
for line in open(os.path.join(HERE, "kernels_dump.txt")).read().split("\n")[:n]:
    tok = line.split()
    lab, b = tok[0], K.from_integer(int(tok[1], 16))
    xs = [K.from_integer(int(h, 16)) for h in tok[2:]]
    E = EllipticCurve(K, [1, 0, 0, 0, b])
    PX = PolynomialRing(K, "X"); X = PX.gen()
    t0 = cputime(); kp = prod(X - xk for xk in xs); t_kp = cputime(t0)
    # Sage library isogeny
    t0 = cputime(); phi = EllipticCurveIsogeny(E, kp); t_sage = cputime(t0)
    Ecod = phi.codomain()
    # PARI library isogeny
    Ep = pari(E)
    t0 = cputime(); iso_p = pari.ellisogeny(Ep, pari(kp)); t_pari = cputime(t0)
    # closed-form map (same formula as the C code)
    T = sum(xs)

    def myphi(P):
        x, y = P.xy()
        Sw = Sw2 = Sa = Sb = K(0)
        for xk in xs:
            e = 1 / (x + xk); w = xk * e
            Sw += w; Sw2 += w * w; Sa += w * w * (w + xk); Sb += w * e
        return E0(x + Sw + Sw2, y + Sw + Sa + y * Sb + T)

    iso = Ecod.isomorphism_to(E0)
    agree = 0
    for _ in range(3):
        P = 4 * E.random_point()
        A_ = iso(phi(P)); B_ = myphi(P)
        agree += int(A_ == B_ or A_ == -B_)
    r = {"label": lab, "sage_codomain_j": str(Ecod.j_invariant()), "t_kernelpoly_s": float(t_kp),
         "sage_isogeny_cpu_s": float(t_sage), "pari_ellisogeny_cpu_s": float(t_pari),
         "pari_codomain_j": str(EllipticCurve(K, [K(c) for c in iso_p[0]]).j_invariant()),
         "closed_form_equals_sage_up_to_sign_3of3": agree}
    print(json.dumps(r)); sys.stdout.flush()
    res.append(r)
json.dump(res, open(os.path.join(HERE, "lib_timing.json"), "w"), indent=1)
