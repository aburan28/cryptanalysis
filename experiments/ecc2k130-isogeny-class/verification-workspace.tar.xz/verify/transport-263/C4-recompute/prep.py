# C4-recompute: independent constants + input file for the C transport code.
# Plain python3 (no Sage).  Constants re-derived from the Lucas recurrence,
# then compared with ground_truth.json (which is only used for the list of b's).
import json, math, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"

m = 131
q = 1 << m
# #E0(F_2): brute force over F_2 for y^2+xy = x^3+1
cnt = 1
for x in (0, 1):
    for y in (0, 1):
        if (y * y + x * y - (x ** 3 + 1)) % 2 == 0:
            cnt += 1
t1 = 2 + 1 - cnt
# Lucas: t_{k+1} = t1*t_k - 2*t_{k-1}, t_0 = 2
a, b = 2, t1
for _ in range(m - 1):
    a, b = b, t1 * b - 2 * a
t = b
card = q + 1 - t
twist = q + 1 + t
assert card % 4 == 0
N = card // 4


def is_probable_prime(n):
    if n < 2:
        return False
    for p in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for a_ in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53]:
        x = pow(a_, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


assert twist % (263 * 263) == 0 and twist % (263 ** 3) != 0
cof = twist // (263 * 263)
gt = json.load(open(GT))
meta = gt["meta"]
checks = {
    "E0_F2_count": cnt,
    "t": str(t),
    "t_matches_gt": str(t) == str(meta["t"]),
    "N_matches_gt": str(N) == str(meta["N"]),
    "twist_matches_gt": str(twist) == str(meta["twist_card"]),
    "N_probable_prime": is_probable_prime(N),
    "cof": str(cof),
    "cof_over_2_probable_prime": is_probable_prime(cof // 2),
    "cof_bits": cof.bit_length(),
    "N_bits": N.bit_length(),
    "log2N": math.log2(N),
}
print(json.dumps(checks, indent=1))
assert checks["t_matches_gt"] and checks["N_matches_gt"] and checks["twist_matches_gt"]

with open(os.path.join(HERE, "input.txt"), "w") as f:
    f.write("%x\n%x\n" % (N, cof))
    f.write("%d\n" % len(gt["curves"]))
    for c in gt["curves"]:
        assert c["a2"] == 0
        f.write("%s %x\n" % (c["label"], int(c["b_int"])))
json.dump(checks, open(os.path.join(HERE, "prep_checks.json"), "w"), indent=1)
