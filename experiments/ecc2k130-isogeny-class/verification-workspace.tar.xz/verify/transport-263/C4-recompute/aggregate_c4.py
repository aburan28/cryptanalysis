# Aggregate the C run + recompute rho baselines at high precision (mpmath) and the
# effective-hardness increment, independently of the sweep's aggregate.py.
import json, os, statistics
from mpmath import mp, mpf, log, pi, sqrt, log1p
mp.dps = 60
HERE = os.path.dirname(os.path.abspath(__file__))
lines = [json.loads(l) for l in open(os.path.join(HERE, "run.jsonl"))]
cal = lines[0]["calib"]
rows = [r for r in lines[1:]]
assert len(rows) == 262, len(rows)
N = int(open(os.path.join(HERE, "input.txt")).readline(), 16)

checks = ["kernel_ok", "codomain_is_E0", "P_order_N", "image_on_E0", "fact_eq_naive", "dlp_preserved",
          "hom", "image_order_N", "neg_perturbed_kernel_detected", "neg_no_iso_detected"]
out = {"n_curves": len(rows), "labels_A": sum(r["label"].startswith("A") for r in rows),
       "labels_B": sum(r["label"].startswith("B") for r in rows)}
out["checks_all_262"] = {c: sum(r[c] for r in rows) for c in checks}


def rng(key, sub):
    v = [r[key][sub] for r in rows]
    return [min(v), statistics.median(v), max(v)]


for k in ["build", "eval_fact", "eval_naive"]:
    out[k + "_ops_min_med_max"] = {s: rng(k, s) for s in "MSIA"}
out["eval_fact_distinct"] = sorted({json.dumps(r["eval_fact"], sort_keys=True) for r in rows})
out["eval_naive_distinct"] = sorted({json.dumps(r["eval_naive"], sort_keys=True) for r in rows})
out["attempts_max"] = max(r["attempts"] for r in rows)
for k in ["build_s_min", "eval_s_min"]:
    v = [r[k] for r in rows]
    out[k + "_min_med_max"] = [min(v), statistics.median(v), max(v)]
out["calibration_C"] = cal

IT = cal["IT_M"] + cal["IT_S"]   # I <= 8 M + 130 S, S counted as M -> 138 M


def mequiv(o):
    return o["M"] + o["S"] + o["I"] * IT


def mequiv_withA(o):
    return o["M"] + o["S"] + o["I"] * IT + o["A"]


costs = []
for r in rows:
    c_fact = mequiv(r["build"]) + 2 * mequiv(r["eval_fact"])
    c_naive = mequiv(r["build"]) + 2 * mequiv(r["eval_naive"])
    c_naive_A = mequiv_withA(r["build"]) + 2 * mequiv_withA(r["eval_naive"])
    # CPU seconds -> E0 affine additions (C, same process)
    sec = r["build_s_min"] + 2 * r["eval_s_min"]
    costs.append((c_fact, c_naive, c_naive_A, sec, sec / cal["E0_affine_add_s"]))
import math
out["transport_M_equiv_fact_min_max"] = [min(c[0] for c in costs), max(c[0] for c in costs)]
out["transport_M_equiv_naive_min_max"] = [min(c[1] for c in costs), max(c[1] for c in costs)]
out["transport_M_equiv_naive_plusA_min_max"] = [min(c[2] for c in costs), max(c[2] for c in costs)]
out["log2_transport_M_equiv_naive_plusA_max"] = math.log2(max(c[2] for c in costs))
out["log2_transport_M_equiv_fact_max"] = math.log2(max(c[0] for c in costs))
out["transport_cpu_seconds_min_max"] = [min(c[3] for c in costs), max(c[3] for c in costs)]
out["transport_E0add_equiv_C_min_max"] = [min(c[4] for c in costs), max(c[4] for c in costs)]

# rho baselines (high precision)
Nm = mpf(N)
rho_tau = log(sqrt(pi * Nm / (4 * 131)), 2)
rho_neg = log(sqrt(pi * Nm / 4), 2)
out["log2N"] = str(log(Nm, 2))
out["rho_E0_neg_tau_log2"] = str(rho_tau)
out["rho_floor_neg_only_log2"] = str(rho_neg)
out["rho_gap_bits"] = str(rho_neg - rho_tau)   # = log2(sqrt(131))
out["half_log2_131"] = str(log(131, 2) / 2)


def eff_inc(c):
    return log1p(mpf(c) / mpf(2) ** rho_tau) / log(2)


worstM = max(c[2] for c in costs)
out["effective_increment_bits_Mequiv_worst"] = str(eff_inc(worstM))
out["effective_log2_Mequiv_worst"] = str(rho_tau + eff_inc(worstM))
# the claim's own worst figure (Sage build, E0-add-equivalents) 5277433.98 from summary.json
out["effective_increment_bits_claim_sage_worst_5277434"] = str(eff_inc(5277433.978556505))
# a deliberately absurd bound: even 1 hour of CPU per transport measured in E0 affine adds (C)
out["effective_increment_bits_if_transport_1h_cpu"] = str(eff_inc(3600 / cal["E0_affine_add_s"]))
# how large would transport have to be to move the hardness by 0.01 bit?
out["transport_needed_for_0.01bit_log2"] = str(rho_tau + log(mpf(2) ** mpf("0.01") - 1, 2))
json.dump(out, open(os.path.join(HERE, "summary_c4.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
