# Check the C field arithmetic (PMULL + word reduction + Itoh-Tsujii + trace mask)
# against (1) a bit-serial Python big-int implementation and (2) Sage GF(2^131).
import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__))
F = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1


def pmul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        b >>= 1
        a <<= 1
        if a >> 131:
            a ^= F
    return r


def ppow(a, e):
    r = 1
    while e:
        if e & 1:
            r = pmul(r, a)
        a = pmul(a, a)
        e >>= 1
    return r


def tr(a):
    s, acc = a, 0
    for _ in range(131):
        acc ^= s
        s = pmul(s, s)
    assert acc in (0, 1)
    return acc


rows = [l.split() for l in open(os.path.join(HERE, "selftest.txt"))]
bad = 0
for a, b, p, s, iv, t in rows:
    a, b, p, s, iv, t = int(a, 16), int(b, 16), int(p, 16), int(s, 16), int(iv, 16), int(t)
    ok = pmul(a, b) == p and pmul(a, a) == s and pmul(a, iv) == 1 and tr(a) == t
    bad += not ok
res = {"rows": len(rows), "python_bitserial_mismatches": bad}
try:
    from sage.all import GF, PolynomialRing
    R = PolynomialRing(GF(2), "z")
    z = R.gen()
    K = GF(2 ** 131, "z", modulus=z ** 131 + z ** 13 + z ** 2 + z + 1)
    bad2 = 0
    for a, b, p, s, iv, t in rows[:60]:
        A, B = K.from_integer(int(a, 16)), K.from_integer(int(b, 16))
        ok = ((A * B).to_integer() == int(p, 16) and (A ** 2).to_integer() == int(s, 16)
              and (A ** -1).to_integer() == int(iv, 16) and int(A.trace()) == int(t))
        bad2 += not ok
    res["sage_checked"] = 60
    res["sage_mismatches"] = bad2
except ImportError:
    res["sage"] = "not available in this interpreter"
print(json.dumps(res))
json.dump(res, open(os.path.join(HERE, "selftest_check.json"), "w"))
