"""
Uniqueness of the F_q-rational 263-subgroup of every floor curve (pure Python, gf2_131):
  v_263(#E'(F_q)) = 2 with #E' = q+1+t, and E'(F_q) has a point of order 263^2  => E'(F_q)[263^oo] = Z/263^2,
  so E'(F_q)[263] (= the x-set of the unique pi-stable 263-line of E) is unique; also 263 does not divide #E = 4N.
  Also checks the file kernel x-set equals the x-set of [263]Q for that order-263^2 point Q (same unique subgroup).
Run: python3 uniqueness_check.py
"""
import json, os, sys, random
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import gf2_131 as F
gt = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
q, t, N = int(gt["meta"]["q"]), int(gt["meta"]["t"]), int(gt["meta"]["N"])
TW = q + 1 + t
assert TW == int(gt["meta"]["twist_card"])
v263 = 0; m = TW
while m % 263 == 0: m //= 263; v263 += 1
COF = TW // 263**2
B = {c["label"]: int(c["b_int"]) for c in gt["curves"] if c["label"] != "E0"}
kall = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"))
rng = random.Random("C5-uniqueness")
cyc = same = 0
for lab, b in B.items():
    for _ in range(40):
        x = rng.getrandbits(131)
        P = F.lift_x(x, 1, b) if x else None
        if P is None: continue
        Q = F.smul(COF, P, 1)
        if Q is not None and F.smul(263, Q, 1) is not None:
            break
    else:
        continue
    assert F.smul(263 * 263, Q, 1) is None
    cyc += 1
    G = F.smul(263, Q, 1); xs, R = set(), G
    for i in range(131):
        xs.add(R[0]); R = F.add(R, G, 1)
    same += xs == {int(h, 16) for h in kall[lab]}
res = {"v263_twist_card": v263, "v263_card_4N": int((4 * N) % 263 == 0), "twist_263_sylow_cyclic_count": cyc,
       "file_kernel_eq_263Q_subgroup_count": same, "n": len(B)}
print(res); json.dump(res, open(os.path.join(HERE, "results_uniqueness.json"), "w"), indent=1)
