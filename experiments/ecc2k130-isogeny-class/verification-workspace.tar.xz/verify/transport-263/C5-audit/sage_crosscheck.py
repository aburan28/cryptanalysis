"""
Sage cross-check for the C5 audit (run: sage -python sage_crosscheck.py):
  * my pure-Python field (gf2_131) == Sage GF(2^131) with modulus z^131+z^13+z^2+z+1 on random products
  * for 3 edges (A130->A000, B130->B000 wrap-arounds, A064->A065): build Sage's isogeny E_next -> C from the
    kernel polynomial prod (X - x^2), x in ker(prev) [Kohel], map C -> E0 by Sage's isomorphism_to, and compare
    with my Velu (gf2_131.velu_to_E0) on a random order-N point, up to Aut(E0) = {+-1}; planted scalar via Sage
  * timing of the 131 squarings (one Frobenius step of one kernel) in Sage/NTL with timeit
"""
import sys, os, json, time, random, timeit
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf2_131 as F
from sage.all import GF, PolynomialRing, EllipticCurve, prod, set_random_seed

gt = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
N = int(gt["meta"]["N"])
CARD = int(gt["meta"]["card"])
B = {c["label"]: int(c["b_int"]) for c in gt["curves"]}
kall = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"))
z = PolynomialRing(GF(2), "z").gen()
K = GF(2 ** 131, "z", modulus=z ** 131 + z ** 13 + z ** 2 + z + 1)
rng = random.Random("C5-sage-crosscheck")
set_random_seed(20260923 + 5)
out = {}
ok = True
for _ in range(300):
    a, b = rng.getrandbits(131), rng.getrandbits(131)
    ok &= int((K.from_integer(a) * K.from_integer(b)).to_integer()) == F.mul(a, b)
    ok &= int((K.from_integer(a) ** 2).to_integer()) == F.sqr(a)
out["field_matches_sage_300_random"] = bool(ok)
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
RX = PolynomialRing(K, "X")
X = RX.gen()
edges = {}
for prev, nxt in [("A130", "A000"), ("B130", "B000"), ("A064", "A065")]:
    xs_int = [F.sqr(int(h, 16)) for h in kall[prev]]           # conjugated kernel of prev
    xs = [K.from_integer(u) for u in xs_int]
    E = EllipticCurve(K, [1, 0, 0, 0, K.from_integer(B[nxt])])
    E.set_order(CARD)
    h = prod([X - u for u in xs])
    c = time.process_time()
    phi = E.isogeny(h)
    iso = phi.codomain().isomorphism_to(E0)
    tb = time.process_time() - c
    R = 4 * E.random_point()
    assert not R.is_zero() and (N * R).is_zero()
    k = rng.randrange(2, N - 1)
    sR, sS = iso(phi(R)), iso(phi(k * R))
    mine = F.velu_to_E0(xs_int, int(R[0].to_integer()), int(R[1].to_integer()))
    mineP = E0(K.from_integer(mine[0]), K.from_integer(mine[1]))
    edges["%s->%s" % (prev, nxt)] = {
        "sage_degree": int(phi.degree()),
        "sage_codomain_j_is_1": bool(phi.codomain().j_invariant() == 1),
        "my_velu_equals_sage": bool(mineP == sR),
        "my_velu_equals_minus_sage": bool(mineP == -sR),
        "sage_planted_ok": bool((not sR.is_zero()) and (N * sR).is_zero() and sS == k * sR),
        "sage_build_cpu_s": round(tb, 2),
    }
    print(prev, "->", nxt, edges["%s->%s" % (prev, nxt)], flush=True)
out["edges"] = edges
xs = [K.from_integer(int(h, 16)) for h in kall["A000"]]
n = 2000
tt = timeit.timeit(lambda: [u * u for u in xs], number=n) / n
tt2 = min(timeit.repeat(lambda: [u * u for u in xs], number=n, repeat=5)) / n
out["sage_131_squarings_seconds_mean"] = tt
out["sage_131_squarings_seconds_best_of_5"] = tt2
full = min(timeit.repeat(lambda: [[u ** (2 ** k) for u in xs] for k in range(131)], number=1, repeat=3))
out["sage_all_131_kernels_of_one_orbit_via_frobenius_power_seconds"] = full
print(json.dumps(out, indent=1))
json.dump(out, open(os.path.join(HERE, "results_sage_crosscheck.json"), "w"), indent=1)
