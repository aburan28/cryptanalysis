"""
Independent pure-Python GF(2^131) and char-2 elliptic-curve arithmetic for the C5 audit.
Written from scratch for this audit: shares no code with transport-263/*.py or with other verifiers.

Field: F_2[z]/(z^131 + z^13 + z^2 + z + 1); an element is a Python int bitmask (bit i = coeff of z^i).
Curves: y^2 + x y = x^3 + a2 x^2 + b, points are (x, y) tuples or None for the point at infinity.
"""
M = 131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << M) - 1


def red(r):
    """reduce a polynomial of degree <= 2*130 (or a bit more) modulo MOD by folding z^131 = z^13+z^2+z+1"""
    while r >> M:
        hi = r >> M
        r = (r & MASK) ^ hi ^ (hi << 1) ^ (hi << 2) ^ (hi << 13)
    return r


def mul(a, b):
    """schoolbook carry-less product with a 4-bit window, then reduction"""
    if a == 0 or b == 0:
        return 0
    tab = [0] * 16
    for i in range(1, 16):
        v = 0
        for j in range(4):
            if (i >> j) & 1:
                v ^= a << j
        tab[i] = v
    r, sh = 0, 0
    while b:
        r ^= tab[b & 15] << sh
        b >>= 4
        sh += 4
    return red(r)


def sqr_spread(a):
    """squaring by interleaving zero bits (Frobenius is F_2-linear): sum a_i z^(2i), then reduce"""
    return red(int("0".join(bin(a)[2:]), 2)) if a else 0


# squaring as an explicit F_2-linear map: column i = z^(2i) mod MOD (built by repeated multiplication by z^2)
_SQ_COLS = []
_c = 1
for _i in range(M):
    _SQ_COLS.append(_c)
    _c = red(_c << 2)


def sqr_matrix(a):
    r, i = 0, 0
    while a:
        if a & 1:
            r ^= _SQ_COLS[i]
        a >>= 1
        i += 1
    return r


sqr = sqr_spread


def inv(a):
    """inverse by the binary-polynomial extended Euclidean algorithm"""
    if a == 0:
        raise ZeroDivisionError
    u, v, g1, g2 = a, MOD, 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v, g1, g2 = v, u, g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return red(g1)


def trace(a):
    s, u = a, a
    for _ in range(M - 1):
        u = sqr(u)
        s ^= u
    return s


def half_trace(c):
    """h with h^2 + h = c when Tr(c) = 0 (M odd): h = sum_{i=0}^{(M-1)/2} c^(2^(2i))"""
    s, u = c, c
    for _ in range((M - 1) // 2):
        u = sqr(sqr(u))
        s ^= u
    return s


def pow2k(a, k):
    for _ in range(k):
        a = sqr(a)
    return a


# ------------------------------------------------------------------ curve y^2 + xy = x^3 + a2 x^2 + b
def on_curve(P, a2, b):
    if P is None:
        return True
    x, y = P
    return (sqr(y) ^ mul(x, y)) == (mul(sqr(x), x) ^ mul(a2, sqr(x)) ^ b)


def neg(P):
    return None if P is None else (P[0], P[0] ^ P[1])


def add(P, Q, a2):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y2 == (x1 ^ y1):
            return None
        return dbl(P, a2)
    lam = mul(y1 ^ y2, inv(x1 ^ x2))
    x3 = sqr(lam) ^ lam ^ x1 ^ x2 ^ a2
    y3 = mul(lam, x1 ^ x3) ^ x3 ^ y1
    return (x3, y3)


def dbl(P, a2):
    if P is None:
        return None
    x1, y1 = P
    if x1 == 0:
        return None
    lam = x1 ^ mul(y1, inv(x1))
    x3 = sqr(lam) ^ lam ^ a2
    y3 = sqr(x1) ^ mul(lam ^ 1, x3)
    return (x3, y3)


def smul(k, P, a2):
    if k < 0:
        return smul(-k, neg(P), a2)
    R = None
    for bit in bin(k)[2:]:
        R = dbl(R, a2)
        if bit == "1":
            R = add(R, P, a2)
    return R


def lift_x(x, a2, b, choose=0):
    """a point with this x on y^2+xy=x^3+a2x^2+b, or None if x does not lift (x != 0)"""
    c = x ^ a2 ^ mul(b, sqr(inv(x)))       # y = x w, w^2 + w = x + a2 + b/x^2
    if trace(c) & 1:
        return None
    w = half_trace(c)
    if choose:
        w ^= 1
    return (x, mul(x, w))


def frob(P):
    return None if P is None else (sqr(P[0]), sqr(P[1]))


# ------------------------------------------------------------------ Velu (odd kernel), char 2, a1 = 1, a3 = a4 = 0
# derived here from the general Velu formulas (Washington, Thm 12.16 / Velu 1971):
#   g^x_Q = x_Q^2 + y_Q, g^y_Q = x_Q, v_Q = x_Q, u_Q = x_Q^2  (all signs/2's vanish in char 2)
#   X = x + sum [x_Q/(x+x_Q) + x_Q^2/(x+x_Q)^2] = x + s + s^2,   s = sum x_Q/(x+x_Q)
#   Y = y + sum [x_Q^2 x/(x+x_Q)^3 + x_Q (x + y + x_Q^2)/(x+x_Q)^2]
#   codomain [1, a2, 0, v, b + v], v = sum x_Q ;  j = 1/(b + v + v^2)
#   if b + v + v^2 = 1 (and a2 = 0): (X, Y) -> (X, Y + v) is an isomorphism onto E0: y^2+xy = x^3+1
def velu_to_E0(xs, x, y):
    s = 0
    Ysum = 0
    xy = x ^ y
    for xq in xs:
        e = inv(x ^ xq)
        e2 = sqr(e)
        t = mul(xq, e)                      # x_Q/(x+x_Q)
        s ^= t
        xq2 = sqr(xq)
        term1 = mul(mul(xq2, x), mul(e2, e))
        term2 = mul(mul(xq, xy ^ xq2), e2)
        Ysum ^= term1 ^ term2
    v = 0
    for xq in xs:
        v ^= xq
    X = x ^ s ^ sqr(s)
    Y = y ^ Ysum ^ v
    return (X, Y)
