# replicate aggregate.py's timing method (process_time around one list of 131 squarings, median over 262 kernels)
import json, time, statistics
from sage.all import GF, PolynomialRing
z = PolynomialRing(GF(2), "z").gen()
K = GF(2 ** 131, "z", modulus=z ** 131 + z ** 13 + z ** 2 + z + 1)
kall = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"))
res = {}
for method, clk in [("process_time", time.process_time), ("perf_counter", time.perf_counter)]:
    ts = []
    for lab, hs in kall.items():
        xs = [K.from_integer(int(h, 16)) for h in hs]
        c = clk(); sq = [u * u for u in xs]; ts.append(clk() - c)
    res[method] = {"median": statistics.median(ts), "min": min(ts), "max": max(ts)}
# one full orbit by iterated squaring (130 steps x 131 squarings)
xs = [K.from_integer(int(h, 16)) for h in kall["A000"]]
c = time.perf_counter()
cur = xs
for k in range(130):
    cur = [u * u for u in cur]
res["full_orbit_130_steps_perf_counter_s"] = time.perf_counter() - c
print(json.dumps(res, indent=1))
json.dump(res, open("results_timing_replica.json", "w"), indent=1)
