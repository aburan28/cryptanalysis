"""
C2 audit: independent re-check of the 'planted scalar' transport claim for all 262 floor curves.

No Sage / PARI: field and curve arithmetic from gf2.py (pure Python, own code).
Inputs read: ground_truth.json (b of every floor curve), transport-263/kernels_all.json (the sweep's ascending-
kernel x-coordinates).  Everything else (points R, U, scalars k, toy k, BSGS) is chosen/computed here with
our own RNG seed "C2-audit:<label>".

Per curve:
 K1  the 131 x_Q are distinct, nonzero, and are NOT x-coordinates of E(F_q) points (so no F_q-point of E
     hits a pole of the formula)
 K2  they are exactly {x(iP') : i = 1..131} for a point P' of order 263 on the twist E'(F_q) = [1,1,0,0,b]
 K3  E'(F_q)[263^oo] has an element Qt of order 263^2 and x(263 Qt) is in the kernel set  (so the kernel is THE
     unique F_q-rational 263-subgroup: the Sylow is cyclic of order 263^2 = 263^v_263(q+1+t))
 K4  v = sum x_Q satisfies b + v + v^2 = 1  (codomain j = 1)
 V1  kernel points of E itself live over F_q2: (x', y' + s x') for (x', y') in <P'>, checked on E/F_q2, 263 P = O
 V2  GENERAL Velu (Washington Thm 12.16, all a-invariants, y_Q included) evaluated over F_q2 agrees with the
     sweep's simplified F_q formula on R, S = kR and on a point U of exact order 4N; general codomain
     A4 = v, A6 = b + v
 P1  own R = 4*(random point) != O, N R = O on E; own random k in [1, N-1]; S = k R
 P2  phi(R), phi(S) lie on E0 = [1,0,0,0,1]; phi(R) != O, N phi(R) = O; phi(S) == k phi(R)   (THE CLAIM)
 H1  U of exact order 4N on E (4N U = O, 2N U != O, 4U != O);  phi(U) has exact order 4N on E0
 H2  phi(A + B) == phi(A) + phi(B) for 4 pairs of full-group points (incl. U, its order-4 multiple, 2-torsion)
 T1  toy DLP: ks < 2^24 planted on E, Ss = ks R; recover ks by our own BSGS (m = 2^12) on E0 from
     (phi(R), phi(Ss))
Negative controls (a few curves): wrong kernel (another curve's), perturbed kernel -> the checks must FAIL.

Run:  python3 indep_check.py [NPROC]
"""
import sys, os, json, time, random, hashlib
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf2
from gf2 import Fq, Fq2, Curve, mul, sqr, inv, trace, lift_x, random_point

GT = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
KERS = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"))
q = 2 ** 131
N = 680564733841876926932320129493409985129
t = -22283658519494248867
CARD, TW = q + 1 - t, q + 1 + t
L = 263
assert CARD == 4 * N and int(GT["meta"]["N"]) == N and int(GT["meta"]["t"]) == t
assert TW % (L * L) == 0 and (TW // (L * L)) % L != 0 and CARD % L != 0
REC = {c["label"]: c for c in GT["curves"]}
FLOOR = [c["label"] for c in GT["curves"] if c["label"] != "E0"]
E0 = Curve(Fq, 0, 1)


# ------------------------------------------------------------------ Velu, general form (Washington Thm 12.16)
def velu_general_setup(F, a, reps):
    """a = (a1,a2,a3,a4,a6) in F; reps = one point per {Q,-Q} of the odd kernel G.  Returns data + codomain."""
    a1, a2, a3, a4, a6 = a
    add, m, sc = F.add, F.mul, F.sc
    data = []
    vv, w = F.zero, F.zero
    for (xQ, yQ) in reps:
        gx = add(add(add(sc(3, m(xQ, xQ)), sc(2, m(a2, xQ))), a4), sc(-1, m(a1, yQ)))
        gy = add(add(sc(-2, yQ), sc(-1, m(a1, xQ))), sc(-1, a3))
        vQ = add(sc(2, gx), sc(-1, m(a1, gy)))
        uQ = m(gy, gy)
        vv = add(vv, vQ)
        w = add(w, add(uQ, m(xQ, vQ)))
        data.append((xQ, yQ, gx, gy, vQ, uQ))
    A4 = add(a4, sc(-5, vv))
    A6 = add(add(a6, sc(-1, m(add(m(a1, a1), sc(4, a2)), vv))), sc(-7, w))
    return data, (a1, a2, a3, A4, A6)


def velu_general_eval(F, a, data, P):
    a1, a2, a3, a4, a6 = a
    add, m, sc = F.add, F.mul, F.sc
    x, y = P
    X, Y = x, y
    for (xQ, yQ, gx, gy, vQ, uQ) in data:
        d = add(x, sc(-1, xQ))
        di = F.inv(d)
        di2 = m(di, di)
        di3 = m(di2, di)
        X = add(X, add(m(vQ, di), m(uQ, di2)))
        t1 = m(m(uQ, add(add(sc(2, y), m(a1, x)), a3)), di3)
        t2 = m(m(vQ, add(add(m(a1, d), y), sc(-1, yQ))), di2)
        t3 = m(add(m(a1, uQ), sc(-1, m(gx, gy))), di2)
        Y = add(Y, sc(-1, add(add(t1, t2), t3)))
    return (X, Y)


# ------------------------------------------------------------------ the sweep's simplified F_q formula, re-typed
def velu_simple(xs, v, P):
    """X = x + sum(a + a^2), a = x_Q/(x+x_Q);  Y = y + v + sum[x_Q^2 x/(x+x_Q)^3 + x_Q (x+y+x_Q^2)/(x+x_Q)^2]"""
    if P is None:
        return None
    x, y = P
    X, Y = x, y ^ v
    for xq in xs:
        di = inv(x ^ xq)
        a = mul(xq, di)
        X ^= a ^ sqr(a)
        di2 = sqr(di)
        Y ^= mul(mul(sqr(xq), x), mul(di2, di)) ^ mul(mul(xq, x ^ y ^ sqr(xq)), di2)
    return (X, Y)


def bsgs(C, P, Q, bound, m=1 << 12):
    """k in [0, bound) with k P = Q, own implementation"""
    table, T = {}, None
    for j in range(m):
        table.setdefault(T, j)
        T = C.add(T, P)
    step = C.neg(C.mulk(m, P))
    G = Q
    for i in range((bound + m - 1) // m):
        if G in table:
            return i * m + table[G]
        G = C.add(G, step)
    return None


def order_exact(C, P, n, primes):
    if C.mulk(n, P) is not None:
        return False
    return all(C.mulk(n // pr, P) is not None for pr in primes)


def check_curve(label, xs_hex=None, rng_tag="C2-audit", do_general=True, do_toy=True):
    rec = {"label": label}
    rng = random.Random(rng_tag + ":" + label)
    b = int(REC[label]["b_int"])
    assert int(REC[label]["a2"]) == 0
    E, Et = Curve(Fq, 0, b), Curve(Fq, 1, b)
    xs = [int(h, 16) for h in (xs_hex if xs_hex is not None else KERS[label])]
    t0 = time.time()

    # ---- K1..K4 kernel
    rec["K1_131_distinct_nonzero"] = len(set(xs)) == 131 and all(0 < u < (1 << 131) for u in xs)
    rec["K1_no_Fq_point_of_E_at_xQ"] = all(lift_x(E, u, rng) is None for u in xs)
    Pp = lift_x(Et, xs[0], rng)
    rec["K2_xQ0_on_twist"] = Pp is not None
    if Pp is None:
        rec["ok"] = False
        return rec
    mults, R_ = [], Pp
    for i in range(131):
        mults.append(R_)
        R_ = Et.add(R_, Pp)
    rec["K2_order_263"] = Et.mulk(L, Pp) is None and Pp is not None
    rec["K2_xset_is_subgroup"] = set(P_[0] for P_ in mults) == set(xs)
    while True:
        Qt = Et.mulk(TW // (L * L), random_point(Et, rng))
        if Et.mulk(L, Qt) is not None:
            break
    rec["K3_twist_has_order_263sq"] = Et.mulk(L * L, Qt) is None
    rec["K3_263Qt_in_kernel"] = Et.mulk(L, Qt)[0] in set(xs)
    v = 0
    for u in xs:
        v ^= u
    rec["K4_codomain_j_is_1"] = (b ^ v ^ sqr(v)) == 1
    kernel_ok = all(rec[k] for k in rec if k.startswith("K"))

    # ---- V1 kernel of E over F_q2
    E2 = Curve(Fq2, (0, 0), (b, 0))
    reps = [((xp, 0), (yp, xp)) for (xp, yp) in mults]        # (x', y' + s x')
    rec["V1_reps_on_E_over_Fq2"] = all(E2.on(P_) for P_ in reps)
    rec["V1_263P_is_O_over_Fq2"] = E2.mulk(L, reps[0]) is None
    rec["V1_reps_y_not_in_Fq"] = all(P_[1][1] != 0 for P_ in reps)
    rec["V1_reps_are_multiples"] = all(E2.add(reps[i], reps[0]) == reps[i + 1] for i in range(130))
    data, cod = velu_general_setup(Fq2, ((1, 0), (0, 0), (0, 0), (0, 0), (b, 0)), reps)
    rec["V2_general_codomain_A4_eq_v_A6_eq_b_plus_v"] = cod[3] == (v, 0) and cod[4] == (b ^ v, 0)

    m2 = gf2.m2
    DOM = ((1, 0), (0, 0), (0, 0), (0, 0), (b, 0))

    def phi_general(P):
        """general Velu over F_q2 (domain a-invariants DOM), image checked on the general codomain
        [1,0,0,A4,A6], then (X, Y) -> (X, Y + A4) onto [1,0,0,0,A6 + A4^2] (= E0 when j = 1)"""
        X, Y = velu_general_eval(Fq2, DOM, data, ((P[0], 0), (P[1], 0)))
        lhs = Fq2.add(m2(Y, Y), m2(X, Y))
        rhs = Fq2.add(Fq2.add(m2(m2(X, X), X), m2(cod[3], X)), cod[4])
        return (X, Fq2.add(Y, cod[3])), lhs == rhs

    # ---- P1 planted scalar
    while True:
        R = E.mulk(4, random_point(E, rng))
        if R is not None:
            break
    rec["P1_R_order_N"] = E.mulk(N, R) is None                   # N prime, R != O
    k = rng.randrange(1, N)
    S = E.mulk(k, R)
    rec["planted_k_audit"] = str(k)
    pR, pS = velu_simple(xs, v, R), velu_simple(xs, v, S)
    rec["P2_phiR_on_E0"] = E0.on(pR)
    rec["P2_phiS_on_E0"] = E0.on(pS)
    rec["P2_phiR_nonzero_order_N"] = pR is not None and E0.mulk(N, pR) is None
    kpR = E0.mulk(k, pR)
    rec["P2_phiS_eq_k_phiR"] = pS == kpR
    # alternative scalar path: k = k1 + 2^65 k2 on E0, and N-k (negation)
    k1, k2 = k & ((1 << 65) - 1), k >> 65
    rec["P2_alt_scalar_path"] = E0.add(E0.mulk(k1, pR), E0.mulk(k2, E0.mulk(1 << 65, pR))) == pS and \
        E0.neg(E0.mulk(N - k, pR)) == pS

    # ---- H1 order 4N
    while True:
        U = random_point(E, rng)
        if E.mulk(4 * N, U) is None and E.mulk(2 * N, U) is not None and E.mulk(4, U) is not None:
            break
    pU = velu_simple(xs, v, U)
    rec["H1_U_exact_order_4N"] = True
    rec["H1_phiU_on_E0"] = E0.on(pU)
    rec["H1_phiU_exact_order_4N"] = E0.mulk(4 * N, pU) is None and E0.mulk(2 * N, pU) is not None and \
        E0.mulk(4, pU) is not None
    T4 = E.mulk(N, U)             # order 4
    T2 = E.dbl(T4)                # the 2-torsion point (0, sqrt b)
    rec["H1_T2_is_x0"] = T2 is not None and T2[0] == 0 and E.dbl(T2) is None
    pT4, pT2 = velu_simple(xs, v, T4), velu_simple(xs, v, T2)
    rec["H1_phiT2_is_E0_2torsion_(0,1)"] = pT2 == (0, 1)
    rec["H1_phiT4_order_4"] = E0.on(pT4) and E0.dbl(pT4) == (0, 1)

    # ---- H2 homomorphism on the full group
    pairs = [(U, T4), (U, R), (random_point(E, rng), random_point(E, rng)), (random_point(E, rng), T2)]
    hom = True
    for A_, B_ in pairs:
        lhs = velu_simple(xs, v, E.add(A_, B_))
        rhs = E0.add(velu_simple(xs, v, A_), velu_simple(xs, v, B_))
        hom &= (lhs == rhs)
    rec["H2_hom_full_group_4_pairs"] = bool(hom)

    # ---- V2 general Velu agrees with the simplified formula
    if do_general:
        gen_ok = True
        for P_, img in [(R, pR), (S, pS), (U, pU)]:
            (gi, on_cod) = phi_general(P_)
            gen_ok &= on_cod and gi[0][1] == 0 and gi[1][1] == 0 and (gi[0][0], gi[1][0]) == img
        rec["V2_general_velu_eq_simplified_on_R_S_U"] = bool(gen_ok)

    # ---- T1 toy DLP
    if do_toy:
        ks = rng.randrange(0, 1 << 24)
        Ss = E.mulk(ks, R)
        pSs = velu_simple(xs, v, Ss)
        kr = bsgs(E0, pR, pSs, 1 << 24)
        rec["T1_toy_k"] = ks
        rec["T1_toy_dlp_recovered_on_E0"] = kr == ks

    rec["seconds"] = round(time.time() - t0, 2)
    rec["kernel_ok"] = bool(kernel_ok)
    rec["planted_ok"] = bool(rec["P1_R_order_N"] and rec["P2_phiR_on_E0"] and rec["P2_phiS_on_E0"]
                             and rec["P2_phiR_nonzero_order_N"] and rec["P2_phiS_eq_k_phiR"] and rec["P2_alt_scalar_path"])
    rec["ok"] = bool(kernel_ok and rec["planted_ok"] and all(rec[k_] for k_ in rec
                                                              if k_[:2] in ("V1", "V2", "H1", "H2", "T1") and k_ != "T1_toy_k"))
    return rec


def work(label):
    try:
        return label, check_curve(label)
    except Exception as ex:          # record, never hide
        return label, {"label": label, "ok": False, "exception": repr(ex)}


def main():
    nproc = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    labels = FLOOR if len(sys.argv) <= 2 else sys.argv[2].split(",")
    assert gf2.self_test()
    # sanity of our EC code on E0 with the repo's Certicom generator and the tau eigenvalue
    G = (0x51c99bfa6f18de467c80c23b98c7994aa, 0x42ea2d112ecec71fcf7e000d7efc978bd)
    lam = 196511074115861092422032515080945363956
    assert E0.on(G) and E0.mulk(N, G) is None and G is not None
    assert E0.mulk(lam, G) == (sqr(G[0]), sqr(G[1]))
    # Hasse: 4N is the only multiple of N in [q+1-2sqrt(q), q+1+2sqrt(q)]
    from math import isqrt
    lo, hi = q + 1 - 2 * isqrt(q) - 2, q + 1 + 2 * isqrt(q) + 2
    assert [m_ for m_ in range(1, 10) if lo <= m_ * N <= hi] == [4]
    out, t0 = {}, time.time()
    fn = os.path.join(HERE, "indep_results.json")
    with Pool(nproc) as pool:
        for i, (lab, rec) in enumerate(pool.imap_unordered(work, labels)):
            out[lab] = rec
            print("[%d/%d %.0fs] %s ok=%s planted=%s kernel=%s %s" % (i + 1, len(labels), time.time() - t0, lab,
                  rec.get("ok"), rec.get("planted_ok"), rec.get("kernel_ok"), rec.get("exception", "")), flush=True)
            if (i + 1) % 20 == 0:
                json.dump(out, open(fn + ".part", "w"), indent=1)
    json.dump(out, open(fn, "w"), indent=1)
    if os.path.exists(fn + ".part"):
        os.remove(fn + ".part")
    keys = sorted({k for r in out.values() for k in r if isinstance(r.get(k), bool)})
    summ = {k: sum(1 for r in out.values() if r.get(k) is True) for k in keys}
    summ["n_curves"] = len(out)
    summ["n_exceptions"] = sum(1 for r in out.values() if "exception" in r)
    summ["wall_seconds"] = round(time.time() - t0, 1)
    json.dump(summ, open(os.path.join(HERE, "indep_summary.json"), "w"), indent=1)
    print(json.dumps(summ, indent=1))


if __name__ == "__main__":
    main()
