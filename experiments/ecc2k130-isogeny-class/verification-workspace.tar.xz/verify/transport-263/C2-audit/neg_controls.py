"""
Negative controls for the C2 planted-scalar check: does the check actually FAIL when the transport map is wrong?
For a few floor curves E we evaluate the sweep's simplified Velu formula with a WRONG kernel x-set:
  (a) the kernel of another floor curve (the Frobenius-next label, and an unrelated label from the other orbit)
  (b) the correct kernel with one x_Q replaced by a random F_q element
  (c) the correct kernel with one x_Q dropped (130 elements)
and record: is phi(R) on the formal codomain [1,0,0,v',b+v'] ?  on E0 after (X,Y)->(X,Y+v') ?
            does phi(kR) == k phi(R) hold on the formal codomain ?
Also (d) the correct kernel but the isomorphism step omitted (image left on [1,0,0,v,b+v]): must not be on E0.
Run: python3 neg_controls.py
"""
import sys, os, json, random
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf2
from gf2 import Fq, Curve, sqr, random_point
import indep_check as I

N = I.N
out = {}
rng = random.Random("C2-audit-neg")
for lab, other in [("A000", "A001"), ("A077", "B050"), ("B013", "A013"), ("B130", "B000")]:
    b = int(I.REC[lab]["b_int"])
    E = Curve(Fq, 0, b)
    good = [int(h, 16) for h in I.KERS[lab]]
    while True:
        R = E.mulk(4, random_point(E, rng))
        if R is not None:
            break
    k = rng.randrange(1, N)
    S = E.mulk(k, R)
    variants = {
        "correct_kernel": good,
        "other_curve_kernel_" + other: [int(h, 16) for h in I.KERS[other]],
        "one_xQ_replaced": good[:7] + [rng.getrandbits(131)] + good[8:],
        "one_xQ_dropped": good[:50] + good[51:],
    }
    res = {}
    for name, xs in variants.items():
        v = 0
        for u in xs:
            v ^= u
        cod = Curve(Fq, 0, 0)
        pR, pS = I.velu_simple(xs, v, R), I.velu_simple(xs, v, S)   # includes (X,Y)->(X,Y+v)

        # formal codomain [1,0,0,v,b+v] ~ [1,0,0,0,b+v+v^2] after the same shift
        C = Curve(Fq, 0, b ^ v ^ sqr(v))
        r = {"codomain_j_is_1": (b ^ v ^ sqr(v)) == 1,
             "phiR_on_formal_codomain": C.on(pR), "phiS_on_formal_codomain": C.on(pS),
             "phiR_on_E0": I.E0.on(pR), "phiS_on_E0": I.E0.on(pS)}
        if C.on(pR) and C.on(pS):
            try:
                r["phiS_eq_k_phiR_on_formal_codomain"] = C.mulk(k, pR) == pS
            except ZeroDivisionError:
                r["phiS_eq_k_phiR_on_formal_codomain"] = "arith-error"
        else:
            r["phiS_eq_k_phiR_on_formal_codomain"] = False
        r["PLANTED_CHECK_WOULD_PASS"] = bool(r["phiR_on_E0"] and r["phiS_on_E0"] and I.E0.mulk(k, pR) == pS
                                             if r["phiR_on_E0"] and r["phiS_on_E0"] else False)
        res[name] = r
    # (d) no isomorphism step
    v = 0
    for u in good:
        v ^= u
    pR = I.velu_simple(good, v, R)
    raw = (pR[0], pR[1] ^ v)
    res["correct_kernel_without_iso_step"] = {"raw_image_on_E0": I.E0.on(raw),
                                              "raw_image_on_[1,0,0,v,b+v]": (sqr(raw[1]) ^ gf2.mul(raw[0], raw[1])) ==
                                              (gf2.mul(sqr(raw[0]), raw[0]) ^ gf2.mul(v, raw[0]) ^ b ^ v)}
    out[lab] = res
    print(lab, json.dumps(res))
json.dump(out, open(os.path.join(HERE, "neg_controls.json"), "w"), indent=1)
