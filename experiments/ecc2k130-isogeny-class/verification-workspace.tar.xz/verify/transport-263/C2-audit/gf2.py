"""
Independent (Sage-free, PARI-free) arithmetic for the C2 audit.

F_q  = F_2[z]/(z^131 + z^13 + z^2 + z + 1), elements = Python ints (bit i = z^i).
F_q2 = F_q[s]/(s^2 + s + 1), elements = pairs (a0, a1) meaning a0 + a1*s.
       (s^2+s+1 is irreducible over F_q because F_4 is not a subfield of F_{2^131}: 2 does not divide 131.)
Elliptic curves  y^2 + x y = x^3 + a2 x^2 + a6  (a1 = 1, a3 = a4 = 0) over either field, affine points,
None = O.  Written from the textbook formulas (Hankerson-Menezes-Vanstone, Guide to ECC, Sec. 3.1.2),
not copied from the sweep's transport.py.
"""
import random

M = 131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << 131) - 1


# ------------------------------------------------------------------ F_q
def red(c):
    while c >> M:
        h = c >> M
        c = (c & MASK) ^ h ^ (h << 1) ^ (h << 2) ^ (h << 13)
    return c


def mul(a, b):
    if a == 0 or b == 0:
        return 0
    tbl = [0] * 16
    tbl[1] = a
    for i in range(2, 16):
        tbl[i] = (tbl[i >> 1] << 1) if i % 2 == 0 else (tbl[i - 1] ^ a)
    r = 0
    sh = ((b.bit_length() + 3) // 4) * 4
    while sh > 0:
        sh -= 4
        r = (r << 4) ^ tbl[(b >> sh) & 15]
    return red(r)


def sqr(a):
    return mul(a, a)


def inv(a):
    """extended Euclid over F_2[z] (HMV Alg. 2.48)"""
    if a == 0:
        raise ZeroDivisionError("inverse of 0 in F_q")
    u, v, g1, g2 = a, MOD, 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v, g1, g2 = v, u, g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return red(g1)


def pw(a, e):
    r = 1
    while e:
        if e & 1:
            r = mul(r, a)
        a = sqr(a)
        e >>= 1
    return r


def trace(c):
    s, u = c, c
    for _ in range(M - 1):
        u = sqr(u)
        s ^= u
    assert s in (0, 1)
    return s


def half_trace(c):
    s, u = c, c
    for _ in range((M - 1) // 2):
        u = sqr(sqr(u))
        s ^= u
    return s


class Fq:
    zero, one = 0, 1
    add = staticmethod(lambda a, b: a ^ b)
    mul = staticmethod(mul)
    inv = staticmethod(inv)

    @staticmethod
    def sc(n, a):          # integer n times a (characteristic 2)
        return a if n & 1 else 0


# ------------------------------------------------------------------ F_q2 = F_q[s]/(s^2+s+1)
def m2(a, b):
    a0, a1 = a
    b0, b1 = b
    p00, p11 = mul(a0, b0), mul(a1, b1)
    p01 = mul(a0 ^ a1, b0 ^ b1) ^ p00 ^ p11          # a0 b1 + a1 b0
    return (p00 ^ p11, p01 ^ p11)                     # s^2 = s + 1


def conj2(a):                                         # s -> s^2 = s + 1
    return (a[0] ^ a[1], a[1])


def inv2(a):
    c = conj2(a)
    n = m2(a, c)
    assert n[1] == 0
    ni = inv(n[0])
    return (mul(c[0], ni), mul(c[1], ni))


class Fq2:
    zero, one = (0, 0), (1, 0)
    add = staticmethod(lambda a, b: (a[0] ^ b[0], a[1] ^ b[1]))
    mul = staticmethod(m2)
    inv = staticmethod(inv2)

    @staticmethod
    def sc(n, a):
        return a if n & 1 else (0, 0)


def emb(a):
    return (a, 0)


# ------------------------------------------------------------------ curves y^2 + xy = x^3 + a2 x^2 + a6
class Curve:
    def __init__(self, F, a2, a6):
        self.F, self.a2, self.a6 = F, a2, a6

    def on(self, P):
        if P is None:
            return True
        F = self.F
        x, y = P
        lhs = F.add(F.mul(y, y), F.mul(x, y))
        x2 = F.mul(x, x)
        rhs = F.add(F.add(F.mul(x2, x), F.mul(self.a2, x2)), self.a6)
        return lhs == rhs

    def neg(self, P):
        return None if P is None else (P[0], self.F.add(P[0], P[1]))

    def add(self, P, Q):
        F = self.F
        if P is None:
            return Q
        if Q is None:
            return P
        x1, y1 = P
        x2, y2 = Q
        if x1 == x2:
            if y2 == F.add(x1, y1):          # Q = -P
                return None
            return self.dbl(P)
        lam = F.mul(F.add(y1, y2), F.inv(F.add(x1, x2)))
        x3 = F.add(F.add(F.add(F.mul(lam, lam), lam), F.add(x1, x2)), self.a2)
        y3 = F.add(F.add(F.mul(lam, F.add(x1, x3)), x3), y1)
        return (x3, y3)

    def dbl(self, P):
        F = self.F
        if P is None:
            return None
        x1, y1 = P
        if x1 == F.zero:                     # the 2-torsion point
            return None
        lam = F.add(x1, F.mul(y1, F.inv(x1)))
        x3 = F.add(F.add(F.mul(lam, lam), lam), self.a2)
        y3 = F.add(F.mul(x1, x1), F.mul(F.add(lam, F.one), x3))
        return (x3, y3)

    def mulk(self, k, P):
        """right-to-left binary (the sweep used left-to-right); handles k < 0"""
        if k < 0:
            return self.mulk(-k, self.neg(P))
        R, A = None, P
        while k:
            if k & 1:
                R = self.add(R, A)
            A = self.dbl(A)
            k >>= 1
        return R


def lift_x(C, x, rng):
    """a point of the F_q-curve C with this x, or None if x is not an x-coordinate of C(F_q)"""
    if x == 0:
        return None
    c = mul(inv(sqr(x)), mul(sqr(x), x) ^ mul(C.a2, sqr(x)) ^ C.a6)    # (x^3 + a2 x^2 + a6)/x^2
    if trace(c):
        return None
    zz = half_trace(c)
    assert sqr(zz) ^ zz == c
    if rng.getrandbits(1):
        zz ^= 1
    P = (x, mul(x, zz))
    assert C.on(P)
    return P


def random_point(C, rng):
    while True:
        P = lift_x(C, rng.getrandbits(M), rng)
        if P is not None:
            return P


def self_test(seed=1):
    rng = random.Random(seed)
    for _ in range(200):
        a, b, c = (rng.getrandbits(M) for _ in range(3))
        assert mul(a, b) == mul(b, a)
        assert mul(a, mul(b, c)) == mul(mul(a, b), c)
        assert mul(a, b ^ c) == mul(a, b) ^ mul(a, c)
        if a:
            assert mul(a, inv(a)) == 1
        assert pw(a, 1 << M) == a                         # a^(2^131) = a  (Fermat: field has 2^131 elements)
        A, B = (rng.getrandbits(M), rng.getrandbits(M)), (rng.getrandbits(M), rng.getrandbits(M))
        if A != (0, 0):
            assert m2(A, inv2(A)) == (1, 0)
    # f = z^131 + z^13 + z^2 + z + 1 is irreducible: deg f = 131 is prime, so f is irreducible iff z^(2^131) = z mod f
    # (every irreducible factor then has degree 1 or 131) and f has no root in F_2 (f(0) = 1, f(1) = 5 mod 2 = 1).
    zel = 2
    assert pw(zel, 1 << M) == zel and (MOD & 1) == 1 and bin(MOD).count("1") % 2 == 1
    s = (0, 1)
    assert Fq2.add(Fq2.add(m2(s, s), s), Fq2.one) == (0, 0)
    return True
