"""C4 audit, part 4: re-time the library isogeny builds (Sage E.isogeny(kernel poly), PARI ellisogeny) on 2 curves."""
import sys, os, json, time
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
import ecc2k
from sage.all import EllipticCurve, PolynomialRing, prod, pari
K = ecc2k.field()
kers = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"))
RX = PolynomialRing(K, "x")
out = {}
for lab in ["A000", "B077"]:
    b = K.from_integer(int(ecc2k.RECORDS[lab]["b_int"]))
    E = EllipticCurve(K, [1, 0, 0, 0, b])
    h = prod([RX.gen() - K.from_integer(int(u, 16)) for u in kers[lab]])
    c = time.process_time(); phi = E.isogeny(h); ts = time.process_time() - c
    c = time.process_time(); res = pari.ellisogeny(pari(E), pari(h)); tp = time.process_time() - c
    out[lab] = {"sage_isogeny_cpu_s": round(ts, 3), "pari_ellisogeny_cpu_s": round(tp, 4),
                "sage_codomain_j_is_1": bool(phi.codomain().j_invariant() == 1),
                "pari_codomain_j_is_1": bool(EllipticCurve(K, [K(res[0][i]) for i in range(5)]).j_invariant() == 1)}
    print(lab, out[lab], flush=True)
json.dump(out, open("lib_timing.json", "w"), indent=1)
