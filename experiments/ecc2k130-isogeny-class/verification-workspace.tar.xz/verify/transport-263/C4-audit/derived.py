"""C4 audit, part 3: derived numbers from count_ops.json and c_results.json (python3 only)."""
import json, math
co = json.load(open("count_ops.json")); cr = json.load(open("c_results.json"))
rho = float(co["rho_E0_neg_tau_log2"]); rhofl = float(co["rho_floor_neg_only_log2"])
out = {}
t = cr["cpu_s"]
tr_iter = t["transport_build_plus_2_eval"] / t["E0_batched_affine_add"]    # transport in (lower-bound) rho-iteration units
out["C_transport_s"] = t["transport_build_plus_2_eval"]
out["C_transport_in_batched_adds_log2"] = math.log2(tr_iter)
out["C_effective_minus_rho_bits"] = math.log1p(tr_iter / 2 ** rho) / math.log(2)
out["C_rho_E0_cpu_core_years_at_batched_add_cost"] = 2 ** rho * t["E0_batched_affine_add"] / (365.25 * 86400)
out["C_velu_eval_us"] = t["velu_eval"] * 1e6
out["C_build_ms"] = t["build"] * 1e3
# sweep-style M-equivalent (S=M, I=8M+130S=138M) of the C-run outlier A115: I=504, one outer retry
# base (0 failed x): I317 M633 S831; one failed x: +1I +1M +131S; outer retry with Q of order 263: 1+175+10 I extra etc.
I, M = 504, 1006 + 2          # 2 failed x
S = 831 + 2 * 131 + (130 + 130 + 1) + (114 * 2 + 61) + (8 * 2 + 2)  # extra random pt, cofactor, 263 (last add is P+(-P): no op)
out["sweep_style_Mequiv_with_one_outer_retry_log2"] = math.log2(M + S + 138 * I + 2 * (914 + 131 + 138))
out["practical_ECC2K130_walk_log2 (Bailey et al. 2009 factor 1.069993)"] = rho + math.log2(1.069993)
out["rho_floor_minus_rho_E0_bits"] = rhofl - rho
out["expected_sweep_style_I"] = 317 + 1 + 187 / 263   # E[failed x] = 1 (Tr = 0 w.p. ~1/2), outer retry w.p. ~1/263
json.dump(out, open("derived.json", "w"), indent=1); print(json.dumps(out, indent=1))
