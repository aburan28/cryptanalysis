"""
C4 audit, part 1: independent operation counts for transport-263.

(a) Instrumented count: wrap every F_q element in a proxy that counts the field operations actually executed
    (mul of two distinct values, squaring = mul of an element by itself, x**-1, +), then run the sweep's own
    velu_eval and build pipeline on the proxies.  This does NOT use the sweep's manual ops.* counters.
(b) Analytic count of velu_eval (batch inversion + per-term cost) and of the build (from the binary expansion
    of the twist cofactor and of 263).
(c) Rho baselines recomputed from N with Sage RealField(300) and with python ints/floats.
(d) Re-derive transport_cost_M_equiv_upper and effective_log2 from per_curve.json fields.

Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python count_ops.py
"""
import sys, os, json, math, random, statistics
HERE = os.path.dirname(os.path.abspath(__file__))
TR = "/Volumes/SSD990/ecdlp-hardness-work/transport-263"
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
sys.path.insert(0, TR)
import ecc2k
import transport as T
from sage.all import RealField, pi as PI, log, sqrt

K = ecc2k.field()
N, q, t = ecc2k.N, ecc2k.q, ecc2k.t
L = 263
out = {}

# ------------------------------------------------------------------ (a) proxy counting
C = {"M": 0, "S": 0, "I": 0, "A": 0, "cmp": 0}


class F:
    __slots__ = ("v",)

    def __init__(self, v):
        self.v = v

    def __mul__(self, o):
        ov = o.v if isinstance(o, F) else K(o)
        if isinstance(o, F) and (o is self or o.v == self.v):
            C["S"] += 1
        else:
            C["M"] += 1
        return F(self.v * ov)

    __rmul__ = __mul__

    def __add__(self, o):
        if isinstance(o, int) and o == 0:     # python sum() start value
            return self
        C["A"] += 1
        return F(self.v + (o.v if isinstance(o, F) else K(o)))

    __radd__ = __add__

    def __pow__(self, e):
        assert e == -1
        C["I"] += 1
        return F(self.v ** -1)

    def __truediv__(self, o):
        C["I"] += 1; C["M"] += 1
        return F(self.v / o.v)

    def __eq__(self, o):
        C["cmp"] += 1
        return self.v == (o.v if isinstance(o, F) else K(o))

    def __ne__(self, o):
        return not self.__eq__(o)

    def __hash__(self):
        return hash(self.v)


def reset():
    for k in C:
        C[k] = 0


kers = json.load(open(os.path.join(TR, "kernels_all.json")))
per = json.load(open(os.path.join(TR, "per_curve.json")))
floor = [lab for lab in ecc2k.LABELS if lab != "E0"]

from sage.all import EllipticCurve, set_random_seed
set_random_seed(4242)
evalcounts = {}
for lab in ["A000", "A010", "A064", "B000", "B130"]:
    b = K.from_integer(int(ecc2k.RECORDS[lab]["b_int"]))
    E = EllipticCurve(K, [1, 0, 0, 0, b])
    xs = [K.from_integer(int(h, 16)) for h in kers[lab]]
    sqs = [u * u for u in xs]
    v = sum(xs)
    R = 4 * E.random_point()
    ref = T.velu_eval(xs, sqs, v, R[0], R[1], T.Ops())
    reset()
    got = T.velu_eval([F(u) for u in xs], [F(u) for u in sqs], F(v), F(R[0]), F(R[1]), T.Ops())
    assert got[0].v == ref[0] and got[1].v == ref[1]
    evalcounts[lab] = {k: C[k] for k in ["M", "S", "I", "A"]}
out["velu_eval_instrumented"] = evalcounts
out["velu_eval_manual_counter_claim"] = {"M": 914, "S": 131, "I": 1, "A": 787}

# analytic
m = 131
out["velu_eval_analytic"] = {
    "batch_inversion_M": 3 * (m - 1), "batch_inversion_I": 1,
    "per_term_M": 4, "per_term_S": 1, "per_term_A": 5,
    "M": 3 * (m - 1) + 4 * m, "S": m, "I": 1,
    "A_incl_final_plus_v": m + 1 + 5 * m + 1,
    "A_as_counted_by_sweep": m + 1 + 5 * m,
}

# build pipeline on proxies, same seeds as transport.run_curve -> must reproduce per_curve build_ops and kernel
class KP:
    """stand-in for K inside random_affine_point: from_integer returns proxies"""
    @staticmethod
    def from_integer(n):
        return F(K.from_integer(n))


buildcounts = {}
COF_TW = T.COF_TW
for lab in ["A000", "A010", "A021", "B000", "B130"]:
    b = F(K.from_integer(int(ecc2k.RECORDS[lab]["b_int"])))
    one = F(K(1))
    rng = random.Random("transport-263:%s:%d" % (lab, T.SEED))
    reset()
    ob = T.Ops()
    tries = 0
    while True:
        tries += 1
        U = T.random_affine_point(KP, one, b, rng, ob)
        Qt = T.pmul(COF_TW, U, one, ob)
        Pt = T.pmul(L, Qt, one, ob)
        if Pt is not None:
            break
    xs = T.kernel_from_generator(Pt, one, ob)
    sqs = [u * u for u in xs]; ob.S += 131
    v = sum(xs); ob.A += 130
    inst = {k: C[k] for k in ["M", "S", "I", "A"]}
    same_kernel = sorted(int(u.v.to_integer()) for u in xs) == sorted(int(h, 16) for h in kers[lab])
    buildcounts[lab] = {"instrumented_executed": inst, "sweep_manual_counter_rerun": ob.d(),
                        "per_curve_json_build_ops": per[lab]["build_ops"], "tries": tries,
                        "kernel_xs_equal_stored": same_kernel}
out["build_instrumented"] = buildcounts

# analytic build: doublings = bitlen-1, additions = popcount-1 per double-and-add
def dbl_add(k):
    return k.bit_length() - 1, bin(k).count("1") - 1


d1, a1 = dbl_add(COF_TW)
d2, a2 = dbl_add(L)
out["build_analytic"] = {
    "COF_TW": str(COF_TW), "COF_TW_bits": COF_TW.bit_length(), "COF_TW_popcount": bin(COF_TW).count("1"),
    "cof_dbl": d1, "cof_add": a1, "263_dbl": d2, "263_add": a2, "kernel_adds": 130,
    "I_with_0_failed_x": 1 + d1 + a1 + d2 + a2 + 130,
    "note": "pdbl = 1I+2M+2S, padd = 1I+2M+1S (kernel 1st step P+P is a doubling); each random x costs 1I+1M+1S+130S(trace), "
            "a successful one +130S(half-trace); sqs = 131S",
}
nd = d1 + d2 + 1          # doublings incl. P+P in kernel generation
na = a1 + a2 + 129
base = {"I": 1 + nd + na, "M": 1 + 2 * nd + 2 * na, "S": 1 + 130 + 130 + 2 * nd + na + 131}
out["build_analytic"]["base_ops_0_failed_x"] = base
out["build_analytic"]["per_failed_x_extra"] = {"I": 1, "M": 1, "S": 131}

# observed number of failed x per curve from per_curve.json
fails = {}
for lab in floor:
    bo = per[lab]["build_ops"]
    kf = bo["I"] - base["I"]
    fails[lab] = kf
    assert bo["M"] == base["M"] + kf and bo["S"] == base["S"] + 131 * kf, (lab, bo, kf)
from collections import Counter
out["build_failed_x_histogram"] = dict(sorted(Counter(fails.values()).items()))
for key in "MSIA":
    vals = [per[lab]["build_ops"][key] for lab in floor]
    out.setdefault("build_ops_range_all_262", {})[key] = [min(vals), max(vals)]

# ------------------------------------------------------------------ (c) rho baselines
R3 = RealField(300)
out["log2_N"] = float(log(R3(N), 2))
out["rho_E0_neg_tau_log2"] = str(log(sqrt(R3(PI) * N / (4 * 131)), 2))
out["rho_floor_neg_only_log2"] = str(log(sqrt(R3(PI) * N / 4), 2))
# plain python cross-check (floats, integer-exact part of log2 N)
l2N = 129 + math.log2(N / 2 ** 129)
out["rho_E0_neg_tau_log2_float"] = (l2N + math.log2(math.pi / 524)) / 2
out["rho_floor_neg_only_log2_float"] = (l2N + math.log2(math.pi / 4)) / 2

# ------------------------------------------------------------------ (d) re-derive cost / effective
cal = json.load(open(os.path.join(TR, "raw", "calibration.json")))
rho = float(R3(out["rho_E0_neg_tau_log2"]))
rows = []
for lab in floor:
    r = per[lab]
    bo, eo = r["build_ops"], r["eval_ops_per_point"]
    Mup = (bo["M"] + bo["S"] + bo["I"] * 138) + 2 * (eo["M"] + eo["S"] + eo["I"] * 138)
    Mup_withA = Mup + bo["A"] + 2 * eo["A"]
    sec_sage = r["sage_build_seconds"] + 2 * r["sage_eval_seconds"]
    adds_sage = sec_sage / cal["E0_affine_add_python_s"]
    adds_expl = (r["build_seconds"] + 2 * r["eval_seconds"]) / cal["E0_affine_add_python_s"]
    worst = max(Mup, adds_sage, adds_expl)
    eff = rho + math.log1p(worst / 2.0 ** rho) / math.log(2)
    effM = rho + math.log1p(Mup / 2.0 ** rho) / math.log(2)
    rows.append((lab, Mup, Mup_withA, adds_sage, worst, eff - rho, effM - rho,
                 Mup == r["transport_cost_M_equiv_upper"]))
out["Mup_matches_per_curve_all"] = all(x[-1] for x in rows)
out["Mup_range"] = [min(x[1] for x in rows), max(x[1] for x in rows)]
out["Mup_log2_range"] = [math.log2(out["Mup_range"][0]), math.log2(out["Mup_range"][1])]
out["Mup_counting_additions_as_M_log2_max"] = math.log2(max(x[2] for x in rows))
out["worst_is_sage_build_for_all"] = all(x[4] == x[3] for x in rows)
out["effective_minus_rho_range"] = [min(x[5] for x in rows), max(x[5] for x in rows)]
out["effective_minus_rho_using_Mup_only_max"] = max(x[6] for x in rows)
out["margin_bits_rho_minus_log2_worst"] = rho - math.log2(max(x[4] for x in rows))
out["margin_bits_rho_minus_log2_Mup"] = rho - math.log2(out["Mup_range"][1])

json.dump(out, open(os.path.join(HERE, "count_ops.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
