"""
C4 audit, part 2a: write the input for the independent C implementation (transport_c.c).
For each of the 262 floor curves: b, the stored ascending-kernel x-coords (kernels_all.json), a fresh random point R
of order N on E (own seed), a fresh planted k, S = kR, and the sweep's Python velu_eval(R) for comparison.
Run: export TMPDIR=/Volumes/SSD990/ecdlp-hardness-work/tmp; sage -python prep_c_input.py
"""
import sys, os, json, random
HERE = os.path.dirname(os.path.abspath(__file__))
TR = "/Volumes/SSD990/ecdlp-hardness-work/transport-263"
sys.path.insert(0, "/Volumes/SSD990/ecdlp-hardness-work/ground_truth")
sys.path.insert(0, TR)
import ecc2k
import transport as T
from sage.all import EllipticCurve, set_random_seed

K = ecc2k.field()
N = ecc2k.N
kers = json.load(open(os.path.join(TR, "kernels_all.json")))
floor = [lab for lab in ecc2k.LABELS if lab != "E0"]
set_random_seed(20260923 + 4)
rng = random.Random("C4-audit")
h = lambda u: format(int(u.to_integer()), "x")
lines = [format(T.COF_TW, "x"), format(N, "x"), str(len(floor))]
for lab in floor:
    b = K.from_integer(int(ecc2k.RECORDS[lab]["b_int"]))
    E = EllipticCurve(K, [1, 0, 0, 0, b])
    xs = [K.from_integer(int(u, 16)) for u in kers[lab]]
    sqs = [u * u for u in xs]
    v = sum(xs)
    while True:
        R = 4 * E.random_point()
        if not R.is_zero():
            break
    assert (N * R).is_zero()
    k = rng.randrange(2, N - 1)
    S = k * R
    X, Y = T.velu_eval(xs, sqs, v, R[0], R[1], T.Ops())
    lines.append(lab + " " + h(b))
    lines.append(" ".join(kers[lab]))
    lines.append(" ".join([h(R[0]), h(R[1]), format(k, "x"), h(S[0]), h(S[1]), h(X), h(Y)]))
open(os.path.join(HERE, "c_input.txt"), "w").write("\n".join(lines) + "\n")
print("wrote", len(floor), "curves")
