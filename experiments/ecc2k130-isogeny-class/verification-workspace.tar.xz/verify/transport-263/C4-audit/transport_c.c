/*
 * C4 audit, part 2b: independent C implementation of the transport-263 isogeny E -> E0 over
 * F_q = F_2[z]/(z^131+z^13+z^2+z+1), using ARM PMULL carry-less multiplication.
 *
 * For every floor curve in c_input.txt:
 *   1. BUILD from scratch (own RNG, own code): random point on the twist y^2+xy=x^3+x^2+b, times the twist
 *      cofactor, times 263 -> generator of the unique F_q-rational 263-subgroup; 131 x-coords by repeated addition.
 *      Check: x-set equals the sweep's stored kernel (kernels_all.json), and b+v+v^2 == 1 (codomain j = 1).
 *   2. EVAL: explicit char-2 Velu (same formula as transport.velu_eval) + (X,Y)->(X,Y+v).
 *      Check: phi(R) equals the sweep's Python velu_eval(R), phi(R) lies on E0: y^2+xy=x^3+1,
 *      [N]phi(R) = O, phi(R) != O, and [k]phi(R) == phi(kR) (planted k, own scalar multiplication).
 *   3. TIME (CPU time of this thread): F_q M, S, I; one affine E0 addition; one Montgomery-batched affine addition
 *      (lower bound for a rho iteration); velu_eval; the whole build.
 * Operation counters are kept in the C code as well (independent of the Python counters).
 *
 * Build: clang -O3 -mcpu=apple-m4 -o transport_c transport_c.c   (falls back to -march=armv8-a+crypto)
 */
#include <arm_neon.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct { uint64_t w[3]; } fe;
typedef struct { fe x, y; int inf; } pt;

static uint64_t cM, cS, cI, cA;   /* op counters */
#define CNT 1

static inline void clmul(uint64_t a, uint64_t b, uint64_t *lo, uint64_t *hi) {
    poly128_t r = vmull_p64((poly64_t)a, (poly64_t)b);
    uint64x2_t v = vreinterpretq_u64_p128(r);
    *lo = vgetq_lane_u64(v, 0);
    *hi = vgetq_lane_u64(v, 1);
}

static inline fe reduce5(const uint64_t r[5]) {
    uint64_t h0 = (r[2] >> 3) | (r[3] << 61);
    uint64_t h1 = (r[3] >> 3) | (r[4] << 61);
    uint64_t h2 = (r[4] >> 3);
    uint64_t t0 = h0 ^ (h0 << 1) ^ (h0 << 2) ^ (h0 << 13);
    uint64_t t1 = h1 ^ (h1 << 1) ^ (h0 >> 63) ^ (h1 << 2) ^ (h0 >> 62) ^ (h1 << 13) ^ (h0 >> 51);
    uint64_t t2 = h2 ^ (h2 << 1) ^ (h1 >> 63) ^ (h2 << 2) ^ (h1 >> 62) ^ (h2 << 13) ^ (h1 >> 51);
    uint64_t g = t2 >> 3;
    t2 &= 7;
    t0 ^= g ^ (g << 1) ^ (g << 2) ^ (g << 13);
    fe o;
    o.w[0] = r[0] ^ t0;
    o.w[1] = r[1] ^ t1;
    o.w[2] = (r[2] & 7) ^ t2;
    return o;
}

static inline fe fmul_nc(fe a, fe b) {
    uint64_t r[5] = {0, 0, 0, 0, 0}, lo, hi;
    clmul(a.w[0], b.w[0], &lo, &hi); r[0] ^= lo; r[1] ^= hi;
    clmul(a.w[0], b.w[1], &lo, &hi); r[1] ^= lo; r[2] ^= hi;
    clmul(a.w[1], b.w[0], &lo, &hi); r[1] ^= lo; r[2] ^= hi;
    clmul(a.w[1], b.w[1], &lo, &hi); r[2] ^= lo; r[3] ^= hi;
    clmul(a.w[0], b.w[2], &lo, &hi); r[2] ^= lo; r[3] ^= hi;
    clmul(a.w[2], b.w[0], &lo, &hi); r[2] ^= lo; r[3] ^= hi;
    clmul(a.w[1], b.w[2], &lo, &hi); r[3] ^= lo; r[4] ^= hi;
    clmul(a.w[2], b.w[1], &lo, &hi); r[3] ^= lo; r[4] ^= hi;
    clmul(a.w[2], b.w[2], &lo, &hi); r[4] ^= lo;
    return reduce5(r);
}
static inline fe fsqr_nc(fe a) {
    uint64_t r[5], hi;
    clmul(a.w[0], a.w[0], &r[0], &r[1]);
    clmul(a.w[1], a.w[1], &r[2], &r[3]);
    clmul(a.w[2], a.w[2], &r[4], &hi);
    return reduce5(r);
}
static inline fe fmul(fe a, fe b) { if (CNT) cM++; return fmul_nc(a, b); }
static inline fe fsqr(fe a) { if (CNT) cS++; return fsqr_nc(a); }
static inline fe fadd(fe a, fe b) {
    if (CNT) cA++;
    fe o = {{a.w[0] ^ b.w[0], a.w[1] ^ b.w[1], a.w[2] ^ b.w[2]}};
    return o;
}
static inline int feq(fe a, fe b) { return a.w[0] == b.w[0] && a.w[1] == b.w[1] && a.w[2] == b.w[2]; }
static inline int fzero(fe a) { return (a.w[0] | a.w[1] | a.w[2]) == 0; }
static const fe ONE = {{1, 0, 0}};
static const fe ZERO = {{0, 0, 0}};

static fe fsqrn_nc(fe a, int n) { while (n--) a = fsqr_nc(a); return a; }
/* Itoh-Tsujii: a^-1 = (a^(2^130-1))^2, chain 1,2,4,8,16,32,64,128,130: 8 M + 130 S */
static fe finv_nc(fe a) {
    fe b1 = a;
    fe b2 = fmul_nc(fsqrn_nc(b1, 1), b1);
    fe b4 = fmul_nc(fsqrn_nc(b2, 2), b2);
    fe b8 = fmul_nc(fsqrn_nc(b4, 4), b4);
    fe b16 = fmul_nc(fsqrn_nc(b8, 8), b8);
    fe b32 = fmul_nc(fsqrn_nc(b16, 16), b16);
    fe b64 = fmul_nc(fsqrn_nc(b32, 32), b32);
    fe b128 = fmul_nc(fsqrn_nc(b64, 64), b64);
    fe b130 = fmul_nc(fsqrn_nc(b128, 2), b2);
    return fsqr_nc(b130);
}
static inline fe finv(fe a) { if (CNT) cI++; return finv_nc(a); }

static fe TRMASK;
static int trace_slow(fe c) {
    fe s = c, u = c;
    for (int i = 0; i < 130; i++) { u = fsqr_nc(u); s.w[0] ^= u.w[0]; s.w[1] ^= u.w[1]; s.w[2] ^= u.w[2]; }
    return (int)(s.w[0] & 1);   /* trace lies in F_2 */
}
static int ftrace(fe c) {  /* linear functional: parity of c & TRMASK */
    if (CNT) cA++;
    return (__builtin_popcountll(c.w[0] & TRMASK.w[0]) + __builtin_popcountll(c.w[1] & TRMASK.w[1]) +
            __builtin_popcountll(c.w[2] & TRMASK.w[2])) & 1;
}
static fe fhalftrace(fe c) {  /* sum_{i=0}^{65} c^(4^i), 130 S */
    fe s = c, u = c;
    for (int i = 0; i < 65; i++) { u = fsqr(fsqr(u)); s = fadd(s, u); }
    return s;
}

/* ------------------------------------------------ affine char-2 curve arithmetic, y^2+xy = x^3+a2x^2+b */
static pt pdbl(pt P, fe a2) {
    pt R;
    if (P.inf || fzero(P.x)) { R.inf = 1; return R; }
    fe lam = fadd(P.x, fmul(P.y, finv(P.x)));
    fe x3 = fadd(fadd(fsqr(lam), lam), a2);
    fe y3 = fadd(fsqr(P.x), fmul(fadd(lam, ONE), x3));
    R.x = x3; R.y = y3; R.inf = 0;
    return R;
}
static pt padd(pt P, pt Q, fe a2) {
    if (P.inf) return Q;
    if (Q.inf) return P;
    if (feq(P.x, Q.x)) {
        fe s = fadd(P.y, Q.y);
        if (feq(s, Q.x)) { pt R; R.inf = 1; return R; }
        return pdbl(P, a2);
    }
    fe lam = fmul(fadd(P.y, Q.y), finv(fadd(P.x, Q.x)));
    fe x3 = fadd(fadd(fadd(fadd(fsqr(lam), lam), P.x), Q.x), a2);
    fe y3 = fadd(fadd(fmul(lam, fadd(P.x, x3)), x3), P.y);
    pt R; R.x = x3; R.y = y3; R.inf = 0;
    return R;
}
/* scalar given as little-endian 64-bit words */
static pt pmul(const uint64_t *k, int nw, pt P, fe a2) {
    pt R; R.inf = 1;
    int top = nw * 64 - 1;
    while (top >= 0 && !((k[top / 64] >> (top % 64)) & 1)) top--;
    for (int i = top; i >= 0; i--) {
        R = pdbl(R, a2);
        if ((k[i / 64] >> (i % 64)) & 1) R = padd(R, P, a2);
    }
    return R;
}
static int on_curve(pt P, fe a2, fe b) {
    if (P.inf) return 1;
    fe x2 = fsqr_nc(P.x);
    fe y2 = fsqr_nc(P.y), xy = fmul_nc(P.x, P.y);
    fe lhs = {{y2.w[0] ^ xy.w[0], y2.w[1] ^ xy.w[1], y2.w[2] ^ xy.w[2]}};
    fe rhs = fmul_nc(x2, P.x);
    fe t = fmul_nc(a2, x2);
    rhs = (fe){{rhs.w[0] ^ t.w[0] ^ b.w[0], rhs.w[1] ^ t.w[1] ^ b.w[1], rhs.w[2] ^ t.w[2] ^ b.w[2]}};
    return feq(lhs, rhs);
}

/* ------------------------------------------------ Velu (same formula as transport.velu_eval) */
#define MK 131
static fe velu_eval(const fe *xs, const fe *sqs, fe v, fe x, fe y, fe *Yout) {
    fe d[MK], pref[MK], e[MK];
    for (int i = 0; i < MK; i++) d[i] = fadd(x, xs[i]);
    fe acc = d[0];
    pref[0] = acc;
    for (int i = 1; i < MK; i++) { acc = fmul(acc, d[i]); pref[i] = acc; }
    fe inv = finv(acc);
    for (int i = MK - 1; i > 0; i--) { e[i] = fmul(inv, pref[i - 1]); inv = fmul(inv, d[i]); }
    e[0] = inv;
    fe X = x, Y = y, xy = fadd(x, y);
    for (int i = 0; i < MK; i++) {
        fe a = fmul(xs[i], e[i]);
        X = fadd(X, fadd(a, fsqr(a)));
        fe ae = fmul(a, e[i]);
        fe inner = fadd(fadd(fmul(a, x), xy), sqs[i]);
        Y = fadd(Y, fmul(ae, inner));
    }
    *Yout = fadd(Y, v);
    return X;
}

/* ------------------------------------------------ parsing, rng, timing */
static fe hex2fe(const char *s) {
    fe o = ZERO;
    size_t n = strlen(s);
    for (size_t i = 0; i < n; i++) {
        char c = s[n - 1 - i];
        int d = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : (c - 'A' + 10);
        size_t bit = 4 * i;
        if (bit < 192) o.w[bit / 64] |= ((uint64_t)d) << (bit % 64);
    }
    return o;
}
static int hex2words(const char *s, uint64_t *w, int maxw) {
    memset(w, 0, sizeof(uint64_t) * maxw);
    size_t n = strlen(s);
    for (size_t i = 0; i < n; i++) {
        char c = s[n - 1 - i];
        int d = (c >= '0' && c <= '9') ? c - '0' : (c - 'a' + 10);
        size_t bit = 4 * i;
        w[bit / 64] |= ((uint64_t)d) << (bit % 64);
    }
    return (int)((4 * n + 63) / 64);
}
static int cmpfe(const void *a, const void *b) {
    const fe *x = a, *y = b;
    for (int i = 2; i >= 0; i--) {
        if (x->w[i] < y->w[i]) return -1;
        if (x->w[i] > y->w[i]) return 1;
    }
    return 0;
}
static uint64_t rs = 0x9E3779B97F4A7C15ULL;
static uint64_t rnd(void) { rs ^= rs >> 12; rs ^= rs << 25; rs ^= rs >> 27; return rs * 2685821657736338717ULL; }
static fe rndfe(void) { fe o = {{rnd(), rnd(), rnd() & 7}}; return o; }
static double cpu_now(void) {
    struct timespec ts;
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
    return ts.tv_sec + 1e-9 * ts.tv_nsec;
}

static uint64_t COF[4], NW[4], K263[1] = {263};
static int COFn, Nn;

/* BUILD: returns number of x tried; fills xs (131), sqs, v */
static int build(fe b, fe *xs, fe *sqs, fe *v) {
    int tries_x = 0;
    for (;;) {
        pt U;
        for (;;) {
            fe x = rndfe();
            if (fzero(x)) continue;
            tries_x++;
            fe ix = finv(x);
            fe c = fadd(fadd(x, ONE), fmul(b, fsqr(ix)));          /* x + a2 + b/x^2, a2 = 1 */
            if (ftrace(c)) continue;
            fe z = fhalftrace(c);
            if (rnd() & 1) z = fadd(z, ONE);
            U.x = x; U.y = fmul(x, z); U.inf = 0;
            break;
        }
        pt Q = pmul(COF, COFn, U, ONE);
        pt P = pmul(K263, 1, Q, ONE);
        if (P.inf) continue;
        pt R = P;
        for (int i = 0; i < MK; i++) {
            xs[i] = R.x;
            if (i < MK - 1) R = padd(R, P, ONE);
        }
        break;
    }
    fe s = ZERO;
    for (int i = 0; i < MK; i++) { sqs[i] = fsqr(xs[i]); s = fadd(s, xs[i]); }
    *v = s;
    return tries_x;
}

int main(int argc, char **argv) {
    const char *fn = argc > 1 ? argv[1] : "c_input.txt";
    int reps_eval = argc > 2 ? atoi(argv[2]) : 20000;
    int reps_build = argc > 3 ? atoi(argv[3]) : 200;
    FILE *f = fopen(fn, "r");
    if (!f) { perror("open"); return 1; }
    static char buf[1 << 16];
    char tok[256];
    /* trace mask */
    for (int i = 0; i < 131; i++) {
        fe zi = ZERO; zi.w[i / 64] = 1ULL << (i % 64);
        if (trace_slow(zi)) TRMASK.w[i / 64] |= 1ULL << (i % 64);
    }
    if (fscanf(f, "%255s", tok) != 1) return 1; COFn = hex2words(tok, COF, 4);
    if (fscanf(f, "%255s", tok) != 1) return 1; Nn = hex2words(tok, NW, 4);
    int ncur; if (fscanf(f, "%d", &ncur) != 1) return 1;
    /* sanity of field arithmetic: a * a^-1 == 1, (a*b)*c == a*(b*c), sqr == mul */
    for (int i = 0; i < 1000; i++) {
        fe a = rndfe(), b2 = rndfe(), c = rndfe();
        if (fzero(a)) continue;
        if (!feq(fmul_nc(a, finv_nc(a)), ONE)) { printf("inv FAIL\n"); return 2; }
        if (!feq(fmul_nc(fmul_nc(a, b2), c), fmul_nc(a, fmul_nc(b2, c)))) { printf("assoc FAIL\n"); return 2; }
        if (!feq(fsqr_nc(a), fmul_nc(a, a))) { printf("sqr FAIL\n"); return 2; }
        fe l = fmul_nc(a, fadd(b2, c)), r = fadd(fmul_nc(a, b2), fmul_nc(a, c));
        if (!feq(l, r)) { printf("distrib FAIL\n"); return 2; }
    }
    fe xs[MK], sqs[MK], bx[MK], bsq[MK], v, bv;
    int n_kernel_eq = 0, n_j1 = 0, n_py = 0, n_onE0 = 0, n_ordN = 0, n_planted = 0, n_ok = 0;
    long long evM = -1, evS = -1, evI = -1, evA = -1;
    int eval_count_const = 1;
    long long bmin[4] = {1LL << 60, 1LL << 60, 1LL << 60, 1LL << 60}, bmax[4] = {0, 0, 0, 0};
    double t_build_sum = 0; int t_build_n = 0;
    fe keepx[MK], keepsq[MK], keepv, keepb; pt keepR[64]; int nkeep = 0;
    for (int c = 0; c < ncur; c++) {
        char lab[64], bh[256];
        if (fscanf(f, "%63s %255s", lab, bh) != 2) return 1;
        fe b = hex2fe(bh);
        for (int i = 0; i < MK; i++) { if (fscanf(f, "%255s", tok) != 1) return 1; xs[i] = hex2fe(tok); sqs[i] = fsqr_nc(xs[i]); }
        v = ZERO; for (int i = 0; i < MK; i++) v = (fe){{v.w[0] ^ xs[i].w[0], v.w[1] ^ xs[i].w[1], v.w[2] ^ xs[i].w[2]}};
        char rx[256], ry[256], kh[256], sx[256], sy[256], px[256], py[256];
        if (fscanf(f, "%255s %255s %255s %255s %255s %255s %255s", rx, ry, kh, sx, sy, px, py) != 7) return 1;
        pt R = {hex2fe(rx), hex2fe(ry), 0}, S = {hex2fe(sx), hex2fe(sy), 0};
        uint64_t kw[4]; int kn = hex2words(kh, kw, 4);
        /* 1. build from scratch */
        cM = cS = cI = cA = 0;
        double t0 = cpu_now();
        int tx = build(b, bx, bsq, &bv);
        t_build_sum += cpu_now() - t0; t_build_n++;
        long long bc[4] = {(long long)cM, (long long)cS, (long long)cI, (long long)cA};
        for (int k = 0; k < 4; k++) { if (bc[k] < bmin[k]) bmin[k] = bc[k]; if (bc[k] > bmax[k]) bmax[k] = bc[k]; }
        if (bc[2] > 330) fprintf(stderr, "build-outlier %s M=%lld S=%lld I=%lld x_tried=%d\n", lab, bc[0], bc[1], bc[2], tx);
        fe s1[MK], s2[MK];
        memcpy(s1, xs, sizeof s1); memcpy(s2, bx, sizeof s2);
        qsort(s1, MK, sizeof(fe), cmpfe); qsort(s2, MK, sizeof(fe), cmpfe);
        int keq = memcmp(s1, s2, sizeof s1) == 0;
        fe jj = fadd(fadd(b, bv), fsqr_nc(bv));
        int j1 = feq(jj, ONE);
        (void)tx;
        /* 2. evaluate with the C-built kernel (order of xs irrelevant) */
        pt pR, pS;
        cM = cS = cI = cA = 0;
        pR.x = velu_eval(bx, bsq, bv, R.x, R.y, &pR.y); pR.inf = 0;
        if (evM < 0) { evM = cM; evS = cS; evI = cI; evA = cA; }
        else if (evM != (long long)cM || evS != (long long)cS || evI != (long long)cI || evA != (long long)cA) eval_count_const = 0;
        pS.x = velu_eval(bx, bsq, bv, S.x, S.y, &pS.y); pS.inf = 0;
        int py_eq = feq(pR.x, hex2fe(px)) && feq(pR.y, hex2fe(py));
        int onE0 = on_curve(pR, ZERO, ONE) && on_curve(pS, ZERO, ONE);
        pt NR = pmul(NW, Nn, pR, ZERO);
        int ordN = NR.inf && !pR.inf;
        pt kR = pmul(kw, kn, pR, ZERO);
        int planted = !kR.inf && feq(kR.x, pS.x) && feq(kR.y, pS.y);
        int ok = keq && j1 && py_eq && onE0 && ordN && planted;
        n_kernel_eq += keq; n_j1 += j1; n_py += py_eq; n_onE0 += onE0; n_ordN += ordN; n_planted += planted; n_ok += ok;
        if (!ok) printf("FAIL %s keq=%d j1=%d py=%d onE0=%d ordN=%d planted=%d\n", lab, keq, j1, py_eq, onE0, ordN, planted);
        if (c == 0) { memcpy(keepx, bx, sizeof keepx); memcpy(keepsq, bsq, sizeof keepsq); keepv = bv; keepb = b; }
        if (c == 0 || nkeep < 64) {}
    }
    fclose(f);
    printf("{\n \"n_curves\": %d, \"n_kernel_equal_stored\": %d, \"n_codomain_j1\": %d, \"n_eval_equals_python\": %d,\n"
           " \"n_images_on_E0\": %d, \"n_image_order_N\": %d, \"n_planted_k_ok\": %d, \"n_all_ok\": %d,\n",
           ncur, n_kernel_eq, n_j1, n_py, n_onE0, n_ordN, n_planted, n_ok);
    printf(" \"C_eval_ops\": {\"M\": %lld, \"S\": %lld, \"I\": %lld, \"A\": %lld}, \"C_eval_ops_constant\": %d,\n", evM, evS, evI, evA, eval_count_const);
    printf(" \"C_build_ops_min\": {\"M\": %lld, \"S\": %lld, \"I\": %lld, \"A_incl_trace\": %lld},\n", bmin[0], bmin[1], bmin[2], bmin[3]);
    printf(" \"C_build_ops_max\": {\"M\": %lld, \"S\": %lld, \"I\": %lld, \"A_incl_trace\": %lld},\n", bmax[0], bmax[1], bmax[2], bmax[3]);
    printf(" \"C_build_mean_cpu_s_first_pass\": %.3e,\n", t_build_sum / t_build_n);

    /* ------------------------------------------------ timing */
    fe acc = rndfe(), acc2 = rndfe();
    const int NM = 5000000;
    double t0, t1;
    fe arr[1024]; for (int i = 0; i < 1024; i++) { arr[i] = rndfe(); if (fzero(arr[i])) arr[i] = ONE; }
    double best_M = 1e9, best_S = 1e9, best_I = 1e9, best_add = 1e9, best_badd = 1e9, best_eval = 1e9, best_build = 1e9;
    for (int rep = 0; rep < 5; rep++) {
        t0 = cpu_now(); for (int i = 0; i < NM; i++) acc = fmul_nc(acc, arr[i & 1023]); t1 = cpu_now();
        if ((t1 - t0) / NM < best_M) best_M = (t1 - t0) / NM;
        t0 = cpu_now(); for (int i = 0; i < NM; i++) acc2 = fsqr_nc(acc2); t1 = cpu_now();
        if ((t1 - t0) / NM < best_S) best_S = (t1 - t0) / NM;
        t0 = cpu_now(); for (int i = 0; i < NM / 50; i++) { acc = finv_nc(fadd(acc, arr[i & 1023])); } t1 = cpu_now();
        if ((t1 - t0) / (NM / 50) < best_I) best_I = (t1 - t0) / (NM / 50);
    }
    /* E0 points: random points on y^2+xy=x^3+1 */
    pt P0[1024];
    for (int i = 0; i < 1024; i++) {
        for (;;) {
            fe x = rndfe(); if (fzero(x)) continue;
            fe c = fadd(x, fsqr_nc(finv_nc(x)));   /* x + 0 + 1/x^2 */
            if (ftrace(c)) continue;
            fe z = fhalftrace(c);
            P0[i].x = x; P0[i].y = fmul_nc(x, z); P0[i].inf = 0;
            break;
        }
        if (!on_curve(P0[i], ZERO, ONE)) { printf("E0 point gen FAIL\n"); return 3; }
    }
    /* plain affine addition walk (1I + 2M + 1S) */
    for (int rep = 0; rep < 5; rep++) {
        pt W = P0[0];
        int n = 200000;
        t0 = cpu_now();
        for (int i = 0; i < n; i++) W = padd(W, P0[(i * 7 + 1) & 1023], ZERO);
        t1 = cpu_now();
        if ((t1 - t0) / n < best_add) best_add = (t1 - t0) / n;
        acc = fadd(acc, W.x);
    }
    /* Montgomery-batched affine additions: 256 parallel walks, 1 inversion per batch (lower bound for 1 rho step) */
    {
        enum { B = 256 };
        pt W[B]; fe den[B], pre[B];
        for (int i = 0; i < B; i++) W[i] = P0[i];
        for (int rep = 0; rep < 5; rep++) {
            int rounds = 2000;
            t0 = cpu_now();
            for (int r = 0; r < rounds; r++) {
                for (int i = 0; i < B; i++) { pt Q = P0[(i * 31 + r * 17 + 3) & 1023]; den[i] = fadd(W[i].x, Q.x); }
                fe a = den[0]; pre[0] = a;
                for (int i = 1; i < B; i++) { a = fmul_nc(a, den[i]); pre[i] = a; }
                fe inv = finv_nc(a);
                for (int i = B - 1; i >= 0; i--) {
                    fe e = i ? fmul_nc(inv, pre[i - 1]) : inv;
                    if (i) inv = fmul_nc(inv, den[i]);
                    pt Q = P0[(i * 31 + r * 17 + 3) & 1023];
                    fe lam = fmul_nc(fadd(W[i].y, Q.y), e);
                    fe x3 = fadd(fadd(fadd(fsqr_nc(lam), lam), W[i].x), Q.x);
                    fe y3 = fadd(fadd(fmul_nc(lam, fadd(W[i].x, x3)), x3), W[i].y);
                    W[i].x = x3; W[i].y = y3;
                }
            }
            t1 = cpu_now();
            double per = (t1 - t0) / ((double)rounds * B);
            if (per < best_badd) best_badd = per;
        }
        int okc = 1; for (int i = 0; i < B; i++) okc &= on_curve(W[i], ZERO, ONE);
        printf(" \"batched_walk_points_on_E0\": %d,\n", okc);
    }
    /* velu_eval */
    for (int rep = 0; rep < 5; rep++) {
        fe Y;
        t0 = cpu_now();
        for (int i = 0; i < reps_eval; i++) { fe X = velu_eval(keepx, keepsq, keepv, P0[i & 1023].x, P0[i & 1023].y, &Y); acc = fadd(acc, X); }
        t1 = cpu_now();
        if ((t1 - t0) / reps_eval < best_eval) best_eval = (t1 - t0) / reps_eval;
    }
    /* full build */
    for (int rep = 0; rep < 5; rep++) {
        fe v2;
        t0 = cpu_now();
        for (int i = 0; i < reps_build; i++) build(keepb, bx, bsq, &v2);
        t1 = cpu_now();
        if ((t1 - t0) / reps_build < best_build) best_build = (t1 - t0) / reps_build;
    }
    double transport = best_build + 2 * best_eval;
    printf(" \"cpu_s\": {\"M\": %.3e, \"S\": %.3e, \"I\": %.3e, \"E0_affine_add\": %.3e, \"E0_batched_affine_add\": %.3e,"
           " \"velu_eval\": %.3e, \"build\": %.3e, \"transport_build_plus_2_eval\": %.3e},\n",
           best_M, best_S, best_I, best_add, best_badd, best_eval, best_build, transport);
    printf(" \"transport_in_M_units\": %.1f, \"transport_in_batched_adds\": %.1f, \"transport_in_affine_adds\": %.1f,\n",
           transport / best_M, transport / best_badd, transport / best_add);
    printf(" \"velu_eval_in_batched_adds\": %.1f,\n", best_eval / best_badd);
    printf(" \"sink\": %llu\n}\n", (unsigned long long)(acc.w[0] ^ acc2.w[0]));
    return 0;
}
