default(parisize, 2*10^9);
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
A = sum(i=0,17000, random(z)*'X^i);
B = sum(i=0,17000, random(z)*'X^i);
t0=getabstime(); C = A*B; print("mul 17000x17000: ", getabstime()-t0, " ms deg ", poldegree(C));
t0=getabstime(); D = C % (A + 'X^17001); print("rem: ", getabstime()-t0, " ms");
t0=getabstime(); g = gcd(A, B); print("gcd: ", getabstime()-t0, " ms deg ", poldegree(g));
