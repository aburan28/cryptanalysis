\\ C3 recompute (fast variant): for each floor curve, F(Y) = Phi_263(j, Y) over F_q.
\\ G = gcd(F, Y^q - Y) is the product of the distinct F_q-roots; check G = Y + 1
\\ (only root j = 1, i.e. E0) and that Y = 1 is a simple root ((Y+1)^2 does not divide F).
\\ Run with KLO, NSH, SH defined (shard k = KLO.. with (k-KLO) % NSH == SH).
default(parisize, 10^9);
read("phi263_mod2.gp"); read("gp_input_j.gp");
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
ffint(n) = my(v = binary(n), r = 0*z); for(i=1,#v, r = r*z + v[i]); r;
one = z^0;
nok = 0; nfloor = 0;
{
for(k = KLO, #LABJ, if((k - KLO) % NSH != SH, next); if(LABJ[k] == "E0", next);
  my(j = ffint(JJ[k]), F, R, G, simple, ok, t0 = getabstime());
  F = subst(PHI2, 'x, j) * one;
  R = Mod('y * one, F);
  for(i = 1, 131, R = R^2);
  G = gcd(lift(R) - 'y, F);
  G = G / pollead(G);
  simple = (F % (('y + one)^2)) != 0;
  ok = (poldegree(F) == 264) && (G == 'y + one) && simple;
  nfloor++; if(ok, nok++);
  print(LABJ[k], " degF=", poldegree(F), " gcd_with_Yq_minus_Y=", G, " simple_root=", simple, " ok=", ok, " ms=", getabstime()-t0);
);
print("FAST_FLOOR_OK ", nok, " / ", nfloor);
}
