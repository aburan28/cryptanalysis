"""C3 recompute, pure Python (no Sage, no PARI, no sweep code).

For every floor curve E = [1,0,0,0,b] (b read from ground_truth.json):
  twist route  : on E' = [1,1,0,0,b] over F_q, certify #E' = T = q+1+t, find a point
                 of order 263^2, take K' = 263*Q, list x(i*K') for i = 1..131.
  F_q2 route   : on E over F_q2 = F_q(s), s^2+s+1 = 0, certify #E(F_q) = 4N, so
                 #E(F_q2) = 4N*T; find a point of order 263^2 in E(F_q2), P = 263*Q,
                 check Frob_q(P) = -P, x(P) in F_q, y(P) not in F_q; list x(i*P).
  compare      : both x-sets with each other and with kernels_all.json[label];
                 check Tr(x + b/x^2) = 1 for every kernel x (no F_q point on E);
                 Velu codomain j = 1/(b + v + v^2), v = sum x, should be 1 (E0).
Usage: python3 c3_pure.py [nproc]
"""
import json
import os
import random
import sys
import time
import hashlib
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gf2m import (M, q, FQ, FQ2, Curve, mul, sqr, inv, tr, rand_point_Fq, rand_point_Fq2,
                  e_frob_q, sqrt_)

HERE = os.path.dirname(os.path.abspath(__file__))
GT = "/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"
KER = "/Volumes/SSD990/ecdlp-hardness-work/transport-263/kernels_all.json"
L = 263


def miller_rabin(n, rounds=40, seed=7):
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    rng = random.Random(seed)
    for _ in range(rounds):
        a = rng.randrange(2, n - 1)
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def constants():
    # Lucas sequence for tau^2 + tau + 2 = 0: t_1 = -1, t_{k+1} = -t_k - 2 t_{k-1}
    # (#E0(F_2) = 4 by brute force below gives t_1 = 2+1-4 = -1)
    pts = 1  # O
    for x in (0, 1):
        for y in (0, 1):
            if (y * y + x * y - (x ** 3 + 1)) % 2 == 0:
                pts += 1
    assert pts == 4
    t1 = 2 + 1 - pts
    a, b_ = 2, t1  # t_0, t_1
    for _ in range(M - 1):
        a, b_ = b_, t1 * b_ - 2 * a
    t = b_
    card = q + 1 - t
    assert card % 4 == 0
    N = card // 4
    T = q + 1 + t
    return t, card, N, T


t, CARD, N, T = constants()
assert t == -22283658519494248867, t
v263 = 0
_x = T
while _x % L == 0:
    _x //= L
    v263 += 1
H_TW = T // L ** 2           # twist cofactor
P114 = H_TW // 2
CARD2 = (q + 1) ** 2 - t ** 2  # #E(F_q2) = #E(F_q) * #E'(F_q)
assert CARD2 == CARD * T
M2 = CARD2 // L ** 2


def run_label(args):
    label, b_int, j_int, stored_hex = args
    t0 = time.time()
    rng = random.Random("C3pure:" + label)
    rec = {"label": label}
    b = b_int
    rec["b_times_j_is_1"] = mul(b, j_int) == 1
    # ---------------- twist route (F_q) ----------------
    Ct = Curve(FQ, 1, b)
    two_tors = (0, sqrt_(b))
    rec["tw_2torsion_ok"] = Ct.on(two_tors) and Ct.dbl(two_tors) is None
    tries = 0
    while True:
        tries += 1
        U = rand_point_Fq(Ct, rng)
        if Ct.mulk(T, U) is not None:
            rec["tw_T_kills_U"] = False
            break
        rec["tw_T_kills_U"] = True
        # order of U divisible by P114 (prime) => ord > 4 sqrt(q) => #E' = T
        if Ct.mulk(T // P114, U) is None:
            continue
        Q = Ct.mulk(H_TW, U)
        if Ct.mulk(L, Q) is None:
            continue
        break
    rec["tw_tries"] = tries
    rec["tw_card_certified_T"] = rec["tw_T_kills_U"]  # plus P114 | ord(U), checked in loop
    rec["tw_Q_order_263sq"] = Ct.mulk(L * L, Q) is None and Ct.mulk(L, Q) is not None
    K = Ct.mulk(L, Q)
    rec["tw_K_order_263"] = K is not None and Ct.mulk(L, K) is None
    xs_tw = []
    R = None
    for i in range(1, 132):
        R = Ct.add(R, K)
        xs_tw.append(R[0])
    # the other half are negatives: check 262*K = -K and 132*K = -(131*K)
    R132 = Ct.add(R, K)
    rec["tw_half_closed"] = R132 is not None and R132[0] == xs_tw[-1] and R132 == Ct.neg(R)
    rec["tw_xs_distinct_131_nonzero"] = len(set(xs_tw)) == 131 and 0 not in xs_tw
    # ---------------- F_q2 route on E itself ----------------
    Cq = Curve(FQ, 0, b)
    while True:
        V = rand_point_Fq(Cq, rng)
        if Cq.mulk(4, V) is not None:
            break
    # CARD*V = O and 4V != O => N | ord(V) => #E(F_q) = 4N (only multiple of N in Hasse)
    rec["E_card_4N_certified"] = Cq.mulk(CARD, V) is None
    rec["E_Fq_no_263"] = CARD % L != 0
    C2 = Curve(FQ2, (0, 0), (b, 0))
    tries2 = 0
    while True:
        tries2 += 1
        U2 = rand_point_Fq2(C2, rng)
        Q2 = C2.mulk(M2, U2)
        if Q2 is None or C2.mulk(L, Q2) is None:
            continue
        break
    rec["fq2_tries"] = tries2
    rec["fq2_Q_order_263sq"] = C2.mulk(L * L, Q2) is None
    P = C2.mulk(L, Q2)
    rec["fq2_P_order_263"] = P is not None and C2.mulk(L, P) is None
    FP = (e_frob_q(P[0]), e_frob_q(P[1]))
    rec["fq2_frob_P_eq_minus_P"] = FP == C2.neg(P)
    rec["fq2_frob_P_ne_P"] = FP != P
    rec["fq2_x_in_Fq"] = P[0][1] == 0
    rec["fq2_y_not_in_Fq"] = P[1][1] != 0
    xs_2 = []
    R = None
    allx_fq = True
    ally_not_fq = True
    for i in range(1, 132):
        R = C2.add(R, P)
        allx_fq &= R[0][1] == 0
        ally_not_fq &= R[1][1] != 0
        xs_2.append(R[0][0])
    rec["fq2_all_131_x_in_Fq"] = allx_fq
    rec["fq2_all_131_y_not_in_Fq"] = ally_not_fq
    # ---------------- comparisons ----------------
    s_tw = set(xs_tw)
    s_2 = set(xs_2)
    stored = [int(h, 16) for h in stored_hex]
    s_st = set(stored)
    rec["stored_len"] = len(stored)
    rec["info_stored_int_ascending"] = str(stored == sorted(stored))
    rec["twist_eq_fq2"] = s_tw == s_2
    rec["twist_eq_stored"] = s_tw == s_st
    rec["fq2_eq_stored"] = s_2 == s_st
    rec["no_Fq_point_on_E_for_kernel_x"] = all(tr(x ^ mul(b, inv(sqr(x)))) == 1 for x in xs_tw)
    rec["twist_has_Fq_point_for_kernel_x"] = all(tr(x ^ 1 ^ mul(b, inv(sqr(x)))) == 0 for x in xs_tw)
    v = 0
    for x in xs_tw:
        v ^= x
    jc_den = b ^ v ^ sqr(v)
    rec["velu_codomain_j_is_1"] = jc_den == 1
    # kernel polynomial coefficients (F_q), digest
    poly = [1]  # low -> high
    for x in sorted(xs_tw):
        new = [0] * (len(poly) + 1)
        for i, c in enumerate(poly):
            new[i + 1] ^= c
            new[i] ^= mul(c, x)
        poly = new
    rec["kernel_poly_deg"] = len(poly) - 1
    rec["kernel_poly_sha256"] = hashlib.sha256(",".join(hex(c) for c in poly).encode()).hexdigest()
    rec["seconds"] = round(time.time() - t0, 2)
    flags = [k for k, v_ in rec.items() if isinstance(v_, bool)]
    rec["all_ok"] = all(rec[k] for k in flags)
    return rec


def main():
    nproc = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    only = sys.argv[2].split(",") if len(sys.argv) > 2 else None
    gt = json.load(open(GT))
    ker = json.load(open(KER))
    jobs = []
    for c in gt["curves"]:
        if c["label"] == "E0":
            continue
        if only and c["label"] not in only:
            continue
        jobs.append((c["label"], int(c["b_int"]), int(c["j_int"]), ker.get(c["label"], [])))
    glob = {
        "t": str(t), "t_matches_task": t == -22283658519494248867,
        "CARD_is_4N": CARD == 4 * N, "N": str(N),
        "N_mr_prime": miller_rabin(N),
        "T": str(T), "v263_T": v263, "v263_CARD": 0 if CARD % L else "nonzero",
        "T_over_263sq": str(H_TW), "T_over_263sq_even": H_TW % 2 == 0,
        "P114": str(P114), "P114_bits": P114.bit_length(), "P114_mr_prime": miller_rabin(P114),
        "t_mod_263": t % L, "q_mod_263": q % L,
        "charpoly_mod_263_is_(X+1)^2": (t % L == L - 2) and (q % L == 1),
        "disc_mod_263": (t * t - 4 * q) % L,
        "n_jobs": len(jobs), "labels_in_kernels_all": len(ker),
    }
    print(json.dumps(glob, indent=1), flush=True)
    t0 = time.time()
    with Pool(nproc) as pool:
        recs = []
        for r in pool.imap_unordered(run_label, jobs):
            recs.append(r)
            print(r["label"], r["all_ok"], r["seconds"], flush=True)
    recs.sort(key=lambda r: r["label"])
    flags = sorted({k for r in recs for k, v_ in r.items() if isinstance(v_, bool)})
    counts = {k: sum(1 for r in recs if r.get(k) is True) for k in flags}
    out = {"global": glob, "counts_true": counts, "n": len(recs),
           "wall_seconds": round(time.time() - t0, 1), "per_curve": recs}
    tag = "all" if not only else "subset"
    json.dump(out, open(os.path.join(HERE, "c3_pure_%s.json" % tag), "w"), indent=1)
    print(json.dumps(counts, indent=1))
    print("n", len(recs), "wall", out["wall_seconds"])


if __name__ == "__main__":
    main()
