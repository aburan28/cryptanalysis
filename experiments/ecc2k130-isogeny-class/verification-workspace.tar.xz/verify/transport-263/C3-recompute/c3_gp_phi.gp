\\ C3 recompute: count F_q-rational 263-isogenies from each curve via the classical
\\ modular polynomial Phi_263 (PARI polmodular over Z, reduced mod 2).
\\ #F_q-roots of Phi_263(j(E), Y), with multiplicity, bounds the number of F_q-rational
\\ cyclic 263-subgroups; a simple root plus irreducible rest means exactly one.
default(parisize, 2*10^9);
read("phi263_mod2.gp"); read("gp_input_j.gp");
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
ffint(n) = my(v = binary(n), r = 0*z); for(i=1,#v, r = r*z + v[i]); r;
one = z^0;
nok = 0; nfloor = 0;
{
for(k = 1, #LABJ,
  my(j = ffint(JJ[k]), F, fa, degs, rat = 0, ratroots = List(), t0 = getabstime(), ok);
  F = subst(PHI2, 'x, j) * one;
  fa = factor(F);
  degs = vector(#fa~, i, [poldegree(fa[i,1]), fa[i,2]]);
  for(i = 1, #fa~, if(poldegree(fa[i,1]) == 1, rat += fa[i,2]; listput(ratroots, [-polcoef(fa[i,1],0)/polcoef(fa[i,1],1), fa[i,2]])));
  if(LABJ[k] == "E0",
     print(LABJ[k], " degF=", poldegree(F), " factor_degs[deg,mult]=", degs, " rational_roots_with_mult=", Vec(ratroots)),
     nfloor++;
     ok = (poldegree(F) == 264) && (rat == 1) && (#ratroots == 1) && (ratroots[1][1] == one) && (ratroots[1][2] == 1);
     if(ok, nok++);
     print(LABJ[k], " degF=", poldegree(F), " factor_degs[deg,mult]=", degs, " n_rational_roots=", rat, " root_is_1=", ratroots[1][1] == one, " ok=", ok, " ms=", getabstime()-t0));
);
print("FLOOR_OK ", nok, " / ", nfloor);
}
