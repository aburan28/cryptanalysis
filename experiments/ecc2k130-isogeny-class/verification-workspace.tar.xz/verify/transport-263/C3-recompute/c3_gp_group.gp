\\ C3 recompute with standalone PARI/GP (not Sage): group structure of the twist,
\\ kernel from PARI's own generator, comparison with kernels_all.json.
default(parisize, 10^9);
read("gp_input.gp"); read("stored_kernels.gp");
z = ffgen(Mod(1,2)*(x^131+x^13+x^2+x+1), 'z);
ffint(n) = my(v = binary(n), r = 0*z); for(i=1,#v, r = r*z + v[i]); r;
fftoint(u) = my(p = u.pol); if(type(p)=="t_POL", subst(lift(p), variable(p), 2), lift(p));
q = 2^131; t = -22283658519494248867; T = q+1+t; CARD = q+1-t;
nok = 0;
{
for(k = 1, #LAB,
  my(b = ffint(BB[k]), Et = ellinit([1,1,0,0,b]), E = ellinit([1,0,0,0,b]), G, cyc, g, K, xs = List(), R, ok, st, cyc263, e263, Gsyl);
  G = ellgroup(Et, , 1); cyc = G[2]; ok0 = (G[1] == T);
  \\ 263-part of each invariant factor
  cyc263 = vector(#cyc, i, valuation(cyc[i], 263));
  ok = ok0 && (ellcard(Et) == T) && (ellcard(E) == CARD) && (vecsum(cyc263) == 2) && (#select(e -> e > 0, cyc263) == 1);
  \\ generator carrying the 263-part: component with valuation 2
  my(idx = 0); for(i = 1, #cyc, if(cyc263[i] == 2, idx = i));
  g = G[3][idx];
  Gsyl = ellmul(Et, g, cyc[idx] / 263^2);
  ok = ok && (ellorder(Et, Gsyl) == 263^2);
  K = ellmul(Et, Gsyl, 263);
  ok = ok && (ellorder(Et, K) == 263);
  R = K;
  for(i = 1, 131, listput(xs, fftoint(R[1])); R = elladd(Et, R, K));
  xs = Set(Vec(xs));
  st = Set(STORED[k]);
  ok = ok && (#xs == 131) && (xs == st);
  \\ E(F_q) has no 263-torsion
  ok = ok && (valuation(ellcard(E), 263) == 0);
  if(ok, nok++);
  print(LAB[k], " cyc=", cyc, " v263=", cyc263, " kernel_matches_stored=", xs == st, " ok=", ok);
);
print("NOK ", nok, " / ", #LAB);
}
