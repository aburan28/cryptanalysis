"""Standalone pure-Python arithmetic for F_q = F_2[z]/(z^131+z^13+z^2+z+1) and
F_{q^2} = F_q[s]/(s^2+s+1), plus affine arithmetic on y^2 + xy = x^3 + a2 x^2 + b.

Written for the C3 recompute check. It uses no Sage and no PARI, and none of the
transport-263 sweep code. Field elements of F_q are ints (bit i = coeff of z^i).
F_{q^2} elements are pairs (a0, a1) meaning a0 + a1*s, with s^2 = s + 1.
"""
import random

M = 131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << M) - 1
q = 1 << M


def red(c):
    while c >> M:
        hi = c >> M
        c = (c & MASK) ^ hi ^ (hi << 1) ^ (hi << 2) ^ (hi << 13)
    return c


def clmul(a, b):
    """carry-less product via a 4-bit window table"""
    if a == 0 or b == 0:
        return 0
    t = [0] * 16
    t[1] = a
    for i in range(2, 16):
        t[i] = (t[i >> 1] << 1) if (i & 1) == 0 else (t[i - 1] ^ a)
    r = 0
    nb = (b.bit_length() + 3) // 4
    for k in range(nb - 1, -1, -1):
        r = (r << 4) ^ t[(b >> (4 * k)) & 15]
    return r


def mul(a, b):
    return red(clmul(a, b))


# squaring: spread bits (independent of clmul)
_SPREAD = [0] * 256
for _i in range(256):
    _v = 0
    for _k in range(8):
        if (_i >> _k) & 1:
            _v |= 1 << (2 * _k)
    _SPREAD[_i] = _v


def sqr(a):
    r = 0
    k = 0
    while a:
        r |= _SPREAD[a & 255] << (16 * k)
        a >>= 8
        k += 1
    return red(r)


def inv(a):
    """extended Euclid in F_2[z]"""
    if a == 0:
        raise ZeroDivisionError
    u, v = a, MOD
    g1, g2 = 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v = v, u
            g1, g2 = g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return red(g1)


def frob_pow(a, k):
    for _ in range(k):
        a = sqr(a)
    return a


def trace_slow(a):
    s = a
    acc = a
    for _ in range(M - 1):
        s = sqr(s)
        acc ^= s
    assert acc in (0, 1)
    return acc


# trace as a linear functional: TMASK bit i = Tr(z^i)
TMASK = 0
for _i in range(M):
    if trace_slow(1 << _i):
        TMASK |= 1 << _i


def tr(a):
    return bin(a & TMASK).count("1") & 1


def half_trace(c):
    """h with h^2 + h = c when Tr(c) = 0 (M odd)"""
    h = c
    s = c
    for _ in range((M - 1) // 2):
        s = sqr(sqr(s))
        h ^= s
    return h


def sqrt_(a):
    return frob_pow(a, M - 1)


# ---------------- F_{q^2} = F_q(s), s^2 = s + 1 -----------------
# s^2 + s + 1 is irreducible over F_q iff Tr(1) = 1 (M odd)
def e_add(x, y):
    return (x[0] ^ y[0], x[1] ^ y[1])


def e_mul(x, y):
    a0, a1 = x
    b0, b1 = y
    p0 = mul(a0, b0)
    p1 = mul(a1, b1)
    pm = mul(a0 ^ a1, b0 ^ b1)
    # (a0 + a1 s)(b0 + b1 s) = a0b0 + (a0b1+a1b0) s + a1b1 (s+1)
    return (p0 ^ p1, pm ^ p0)  # pm ^ p0 ^ p1 + p1 = pm ^ p0


def e_sqr(x):
    a0, a1 = x
    s0 = sqr(a0)
    s1 = sqr(a1)
    # a0^2 + a1^2 s^2 = a0^2 + a1^2 + a1^2 s
    return (s0 ^ s1, s1)


def e_inv(x):
    a0, a1 = x
    n = sqr(a0) ^ mul(a0, a1) ^ sqr(a1)  # norm to F_q
    ni = inv(n)
    return (mul(a0 ^ a1, ni), mul(a1, ni))  # conj = (a0+a1) + a1 s


def e_frob_q(x):
    """x^q : s -> s + 1"""
    a0, a1 = x
    return (a0 ^ a1, a1)


def e_tr_to_F2(x):
    # Tr_{F_q2/F_2}(a0 + a1 s) = Tr_{F_q/F_2}(Tr_{F_q2/F_q}) = Tr(a1)  (since s + s^q = 1)
    return tr(x[1])


def e_solve_artin(c):
    """z in F_q2 with z^2 + z = c, assuming Tr(c)=0 in F_q2"""
    c0, c1 = c
    assert tr(c1) == 0
    z1 = half_trace(c1)
    # need z0^2 + z0 = c0 + z1^2
    r = c0 ^ sqr(z1)
    if tr(r) != 0:
        z1 ^= 1
        r = c0 ^ sqr(z1)
    assert tr(r) == 0
    z0 = half_trace(r)
    z = (z0, z1)
    assert e_add(e_sqr(z), z) == c
    return z


# --------------- curves -------------------------
class Field:
    def __init__(self, add, mul, sqr, inv, zero, one):
        self.add, self.mul, self.sqr, self.inv, self.zero, self.one = add, mul, sqr, inv, zero, one


FQ = Field(lambda a, b: a ^ b, mul, sqr, inv, 0, 1)
FQ2 = Field(e_add, e_mul, e_sqr, e_inv, (0, 0), (1, 0))


class Curve:
    """y^2 + xy = x^3 + a2 x^2 + b over field F; O is None"""

    def __init__(self, F, a2, b):
        self.F, self.a2, self.b = F, a2, b

    def on(self, P):
        if P is None:
            return True
        F = self.F
        x, y = P
        lhs = F.add(F.sqr(y), F.mul(x, y))
        x2 = F.sqr(x)
        rhs = F.add(F.add(F.mul(x2, x), F.mul(self.a2, x2)), self.b)
        return lhs == rhs

    def neg(self, P):
        if P is None:
            return None
        return (P[0], self.F.add(P[0], P[1]))

    def dbl(self, P):
        F = self.F
        if P is None:
            return None
        x, y = P
        if x == F.zero:
            return None
        lam = F.add(x, F.mul(y, F.inv(x)))
        x3 = F.add(F.add(F.sqr(lam), lam), self.a2)
        y3 = F.add(F.sqr(x), F.mul(F.add(lam, F.one), x3))
        return (x3, y3)

    def add(self, P, Q):
        F = self.F
        if P is None:
            return Q
        if Q is None:
            return P
        x1, y1 = P
        x2, y2 = Q
        if x1 == x2:
            if y1 == y2:
                return self.dbl(P)
            return None  # Q = -P
        lam = F.mul(F.add(y1, y2), F.inv(F.add(x1, x2)))
        x3 = F.add(F.add(F.add(F.add(F.sqr(lam), lam), x1), x2), self.a2)
        y3 = F.add(F.add(F.mul(lam, F.add(x1, x3)), x3), y1)
        return (x3, y3)

    def mulk(self, k, P):
        if k < 0:
            return self.mulk(-k, self.neg(P))
        R = None
        for bit in bin(k)[2:] if k else "":
            R = self.dbl(R)
            if bit == "1":
                R = self.add(R, P)
        return R


def rand_point_Fq(C, rng):
    """random F_q point of C (a2, b in F_q)"""
    while True:
        x = rng.getrandbits(M)
        if x == 0:
            continue
        xi2 = inv(sqr(x))
        c = x ^ mul(C.a2, 1) ^ mul(C.b, xi2)  # (x^3 + a2 x^2 + b)/x^2
        if tr(c) != 0:
            continue
        z = half_trace(c)
        y = mul(x, z)
        if rng.getrandbits(1):
            y ^= x
        P = (x, y)
        assert C.on(P)
        return P


def rand_point_Fq2(C, rng):
    while True:
        x = (rng.getrandbits(M), rng.getrandbits(M))
        if x == (0, 0):
            continue
        F = C.F
        xi2 = F.inv(F.sqr(x))
        c = F.add(F.add(x, C.a2), F.mul(C.b, xi2))
        if e_tr_to_F2(c) != 0:
            continue
        z = e_solve_artin(c)
        y = F.mul(x, z)
        P = (x, y)
        assert C.on(P)
        return P
