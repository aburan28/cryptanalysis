default(parisize, 10^9);
read("phi263_mod2.gp");
nterms = 0; M = Vec(PHI2); for(i=1,#M, my(c = M[i]); if(type(c)=="t_POL", nterms += #select(e->e!=0, Vec(c)), nterms += (c!=0)));
print("terms ", nterms, " degx ", poldegree(PHI2,'x), " degy ", poldegree(PHI2,'y));
S = substvec(PHI2, ['x,'y], ['y,'x]);
print("symmetric mod 2: ", (S - PHI2) % 2 == 0);
A = subst(PHI2, 'x, 1) * Mod(1,2);
B = polmodular(263, 0, Mod(1,2), 'y);
print("PHI2(1,y) == polmodular(263,0,Mod(1,2)): ", A == B);
A0 = subst(PHI2, 'x, 0) * Mod(1,2);
B0 = polmodular(263, 0, Mod(0,2), 'y);
print("PHI2(0,y) == polmodular(263,0,Mod(0,2)): ", A0 == B0, "  ", A0);
\\ Kronecker-type sanity: Phi_l(X,Y) = X^(l+1) + Y^(l+1) - X^l Y^l + ... leading terms
print("coef x^264 y^0: ", polcoef(polcoef(PHI2,264,'x),0,'y), "  x^263 y^263: ", polcoef(polcoef(PHI2,263,'x),263,'y));
