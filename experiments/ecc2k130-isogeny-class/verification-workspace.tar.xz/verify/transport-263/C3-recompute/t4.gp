default(parisize, 4*10^9);
t0=getabstime();
P = polmodular(263);
print("polmodular(263) time ", getabstime()-t0, " ms; degx ", poldegree(P,'x), " degy ", poldegree(P,'y), " maxbits ", vecmax(apply(c->if(c==0,0,exponent(c)), concat(apply(r->Vec(r), Vec(P))))));
P2 = P*Mod(1,2);
write("phi263_mod2.gp", "PHI2 = ", lift(P2), ";");
print("written");
