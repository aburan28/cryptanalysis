"""Merge the Phi_263 root-count logs (main run + tail shards) into one per-label table."""
import glob
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
pat = re.compile(r"^([AB]\d{3}) degF=(\d+) factor_degs\[deg,mult\]=(\[.*\]) n_rational_roots=(\d+) root_is_1=(\d) ok=(\d)")
res = {}
for f in [os.path.join(HERE, "c3_gp_phi.log")] + sorted(glob.glob(os.path.join(HERE, "c3_gp_phi_shard*.log"))):
    for line in open(f):
        m = pat.match(line)
        if not m:
            continue
        lab = m.group(1)
        rec = {"degF": int(m.group(2)), "factor_degs_mult": m.group(3),
               "n_rational_roots": int(m.group(4)), "root_is_1": m.group(5) == "1", "ok": m.group(6) == "1"}
        if lab in res:
            assert res[lab] == rec, (lab, res[lab], rec)
        res[lab] = rec
gt = json.load(open("/Volumes/SSD990/ecdlp-hardness-work/ground_truth/ground_truth.json"))
floor = [c["label"] for c in gt["curves"] if c["label"] != "E0"]
missing = [l for l in floor if l not in res]
pattern_counts = {}
for r in res.values():
    pattern_counts[r["factor_degs_mult"]] = pattern_counts.get(r["factor_degs_mult"], 0) + 1
out = {"n_floor": len(floor), "n_covered": len(res), "missing": missing,
       "n_ok": sum(r["ok"] for r in res.values()), "factor_pattern_counts": pattern_counts,
       "per_label": res}
json.dump(out, open(os.path.join(HERE, "c3_gp_phi_merged.json"), "w"), indent=1)
print(json.dumps({k: v for k, v in out.items() if k != "per_label"}, indent=1))
