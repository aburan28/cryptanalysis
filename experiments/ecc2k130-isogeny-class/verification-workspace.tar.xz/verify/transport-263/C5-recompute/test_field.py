"""Self-tests of gf2m.py (pure python3) + cross-check against Sage/NTL on random elements (run under sage -python)."""
import random, sys, os, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gf2m as F

rng = random.Random(20260923)
out = {}
# internal consistency
n_ok = 0
for _ in range(2000):
    a, b, c = (rng.getrandbits(131) for _ in range(3))
    assert F.mul(a, b) == F.mul(b, a)
    assert F.mul(a, b ^ c) == F.mul(a, b) ^ F.mul(a, c)
    assert F.mul(F.mul(a, b), c) == F.mul(a, F.mul(b, c))
    assert F.sqr_spread(a) == F.sqr_matrix(a) == F.mul(a, a)
    if a:
        assert F.mul(a, F.inv(a)) == 1
    assert F.power(a, 2 ** 131) == a
    h = F.half_trace(a)
    assert F.sqr(h) ^ h == a ^ F.trace(a)
    assert F.trace(a) == F._trace_slow(a)
    n_ok += 1
out["internal_random_tests"] = n_ok
out["trace_mask"] = hex(F.TRACE_MASK)

try:
    from sage.all import GF, PolynomialRing
    z = PolynomialRing(GF(2), "z").gen()
    K = GF(2 ** 131, name="z", modulus=z ** 131 + z ** 13 + z ** 2 + z + 1)
    assert int(K.modulus().change_ring(GF(2))(2) if False else 0) == 0
    m = 0
    for _ in range(500):
        a, b = rng.getrandbits(131), rng.getrandbits(131)
        A, B = K.from_integer(a), K.from_integer(b)
        assert (A * B).to_integer() == F.mul(a, b)
        assert (A * A).to_integer() == F.sqr_matrix(a)
        assert int(A.trace()) == F.trace(a)
        if a:
            assert (1 / A).to_integer() == F.inv(a)
        m += 1
    out["sage_crosscheck_random_elements"] = m
    # modulus as int
    out["sage_modulus_int_matches"] = sum(int(c) << i for i, c in enumerate(K.modulus().list())) == F.MOD
except ImportError:
    out["sage_crosscheck_random_elements"] = "sage not available"
print(json.dumps(out, indent=1))
