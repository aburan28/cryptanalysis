"""Different code path for a sample of edges: Sage/Kohel isogeny from the kernel POLYNOMIAL prod(X - x^2),
x in S_L (conjugated kernel), on M = frob_next(L); compare with the pure-python Velu map of verify_c5.py.
Also: PARI polynomial-level check that the conjugated kernel polynomial equals the Frobenius twist of S_L's
polynomial, and a timing of 131 Sage squarings.   Run: sage -python sage_crosscheck.py L1 L2 ...
"""
import sys, os, json, time, random, timeit
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gf2m as F
import verify_c5 as V
from sage.all import GF, PolynomialRing, EllipticCurve, EllipticCurveIsogeny, set_random_seed

z = PolynomialRing(GF(2), "z").gen()
K = GF(2 ** 131, name="z", modulus=z ** 131 + z ** 13 + z ** 2 + z + 1)
R_ = PolynomialRing(K, "X")
X = R_.gen()
E0 = EllipticCurve(K, [1, 0, 0, 0, 1])
d = K.from_integer
out = {}
labels = sys.argv[1:] or ["A130", "B130", "A064", "B021"]
for L in labels:
    Mlab = V.nxt(L)
    rng = random.Random("C5-sage:" + L)
    set_random_seed(int.from_bytes(("C5s" + L).encode(), "big"))
    xsL = [d(u) for u in V.KER[L]]
    xsM = [u ** 2 for u in xsL]                                  # Sage squaring (NTL), not gf2m
    hL = R_.prod(X - u for u in xsL)
    hM = R_.prod(X - u for u in xsM)
    # Frobenius-twisted polynomial: apply u -> u^2 to coefficients of hL
    hL_frob = R_([c ** 2 for c in hL.list()])
    EM = EllipticCurve(K, [1, 0, 0, 0, d(V.B[Mlab])])
    c = time.process_time()
    phi = EllipticCurveIsogeny(EM, hM)
    tb = time.process_time() - c
    C = phi.codomain()
    iso = C.isomorphism_to(E0) if C.j_invariant() == 1 else None
    R0 = EM.random_point()
    Rp = 4 * R0
    k = rng.randrange(2, V.N - 1)
    Sp = k * Rp
    img = phi(Rp)
    # pure python Velu image of the same point (gf2m)
    mine = V.velu_to_E0([F.sqr(u) for u in V.KER[L]], V.xor_sum([F.sqr(u) for u in V.KER[L]]),
                        (int(Rp[0].to_integer()), int(Rp[1].to_integer())))
    e0img = iso(img) if iso else None
    out[L] = {
        "M": Mlab,
        "hM_equals_frobenius_twist_of_hL": hM == hL_frob,
        "sage_degree": int(phi.degree()),
        "sage_codomain_j_is_1": C.j_invariant() == 1,
        "sage_codomain_a_invariants": [str(a.to_integer()) for a in C.a_invariants()],
        "sage_x_equals_mine": int(img[0].to_integer()) == mine[0],
        "sage_iso_to_E0_point_equals_mine_up_to_sign": e0img is not None and (
            (int(e0img[0].to_integer()), int(e0img[1].to_integer())) in (mine, F.neg(mine))),
        "sage_planted_ok": (not img.is_zero()) and (V.N * img).is_zero() and phi(Sp) == k * img,
        "sage_build_cpu_s": round(tb, 2),
    }
    print(L, json.dumps(out[L]), flush=True)

# timing: 131 squarings in Sage (python loop over NTL GF2E elements)
xs = [d(u) for u in V.KER["A000"]]
reps = 2000
tt = min(timeit.repeat(lambda: [u * u for u in xs], number=reps, repeat=5)) / reps
out["timing_sage_131_squarings_seconds"] = tt
tt2 = min(timeit.repeat(lambda: [F.sqr_matrix(u) for u in V.KER["A000"]], number=200, repeat=5)) / 200
out["timing_gf2m_matrix_131_squarings_seconds"] = tt2
json.dump(out, open(os.path.join(HERE, "sage_crosscheck.json"), "w"), indent=1)
print(json.dumps({k: v for k, v in out.items() if k.startswith("timing")}, indent=1))
