"""Stand-alone GF(2^131) and binary-curve arithmetic in plain Python ints (no Sage, no reuse of the sweep).

Field: F_2[z]/(z^131 + z^13 + z^2 + z + 1); element = int bitmask, bit i = coeff of z^i.
Curves: y^2 + x y = x^3 + a2 x^2 + b   (a1 = 1, a3 = a4 = 0); points are (x, y) tuples, None = infinity.
"""
M_DEG = 131
MOD = (1 << 131) | (1 << 13) | (1 << 2) | (1 << 1) | 1
MASK = (1 << 131) - 1


def reduce(r):
    # fold bits >= 131 using z^131 = z^13 + z^2 + z + 1 (two rounds suffice for deg <= 261)
    for _ in range(3):
        hi = r >> 131
        if not hi:
            return r
        r = (r & MASK) ^ hi ^ (hi << 1) ^ (hi << 2) ^ (hi << 13)
    assert r >> 131 == 0
    return r


def clmul(a, b):
    """carry-less product, 4-bit windows"""
    t = [0] * 16
    t[1] = a
    for i in range(2, 16):
        t[i] = (t[i >> 1] << 1) if not (i & 1) else (t[i - 1] ^ a)
    r = 0
    n = (b.bit_length() + 3) // 4
    for i in range(n - 1, -1, -1):
        r = (r << 4) ^ t[(b >> (4 * i)) & 15]
    return r


def mul(a, b):
    return reduce(clmul(a, b))


# --- squaring, two independent implementations -------------------------------------------------
_SPREAD = []
for _v in range(256):
    _s = 0
    for _i in range(8):
        if (_v >> _i) & 1:
            _s |= 1 << (2 * _i)
    _SPREAD.append(_s)


def sqr_spread(a):
    r, sh = 0, 0
    while a:
        r |= _SPREAD[a & 255] << sh
        a >>= 8
        sh += 16
    return reduce(r)


# squaring matrix: column i = z^(2i) mod MOD, computed by repeated multiplication by z (shift+reduce),
# i.e. without using clmul or the spread table.
def _mulz(a):
    a <<= 1
    if a >> 131:
        a ^= MOD
    return a


SQ_COLS = []
_p = 1
for _i in range(2 * M_DEG):
    if _i % 2 == 0:
        SQ_COLS.append(_p)
    _p = _mulz(_p)
assert len(SQ_COLS) == M_DEG

# byte-sliced lookup tables for the linear map (pure precomputation of the same matrix)
_SQ_TAB = []
for _byte in range((M_DEG + 7) // 8):
    tab = [0] * 256
    for _v in range(256):
        acc = 0
        for _i in range(8):
            idx = 8 * _byte + _i
            if (_v >> _i) & 1 and idx < M_DEG:
                acc ^= SQ_COLS[idx]
        tab[_v] = acc
    _SQ_TAB.append(tab)


def sqr_matrix(a):
    r = 0
    byte = 0
    while a:
        r ^= _SQ_TAB[byte][a & 255]
        a >>= 8
        byte += 1
    return r


sqr = sqr_spread


def inv(a):
    """binary extended Euclid (Hankerson-Menezes-Vanstone Alg. 2.48)"""
    assert a != 0
    u, v, g1, g2 = a, MOD, 1, 0
    while u != 1:
        j = u.bit_length() - v.bit_length()
        if j < 0:
            u, v, g1, g2 = v, u, g2, g1
            j = -j
        u ^= v << j
        g1 ^= g2 << j
    return reduce(g1)


def div(a, b):
    return mul(a, inv(b))


def power(a, e):
    r = 1
    while e:
        if e & 1:
            r = mul(r, a)
        a = sqr(a)
        e >>= 1
    return r


# trace: Tr(c) = sum_{i<131} c^(2^i), linear -> mask of basis elements with trace 1
def _trace_slow(c):
    s, x = 0, c
    for _ in range(M_DEG):
        s ^= x
        x = sqr(x)
    assert s in (0, 1)
    return s


TRACE_MASK = 0
for _i in range(M_DEG):
    if _trace_slow(1 << _i):
        TRACE_MASK |= 1 << _i


def trace(c):
    return bin(c & TRACE_MASK).count("1") & 1


def half_trace(c):
    """H(c) = sum_{i=0}^{65} c^(4^i); H^2 + H = c + Tr(c) for odd degree"""
    h, x = 0, c
    for _ in range((M_DEG - 1) // 2 + 1):
        h ^= x
        x = sqr(sqr(x))
    return h


# ------------------------------------------------------------------------------------ curves
def on_curve(P, a2, b):
    if P is None:
        return True
    x, y = P
    return sqr(y) ^ mul(x, y) == mul(sqr(x), x) ^ mul(a2, sqr(x)) ^ b


def neg(P):
    return None if P is None else (P[0], P[0] ^ P[1])


def add(P, Q, a2):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2:
        if y1 ^ y2 == x1:           # Q = -P (covers x1 = 0 order-2 point: y1 == y2 there)
            return None
        return dbl(P, a2)
    lam = div(y1 ^ y2, x1 ^ x2)
    x3 = sqr(lam) ^ lam ^ x1 ^ x2 ^ a2
    y3 = mul(lam, x1 ^ x3) ^ x3 ^ y1
    return (x3, y3)


def dbl(P, a2):
    if P is None:
        return None
    x1, y1 = P
    if x1 == 0:
        return None
    lam = x1 ^ div(y1, x1)
    x3 = sqr(lam) ^ lam ^ a2
    y3 = sqr(x1) ^ mul(lam ^ 1, x3)
    return (x3, y3)


def smul(k, P, a2):
    if k < 0:
        return smul(-k, neg(P), a2)
    R = None
    for bit in bin(k)[2:]:
        R = dbl(R, a2)
        if bit == "1":
            R = add(R, P, a2)
    return R


def random_point(rng, a2, b):
    while True:
        x = rng.getrandbits(131)
        if x == 0:
            continue
        c = x ^ a2 ^ div(b, sqr(x))
        if trace(c):
            continue
        w = half_trace(c)
        y = mul(x, w)
        if rng.getrandbits(1):
            y ^= x
        P = (x, y)
        assert on_curve(P, a2, b)
        return P
