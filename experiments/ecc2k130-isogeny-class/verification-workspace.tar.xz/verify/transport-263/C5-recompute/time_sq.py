import sys, os, json, time, timeit
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import verify_c5 as V
from sage.all import GF, PolynomialRing
z = PolynomialRing(GF(2), "z").gen()
K = GF(2 ** 131, name="z", modulus=z ** 131 + z ** 13 + z ** 2 + z + 1)
res = {}
for L in ("A000", "B077"):
    xs = [K.from_integer(u) for u in V.KER[L]]
    cpu = min(timeit.repeat(lambda: [u * u for u in xs], number=2000, repeat=7, timer=time.process_time)) / 2000
    wall = min(timeit.repeat(lambda: [u * u for u in xs], number=2000, repeat=7)) / 2000
    res[L] = {"cpu_s_per_131_sq": cpu, "wall_s_per_131_sq": wall}
print(json.dumps(res, indent=1))
json.dump(res, open("time_sq.json", "w"), indent=1)
