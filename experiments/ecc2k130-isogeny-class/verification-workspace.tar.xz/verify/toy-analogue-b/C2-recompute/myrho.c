/*
 * myrho.c -- C2 independent recompute (verify/toy-analogue-b/C2-recompute).
 * Written from scratch; does NOT reuse toy-analogue-b/scripts/toyrho.c.
 *
 * Differences from the sweep's code path, on purpose:
 *   - field F_2[z]/(z^179+z^4+z^2+z+1): software 4-bit comb multiplication (no PMULL), byte-spread
 *     squaring table, inversion by the polynomial extended Euclidean algorithm (no Itoh-Tsujii);
 *   - ONE serial walk per instance, with a FULL history hash table: every visited class is stored, so the
 *     first repeat of a class is detected at the exact step it happens (no distinguished points, no DP tail,
 *     no parallel walks / batched inversion);
 *   - class representative: mode 0 (negation only): sign chosen so that y has a 0 at the LOWEST set bit of x;
 *     mode 1 (negation + sigma, sigma(x,y) = (x^2,y^2)): minimal x^(2^i) as an integer in the POLYNOMIAL basis
 *     found by 178 explicit squarings (no normal basis), then the same sign rule;
 *   - fruitless cycle = repeat of a class with identical (a,b) mod N; escape = double the point of the cycle
 *     with minimal x (read from the history, no re-traversal), counted as one extra group operation.
 * Walk: r-adding, R_j = c_j G + d_j H, j = hash(canonical x) (multiplicative hash, any r).
 *
 * stdin, one instance per line:  id mode r a2hex bhex N s Gx Gy Hx Hy seed
 * stdout, one JSON line per instance.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

typedef unsigned __int128 u128;
typedef struct { uint64_t w[3]; } fe;
static const uint64_t TOPMASK = (1ULL << 51) - 1;   /* bits 128..178 live in w[2] bits 0..50 */

static double cpu(void) { struct timespec ts; clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts); return ts.tv_sec + 1e-9 * ts.tv_nsec; }

/* ---------- field ---------- */
static uint16_t SPREAD[256];
static void init_spread(void) {
    for (int v = 0; v < 256; v++) { uint16_t s = 0; for (int i = 0; i < 8; i++) if (v >> i & 1) s |= (uint16_t)1 << (2 * i); SPREAD[v] = s; }
}
static inline void xor_at(uint64_t *c, uint64_t t, int off) {   /* c ^= t * z^off */
    int w = off >> 6, b = off & 63;
    c[w] ^= t << b;
    if (b) c[w + 1] ^= t >> (64 - b);
}
static inline fe reduce(uint64_t c[7]) {   /* c has degree <= 383 (c[6] must be 0 on entry, used as spill) */
    for (int i = 5; i >= 3; i--) {
        uint64_t t = c[i]; c[i] = 0;
        if (!t) continue;
        int off = 64 * i - 179;           /* z^(64i) = z^(64i-179) * z^179 == z^off * (1+z+z^2+z^4) */
        xor_at(c, t, off); xor_at(c, t, off + 1); xor_at(c, t, off + 2); xor_at(c, t, off + 4);
    }
    uint64_t t = c[2] >> 51; c[2] &= TOPMASK;
    c[0] ^= t ^ (t << 1) ^ (t << 2) ^ (t << 4);
    fe r = {{c[0], c[1], c[2]}}; return r;
}
static inline fe fmul(fe a, fe b) {
    uint64_t T[16][3];
    T[0][0] = T[0][1] = T[0][2] = 0;
    T[1][0] = b.w[0]; T[1][1] = b.w[1]; T[1][2] = b.w[2];
    for (int u = 2; u < 16; u += 2) {   /* T[u] = T[u/2] * z, T[u+1] = T[u] ^ b */
        const uint64_t *h = T[u >> 1];
        T[u][0] = h[0] << 1; T[u][1] = (h[1] << 1) | (h[0] >> 63); T[u][2] = (h[2] << 1) | (h[1] >> 63);
        T[u + 1][0] = T[u][0] ^ b.w[0]; T[u + 1][1] = T[u][1] ^ b.w[1]; T[u + 1][2] = T[u][2] ^ b.w[2];
    }
    uint64_t c[7] = {0, 0, 0, 0, 0, 0, 0};
    for (int k = 15; k >= 0; k--) {
        for (int i = 0; i < 3; i++) {
            unsigned u = (unsigned)(a.w[i] >> (4 * k)) & 15u;
            c[i] ^= T[u][0]; c[i + 1] ^= T[u][1]; c[i + 2] ^= T[u][2];
        }
        if (k) {
            for (int i = 5; i > 0; i--) c[i] = (c[i] << 4) | (c[i - 1] >> 60);
            c[0] <<= 4;
        }
    }
    return reduce(c);
}
static inline uint64_t spread32(uint32_t v) {
    return (uint64_t)SPREAD[v & 255] | ((uint64_t)SPREAD[(v >> 8) & 255] << 16) | ((uint64_t)SPREAD[(v >> 16) & 255] << 32) | ((uint64_t)SPREAD[v >> 24] << 48);
}
static inline fe fsqr(fe a) {
    uint64_t c[7];
    for (int i = 0; i < 3; i++) { c[2 * i] = spread32((uint32_t)a.w[i]); c[2 * i + 1] = spread32((uint32_t)(a.w[i] >> 32)); }
    c[6] = 0;
    return reduce(c);
}
static inline fe fadd(fe a, fe b) { fe r = {{a.w[0] ^ b.w[0], a.w[1] ^ b.w[1], a.w[2] ^ b.w[2]}}; return r; }
static inline int fiszero(fe a) { return !(a.w[0] | a.w[1] | a.w[2]); }
static inline int feq(fe a, fe b) { return a.w[0] == b.w[0] && a.w[1] == b.w[1] && a.w[2] == b.w[2]; }
static inline int flt(fe a, fe b) { for (int i = 2; i >= 0; i--) if (a.w[i] != b.w[i]) return a.w[i] < b.w[i]; return 0; }
static inline int fdeg(const fe *a) {
    if (a->w[2]) return 128 + 63 - __builtin_clzll(a->w[2]);
    if (a->w[1]) return 64 + 63 - __builtin_clzll(a->w[1]);
    if (a->w[0]) return 63 - __builtin_clzll(a->w[0]);
    return -1;
}
static inline void xor_shl(fe *u, const fe *v, int j) {   /* u ^= v * z^j, result assumed < 2^192 */
    int ws = j >> 6, bs = j & 63;
    for (int i = 2; i >= ws; i--) {
        uint64_t x = v->w[i - ws] << bs;
        if (bs && i - ws - 1 >= 0) x |= v->w[i - ws - 1] >> (64 - bs);
        u->w[i] ^= x;
    }
}
static fe finv(fe a) {   /* extended Euclid over F_2[z] */
    fe u = a, v = {{0x17, 0, 1ULL << 51}}, g1 = {{1, 0, 0}}, g2 = {{0, 0, 0}};
    int du = fdeg(&u), dv = 179;
    while (du > 0) {
        int j = du - dv;
        if (j < 0) { fe t = u; u = v; v = t; t = g1; g1 = g2; g2 = t; int d = du; du = dv; dv = d; j = -j; }
        xor_shl(&u, &v, j); xor_shl(&g1, &g2, j);
        du = fdeg(&u);
    }
    if (du < 0) { fprintf(stderr, "finv(0)\n"); exit(3); }
    return g1;
}
static int hexval(char c) { if (c >= '0' && c <= '9') return c - '0'; if (c >= 'a' && c <= 'f') return c - 'a' + 10; if (c >= 'A' && c <= 'F') return c - 'A' + 10; return -1; }
static fe fparse(const char *s) {
    fe r = {{0, 0, 0}};
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
    for (; *s; s++) {
        int v = hexval(*s); if (v < 0) break;
        r.w[2] = (r.w[2] << 4) | (r.w[1] >> 60); r.w[1] = (r.w[1] << 4) | (r.w[0] >> 60); r.w[0] = (r.w[0] << 4) | (uint64_t)v;
    }
    return r;
}

/* ---------- curve y^2 + xy = x^3 + a2 x^2 + b ---------- */
typedef struct { fe x, y; int inf; } pt;
static fe A2, B;
static int oncurve(pt P) {
    if (P.inf) return 1;
    fe x2 = fsqr(P.x);
    fe l = fadd(fsqr(P.y), fmul(P.x, P.y));
    fe r = fadd(fadd(fmul(x2, P.x), fmul(A2, x2)), B);
    return feq(l, r);
}
static pt pneg(pt P) { if (!P.inf) P.y = fadd(P.y, P.x); return P; }
static pt pdbl(pt P) {
    if (P.inf || fiszero(P.x)) { pt O; memset(&O, 0, sizeof O); O.inf = 1; return O; }
    fe lam = fadd(P.x, fmul(P.y, finv(P.x)));
    fe x3 = fadd(fadd(fsqr(lam), lam), A2);
    fe y3 = fadd(fadd(fsqr(P.x), fmul(lam, x3)), x3);
    pt R = {x3, y3, 0}; return R;
}
static pt padd(pt P, pt Q) {
    if (P.inf) return Q;
    if (Q.inf) return P;
    if (feq(P.x, Q.x)) {
        if (feq(P.y, Q.y)) return pdbl(P);
        pt O; memset(&O, 0, sizeof O); O.inf = 1; return O;
    }
    fe dx = fadd(P.x, Q.x);
    fe lam = fmul(fadd(P.y, Q.y), finv(dx));
    fe x3 = fadd(fadd(fadd(fsqr(lam), lam), dx), A2);
    fe y3 = fadd(fadd(fmul(lam, fadd(P.x, x3)), x3), P.y);
    pt R = {x3, y3, 0}; return R;
}
static pt pmul(pt P, uint64_t k) {
    pt R; memset(&R, 0, sizeof R); R.inf = 1;
    for (int i = 63; i >= 0; i--) { R = pdbl(R); if (k >> i & 1) R = padd(R, P); }
    return R;
}
static int peq(pt P, pt Q) { if (P.inf || Q.inf) return P.inf == Q.inf; return feq(P.x, Q.x) && feq(P.y, Q.y); }

/* ---------- mod N ---------- */
static uint64_t NN, S;
static uint64_t SPOW[179];
static inline uint64_t mmul(uint64_t a, uint64_t b) { return (uint64_t)((u128)a * b % NN); }
static inline uint64_t madd(uint64_t a, uint64_t b) { uint64_t c = a + b; return c >= NN ? c - NN : c; }
static inline uint64_t mneg(uint64_t a) { return a ? NN - a : 0; }
static uint64_t mpow(uint64_t a, uint64_t e) { uint64_t r = 1; while (e) { if (e & 1) r = mmul(r, a); a = mmul(a, a); e >>= 1; } return r; }
static uint64_t minv(uint64_t a) { return mpow(a, NN - 2); }   /* N prime */

/* ---------- rng ---------- */
static uint64_t rs;
static uint64_t rnd(void) { uint64_t z = (rs += 0x9E3779B97F4A7C15ULL); z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL; z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL; return z ^ (z >> 31); }
static uint64_t rndN(void) { return rnd() % NN; }

/* ---------- class representative ---------- */
static int MODE;
typedef struct { pt P; uint64_t a, b; } st;   /* P = a G + b H */
static inline void signfix(st *s) {
    uint64_t low; int bit;
    if (s->P.x.w[0]) { low = s->P.x.w[0] & (~s->P.x.w[0] + 1); bit = (s->P.y.w[0] & low) != 0; }
    else if (s->P.x.w[1]) { low = s->P.x.w[1] & (~s->P.x.w[1] + 1); bit = (s->P.y.w[1] & low) != 0; }
    else { low = s->P.x.w[2] & (~s->P.x.w[2] + 1); bit = (s->P.y.w[2] & low) != 0; }
    if (bit) { s->P.y = fadd(s->P.y, s->P.x); s->a = mneg(s->a); s->b = mneg(s->b); }
}
static inline void canon(st *s) {
    if (MODE == 1) {
        fe xs = s->P.x, best = s->P.x; int bi = 0;
        for (int i = 1; i < 179; i++) { xs = fsqr(xs); if (flt(xs, best)) { best = xs; bi = i; } }
        if (bi) {
            fe y = s->P.y; for (int i = 0; i < bi; i++) y = fsqr(y);
            s->P.x = best; s->P.y = y; s->a = mmul(s->a, SPOW[bi]); s->b = mmul(s->b, SPOW[bi]);
        }
    }
    signfix(s);
}
static inline uint64_t hmix(fe x) {
    uint64_t h = x.w[0] ^ ((x.w[1] << 21) | (x.w[1] >> 43)) ^ ((x.w[2] << 42) | (x.w[2] >> 22));
    h *= 0xD6E8FEB86659FD93ULL; h ^= h >> 32; h *= 0xD6E8FEB86659FD93ULL; h ^= h >> 29;
    return h;
}

/* ---------- history + table ---------- */
#define HCAP (1u << 22)
#define TBITS 23
#define TSIZE (1u << TBITS)
static st *HIST;
static uint32_t *TAB;

int main(void) {
    init_spread();
    HIST = malloc(sizeof(st) * HCAP);
    TAB = malloc(sizeof(uint32_t) * TSIZE);
    if (!HIST || !TAB) { fprintf(stderr, "oom\n"); return 1; }
    /* self test: inverse, distributivity, squaring vs multiplication */
    rs = 12345;
    for (int t = 0; t < 2000; t++) {
        fe a = {{rnd(), rnd(), rnd() & TOPMASK}}, b = {{rnd(), rnd(), rnd() & TOPMASK}}, c = {{rnd(), rnd(), rnd() & TOPMASK}};
        if (fiszero(a)) continue;
        fe one = fmul(a, finv(a));
        if (!(one.w[0] == 1 && one.w[1] == 0 && one.w[2] == 0)) { fprintf(stderr, "selftest inv fail\n"); return 2; }
        if (!feq(fmul(a, fadd(b, c)), fadd(fmul(a, b), fmul(a, c)))) { fprintf(stderr, "selftest distrib fail\n"); return 2; }
        if (!feq(fsqr(a), fmul(a, a))) { fprintf(stderr, "selftest sqr fail\n"); return 2; }
        if (!feq(fmul(a, b), fmul(b, a))) { fprintf(stderr, "selftest comm fail\n"); return 2; }
    }
    char line[4096];
    while (fgets(line, sizeof line, stdin)) {
        char id[128], a2h[128], bh[128], gx[128], gy[128], hx[128], hy[128];
        int mode, r; unsigned long long n, s, seed;
        if (sscanf(line, "%127s %d %d %127s %127s %llu %llu %127s %127s %127s %127s %llu", id, &mode, &r, a2h, bh, &n, &s, gx, gy, hx, hy, &seed) != 12) continue;
        double c0 = cpu();
        MODE = mode; NN = n; S = s % n; A2 = fparse(a2h); B = fparse(bh); rs = seed;
        pt G = {fparse(gx), fparse(gy), 0}, H = {fparse(hx), fparse(hy), 0};
        int ok_curve = oncurve(G) && oncurve(H);
        int ok_order = pmul(G, NN).inf && pmul(H, NN).inf && !G.inf;
        int ok_tau = 1;
        if (mode == 1) {
            SPOW[0] = 1; for (int i = 1; i < 179; i++) SPOW[i] = mmul(SPOW[i - 1], S);
            pt tG = {fsqr(G.x), fsqr(G.y), 0}, tH = {fsqr(H.x), fsqr(H.y), 0};
            ok_tau = peq(tG, pmul(G, S)) && peq(tH, pmul(H, S)) && (mpow(S, 179) == 1);
        }
        if (!ok_curve || !ok_order || !ok_tau) {
            printf("{\"id\":\"%s\",\"error\":\"setup\",\"ok_curve\":%d,\"ok_order\":%d,\"ok_tau\":%d}\n", id, ok_curve, ok_order, ok_tau);
            fflush(stdout); continue;
        }
        /* r-adding multipliers */
        st *R = malloc(sizeof(st) * r);
        for (int j = 0; j < r; j++) {
            R[j].a = rndN(); R[j].b = rndN();
            R[j].P = padd(pmul(G, R[j].a), pmul(H, R[j].b));
        }
        memset(TAB, 0, sizeof(uint32_t) * TSIZE);
        st cur; cur.a = rndN(); cur.b = rndN(); cur.P = padd(pmul(G, cur.a), pmul(H, cur.b));
        canon(&cur);
        double c1 = cpu();
        uint64_t ops = 0, fruitless = 0, escapes = 0, fr_consec = 0, hlen = 0;
        int found = 0, abandoned = 0, verified = 0; uint64_t k = 0;
        uint64_t mu = 0, collide_ops = 0;
        for (;;) {
            /* look up / insert cur */
            uint32_t slot = (uint32_t)(hmix(cur.P.x) >> (64 - TBITS));
            int hit = -1;
            while (TAB[slot]) {
                uint32_t idx = TAB[slot] - 1;
                if (feq(HIST[idx].P.x, cur.P.x)) { hit = (int)idx; break; }
                slot = (slot + 1) & (TSIZE - 1);
            }
            if (hit >= 0) {
                st *o = &HIST[hit];
                if (!feq(o->P.y, cur.P.y)) { printf("{\"id\":\"%s\",\"error\":\"canon_mismatch\"}\n", id); abandoned = 1; break; }
                if (o->b != cur.b) {
                    k = mmul(madd(o->a, mneg(cur.a)), minv(madd(cur.b, mneg(o->b))));
                    found = 1; mu = (uint64_t)hit; collide_ops = ops;
                    verified = peq(pmul(G, k), H);
                    break;
                }
                if (o->a != cur.a) { printf("{\"id\":\"%s\",\"error\":\"same_b_diff_a\"}\n", id); abandoned = 1; break; }
                /* fruitless cycle: HIST[hit .. hlen-1] */
                fruitless++;
                if (++fr_consec > 50) { abandoned = 1; break; }
                uint64_t m = (uint64_t)hit;
                for (uint64_t i = (uint64_t)hit + 1; i < hlen; i++) if (flt(HIST[i].P.x, HIST[m].P.x)) m = i;
                st e = HIST[m];
                e.P = pdbl(e.P); e.a = madd(e.a, e.a); e.b = madd(e.b, e.b);
                ops++; escapes++;
                if (e.P.inf) { abandoned = 1; break; }
                canon(&e);
                cur = e;
                continue;
            }
            fr_consec = 0;
            if (hlen >= HCAP - 1) { abandoned = 1; break; }
            HIST[hlen] = cur; TAB[slot] = (uint32_t)(hlen + 1); hlen++;
            /* step */
            uint32_t j = (uint32_t)(((u128)hmix(fadd(cur.P.x, (fe){{0x5bd1e995ULL, 0, 0}})) * (uint64_t)r) >> 64);
            st nx; nx.P = padd(cur.P, R[j].P); nx.a = madd(cur.a, R[j].a); nx.b = madd(cur.b, R[j].b);
            ops++;
            if (nx.P.inf) { abandoned = 1; break; }
            canon(&nx);
            cur = nx;
        }
        double c2 = cpu();
        printf("{\"id\":\"%s\",\"mode\":%d,\"r\":%d,\"found\":%d,\"verified\":%d,\"k\":%llu,\"ops\":%llu,\"distinct\":%llu,"
               "\"fruitless\":%llu,\"escapes\":%llu,\"mu\":%llu,\"abandoned\":%d,\"cpu_setup\":%.4f,\"cpu_walk\":%.4f}\n",
               id, mode, r, found, verified, (unsigned long long)k, (unsigned long long)collide_ops, (unsigned long long)hlen,
               (unsigned long long)fruitless, (unsigned long long)escapes, (unsigned long long)mu, abandoned, c1 - c0, c2 - c1);
        fflush(stdout);
        free(R);
    }
    return 0;
}
