#!/usr/bin/env python3
"""Aggregate my independent rho runs (out/*.jsonl) and recompute the sweep's headline means from its raw
jsonl files with my own arithmetic (no use of the sweep's analyze.py)."""
import json, glob, math, statistics as st, os

BASE = '/Volumes/SSD990/ecdlp-hardness-work/verify/toy-analogue-b/C2-recompute/'
SW = '/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-b/raw/'
gt = json.load(open('/Volumes/SSD990/ecdlp-hardness-work/toy-analogue-b/raw/toy_ground_truth.json'))
N = int(gt['meta']['N'])
planted = json.load(open(BASE + 'inputs/planted.json'))
pl = dict(planted['floor']); pl.update(planted['E0'])

S_neg = (N - 1) / 2          # non-identity classes {P,-P}
S_tau = (N - 1) / 358        # non-identity classes {+-sigma^i P}, sigma of order 179 on <G>
base_neg = math.sqrt(math.pi * S_neg / 2)
base_tau = math.sqrt(math.pi * S_tau / 2)


def load(prefix):
    recs = []
    for f in sorted(glob.glob(BASE + 'out/%s.*.jsonl' % prefix)):
        for ln in open(f):
            ln = ln.strip()
            if ln:
                recs.append(json.loads(ln))
    return recs


def summarize(recs, base, sign_ok=False):
    bad = [r for r in recs if 'error' in r or not r.get('found') or not r.get('verified') or r.get('abandoned')]
    good = [r for r in recs if r not in bad]
    if sign_ok:
        mism = [r['id'] for r in good if r['k'] not in (pl[r['id']], (N - pl[r['id']]) % N)]
    else:
        mism = [r['id'] for r in good if r['k'] != pl[r['id']]]
    ops = [r['ops'] for r in good]
    dist = [r['distinct'] for r in good]
    fr = [r['fruitless'] for r in good]
    n = len(ops)
    m, sd = st.mean(ops), st.pstdev(ops)
    md, sdd = st.mean(dist), st.pstdev(dist)
    cpu = [r['cpu_walk'] for r in good]
    return dict(count=n, bad=len(bad), planted_mismatch=len(mism), mism_ids=mism[:5],
                ops_mean=m, ops_se=sd / math.sqrt(n), ops_median=st.median(ops), log2_ops_mean=math.log2(m),
                ratio_ops_to_base=m / base, ratio_ops_se=sd / math.sqrt(n) / base,
                distinct_mean=md, distinct_se=sdd / math.sqrt(n), ratio_distinct_to_base=md / base,
                ratio_distinct_se=sdd / math.sqrt(n) / base,
                fruitless_mean=st.mean(fr), fruitless_per_op=sum(fr) / sum(ops),
                cv_ops=sd / m, cv_rayleigh=math.sqrt((4 - math.pi) / math.pi),
                cpu_walk_mean_s=st.mean(cpu), ns_per_op=1e9 * sum(cpu) / sum(ops))


def ratio(a, b):
    r = a['ops_mean'] / b['ops_mean']
    se = r * math.sqrt((a['ops_se'] / a['ops_mean']) ** 2 + (b['ops_se'] / b['ops_mean']) ** 2)
    rd = a['distinct_mean'] / b['distinct_mean']
    sed = rd * math.sqrt((a['distinct_se'] / a['distinct_mean']) ** 2 + (b['distinct_se'] / b['distinct_mean']) ** 2)
    return dict(ops_ratio=r, ops_ratio_se=se, distinct_ratio=rd, distinct_ratio_se=sed,
                z_ops_vs_sqrt179=(r - math.sqrt(179)) / se, z_distinct_vs_sqrt179=(rd - math.sqrt(179)) / sed)


out = dict(meta=dict(N=N, S_neg=S_neg, S_tau=S_tau, base_neg_sqrt_pi_S_over_2=base_neg, base_tau_sqrt_pi_S_over_2=base_tau,
                     sqrt179=math.sqrt(179),
                     model_neg_r32_my=base_neg / math.sqrt(1 - 1 / 64), model_neg_r32_sweep=base_neg / math.sqrt(1 - 1 / 32),
                     model_neg_r1024_my=base_neg / math.sqrt(1 - 1 / 2048),
                     model_tau_r32_my=base_tau / math.sqrt(1 - 1 / (358 * 32)), model_tau_r32_sweep=base_tau / math.sqrt(1 - 1 / 32)))
sets = {}
for tag, base, sgn in [('i_r32', base_neg, False), ('ii_r32', base_tau, False), ('iip_r32', base_neg, False), ('iii_r32', base_tau, True),
                       ('i_r1024', base_neg, False), ('ii_r1024', base_tau, False), ('iip_r1024', base_neg, False)]:
    recs = load(tag)
    if recs:
        sets[tag] = summarize(recs, base, sgn)
out['mine'] = sets
rat = {}
for a, b in [('i_r32', 'ii_r32'), ('i_r32', 'iii_r32'), ('iip_r32', 'ii_r32'), ('i_r1024', 'ii_r1024'), ('iip_r1024', 'ii_r1024'), ('i_r32', 'iip_r32')]:
    if a in sets and b in sets:
        rat[a + '/' + b] = ratio(sets[a], sets[b])
out['ratios'] = rat

# sweep raw numbers recomputed by me (work = iters + iters_escape, as the sweep defines it)
sw = {}
for tag, fn in [('i', 'results_i.jsonl'), ('ii', 'results_ii.jsonl'), ('iip', 'results_iip.jsonl'), ('iii', 'results_iii.jsonl')]:
    w, ex, okk = [], [], 0
    for ln in open(SW + fn):
        ln = ln.strip()
        if not ln:
            continue
        rows = json.loads(ln)
        rows = rows if isinstance(rows, list) else [rows]
        for r in rows:
            w.append(r['iters'] + r['iters_escape']); ex.append(r['iters'] - r['escapes'])
            okk += bool(r.get('k_matches_planted'))
    sw[tag] = dict(count=len(w), planted_ok=okk, work_mean=st.mean(w), work_se=st.pstdev(w) / math.sqrt(len(w)),
                   iters_minus_escapes_mean=st.mean(ex), escape_steps_mean=st.mean(w) - st.mean(ex))
for tag, base in [('i', base_neg), ('ii', base_tau), ('iip', base_neg), ('iii', base_tau)]:
    sw[tag]['ratio_to_base'] = sw[tag]['work_mean'] / base
    sw[tag]['ratio_se'] = sw[tag]['work_se'] / base
sw['i/iii'] = sw['i']['work_mean'] / sw['iii']['work_mean']
sw['iip/ii'] = sw['iip']['work_mean'] / sw['ii']['work_mean']
sw['i/ii'] = sw['i']['work_mean'] / sw['ii']['work_mean']
# the sweep's walks minus their own analytic DP tails (M * 2^dpbits: 16*256 for mode 0, 8*32 for mode 1)
sw['i_minus_dptail_over_base'] = (sw['i']['work_mean'] - 4096) / base_neg
sw['iii_minus_dptail_over_base'] = (sw['iii']['work_mean'] - 256) / base_tau
sw['ratio_i_over_iii_after_removing_dp_tails'] = (sw['i']['work_mean'] - 4096) / (sw['iii']['work_mean'] - 256)
out['sweep_raw_recomputed'] = sw

# ECC2K-130 analogue numbers
NB = 680564733841876926932320129493409985129
out['ecc2k130'] = dict(log2_neg=0.5 * math.log2(math.pi * NB / 4), log2_tau=0.5 * math.log2(math.pi * NB / (4 * 131)),
                       log2_gain=0.5 * math.log2(131))
json.dump(out, open(BASE + 'c2_summary.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
