// Experimental forward scheduling for the unchanged Frobenius walk.
// Included inside eccPacked131 after load/store, weight and toLimbs.
#pragma once
#if ECC_PACKED_FROB_PIPE
#if ECC_WALK_TABLE || !ECC_PACKED_POLY_STATE || ECC_PACKED_WEIGHTED_PREFIX != 2 || !ECC_PACKED_CACHE_DENOM || ECC_PACKED_POLY_SIGMA || ECC_PACKED_SHUFFLE_SIGMA || ECC_BATCH < 2
#error "Frobenius pipeline requires legacy polynomial state, weighted prefix 2, cached denominators, and batch >=2"
#endif
static __device__ __forceinline__ PolynomialPair frobeniusSelectSlot131(
    WalkParams<unsigned> p,const unsigned *__restrict__ stateX,const unsigned *__restrict__ stateY,
    unsigned *__restrict__ stateDead,const unsigned long long *__restrict__ stateSeed,
    const unsigned long long *__restrict__ stateStart,DpRecord *__restrict__ reports,
    unsigned *__restrict__ reportCounts,unsigned *__restrict__ denominators,
    int slot,int tid,unsigned long long now,bool guard) {
    const P131 x=fromPolynomial131(load(stateX,slot,tid,p.threads));
    const int hw=weight(x);
    const size_t id=size_t(slot)*p.threads+tid;
    if(!goal22ReadDead(stateDead,id)) {
        if(hw<=p.dpWeight) {
            if((stateSeed[id]&0xffffull)==0xffffull) atomicAdd(reportCounts+2,1u);
            const unsigned dest=atomicAdd(reportCounts,1u);
            if(dest<p.dpCap) {
                DpRecord rec;rec.seed=stateSeed[id];rec.iters=now-stateStart[id];
                toLimbs(x,rec.x);toLimbs(fromPolynomial131(load(stateY,slot,tid,p.threads)),rec.y);
                reports[dest]=rec;
            }
            goal22WriteDead(stateDead,id,1);
        } else if(guard && now-stateStart[id]>=p.maxIters) {
            if((stateSeed[id]&0xffffull)==0xffffull) atomicAdd(reportCounts+2,1u);
            goal22WriteDead(stateDead,id,1);atomicAdd(reportCounts+1,1u);
        }
    }
    const int index=(hw>>1)&7;
    const P131 y=fromPolynomial131(load(stateY,slot,tid,p.threads));
#if ECC_PACKED_SHARED_SIGMA
    const SigmaWalkPair131 sigmas=sigmaWalkNetworkPairShared131(x,y,index);
#else
    const SigmaWalkPair131 sigmas=sigmaWalkNetworkPair131(x,y,index);
#endif
    const P131 dp=toPolynomial131(add131(x,sigmas.first));
    const P131 ep=toPolynomial131(add131(y,sigmas.second));
    P131 tagged=dp;tagged.v[4]|=unsigned(index)<<3;
    store(denominators,slot,tid,p.threads,tagged);
    return PolynomialPair{dp,ep};
}
#endif
