// Opt-in fusion for the original Frobenius walk. Included inside eccPacked131.
// The reverse pass also builds the following step's prefix from register-held
// coordinates. Slot order alternates so no extra state arrays are needed.
#pragma once
#if ECC_PACKED_FROB_FUSED
#if ECC_WALK_TABLE || !ECC_PACKED_POLY_STATE || ECC_PACKED_WEIGHTED_PREFIX != 2 || !ECC_PACKED_CACHE_DENOM || ECC_PACKED_FROB_PIPE || ECC_PACKED_POLY_SIGMA || ECC_PACKED_SHUFFLE_SIGMA || ECC_PHASE_PROFILE || ECC_PACKED_SLOT_PIPELINE || ECC_PACKED_SLOT_PREFETCH
#error "fused Frobenius requires the scalar-inverse polynomial-state paired-prefix path"
#endif
static __device__ __forceinline__ void fusedFrobeniusSelect131(
    const WalkParams<unsigned> &p,unsigned *__restrict__ statePrefix,
    unsigned *__restrict__ stateDead,const unsigned long long *__restrict__ stateSeed,
    const unsigned long long *__restrict__ stateStart,DpRecord *__restrict__ reports,
    unsigned *__restrict__ reportCounts,unsigned *__restrict__ denominators,
    P131 xp,P131 yp,int slot,int tid,unsigned long long now,bool guard,bool first,P131 *prod,unsigned *deadMask) {
    const P131 x=fromPolynomial131(xp),y=fromPolynomial131(yp);
    const int hw=weight(x);
    const size_t id=size_t(slot)*p.threads+tid;
    if(!(*deadMask & (1u<<slot))) {
        if(hw<=p.dpWeight) {
            if((stateSeed[id]&0xffffull)==0xffffull) atomicAdd(reportCounts+2,1u);
            const unsigned dest=atomicAdd(reportCounts,1u);
            if(dest<p.dpCap) {
                DpRecord rec;rec.seed=stateSeed[id];rec.iters=now-stateStart[id];
                toLimbs(x,rec.x);toLimbs(y,rec.y);reports[dest]=rec;
            }
            *deadMask |= 1u<<slot;
        } else if(guard && now-stateStart[id]>=p.maxIters) {
            if((stateSeed[id]&0xffffull)==0xffffull) atomicAdd(reportCounts+2,1u);
            *deadMask |= 1u<<slot;atomicAdd(reportCounts+1,1u);
        }
    }
    const int index=(hw>>1)&7;
#if ECC_PACKED_SIGMA_TOPOLOGY
    const SigmaWalkPair131 sigmas=sigmaTopologyPair131(x,y,index);
#elif ECC_PACKED_SHARED_SIGMA
    const SigmaWalkPair131 sigmas=sigmaWalkNetworkPairShared131(x,y,index);
#else
    const SigmaWalkPair131 sigmas=sigmaWalkNetworkPair131(x,y,index);
#endif
    const P131 dp=toPolynomial131(add131(x,sigmas.first));
    const P131 ep=toPolynomial131(add131(y,sigmas.second));
    P131 tagged=dp;tagged.v[4]|=unsigned(index)<<3;
    store(denominators,slot,tid,p.threads,tagged);
    if(first) {
        *prod=dp;store(statePrefix,slot,tid,p.threads,ep);
    } else {
        const PolynomialPair pair=mulPolynomialPair131(*prod,ep,dp);
        store(statePrefix,slot,tid,p.threads,pair.first);*prod=pair.second;
    }
}

static __device__ __forceinline__ void fusedFrobeniusBody131(
    WalkParams<unsigned> p,unsigned *__restrict__ stateX,unsigned *__restrict__ stateY,
    unsigned *__restrict__ statePrefix,unsigned *__restrict__ stateDead,
    const unsigned long long *__restrict__ stateSeed,const unsigned long long *__restrict__ stateStart,
    DpRecord *__restrict__ reports,unsigned *__restrict__ reportCounts,unsigned *__restrict__ denominators,int tid) {
    if(!p.steps) return;
    static_assert(ECC_BATCH <= 32,"register dead flags need at most 32 slots");
    unsigned deadMask=0;
#pragma unroll 1
    for(int slot=0;slot<ECC_BATCH;slot++)
        if(goal22ReadDead(stateDead,size_t(slot)*p.threads+tid))deadMask|=1u<<slot;
    const unsigned initialDeadMask=deadMask;
    P131 prod;
    const unsigned long long initial=p.iterBase;
    const bool initialGuard=p.maxIters && initial%ECC_GUARD_PERIOD==0;
#pragma unroll 1
    for(int i=0;i<ECC_BATCH;i++) {
        // Absolute iteration parity preserves scratch state across odd-length
        // launches and resumes, as well as the ordinary even-length workload.
        const int slot=(initial&1ull)?ECC_BATCH-1-i:i;
        fusedFrobeniusSelect131(p,statePrefix,stateDead,stateSeed,stateStart,reports,
            reportCounts,denominators,load(stateX,slot,tid,p.threads),load(stateY,slot,tid,p.threads),
            slot,tid,initial,initialGuard,i==0,&prod,&deadMask);
    }
#pragma unroll 1
    for(int step=0;step<p.steps;step++) {
        const unsigned long long now=p.iterBase+step;
        const bool ascending=(now&1ull)!=0;
        const bool last=step+1==p.steps;
        const unsigned long long following=now+1;
        const bool guard=p.maxIters && following%ECC_GUARD_PERIOD==0;
        P131 inv=batchInverse131(prod,p.threads),next{};
#pragma unroll 1
        for(int i=0;i<ECC_BATCH;i++) {
            const int slot=ascending?i:ECC_BATCH-1-i;
            const P131 x=load(stateX,slot,tid,p.threads),y=load(stateY,slot,tid,p.threads);
            const P131 w=load(statePrefix,slot,tid,p.threads);
            P131 dp=load(denominators,slot,tid,p.threads);dp.v[4]&=7u;
            P131 lambda;
            if(i+1<ECC_BATCH) {
                const PolynomialPair pair=mulPolynomialPair131(inv,w,dp);
                lambda=pair.first;inv=pair.second;
            } else lambda=mulPolynomial131(inv,w);
            const P131 nx=add131(add131(squarePolynomial131(lambda),lambda),dp);
            const P131 ny=add131(add131(mulPolynomial131(lambda,add131(x,nx)),nx),y);
            store(stateX,slot,tid,p.threads,nx);store(stateY,slot,tid,p.threads,ny);
            // Do not report or mutate the following step after the workload's
            // final update; that point is inspected at the next launch.
            if(!last) fusedFrobeniusSelect131(p,statePrefix,stateDead,stateSeed,stateStart,
                reports,reportCounts,denominators,nx,ny,slot,tid,following,guard,i==0,&next,&deadMask);
        }
        if(!last) prod=next;
    }
    const unsigned newlyDead=deadMask^initialDeadMask;
    if(newlyDead) {
#pragma unroll 1
        for(int slot=0;slot<ECC_BATCH;slot++)
            if(newlyDead & (1u<<slot))goal22WriteDead(stateDead,size_t(slot)*p.threads+tid,1);
    }
}
#endif
