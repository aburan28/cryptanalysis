// Included inside eccPacked131 after the optimized ordinary walk. Uses the
// same native field, compact state, weighted batch prefixes and warp inversion.
#pragma once
#if ECC_TABLE_PAIR_STEPS
#ifndef ECC_PAIR_SIGN_ONB
#define ECC_PAIR_SIGN_ONB 0
#endif
#if !ECC_WALK_TABLE || !ECC_TABLE_TAG_DENOM || ECC_PACKED_WEIGHTED_PREFIX != 2 || ECC_TABLE_FUSED || ECC_TABLE_PIPE_SELECT
#error "Pair steps require the ordinary table/weighted-prefix/tag-denominator path"
#endif

struct PairEntry131 { uint32_t w[9]; };
static_assert(sizeof(PairEntry131)==36,"pair entry ABI");
#ifndef ECC_PAIR_CACHE_WORDS
#define ECC_PAIR_CACHE_WORDS 9
#endif
#if ECC_PAIR_CACHE_WORDS == 9
using PairCacheEntry131=PairEntry131;
#elif ECC_PAIR_CACHE_WORDS == 12 || ECC_PAIR_CACHE_WORDS == 16
struct __align__(16) PairCacheEntry131 {
    uint4 x,y;
    uint32_t top;
    uint32_t padding[ECC_PAIR_CACHE_WORDS-9];
};
#else
#error "ECC_PAIR_CACHE_WORDS must be 9, 12 or 16"
#endif
static_assert(sizeof(PairCacheEntry131)==4*ECC_PAIR_CACHE_WORDS,"native cache stride");
static const uint64_t PAIR_DIRECTIONS=uint64_t(2)*131*TW_H;
static const uint64_t PAIR_FULL_ENTRIES=PAIR_DIRECTIONS*(PAIR_DIRECTIONS+1)/2;
static const uint64_t PAIR_POSITIVE_DIRECTIONS=uint64_t(131)*TW_H;
// Simultaneously negate both directions to make the larger one positive.
// Row v contains two signs for u<v, then one doubling: 2*v+1 entries.
// Inverse pairs are implicit infinity. Total storage is N*N, about half of
// the complete unordered signed table, without changing a selected point.
static const uint64_t PAIR_ENTRIES=PAIR_POSITIVE_DIRECTIONS*PAIR_POSITIVE_DIRECTIONS;
static_assert(PAIR_ENTRIES<=0xffffffffull,"native cache indices must fit uint32");

// Index in the original, uncompressed SSD artifact (not the native cache).
ECC_HD uint64_t fullPairOffset131(unsigned a,unsigned b) {
    uint64_t u=2*(uint64_t(eccTagK(a))*TW_H+eccTagH(a))+eccTagEps(a);
    uint64_t v=2*(uint64_t(eccTagK(b))*TW_H+eccTagH(b))+eccTagEps(b);
    if(u>v){uint64_t t=u;u=v;v=t;}
    return v*(v+1)/2+u;
}
ECC_HD P131 pairX131(PairEntry131 p){return P131{{p.w[0],p.w[1],p.w[2],p.w[3],p.w[8]&7}};}
ECC_HD P131 pairY131(PairEntry131 p){return P131{{p.w[4],p.w[5],p.w[6],p.w[7],(p.w[8]>>3)&7}};}
ECC_HD bool pairZero131(P131 a){return !(a.v[0]|a.v[1]|a.v[2]|a.v[3]|a.v[4]);}
ECC_HD PairEntry131 pairPack131(P131 x,P131 y,bool inf=false){
    if(inf)return PairEntry131{{0,0,0,0,0,0,0,0,0x80000000u}};
    return PairEntry131{{x.v[0],x.v[1],x.v[2],x.v[3],y.v[0],y.v[1],y.v[2],y.v[3],x.v[4]|(y.v[4]<<3)}};
}

ECC_HD PairCacheEntry131 pairCacheEncode131(PairEntry131 p){
#if ECC_PAIR_CACHE_WORDS == 9
    return p;
#else
    PairCacheEntry131 out{};
    out.x=uint4{p.w[0],p.w[1],p.w[2],p.w[3]};
    out.y=uint4{p.w[4],p.w[5],p.w[6],p.w[7]};out.top=p.w[8];
    return out;
#endif
}
ECC_HD PairEntry131 pairCacheRead131(const PairCacheEntry131 *pairs,uint32_t index){
#if ECC_PAIR_CACHE_WORDS == 9
    return pairs[index];
#else
#ifdef __CUDA_ARCH__
    const uint4 x=__ldg(&pairs[index].x),y=__ldg(&pairs[index].y);
    const unsigned top=__ldg(&pairs[index].top);
#else
    const uint4 x=pairs[index].x,y=pairs[index].y;const unsigned top=pairs[index].top;
#endif
    return PairEntry131{{x.x,x.y,x.z,x.w,y.x,y.y,y.z,y.w,top}};
#endif
}
ECC_HD PairEntry131 pairLoad131(const PairCacheEntry131 *pairs,unsigned a,unsigned b){
    uint32_t u=unsigned(eccTagK(a))*TW_H+eccTagH(a),v=unsigned(eccTagK(b))*TW_H+eccTagH(b);
    unsigned sa=eccTagEps(a),sb=eccTagEps(b);
    if(u>v){uint32_t t=u;u=v;v=t;unsigned s=sa;sa=sb;sb=s;}
    if(u==v&&sa!=sb)return PairEntry131{{0,0,0,0,0,0,0,0,0x80000000u}};
    PairEntry131 sum=pairCacheRead131(pairs,v*v+2*u+(sa^sb));
    const unsigned mask=0u-sb;
#pragma unroll
    for(int w=0;w<4;++w)sum.w[4+w]^=sum.w[w]&mask;
    sum.w[8]^=((sum.w[8]&7u)<<3)&mask;
    return sum;
}

static __global__ void ECC_BOUNDS buildPairs131(PairCacheEntry131 *out,const PairEntry131 *dirs) {
    const uint64_t stride=uint64_t(gridDim.x)*blockDim.x;
    for(uint64_t base=uint64_t(blockIdx.x)*blockDim.x;base<PAIR_ENTRIES;base+=stride){
        const uint64_t index=base+threadIdx.x;
        uint64_t v=uint64_t(sqrt(double(index)));
        while((v+1)*(v+1)<=index)++v;
        while(v*v>index)--v;
        uint64_t u=index-v*v;
        // u is already the signed direction 2*base+relative_sign.
        v*=2;
        if(index>=PAIR_ENTRIES)u=v=0;
        const P131 x=pairX131(dirs[u]),y=pairY131(dirs[u]);
        const P131 qx=pairX131(dirs[v]),qy=pairY131(dirs[v]);
        const bool sameX=pairZero131(add131(x,qx)),sameY=pairZero131(add131(y,qy));
        const P131 one{{1,0,0,0,0}};
        const P131 d=sameX?(sameY?x:one):add131(x,qx);
        const P131 inv=batchInverse131(d,int(stride));
        P131 nx{},ny{};
        if(sameX&&sameY){
            const P131 lam=add131(x,mulPolynomial131(y,inv));
            nx=add131(squarePolynomial131(lam),lam);
            ny=add131(squarePolynomial131(x),mulPolynomial131(add131(lam,one),nx));
        }else if(!sameX){
            const P131 lam=mulPolynomial131(add131(y,qy),inv);
            nx=add131(add131(squarePolynomial131(lam),lam),d);
            ny=add131(add131(mulPolynomial131(lam,add131(x,nx)),nx),y);
        }
        if(index<PAIR_ENTRIES)out[index]=pairCacheEncode131(pairPack131(nx,ny,sameX&&!sameY));
    }
}

// DP and timeout semantics match the ordinary kernel at the start of each
// logical update. A paired launch checks its intermediate point at now+1.
__device__ __forceinline__ bool pairNeedsY131(const WalkParams<unsigned> &p,size_t id,int hw,unsigned long long now){
    return !goal22ReadDead(p.dead,id)&&hw<=p.dpWeight;
}
__device__ __forceinline__ void pairReport131(const WalkParams<unsigned> &p,size_t id,P131 xn,P131 yp,int hw,unsigned long long now){
    if(!goal22ReadDead(p.dead,id)){
        if(hw<=p.dpWeight){
            if((p.seed[id]&0xffffull)==0xffffull)atomicAdd(p.dpCount+2,1u);
            const unsigned dest=atomicAdd(p.dpCount,1u);
            if(dest<p.dpCap){
                DpRecord rec;rec.seed=p.seed[id];rec.iters=now-p.startIter[id];
                toLimbs(xn,rec.x);toLimbs(fromPolynomial131(yp),rec.y);p.dp[dest]=rec;
            }
            goal22WriteDead(p.dead,id,1);
        }else if(p.maxIters&&now%ECC_GUARD_PERIOD==0&&now-p.startIter[id]>=p.maxIters){
            if((p.seed[id]&0xffffull)==0xffffull)atomicAdd(p.dpCount+2,1u);
            goal22WriteDead(p.dead,id,1);atomicAdd(p.dpCount+1,1u);
        }
    }
}

__device__ __forceinline__ unsigned pairSelectProjected131(P131 xn,int hw,const uint32_t rawY[9],
    unsigned long long *history,const uint32_t *sel,const uint32_t *projection){
    const uint8_t *bytes=reinterpret_cast<const uint8_t *>(sel);
    const int k=twPhase(xn,hw,bytes+4*(TW_PHASE_OFF-TW_SEL0),sel+TW_INV_OFF-TW_SEL0);
    const int pivot=twPivot(xn,k,sel+TW_MASK_OFF-TW_SEL0,bytes+4*(TW_MAX_OFF-TW_SEL0),bytes+4*(TW_LINV_OFF-TW_SEL0));
    const int eps=pairProjectionSign131(rawY,pivot,sel,projection);
    int h=twBranch(xn,k,hw,sel);
    unsigned tag=eccTag(h,k,eps);
    while(eccTagFruitless(tag,*history)){h=(h+1)&(TW_H-1);tag=eccTag(h,k,eps);}
    *history=eccHistPush(*history,tag);return tag;
}

__device__ __forceinline__ unsigned pairSelectOnb131(P131 xn,int hw,P131 lambda,P131 deltaX,P131 baseY,
    unsigned long long *history,const uint32_t *sel){
    const uint8_t *bytes=reinterpret_cast<const uint8_t *>(sel);
    const int k=twPhase(xn,hw,bytes+4*(TW_PHASE_OFF-TW_SEL0),sel+TW_INV_OFF-TW_SEL0);
    const int pivot=twPivot(xn,k,sel+TW_MASK_OFF-TW_SEL0,bytes+4*(TW_MAX_OFF-TW_SEL0),bytes+4*(TW_LINV_OFF-TW_SEL0));
    const int eps=pairOnbProductBit131(fromPolynomial131(lambda),fromPolynomial131(deltaX),pivot)
        ^twCoordinate(baseY,pivot,sel+TW_ROW_OFF-TW_SEL0);
    int h=twBranch(xn,k,hw,sel);unsigned tag=eccTag(h,k,eps);
    while(eccTagFruitless(tag,*history)){h=(h+1)&(TW_H-1);tag=eccTag(h,k,eps);}
    *history=eccHistPush(*history,tag);return tag;
}

static __global__ void ECC_BOUNDS pairedWalk(WalkParams<unsigned> p,
    unsigned *__restrict__ stateX,unsigned *__restrict__ stateY,unsigned *__restrict__ statePrefix,
    unsigned *__restrict__ pairDenom,unsigned long long *__restrict__ history,
    const unsigned *__restrict__ constants,const PairCacheEntry131 *__restrict__ pairs,
    const uint32_t *__restrict__ rows,unsigned *__restrict__ fallbackCount){
    const int tid=blockIdx.x*blockDim.x+threadIdx.x;
#if !ECC_PAIR_SIGN_ONB
    __shared__ uint32_t projection[PAIR_PROJECTION_WORDS];
    for(unsigned i=threadIdx.x;i<PAIR_PROJECTION_WORDS;i+=blockDim.x)projection[i]=rows[i];
#else
    (void)rows;
#endif
#if ECC_TABLE_GLOBAL
    const uint32_t *sel=constants,*tab=constants;__syncthreads();
#elif ECC_TABLE_ADDEND_GLOBAL
    extern __shared__ uint32_t sel[];
    twLoadShared(sel,constants+TW_MASK_OFF,TW_SEL_WORDS);const uint32_t *tab=constants;
#else
    extern __shared__ uint32_t sel[];
    twLoadShared(sel,constants);const uint32_t *tab=sel;
#endif
    if(tid>=p.threads)return;
#pragma unroll 1
    for(int step=0;step<p.steps;step+=2){
        const unsigned long long now=p.iterBase+step;
        P131 product;
        // The shipping weighted prefix, with all 16 slots and ordinary tags.
#pragma unroll 1
        for(int slot=0;slot<ECC_BATCH;++slot){
            const size_t id=size_t(slot)*p.threads+tid;
            const P131 xp=load(stateX,slot,tid,p.threads),yp=load(stateY,slot,tid,p.threads);
            const P131 xn=fromPolynomial131(xp);const int hw=weight(xn);
            pairReport131(p,id,xn,yp,hw,now);
            unsigned long long hist=goal22ReadHist(history,id,size_t(p.threads)*ECC_BATCH);
            const unsigned tag=twSelectHist(xn,yp,hw,&hist,sel);
            goal22WriteHist(history,id,size_t(p.threads)*ECC_BATCH,hist);
            P131 d,e;twAddend(tag,xp,yp,tab,&d,&e,constants+TW_Y_OFF);
            if(slot){
                const PolynomialPair products=mulPolynomialPair131(product,e,d);
                store(statePrefix,slot,tid,p.threads,products.first);product=products.second;
            }else{product=d;store(statePrefix,slot,tid,p.threads,e);}
        }
        P131 inv=batchInverse131(product,p.threads),secondProduct;
        // Consume the first chain backwards and build the pair-addition chain
        // in that same reverse order. Ordinary lanes keep original X/Y in place.
#pragma unroll 1
        for(int slot=ECC_BATCH-1;slot>=0;--slot){
            const size_t id=size_t(slot)*p.threads+tid;
            const P131 x=load(stateX,slot,tid,p.threads),y=load(stateY,slot,tid,p.threads);
            unsigned long long hist=goal22ReadHist(history,id,size_t(p.threads)*ECC_BATCH);
            const unsigned first=eccHistTag(hist);
            P131 d;twDenominator(first,x,tab,&d);
            P131 lambda;
            if(slot){
                const PolynomialPair products=mulPolynomialPair131(inv,d,load(statePrefix,slot,tid,p.threads));
                inv=products.first;lambda=products.second;
            }else lambda=mulPolynomial131(inv,load(statePrefix,slot,tid,p.threads));
            const P131 nx=add131(add131(squarePolynomial131(lambda),lambda),d);
#if !ECC_PAIR_SIGN_ONB
            uint32_t rawY[9];product131(lambda,add131(x,nx),rawY);
#pragma unroll
            for(int w=0;w<5;++w)rawY[w]^=nx.v[w]^y.v[w];
#endif
            const P131 xn=fromPolynomial131(nx);const int hw=weight(xn);
            // Only materialize y for a report or a rare shortcut exception.
            const bool reportY=pairNeedsY131(p,id,hw,now+1);
            P131 middleY{};
            if(reportY){
#if ECC_PAIR_SIGN_ONB
                middleY=add131(mulPolynomial131(lambda,add131(x,nx)),add131(nx,y));
#else
                middleY=reducePolynomial131(rawY);
#endif
            }
            pairReport131(p,id,xn,middleY,hw,now+1);
#if ECC_PAIR_SIGN_ONB
            const unsigned second=pairSelectOnb131(xn,hw,lambda,add131(x,nx),add131(nx,y),&hist,sel);
#else
            const unsigned second=pairSelectProjected131(xn,hw,rawY,&hist,sel,projection);
#endif
            goal22WriteHist(history,id,size_t(p.threads)*ECC_BATCH,hist);
            const PairEntry131 sum=pairLoad131(pairs,first,second);
            P131 nextD=add131(x,pairX131(sum)),nextE=add131(y,pairY131(sum));
            if((sum.w[8]&0x80000000u)||pairZero131(nextD)){
                // The shortcut can have a zero denominator even when both
                // ordinary additions are regular. Use the already-known middle
                // point and second addend for this lane, in the same batch.
                if(!reportY){
#if ECC_PAIR_SIGN_ONB
                    middleY=add131(mulPolynomial131(lambda,add131(x,nx)),add131(nx,y));
#else
                    middleY=reducePolynomial131(rawY);
#endif
                }
                twAddend(second,nx,middleY,tab,&nextD,&nextE,constants+TW_Y_OFF);
                store(stateX,slot,tid,p.threads,nx);store(stateY,slot,tid,p.threads,middleY);
                atomicAdd(fallbackCount,1u);
            }
            store(pairDenom,slot,tid,p.threads,nextD);
            if(slot!=ECC_BATCH-1){
                const PolynomialPair products=mulPolynomialPair131(secondProduct,nextE,nextD);
                store(statePrefix,slot,tid,p.threads,products.first);secondProduct=products.second;
            }else{secondProduct=nextD;store(statePrefix,slot,tid,p.threads,nextE);}
        }
        inv=batchInverse131(secondProduct,p.threads);
        // Reverse the second chain, i.e. visit slots forwards.
#pragma unroll 1
        for(int slot=0;slot<ECC_BATCH;++slot){
            const P131 x=load(stateX,slot,tid,p.threads),y=load(stateY,slot,tid,p.threads);
            const P131 d=load(pairDenom,slot,tid,p.threads);P131 lambda;
            if(slot+1<ECC_BATCH){
                const PolynomialPair products=mulPolynomialPair131(inv,d,load(statePrefix,slot,tid,p.threads));
                inv=products.first;lambda=products.second;
            }else lambda=mulPolynomial131(inv,load(statePrefix,slot,tid,p.threads));
            const P131 nx=add131(add131(squarePolynomial131(lambda),lambda),d);
            const P131 ny=add131(add131(mulPolynomial131(lambda,add131(x,nx)),nx),y);
            store(stateX,slot,tid,p.threads,nx);store(stateY,slot,tid,p.threads,ny);
        }
    }
}
#endif
