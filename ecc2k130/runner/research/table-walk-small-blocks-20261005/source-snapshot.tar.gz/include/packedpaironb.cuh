// Included inside eccPacked131. One coefficient of an ONB product without
// forming the complete carryless product. gamma_i*gamma_j=gamma_(i+j)+gamma_(i-j).
#pragma once
#if ECC_TABLE_PAIR_STEPS
struct PairBits131 { uint64_t lo,hi,top; };
ECC_HD PairBits131 pairBits131(P131 p){return {uint64_t(p.v[0])|(uint64_t(p.v[1])<<32),uint64_t(p.v[2])|(uint64_t(p.v[3])<<32),p.v[4]};}
ECC_HD PairBits131 pairBitsXor131(PairBits131 a,PairBits131 b){return {a.lo^b.lo,a.hi^b.hi,a.top^b.top};}
ECC_HD PairBits131 pairShiftLeft131(PairBits131 a,unsigned s){
    if(!s)return a;if(s>=131)return {0,0,0};
    if(s<64)return {a.lo<<s,(a.hi<<s)|(a.lo>>(64-s)),((a.top<<s)|(a.hi>>(64-s)))&7};
    if(s==64)return {0,a.lo,a.hi&7};
    if(s<128){s-=64;return {0,a.lo<<s,((a.hi<<s)|(a.lo>>(64-s)))&7};}
    return {0,0,(a.lo<<(s-128))&7};
}
ECC_HD PairBits131 pairShiftRight131(PairBits131 a,unsigned s){
    if(!s)return a;if(s>=131)return {0,0,0};
    if(s<64)return {(a.lo>>s)|(a.hi<<(64-s)),(a.hi>>s)|(a.top<<(64-s)),a.top>>s};
    if(s==64)return {a.hi,a.top,0};
    if(s<128){s-=64;return {(a.hi>>s)|(a.top<<(64-s)),a.top>>s,0};}
    return {a.top>>(s-128),0,0};
}
ECC_HD unsigned pairOnbProductBit131(P131 a,P131 b,unsigned pivot){
    const unsigned p=pivot+1; // gamma indices are 1..131.
    const PairBits131 aa=pairBits131(a),bb=pairBits131(b),rev=pairBits131(reverse131(b));
    // For coordinate i, T_i=b_fold(i+p)+b_fold(i-p), with b_0=0.
    // Reflection at 131 gives these four truncated shifts exactly.
    PairBits131 t=pairBitsXor131(pairShiftRight131(bb,p),pairShiftLeft131(bb,p));
    t=pairBitsXor131(t,pairShiftLeft131(rev,131-p));
    t=pairBitsXor131(t,pairShiftRight131(rev,132-p));
    const uint64_t value=(aa.lo&t.lo)^(aa.hi&t.hi)^(aa.top&t.top);
#ifdef __CUDA_ARCH__
    return unsigned(__popcll(value)&1);
#else
    return unsigned(__builtin_popcountll(value)&1);
#endif
}
#endif
