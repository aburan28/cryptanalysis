// Experimental execution schedule. All points, selectors, reports and histories
// match the ordinary table walk; small batches retain their state in registers.
#pragma once
namespace eccPacked131 {
static __global__ void ECC_BOUNDS registerWalk(WalkParams<unsigned> p,
    unsigned *__restrict__ stateX,unsigned *__restrict__ stateY,
    unsigned *__restrict__ stateDead,unsigned long long *__restrict__ history,
    const unsigned long long *__restrict__ seeds,const unsigned long long *__restrict__ starts,
    DpRecord *__restrict__ reports,unsigned *__restrict__ counts,const unsigned *__restrict__ constants){
    const int tid=blockIdx.x*blockDim.x+threadIdx.x;
#if ECC_TABLE_GLOBAL
    const uint32_t *sel=constants,*tab=constants;
#elif ECC_TABLE_ADDEND_GLOBAL
    extern __shared__ uint32_t shared[];
    twLoadShared(shared,constants+TW_MASK_OFF,TW_SEL_WORDS);
    const uint32_t *sel=shared,*tab=constants;
#else
    extern __shared__ uint32_t shared[];
    twLoadShared(shared,constants);
    const uint32_t *sel=shared,*tab=shared;
#endif
    if(tid>=p.threads)return;
    P131 xs[ECC_BATCH],ys[ECC_BATCH],prefix[ECC_BATCH];
    unsigned long long histories[ECC_BATCH];
    unsigned dead[ECC_BATCH];
#pragma unroll
    for(int slot=0;slot<ECC_BATCH;++slot){
        const size_t id=size_t(slot)*p.threads+tid;
        xs[slot]=load(stateX,slot,tid,p.threads);
        ys[slot]=load(stateY,slot,tid,p.threads);
        histories[slot]=goal22ReadHist(history,id,size_t(p.threads)*ECC_BATCH);
        dead[slot]=goal22ReadDead(stateDead,id);
    }
#pragma unroll 1
    for(int step=0;step<p.steps;++step){
        const unsigned long long now=p.iterBase+step;
        const bool guard=p.maxIters&&now%ECC_GUARD_PERIOD==0;
        P131 product;
#pragma unroll
        for(int slot=0;slot<ECC_BATCH;++slot){
            const size_t id=size_t(slot)*p.threads+tid;
            const P131 normal=fromPolynomial131(xs[slot]);
            const int hw=weight(normal);
            if(!dead[slot]){
                if(hw<=p.dpWeight){
                    if((seeds[id]&0xffffull)==0xffffull)atomicAdd(counts+2,1u);
                    const unsigned dest=atomicAdd(counts,1u);
                    if(dest<p.dpCap){
                        DpRecord record;
                        record.seed=seeds[id];record.iters=now-starts[id];
                        toLimbs(normal,record.x);toLimbs(fromPolynomial131(ys[slot]),record.y);
                        reports[dest]=record;
                    }
                    dead[slot]=1;
                }else if(guard&&now-starts[id]>=p.maxIters){
                    if((seeds[id]&0xffffull)==0xffffull)atomicAdd(counts+2,1u);
                    dead[slot]=1;atomicAdd(counts+1,1u);
                }
            }
            const unsigned tag=twSelectHist(normal,ys[slot],hw,&histories[slot],sel);
            P131 d,e;twAddend(tag,xs[slot],ys[slot],tab,&d,&e,constants+TW_Y_OFF);
            if(slot){
                const PolynomialPair products=mulPolynomialPair131(product,e,d);
                prefix[slot]=products.first;product=products.second;
            }else{product=d;prefix[slot]=e;}
        }
        P131 inverse=batchInverse131(product,p.threads);
#pragma unroll
        for(int slot=ECC_BATCH-1;slot>=0;--slot){
            P131 d;twDenominator(eccHistTag(histories[slot]),xs[slot],tab,&d);
            P131 lambda;
            if(slot){
                const PolynomialPair products=mulPolynomialPair131(inverse,d,prefix[slot]);
                inverse=products.first;lambda=products.second;
            }else lambda=mulPolynomial131(inverse,prefix[slot]);
            const P131 nx=add131(add131(squarePolynomial131(lambda),lambda),d);
            ys[slot]=add131(add131(mulPolynomial131(lambda,add131(xs[slot],nx)),nx),ys[slot]);
            xs[slot]=nx;
        }
    }
#pragma unroll
    for(int slot=0;slot<ECC_BATCH;++slot){
        const size_t id=size_t(slot)*p.threads+tid;
        store(stateX,slot,tid,p.threads,xs[slot]);store(stateY,slot,tid,p.threads,ys[slot]);
        goal22WriteHist(history,id,size_t(p.threads)*ECC_BATCH,histories[slot]);
        goal22WriteDead(stateDead,id,dead[slot]);
    }
}
} // namespace eccPacked131
