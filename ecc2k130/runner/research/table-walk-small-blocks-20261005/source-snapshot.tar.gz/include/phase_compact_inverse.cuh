// A lossless 17-byte shared scratch representation for reduced GF(2^131) values.
// The product tree, warp placement, barrier IDs and zero handling are unchanged.
#pragma once
namespace eccPacked131 {
__device__ __forceinline__ P131 phaseInverseLoad(const uint32_t *low,const uint8_t *top,int id){
    P131 value;
#pragma unroll
    for(int i=0;i<4;++i)value.v[i]=low[i*ECC_THREADS+id];
    value.v[4]=top[id];return value;
}
__device__ __forceinline__ void phaseInverseStore(uint32_t *low,uint8_t *top,int id,P131 value){
#pragma unroll
    for(int i=0;i<4;++i)low[i*ECC_THREADS+id]=value.v[i];
    top[id]=uint8_t(value.v[4]);
}
template<int WARPS>
__device__ __noinline__ P131 phaseCollectiveInverse(P131 input){
    static_assert(WARPS==2||WARPS==4||WARPS==8||WARPS==16);
    static_assert(ECC_THREADS%(32*WARPS)==0);
    constexpr int LEVELS=WARPS==2?1:WARPS==4?2:WARPS==8?3:4;
    __shared__ uint32_t low[4*ECC_THREADS];
    __shared__ uint8_t top[ECC_THREADS];
    const int physicalWarp=int(threadIdx.x)/32,group=physicalWarp/WARPS;
    const int rotation=group/(WARPS<4?4/WARPS:1);
    const int warp=group*WARPS+(physicalWarp%WARPS+rotation)%WARPS;
    const int id=warp*32+int(threadIdx.x)%32;
    const bool zero=!(input.v[0]|input.v[1]|input.v[2]|input.v[3]|input.v[4]);
    P131 acc=zero?P131{{1,0,0,0,0}}:input,right[LEVELS];
    phaseInverseStore(low,top,id,acc);goal22GroupBarrier<WARPS>();
#pragma unroll
    for(int level=0;level<LEVELS;++level){
        const int width=1<<(level+1),offset=32<<level;
        if((warp&(width-1))==width-1){
            right[level]=acc;acc=mulPolynomial131(phaseInverseLoad(low,top,id-offset),acc);
            phaseInverseStore(low,top,id,acc);
        }
        goal22GroupBarrier<WARPS>();
    }
    if((warp&(WARPS-1))==WARPS-1){
        acc=toPolynomial131(inv131(fromPolynomial131(acc)));phaseInverseStore(low,top,id,acc);
    }
    goal22GroupBarrier<WARPS>();
#pragma unroll
    for(int level=LEVELS-1;level>=0;--level){
        const int width=1<<(level+1),offset=32<<level;
        if((warp&(width-1))==width-1){
            const auto inverse=mulPolynomialPair131(phaseInverseLoad(low,top,id),right[level],phaseInverseLoad(low,top,id-offset));
            phaseInverseStore(low,top,id-offset,inverse.first);phaseInverseStore(low,top,id,inverse.second);
        }
        goal22GroupBarrier<WARPS>();
    }
    P131 result=phaseInverseLoad(low,top,id);goal22GroupBarrier<WARPS>();
    return zero?P131{{0,0,0,0,0}}:result;
}
__device__ __forceinline__ P131 phaseBatchInverse131(P131 input,int workers){
#if ECC_COLLECTIVE_WARPS
    if((blockIdx.x+1)*blockDim.x<=workers)return phaseCollectiveInverse<ECC_COLLECTIVE_WARPS>(input);
#endif
    return toPolynomial131(inv131(fromPolynomial131(input)));
}
}
