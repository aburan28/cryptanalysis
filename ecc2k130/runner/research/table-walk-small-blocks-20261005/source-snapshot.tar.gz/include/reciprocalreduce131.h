// Optional exact reduction in the existing field. The quotient is the upper
// 130 bits of D*C, C=0x1d0d000d0000000d000000000000000d0, after a 128-bit shift.
// Included inside eccPacked131. Zero is the ordinary ALU reducer in packed131.h.
#pragma once
#if ECC_NATIVE_REDUCTION != 1 && ECC_NATIVE_REDUCTION != 2
#error "ECC_NATIVE_REDUCTION must be 0, 1 or 2"
#endif
ECC_HD uint64_t reciprocalLo131(uint64_t a,uint64_t b,uint64_t add=0){
#if ECC_USE_CLMAD_INSN
    uint64_t r;asm("clmad.lo.u64 %0, %1, %2, %3;":"=l"(r):"l"(a),"l"(b),"l"(add));return r;
#else
    uint32_t aa[2]={uint32_t(a),uint32_t(a>>32)},bb[2]={uint32_t(b),uint32_t(b>>32)},r[4];
    clmul64(r,aa,bb);return (uint64_t(r[0])|(uint64_t(r[1])<<32))^add;
#endif
}
ECC_HD uint64_t reciprocalHi131(uint64_t a,uint64_t b,uint64_t add=0){
#if ECC_USE_CLMAD_INSN
    uint64_t r;asm("clmad.hi.u64 %0, %1, %2, %3;":"=l"(r):"l"(a),"l"(b),"l"(add));return r;
#else
    uint32_t aa[2]={uint32_t(a),uint32_t(a>>32)},bb[2]={uint32_t(b),uint32_t(b>>32)},r[4];
    clmul64(r,aa,bb);return (uint64_t(r[2])|(uint64_t(r[3])<<32))^add;
#endif
}
ECC_HD P131 reducePolynomial131(const uint32_t *h){
    const uint64_t c0=0xd0ull,c1=0xd0d000d0000000d0ull;
    const uint64_t d0=((uint64_t(h[4])|(uint64_t(h[5])<<32))>>3)|(uint64_t(h[6])<<61);
    const uint64_t d1=((uint64_t(h[6])|(uint64_t(h[7])<<32))>>3)|(uint64_t(h[8])<<61);
    const uint32_t d2=(h[8]>>3)&3u;
    const uint64_t m0=0ull-(d2&1u),m1=0ull-(d2>>1);
    uint64_t low=reciprocalHi131(d0,c1,d0)^reciprocalHi131(d1,c0);
    low=reciprocalLo131(d1,c1,low)^(c0&m0)^((c0<<1)&m1);
    const uint64_t high=reciprocalHi131(d1,c1,d1)^(c1&m0)^((c1<<1)&m1);
    const uint32_t q0=uint32_t(low),q1=uint32_t(low>>32),q2=uint32_t(high),q3=uint32_t(high>>32),q4=d2^(d2>>1);
#if ECC_NATIVE_REDUCTION == 2
    const uint64_t tl=reciprocalLo131(low,13),th=reciprocalLo131(high,13,reciprocalHi131(low,13));
    const uint32_t t0=uint32_t(tl),t1=uint32_t(tl>>32),t2=uint32_t(th),t3=uint32_t(th>>32);
#else
    const uint32_t t0=q0^(q0<<2)^(q0<<3);
    const uint32_t t1=q1^((q1<<2)|(q0>>30))^((q1<<3)|(q0>>29));
    const uint32_t t2=q2^((q2<<2)|(q1>>30))^((q2<<3)|(q1>>29));
    const uint32_t t3=q3^((q3<<2)|(q2>>30))^((q3<<3)|(q2>>29));
#endif
    const uint32_t t4=q4^((q4<<2)|(q3>>30))^((q4<<3)|(q3>>29));
    return P131{{h[0]^t0,h[1]^t1,h[2]^t2^t0,
        h[3]^t3^t1^t0^(t0<<16)^(t0<<24)^(q0<<28),
        (h[4]^t4^t2^t1^((t1<<16)|(t0>>16))^((t1<<24)|(t0>>8))^t0^((q1<<28)|(q0>>4)))&7u}};
}
