// Included inside eccPacked131 after the ordinary table-selector helpers.
// Reuse its low-coordinate rows; only the high product coefficients are new.
#pragma once
#if ECC_TABLE_PAIR_STEPS
#ifndef ECC_PAIR_COMPACT_PROJECTION
#define ECC_PAIR_COMPACT_PROJECTION 1
#endif
#if ECC_PAIR_COMPACT_PROJECTION != 0 && ECC_PAIR_COMPACT_PROJECTION != 1
#error "ECC_PAIR_COMPACT_PROJECTION must be 0 or 1"
#endif
static const size_t PAIR_PROJECTION_WORDS=ECC_PAIR_COMPACT_PROJECTION ? 131*4+33 : 131*9;

inline void pairFillProjection131(uint32_t *rows){
    for(size_t i=0;i<PAIR_PROJECTION_WORDS;++i)rows[i]=0;
    for(int j=ECC_PAIR_COMPACT_PROJECTION?128:0;j<261;++j){
        uint32_t raw[9]={};raw[j/32]=1u<<(j%32);
        const P131 normal=fromPolynomialProduct131(raw);
        for(int bit=0;bit<131;++bit)if((normal.v[bit/32]>>(bit%32))&1u){
#if ECC_PAIR_COMPACT_PROJECTION
            if(j<256)rows[bit*4+j/32-4]|=1u<<(j%32);
            else rows[131*4+bit/4]|=1u<<(j-256+8*(bit%4));
#else
            rows[bit*9+j/32]|=1u<<(j%32);
#endif
        }
    }
}

TW_FN int pairProjectionSign131(const uint32_t raw[9],int pivot,
                               const uint32_t *sel,const uint32_t *projection){
    uint32_t parity=0;
#if ECC_PAIR_COMPACT_PROJECTION
    const uint32_t *low=sel+TW_ROW_OFF-TW_SEL0+pivot*(ECC_TABLE_PIVOT_BYTES?4:5);
#pragma unroll
    for(int w=0;w<4;++w)parity^=raw[w]&low[w];
#pragma unroll
    for(int w=4;w<8;++w)parity^=raw[w]&projection[4*pivot+w-4];
    const unsigned top=(projection[131*4+pivot/4]>>(8*(pivot%4)))&31u;
    parity^=raw[8]&top;
#else
    (void)sel;
#pragma unroll
    for(int w=0;w<9;++w)parity^=raw[w]&projection[9*pivot+w];
#endif
    return twParity(parity);
}
#endif
