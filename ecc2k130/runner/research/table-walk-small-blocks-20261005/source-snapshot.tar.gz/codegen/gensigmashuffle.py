from pathlib import Path
import re
root=Path(__file__).resolve().parent.parent
s=(root/'include/packedsigma131.h').read_text()
start=s.index('static ECC_SIGMA_WALK_PROC SigmaWalkPair131 sigmaWalkNetworkPairShared131')
body=s[start:s.index('\n}\n#endif',start)+2]
body=body.replace('static ECC_SIGMA_WALK_PROC SigmaWalkPair131 sigmaWalkNetworkPairShared131(P131 a, P131 b, int index)', 'static ECC_HD SigmaWalkPair131 sigmaWalkNetworkPairShuffle131(P131 a, P131 b, int index, const SigmaShuffleCache131 &cache)')
# Replace the outer CUDA host case with a uniform CPU/partial-warp fallback.
cut=body.index('    uint32_t a0=')
body=body[cut:body.rindex('\n#endif')]
pat=r'#ifdef __CUDA_ARCH__\n    mask=sigmaWalkShared131Masks\[(\d+)\]\[index\];\n#else\n    mask=sigmaWalkNetwork131Masks\[\d+\]\[index\];\n#endif'
def repl(m):
 r=int(m.group(1)); return f'    mask=__shfl_sync(0xffffffffu,cache.m{r//4}, {r%4}*8+index);'
body,count=re.subn(pat,repl,body)
assert count==64,count
out='// Experimental warp-register mask cache. Generated from the checked shared network.\n#pragma once\n#ifndef ECC_PACKED_SHUFFLE_SIGMA\n#define ECC_PACKED_SHUFFLE_SIGMA 0\n#endif\n#if ECC_PACKED_SHUFFLE_SIGMA\n#if !ECC_PACKED_SHARED_SIGMA\n#error "shuffle sigma requires shared sigma fallback"\n#endif\nstruct SigmaShuffleCache131 {\n'
out+=''.join(f'    uint32_t m{i};\n' for i in range(14))+'};\n'
out+='static ECC_HD SigmaShuffleCache131 loadSigmaShuffleCache131() {\n    SigmaShuffleCache131 c{};\n#ifdef __CUDA_ARCH__\n    if (__activemask()==0xffffffffu) {\n    const unsigned lane=threadIdx.x & 31u;\n'
out+=''.join(f'    c.m{i}=__ldg(&sigmaWalkNetwork131Masks[{i*4}+lane/8][lane&7]);\n' for i in range(14))
out+='    }\n#endif\n    return c;\n}\n'
out+='static ECC_HD SigmaWalkPair131 sigmaWalkNetworkPairShuffle131(P131 a, P131 b, int index, const SigmaShuffleCache131 &cache) {\n#ifdef __CUDA_ARCH__\n    if (__activemask()!=0xffffffffu) return sigmaWalkNetworkPairShared131(a,b,index);\n'+body+'\n#else\n    return sigmaWalkNetworkPairShared131(a,b,index);\n#endif\n}\n#endif\n'
(root/'include/packedsigmashuffle131.h').write_text(out)
