#!/usr/bin/env python3
"""Search exact Beneš stage orders for the eight legacy walk permutations.

The objective counts emitted word swaps and mask loads, not measured time.
Padding remains the identity permutation; every selected circuit is checked
on all 256 input basis vectors before a header is written.
"""
import argparse
import json
import random
from pathlib import Path
from gensigma import permutation, route


def relabel(position, order):
    return sum(((position >> axis) & 1) << bit for bit, axis in enumerate(order))


def routed(order):
    labels = [relabel(i, order) for i in range(256)]
    inverse = [0] * 256
    for i, label in enumerate(labels):
        inverse[label] = i
    nets = []
    for power in range(3, 11):
        p = permutation(power)
        q = [labels[p[inverse[j]]] for j in range(256)]
        net = []
        for distance, mask in route(q):
            original_mask = sum(((mask >> j) & 1) << inverse[j] for j in range(256))
            net.append((1 << order[distance.bit_length()-1], original_mask))
        nets.append(net)
    return nets


def operations(nets):
    ops = []
    for stage in range(15):
        distance = nets[0][stage][0]
        for word in range(8):
            masks = tuple((net[stage][1] >> (32*word)) & 0xffffffff for net in nets)
            if any(masks):
                ops.append((distance, word, masks))
    return ops


def score(nets):
    # One shared mask load plus two independent scalar swap expressions.
    return sum(9 if distance < 32 else 7 for distance, _, _ in operations(nets))


def verify(nets):
    for power, net in zip(range(3, 11), nets):
        p = permutation(power)
        for i in range(256):
            value = 1 << i
            for distance, mask in net:
                t = ((value >> distance) ^ value) & mask
                value ^= t ^ (t << distance)
            if value != 1 << p[i]:
                raise ValueError((power, i, "invalid topology"))


def emit(nets, order, mode):
    ops = operations(nets)
    rows = list(dict.fromkeys(masks for _, _, masks in ops))
    lines = [f'#if ECC_PACKED_SIGMA_TOPOLOGY == {mode}',
             '// Stage axes: '+','.join(map(str, order)),
             '#ifdef __CUDACC__',
             f'static __device__ __align__(32) const uint32_t sigmaTopologyGlobal131[{len(rows)}][8] = {{',
             '#else', f'alignas(32) static const uint32_t sigmaTopologyGlobal131[{len(rows)}][8] = {{', '#endif']
    lines += ['    {'+','.join(f'0x{mask:08x}u' for mask in row)+'},' for row in rows]
    lines += ['};', '#if ECC_PACKED_SHARED_SIGMA && defined(__CUDACC__)',
              f'static __shared__ uint32_t sigmaTopologyShared131[{len(rows)}][8];', '#endif',
              'static ECC_HD void initSigmaTopology131() {',
              '#if ECC_PACKED_SHARED_SIGMA && defined(__CUDA_ARCH__)',
              f'    for(unsigned i=threadIdx.x;i<{len(rows)*8}u;i+=blockDim.x)',
              '        sigmaTopologyShared131[i/8][i%8]=__ldg(&sigmaTopologyGlobal131[i/8][i%8]);',
              '    __syncthreads();', '#endif', '}',
              'static ECC_HD SigmaWalkPair131 sigmaTopologyPair131(P131 a,P131 b,int index) {',
              '    uint32_t a0=a.v[0],a1=a.v[1],a2=a.v[2],a3=a.v[3],a4=a.v[4];',
              '    uint32_t b0=b.v[0],b1=b.v[1],b2=b.v[2],b3=b.v[3],b4=b.v[4];',
              '    uint32_t a5=0,a6=0,a7=0,b5=0,b6=0,b7=0,t,mask;']
    for distance, word, masks in ops:
        row = rows.index(masks)
        lines += ['#if ECC_PACKED_SHARED_SIGMA && defined(__CUDA_ARCH__)',
                  f'    mask=sigmaTopologyShared131[{row}][index];',
                  '#elif defined(__CUDA_ARCH__)', f'    mask=__ldg(&sigmaTopologyGlobal131[{row}][index]);',
                  '#else', f'    mask=sigmaTopologyGlobal131[{row}][index];', '#endif']
        for prefix in ('a', 'b'):
            if distance < 32:
                lines += [f'    t=(({prefix}{word}>>{distance})^{prefix}{word})&mask;',
                          f'    {prefix}{word}^=t^(t<<{distance});']
            else:
                other = word + distance//32
                assert other < 8
                lines += [f'    t=({prefix}{word}^{prefix}{other})&mask;',
                          f'    {prefix}{word}^=t;{prefix}{other}^=t;']
    lines += ['    return SigmaWalkPair131{P131{{a0,a1,a2,a3,a4&7u}},P131{{b0,b1,b2,b3,b4&7u}}};', '}', '#endif']
    return lines


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--samples', type=int, default=512)
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent.parent/'include/packedsigmatopology131.h')
    parser.add_argument('--record', type=Path, default=Path(__file__).resolve().parent.parent/'research/rtx5090-structural/sigma-topology-search.json')
    args = parser.parse_args()
    random_source = random.Random(0x5090131)
    orders = {tuple(range(8)), tuple(reversed(range(8)))}
    while len(orders) < args.samples:
        order = list(range(8));random_source.shuffle(order);orders.add(tuple(order))
    results = []
    for order in sorted(orders):
        nets = routed(order)
        results.append(dict(order=order, score=score(nets), word_swaps=len(operations(nets))))
    results.sort(key=lambda row:(row['score'], row['word_swaps'], row['order']))
    chosen = results[:3]
    lines = ['// Generated by codegen/gensigmatopology.py; inside eccPacked131.', '#pragma once',
             '#if ECC_PACKED_SIGMA_TOPOLOGY',
             '#if ECC_PACKED_WEIGHTED_PREFIX != 2 || !(ECC_PACKED_PERM_SIGMA & 1)',
             '#error "topology permutations require paired walk permutation mode"', '#endif']
    for mode, row in enumerate(chosen, 1):
        nets = routed(row['order']);verify(nets)
        lines += emit(nets, row['order'], mode)
    lines += ['#endif']
    args.out.write_text('\n'.join(lines)+'\n')
    args.record.write_text(json.dumps(dict(seed='0x5090131', objective='estimated paired logic operations plus mask loads', baseline=dict(score=score(routed(tuple(range(8)))), word_swaps=len(operations(routed(tuple(range(8)))))), selected=chosen, search=results), indent=2)+'\n')
    print('PASS: three circuits, all 256 basis vectors at powers 3..10; selected', chosen)


if __name__ == '__main__':
    main()
